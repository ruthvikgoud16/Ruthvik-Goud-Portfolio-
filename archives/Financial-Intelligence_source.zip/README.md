# N100 Financial Intelligence Platform

## Overview

The N100 Financial Intelligence Platform is an analytics system for **92 Nifty 100 companies**. It loads organizer-provided financial workbooks into SQLite, computes ratios and screeners, generates reports, and exposes results through an eight-screen Streamlit dashboard and a FastAPI service.

Current delivery status: **PASS-WITH-CAVEATS** (source ROE anomalies, official-rule pros/cons coverage, 10 broad sectors). See `output/DAY45_ACCEPTANCE_GATES.md`, `output/FINAL_PROJECT_DELIVERY_REPORT.md`, and `docs/TEAM_LEAD_SIGNOFF.md`.

## Key Features

- ETL from 12 Excel workbooks into `nifty100.db` with validation and load audits
- Financial ratio engine (profitability, leverage, cash-flow KPIs, fiscal CAGR windows)
- Multi-filter screener with six named presets
- Peer comparison, radar charts, and sector analysis
- Official 12+12 pros/cons rules (no invented generic bullets)
- Cash-flow intelligence, valuation summary, and k-means clustering
- 92 company tearsheets, 10 sector PDFs, and a portfolio summary
- Streamlit dashboard (direct SQLite) and FastAPI (`/api/v1`)

## Architecture

```
Excel sources → ETL (normalize, validate, load) → SQLite nifty100.db
       ↓
 analytics / NLP / screener / reports
       ↓                    ↓
 Streamlit :8501        FastAPI :8000
```

The dashboard reads SQLite directly (`src/dashboard/utils/db.py`). It does not require the API. The API is a separate HTTP surface over the same database.

## Repository Structure

```
src/                  Production code (etl, analytics, nlp, reports, dashboard, api, screener, qa)
tests/                pytest suite (mirrors product areas)
data/                 Notes on runtime data layout (database stays at repo root)
config/               Screener YAML (D-08)
notebooks/            Exploratory SQL (D-04)
output/               Final CSVs, XLSX, and acceptance evidence
reports/              Tearsheets, sector PDFs, portfolio, radar charts, pytest HTML
screenshots/          Dashboard / API captures for GitHub visitors
docs/                 Analyst guide, acceptance checklist, structure guide
project_reference/    Original Bluestock / organizer materials (do not edit)
scripts/              One-off generation helpers
```

Full tree: `docs/REPOSITORY_STRUCTURE.md`.

## Data & Reference Materials

Source workbooks and assignment documents live under `project_reference/` (see `project_reference/README.md`). Runtime SQLite is **`nifty100.db` at the repository root** (gitignored; rebuild with `make load`). Do not treat `project_reference/` as writable application data.

## Installation

Python 3.9+ recommended.

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
# Full local stack (tests, ETL, API, reports):
# pip install -r requirements-dev.txt
cp .env.example .env
export PYTHONPATH=.
```

`.env` holds local paths only (`DB_PATH`, `SOURCE_DATA_DIR`). Optional `FINNHUB_API_KEY` is for the Week-2 demo script, not the platform.

## Database Setup

```bash
make load
```

This reads Excel files from `project_reference/source_data/excel` into `nifty100.db`. Inspect `output/load_audit.csv` and `output/validation_failures.csv`.

If cash-flow rows for ATGL were historically dropped because the workbook ticker is `AGTL`, `src/etl/normaliser.py` maps that alias. Existing databases can be repaired with:

```bash
PYTHONPATH=. python -m src.etl.repair_cashflow_aliases
PYTHONPATH=. python -m src.analytics.capital_allocation
```

## Running the ETL

```bash
make load
make report
```

Loader default: `SOURCE_DATA_DIR=project_reference/source_data/excel`.

## Financial Ratio Engine

Pre-computed ratios are loaded from source; the engine also populates derived metrics used by the dashboard and reports.

```bash
PYTHONPATH=. python -m src.analytics.populate_financial_ratios
```

CAGR uses the latest **annual** fiscal year minus exactly N years (same month). TTM rows (`9999-12`) are not annual endpoints.

## Dashboard

Eight screens, Streamlit, **http://localhost:8501**.

```bash
streamlit run src/dashboard/app.py
# or: make dashboard
```

| Screen | Purpose |
|---|---|
| Home | Market overview KPIs |
| Company Profile | Single-name P&L, balance sheet, cash flow, pros/cons |
| Screener | Metric filters and six presets |
| Peer Comparison | Peer table and radar |
| Trend Analysis | Historical series |
| Sector Analysis | Sector medians and scatter |
| Capital Allocation | Capex / dividends / debt repayment |
| Annual Reports | Links to published reports |

## Screenshots

See [screenshots/README.md](screenshots/README.md).

## Dashboard Screenshots

### Home

[View screenshot](screenshots/dashboard/01_home.png)

### Company Profile

[View screenshot](screenshots/dashboard/02_profile.png)

### Screener

[View screenshot](screenshots/dashboard/03_screener.png)

### Peers

[View screenshot](screenshots/dashboard/04_peers.png)

### Trends

[View screenshot](screenshots/dashboard/05_trends.png)

### Sector

[View screenshot](screenshots/dashboard/06_sector.png)

### Capital Allocation

[View screenshot](screenshots/dashboard/07_capital_allocation.png)

### Reports

[View screenshot](screenshots/dashboard/08_reports.png)

## API

FastAPI on **http://localhost:8000**.

```bash
uvicorn src.api.main:app --port 8000
# or: make api
```

- OpenAPI UI: http://localhost:8000/docs
- Health: `GET /api/v1/health`
- Checked-in spec: `docs/openapi.json`

[API docs screenshot](screenshots/api/01_openapi_docs.png)

## Clustering

```bash
PYTHONPATH=. python -m src.analytics.clustering
```

Outputs: `output/cluster_labels.csv`, `output/cluster_profiles.csv`, `output/outlier_report.csv`, plus `reports/elbow_plot.png` and `reports/correlation_heatmap.png`.

## Reports

```bash
PYTHONPATH=. python -m src.reports.run_batch
PYTHONPATH=. python -m src.nlp.pros_cons_generator
PYTHONPATH=. python -m src.qa.roe_crosswalk
```

| Artifact | Path |
|---|---|
| Tearsheets (D-16) | `reports/tearsheets/<TICKER>_tearsheet.pdf` |
| Sector PDFs (D-17) | `reports/sector/<Sector>_report.pdf` (10 files) |
| Portfolio (D-18) | `reports/portfolio/portfolio_summary.pdf` |
| Radar charts (D-10) | `reports/radar_charts/` |
| Analyst guide (D-22) | `docs/analyst_guide.pdf` |
| Acceptance checklist (D-23) | `docs/acceptance_checklist.pdf` |

## Testing

```bash
PYTHONPATH=. pytest tests/ --html=reports/testing/pytest_report.html -q
PYTHONPATH=. python -m src.qa.run_gates
```

Do not delete older tests to obtain a green run.

## Key Deliverables

| ID | Deliverable | Location |
|---|---|---|
| D-01 | nifty100.db | `nifty100.db` (local, gitignored) |
| D-02 | load_audit.csv | `output/load_audit.csv` (generated on load) |
| D-03 | validation_failures.csv | `output/validation_failures.csv` |
| D-04 | exploratory_queries.sql | `notebooks/exploratory_queries.sql` |
| D-05 | financial_ratios | SQLite `financial_ratios` + source workbook |
| D-06 | capital_allocation.csv | `output/capital_allocation.csv` |
| D-07 | screener_output.xlsx | `output/screener_output.xlsx` |
| D-08 | screener_config.yaml | `config/screener_config.yaml` |
| D-09 | peer comparison | `output/peer_comparison_report.csv` (module writes CSV; not a second copy of Excel) |
| D-10 | radar charts | `reports/radar_charts/` |
| D-11 | Streamlit dashboard | `src/dashboard/app.py` |
| D-12 | valuation_summary.xlsx | `output/valuation_summary.xlsx` |
| D-13 | cashflow_intelligence.xlsx | `output/cashflow_intelligence.xlsx` |
| D-14 | pros_cons_generated.csv | `output/pros_cons_generated.csv` |
| D-15 | analysis_parsed.csv | `output/analysis_parsed.csv` |
| D-16 | company tearsheets | `reports/tearsheets/` |
| D-17 | sector reports | `reports/sector/` |
| D-18 | portfolio summary | `reports/portfolio/portfolio_summary.pdf` |
| D-19 | cluster_labels.csv | `output/cluster_labels.csv` |
| D-20 | FastAPI server | `src/api/main.py` |
| D-21 | pytest report | `reports/testing/pytest_report.html` |
| D-22 | analyst guide | `docs/analyst_guide.pdf` |
| D-23 | acceptance checklist | `docs/acceptance_checklist.pdf` |

Canonical paths (not copies): `output/final/README.md`.

## Known Data Limitations

- **10 broad sectors** in `sectors.xlsx` / `sectors.broad_sector`. Do not invent an 11th. Details: `output/SECTOR_SOURCE_RECONCILIATION.md`.
- **Workbook ROE** (`companies.roe_percentage`) can disagree with engine ROE (example: TCS 0.52 vs ~51%). Engine formula is PAT / (equity_capital + reserves) × 100. See `output/ROE_CROSS_VALIDATION_FINAL.csv`. Do not overwrite the workbook field.
- **Pros/cons** use only the official 12+12 rules with confidence > 60. Names with no qualifying rule are documented, not filled with generic text (`output/D14_PROS_CONS_FINAL_AUDIT.csv`).
- Cash-flow source ticker **`AGTL`** is an alias of **`ATGL`**.
- DIVISLAB has no annual-report URLs (valid empty state).
- Extreme ROE on some capital-goods names is a source denominator issue, not a silent overwrite.

## Acceptance Status

**PASS-WITH-CAVEATS.** Matrix: `output/DAY45_ACCEPTANCE_GATES.md`. Team lead: Ruthvik Goud, `docs/TEAM_LEAD_SIGNOFF.md`.

## Reproducibility

1. Install requirements and copy `.env.example`.
2. `make load` against the Excel files in `project_reference/source_data/excel`.
3. Populate ratios, screener export, NLP, reports, and clustering using the commands above.
4. Run pytest; HTML lands in `reports/testing/pytest_report.html`.
5. Start dashboard and API on ports 8501 and 8000.

Organizer PDFs and workbooks are retained unchanged under `project_reference/`.

## License / Project Information

Academic / internship delivery for the Bluestock N100 assignment. Source financials remain the property of the data provider. This repository does not grant redistribution rights to the original Excel workbooks beyond project use.
