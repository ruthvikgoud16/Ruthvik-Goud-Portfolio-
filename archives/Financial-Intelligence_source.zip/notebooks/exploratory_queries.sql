-- SPRINT 1 EXPLORATORY SQL QUERIES
-- Generated: 2026-08-18
-- Database: nifty100.db
-- All queries tested and executed successfully

-- Query 1: Company Count
-- Result: 92 companies
SELECT COUNT(*) as total_companies FROM companies;

-- Query 2: Sector Distribution
-- Result: 10 sectors, top: Financials (23 companies)
SELECT broad_sector, COUNT(DISTINCT company_id) as count FROM sectors GROUP BY broad_sector ORDER BY count DESC;

-- Query 3: Financial Year Coverage
-- Result: 92 companies, 2011-2024, 41 fiscal years

SELECT 
    COUNT(DISTINCT c.id) as companies_with_pl,
    MIN(CAST(SUBSTR(p.year, 1, 4) AS INTEGER)) as earliest_year,
    MAX(CAST(SUBSTR(p.year, 1, 4) AS INTEGER)) as latest_year,
    COUNT(DISTINCT p.year) as total_fiscal_years
FROM companies c
LEFT JOIN profitandloss p ON c.id = p.company_id
WHERE p.year IS NOT NULL AND p.year != '9999-12';


-- Query 4: Top 5 by Revenue
-- Result: Top: Reliance Industries Ltd
 (899041 Cr)

SELECT c.company_name, p.year, p.sales
FROM companies c
JOIN profitandloss p ON c.id = p.company_id
WHERE p.year = (SELECT MAX(year) FROM profitandloss WHERE company_id = c.id AND year != '9999-12')
ORDER BY p.sales DESC
LIMIT 5;


-- Query 5: Profit Trends
-- Result: 5 years, avg range 1962-12073 Cr

SELECT year, 
       COUNT(*) as companies,
       AVG(net_profit) as avg_profit,
       MAX(net_profit) as max_profit
FROM profitandloss
WHERE year != '9999-12' AND net_profit IS NOT NULL
GROUP BY year
ORDER BY year DESC
LIMIT 5;


-- Query 6: Balance Sheet Assets
-- Result: 91.0 companies, avg 186585 Cr

SELECT COUNT(DISTINCT company_id) as companies,
       AVG(total_assets) as avg_assets,
       MAX(total_assets) as max_assets
FROM balancesheet
WHERE total_assets IS NOT NULL;


-- Query 7: Cash Flow Analysis
-- Result: 91.0 companies, 1054.0 records

SELECT COUNT(DISTINCT company_id) as companies,
       COUNT(*) as records,
       AVG(net_cash_flow) as avg_ncf
FROM cashflow
WHERE net_cash_flow IS NOT NULL;


-- Query 8: Stock Prices
-- Result: 92.0 companies, 5520.0 records

SELECT COUNT(DISTINCT company_id) as companies,
       COUNT(*) as price_records,
       AVG(close_price) as avg_price,
       MAX(close_price) as max_price
FROM stock_prices;


-- Query 9: ROE Distribution
-- Result: 90.0 companies, avg 170.9%

SELECT COUNT(DISTINCT company_id) as companies,
       AVG(return_on_equity_pct) as avg_roe,
       MAX(return_on_equity_pct) as max_roe
FROM financial_ratios
WHERE return_on_equity_pct IS NOT NULL AND return_on_equity_pct > -100;


-- Query 10: Companies <5 Years
-- Result: 1 companies with limited history

SELECT c.id, COUNT(DISTINCT p.year) as pl_years
FROM companies c
LEFT JOIN profitandloss p ON c.id = p.company_id AND p.year != '9999-12'
GROUP BY c.id
HAVING pl_years < 5;


-- Query 11: Table Sizes
-- Result: 5 main tables, 8971 total rows

SELECT 
    'companies' as tbl, COUNT(*) as cnt
FROM companies
UNION ALL
SELECT 'profitandloss', COUNT(*) FROM profitandloss
UNION ALL
SELECT 'balancesheet', COUNT(*) FROM balancesheet
UNION ALL
SELECT 'cashflow', COUNT(*) FROM cashflow
UNION ALL
SELECT 'stock_prices', COUNT(*) FROM stock_prices;


