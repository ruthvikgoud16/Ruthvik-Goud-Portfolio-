#!/usr/bin/env python3
"""
Day 18 — Populate peer_percentiles table
Run peer percentile ranking computation for all companies/years/metrics
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.analytics.peer import PeerPercentile

def main():
    print("="*80)
    print("DAY 18 — PEER PERCENTILE RANKING POPULATION")
    print("="*80)
    
    try:
        pp = PeerPercentile(db_path="nifty100.db")
        
        print("\n[1] Populating peer_percentiles table...")
        stats = pp.populate_peer_percentiles()
        
        print("\n[2] Population Summary:")
        print(f"    Total inserted: {stats['total_inserted']}")
        print(f"    Skipped (no peer): {stats['skipped_no_peer']}")
        print(f"    Skipped (missing value): {stats['skipped_missing_value']}")
        print(f"    Companies with no peer: {len(stats['companies_no_peer'])}")
        if stats['companies_no_peer']:
            print(f"    No-peer companies: {', '.join(stats['companies_no_peer'])}")
        
        if stats['errors']:
            print(f"    Errors: {len(stats['errors'])}")
            for error in stats['errors'][:5]:
                print(f"      - {error}")
        
        print("\n[3] Verifying percentile distribution...")
        verification = pp.verify_percentile_distribution()
        print(f"    Metrics checked: {verification['metrics_checked']}")
        print(f"    Metrics OK: {verification['metrics_ok']}")
        if verification['metrics_issues']:
            print(f"    Metrics with issues: {len(verification['metrics_issues'])}")
            for issue in verification['metrics_issues']:
                print(f"      - {issue}")
        
        print("\n[4] Sample verification (IT Services, latest year)...")
        # Get latest year in database
        import sqlite3
        conn = sqlite3.connect("nifty100.db")
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT year FROM financial_ratios ORDER BY year DESC LIMIT 1")
        latest_year = cursor.fetchone()[0]
        conn.close()
        
        print(f"    Latest year: {latest_year}")
        
        # Get IT Services sample
        it_peers = pp.get_peer_group_summary('IT Services', latest_year, 'ROE')
        if it_peers:
            print(f"    IT Services companies (by ROE percentile):")
            for i, peer in enumerate(it_peers[:3], 1):
                print(f"      {i}. {peer['company_name']}: {peer['metric_value']:.2f}% (rank: {peer['percentile_rank']:.2f})")
        
        print("\n[✓] SUCCESS — Peer percentiles populated")
        pp.close()
        return 0
        
    except Exception as e:
        print(f"\n[✗] ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
