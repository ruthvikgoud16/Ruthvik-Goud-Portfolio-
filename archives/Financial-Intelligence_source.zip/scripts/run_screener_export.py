#!/usr/bin/env python3
"""
Run all 6 preset screeners and export to Excel.

Usage: PYTHONPATH=. python scripts/run_screener_export.py
"""

import logging
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.screener.engine import FilterEngine
from src.screener.exporter import ScreenerExporter

logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def main():
    """Run all 6 presets and export to Excel."""
    
    preset_results = {}
    
    with FilterEngine("nifty100.db") as engine:
        presets = [
            'quality_compounder',
            'value_pick',
            'growth_accelerator',
            'dividend_champion',
            'debt_free_blue_chip',
            'turnaround_watch',
        ]
        
        for preset_name in presets:
            logger.info(f"Running preset: {preset_name}")
            
            try:
                filters = engine.load_preset(preset_name)
                result = engine.apply_filters(filters)
                preset_results[preset_name] = result
                
                logger.info(f"  Result: {len(result)} companies")
                
            except Exception as e:
                logger.error(f"  Failed: {e}")
                preset_results[preset_name] = None
    
    # Export to Excel
    logger.info("\nExporting to Excel...")
    exporter = ScreenerExporter("output/screener_output.xlsx")
    
    # Filter out None results
    valid_results = {k: v for k, v in preset_results.items() if v is not None}
    
    exporter.export_presets(valid_results)
    
    logger.info("\n✓ Export complete: output/screener_output.xlsx")
    
    # Print summary
    print("\n" + "=" * 100)
    print("SCREENER EXPORT SUMMARY")
    print("=" * 100)
    for preset_name, result in preset_results.items():
        count = len(result) if result is not None else 0
        print(f"  {preset_name:25} {count:3} companies")


if __name__ == '__main__':
    main()
