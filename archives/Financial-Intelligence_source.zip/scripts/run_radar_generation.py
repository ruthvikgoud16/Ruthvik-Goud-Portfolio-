#!/usr/bin/env python3
"""
Day 19 — Generate all radar charts
Radar charts for 92 companies: 56 peer group + 36 non-peer with Nifty 100 average
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.analytics.radar import RadarChartGenerator

def main():
    print("="*80)
    print("DAY 19 — RADAR CHART GENERATION")
    print("="*80)
    
    try:
        gen = RadarChartGenerator(db_path="nifty100.db", output_dir="reports/radar_charts")
        
        print("\n[1] Generating radar charts for all companies...")
        stats = gen.generate_all_charts()
        
        print("\n[2] Generation Summary:")
        print(f"    Peer group charts: {stats['peer_group_charts']}")
        print(f"    Non-peer charts: {stats['non_peer_charts']}")
        print(f"    Total charts: {stats['total_charts']}")
        
        if stats['errors']:
            print(f"    Errors: {len(stats['errors'])}")
            for error in stats['errors'][:5]:
                print(f"      - {error}")
        
        print(f"\n[✓] SUCCESS — All radar charts generated")
        print(f"    Output directory: reports/radar_charts/")
        
        gen.close()
        return 0 if stats['total_charts'] > 0 else 1
        
    except Exception as e:
        print(f"\n[✗] ERROR: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        return 1

if __name__ == "__main__":
    sys.exit(main())
