"""Repair source ticker aliases into an already-loaded SQLite database.

Does not rebuild Sprint 1. Inserts only rows whose canonical company_id is
missing from cashflow after AGTL→ATGL (and future aliases) normalization.
"""

from __future__ import annotations

from pathlib import Path
from typing import List

import pandas as pd

from src.analytics.company_panel import PROJECT_ROOT, connect
from src.etl.normaliser import SOURCE_COMPANY_ID_ALIASES, normalize_ticker, normalize_year

SOURCE_CASHFLOW = PROJECT_ROOT / "project_reference" / "source_data" / "excel" / "cashflow.xlsx"


def repair_aliased_cashflow_rows(db_path=None, source_xlsx: Path = SOURCE_CASHFLOW) -> List[str]:
    """
    Insert annual cash-flow rows for canonical IDs that the FK filter dropped.

    Returns company_ids that received new rows.
    """
    if not source_xlsx.exists():
        return []
    raw = pd.read_excel(source_xlsx, header=1)
    if "company_id" not in raw.columns:
        return []
    raw = raw.copy()
    raw["company_id"] = raw["company_id"].apply(normalize_ticker)
    raw["year"] = raw["year"].apply(normalize_year)
    raw = raw[raw["year"].notna() & raw["company_id"].notna()]
    raw = raw[raw["year"].astype(str).str.startswith("20")]
    raw = raw.drop_duplicates(subset=["company_id", "year"], keep="first")

    conn = connect(db_path)
    try:
        valid = {r[0] for r in conn.execute("SELECT id FROM companies")}
        existing = {
            (r[0], r[1])
            for r in conn.execute("SELECT company_id, year FROM cashflow")
        }
        max_id = conn.execute("SELECT COALESCE(MAX(id), 0) FROM cashflow").fetchone()[0]
        inserted_companies = set()
        next_id = int(max_id) + 1
        for _, row in raw.iterrows():
            cid = row["company_id"]
            year = str(row["year"])
            if cid not in valid:
                continue
            if (cid, year) in existing:
                continue
            conn.execute(
                """
                INSERT INTO cashflow (
                    id, company_id, year, operating_activity,
                    investing_activity, financing_activity, net_cash_flow
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    next_id,
                    cid,
                    year,
                    None if pd.isna(row.get("operating_activity")) else float(row["operating_activity"]),
                    None if pd.isna(row.get("investing_activity")) else float(row["investing_activity"]),
                    None if pd.isna(row.get("financing_activity")) else float(row["financing_activity"]),
                    None if pd.isna(row.get("net_cash_flow")) else float(row["net_cash_flow"]),
                ),
            )
            existing.add((cid, year))
            inserted_companies.add(cid)
            next_id += 1
        conn.commit()
    finally:
        conn.close()
    return sorted(inserted_companies)
