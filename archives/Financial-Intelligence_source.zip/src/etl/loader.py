"""
Sprint 1 — Data Foundation
Data Loader Module: Excel → SQLite ETL Pipeline

Loads all 12 Bluestock source files into nifty100.db with:
- Data normalization (year/ticker formats)
- Data quality validation
- Foreign key enforcement
- Load auditing
"""

import sqlite3
import pandas as pd
import os
import sys
from pathlib import Path
from typing import Dict, List, Tuple, Optional, Set
from dotenv import load_dotenv
from datetime import datetime

# Add project root to path for imports
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from src.etl.normaliser import normalize_year, normalize_ticker
from src.etl.validator import DataQualityValidator

# Load environment variables
load_dotenv()

# Configuration
DB_PATH = os.getenv('DB_PATH', './nifty100.db')
SOURCE_DATA_DIR = os.getenv('SOURCE_DATA_DIR', 'project_reference/source_data/excel')
OUTPUT_DIR = os.getenv('OUTPUT_DIR', './output')


class DataLoader:
    """
    ETL Loader for Bluestock Nifty 100 Data
    
    Loads 12 source Excel files into SQLite database with:
    - Data normalization (year/ticker formats)
    - Data quality validation
    - Foreign key enforcement
    - Load auditing
    """
    
    def __init__(self, db_path: str = DB_PATH, source_dir: str = SOURCE_DATA_DIR):
        """
        Initialize loader with database connection.
        
        Args:
            db_path: Path to SQLite database file
            source_dir: Directory containing source Excel files
        """
        self.db_path = db_path
        self.source_dir = source_dir
        self.conn: Optional[sqlite3.Connection] = None
        self.load_audit: List[Dict] = []
        self.all_validation_failures: List[pd.DataFrame] = []
        self.validator = DataQualityValidator()
        self.valid_company_ids: Set[str] = set()
    
    def connect(self):
        """Establish database connection (FK enforcement enabled after load)."""
        self.conn = sqlite3.connect(self.db_path)
        # Note: FK enforcement disabled during load to allow any load order
        # Will be enabled during verification
        self.conn.execute("PRAGMA foreign_keys = OFF;")
        self.conn.commit()
        print(f"✓ Connected to database: {self.db_path}")
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            self.conn = None
            print("✓ Database connection closed")
    
    def create_schema(self, schema_path: str = "db/schema.sql"):
        """Create database schema from SQL file."""
        schema_file = os.path.join(project_root, schema_path)
        
        if not os.path.exists(schema_file):
            raise FileNotFoundError(f"Schema file not found: {schema_file}")
        
        with open(schema_file, 'r') as f:
            schema_sql = f.read()
        
        self.conn.executescript(schema_sql)
        self.conn.commit()
        print(f"✓ Schema created from {schema_path}")
    
    def load_table(self, table_name: str, source_file: str, header_row: int = 1,
                   normalize_years: bool = True, expected_rows: Optional[int] = None) -> Dict:
        """
        Load a single table from Excel file.
        
        Args:
            table_name: Target database table name
            source_file: Source Excel filename
            header_row: Excel header row (0 or 1)
            normalize_years: Whether to normalize year columns
            expected_rows: Expected row count for validation
        
        Returns:
            Load audit dictionary
        """
        source_path = os.path.join(self.source_dir, source_file)
        
        print(f"\n→ Loading {table_name} from {source_file}...")
        
        # Read Excel
        try:
            df = pd.read_excel(source_path, header=header_row)
        except Exception as e:
            return {
                'table': table_name,
                'source_file': source_file,
                'expected_rows': expected_rows,
                'loaded_rows': 0,
                'rejected_rows': 0,
                'critical_rejections': 0,
                'warning_rejections': 0,
                'load_status': 'FAILED',
                'reason': f'Excel read error: {str(e)}'
            }
        
        original_count = len(df)
        print(f"  Read {original_count} rows from Excel")
        
        # Normalize company_id (ticker) if present
        if 'company_id' in df.columns:
            df['company_id'] = df['company_id'].apply(normalize_ticker)
            # Filter out rows with invalid company_id (FK validation)
            if self.valid_company_ids:  # Only if companies have been loaded
                before_fk = len(df)
                df = df[df['company_id'].isin(self.valid_company_ids)]
                after_fk = len(df)
                if before_fk != after_fk:
                    print(f"  Filtered out {before_fk - after_fk} rows with invalid company_id (FK)")
        
        # Normalize id (for companies table)
        if table_name == 'companies' and 'id' in df.columns:
            df['id'] = df['id'].apply(normalize_ticker)
        
        # Normalize year columns
        if normalize_years:
            if 'year' in df.columns:
                df['year'] = df['year'].apply(normalize_year)
                # Filter out None values (unparseable year formats)
                before_year_filter = len(df)
                df = df[df['year'].notna()]
                after_year_filter = len(df)
                if before_year_filter != after_year_filter:
                    print(f"  Filtered out {before_year_filter - after_year_filter} rows with unparseable year")
                # NOTE: TTM records ARE KEPT (normalized to 9999-12)
                # TTM represents "Latest available" period and is valid supplementary data
                ttm_count = len(df[df['year'] == '9999-12'])
                if ttm_count > 0:
                    print(f"  Kept {ttm_count} TTM records (normalized to 9999-12 as latest period)")
                # Remove duplicates based on (company_id, year) - keep first occurrence
                # This naturally handles duplicate TTM records
                before_dedup = len(df)
                df = df.drop_duplicates(subset=['company_id', 'year'], keep='first')
                after_dedup = len(df)
                if before_dedup != after_dedup:
                    print(f"  Removed {before_dedup - after_dedup} duplicate (company_id, year) records")
                print(f"  {after_dedup} rows after normalization and deduplication")
            elif 'Year' in df.columns:  # documents.xlsx uses capital Y
                # Normalize year: convert to string and apply normalize_year function
                df['Year'] = df['Year'].apply(lambda x: normalize_year(x) if pd.notna(x) else None)
                # Filter None values
                before_year_filter = len(df)
                df = df[df['Year'].notna()]
                after_year_filter = len(df)
                if before_year_filter != after_year_filter:
                    print(f"  Filtered out {before_year_filter - after_year_filter} rows with null Year")
                # Rename Year to year for consistency with schema
                df = df.rename(columns={'Year': 'year'})
                # Remove duplicates based on (company_id, year) - keep first occurrence
                before_dedup = len(df)
                df = df.drop_duplicates(subset=['company_id', 'year'], keep='first')
                after_dedup = len(df)
                if before_dedup != after_dedup:
                    print(f"  Removed {before_dedup - after_dedup} duplicate (company_id, year) records")
                print(f"  {after_dedup} rows after normalization and deduplication")
        
        # Normalize date columns (e.g., stock_prices has date as YYYY-MM-DD, schema expects YYYY-MM)
        if 'date' in df.columns and table_name == 'stock_prices':
            # Convert YYYY-MM-DD to YYYY-MM
            df['date'] = df['date'].apply(lambda x: str(x)[:7] if pd.notna(x) else None)
            # Remove duplicates based on (company_id, date)
            before_dedup = len(df)
            df = df.drop_duplicates(subset=['company_id', 'date'], keep='first')
            after_dedup = len(df)
            if before_dedup != after_dedup:
                print(f"  Removed {before_dedup - after_dedup} duplicate (company_id, date) records")
        
        # For tables with company_id as unique constraint (analysis, prosandcons)
        if table_name in ['analysis', 'prosandcons']:
            before_dedup = len(df)
            df = df.drop_duplicates(subset=['company_id'], keep='first')
            after_dedup = len(df)
            if before_dedup != after_dedup:
                print(f"  Removed {before_dedup - after_dedup} duplicate company_id records")
        
        # Rename columns to match schema (handle case sensitivity)
        # documents.xlsx has Annual_Report but schema expects annual_report
        if table_name == 'documents' and 'Annual_Report' in df.columns:
            df = df.rename(columns={'Annual_Report': 'annual_report'})
        
        # Run DQ validation
        validation_context = {
            'table_name': table_name,
            'valid_company_ids': self.valid_company_ids,
            'url_validation_enabled': False,  # Disabled by default (too slow for 1,585 URLs)
            'url_timeout': 10
        }
        
        validation_failures = self.validator.validate_all(df, **validation_context)
        
        # Filter CRITICAL failures
        critical_failures = self.validator.get_critical_failures(validation_failures)
        warning_failures = self.validator.get_warning_failures(validation_failures)
        
        # REJECT rows with CRITICAL failures
        # CRITICAL failures are data integrity violations that must be fixed
        if not critical_failures.empty:
            critical_record_ids = set(critical_failures['record_identifier'].unique())
            rows_before_reject = len(df)
            df = df[~df['id'].isin(critical_record_ids)]
            rows_after_reject = len(df)
            rejected_count = rows_before_reject - rows_after_reject
            print(f"  ⚠ Rejected {rejected_count} rows with CRITICAL DQ failures")
        
        # Store validation failures for report
        if not validation_failures.empty:
            self.all_validation_failures.append(validation_failures)
            critical_count = len(critical_failures)
            warning_count = len(warning_failures)
            if critical_count > 0:
                print(f"    CRITICAL failures: {critical_count} (rows rejected)")
            if warning_count > 0:
                print(f"    WARNING issues: {warning_count} (rows loaded)")
        
        # Write to database
        try:
            df.to_sql(table_name, self.conn, if_exists='append', index=False)
            loaded_count = len(df)
            print(f"  ✓ Loaded {loaded_count} rows into {table_name}")
        except Exception as e:
            error_msg = str(e)
            print(f"  ❌ Database insert error: {error_msg}")
            # Try to diagnose the issue
            if 'id' in df.columns:
                print(f"  Debug: DataFrame has {len(df)} rows, columns: {list(df.columns)}")
                print(f"  Debug: Sample data:\n{df.head(2)}")
            
            return {
                'table': table_name,
                'source_file': source_file,
                'expected_rows': expected_rows,
                'loaded_rows': 0,
                'rejected_rows': original_count,
                'critical_rejections': len(critical_failures),
                'warning_rejections': len(warning_failures),
                'load_status': 'FAILED',
                'reason': f'Database insert error: {error_msg}'
            }
        
        # Build audit record
        status = 'SUCCESS'
        reason = ''
        rejected_count = (original_count - len(df)) if 'rejected_count' not in locals() else rejected_count
        
        if len(critical_failures) > 0:
            status = 'PARTIAL'
            reason = f'{len(critical_failures)} CRITICAL validation failures (rejected)'
        
        if expected_rows and loaded_count != expected_rows:
            diff = loaded_count - expected_rows
            if reason:
                reason += f'; '
            reason += f'Expected {expected_rows}, got {loaded_count} (diff {diff:+d})'
        
        if not reason:
            reason = 'All rows loaded successfully'
        
        audit_record = {
            'table': table_name,
            'source_file': source_file,
            'expected_rows': expected_rows if expected_rows else '',
            'loaded_rows': loaded_count,
            'rejected_rows': rejected_count,
            'critical_rejections': len(critical_failures),
            'warning_rejections': len(warning_failures),
            'load_status': status,
            'reason': reason.strip()
        }
        
        return audit_record
    
    def load_all(self):
        """
        Load all 12 source files in correct order.
        
        Load sequence (respecting foreign keys):
        1. companies (master table)
        2. sectors
        3. profitandloss, balancesheet, cashflow, financial_ratios
        4. analysis, documents, prosandcons
        5. stock_prices, market_cap
        6. peer_groups
        """
        print("\n" + "="*70)
        print("STARTING FULL DATA LOAD")
        print("="*70)
        
        # 1. Companies (master table)
        audit = self.load_table('companies', 'companies.xlsx', header_row=1, 
                                normalize_years=False, expected_rows=92)
        self.load_audit.append(audit)
        
        # Load valid company IDs for FK validation
        df_companies = pd.read_sql("SELECT id FROM companies", self.conn)
        self.valid_company_ids = set(df_companies['id'].values)
        print(f"  ✓ Loaded {len(self.valid_company_ids)} company IDs for FK validation")
        
        # 2. Sectors
        audit = self.load_table('sectors', 'sectors.xlsx', header_row=0,
                                normalize_years=False, expected_rows=92)
        self.load_audit.append(audit)
        
        # 3. Financial statements (core data)
        audit = self.load_table('profitandloss', 'profitandloss.xlsx', header_row=1,
                                normalize_years=True, expected_rows=1276)
        self.load_audit.append(audit)
        
        audit = self.load_table('balancesheet', 'balancesheet.xlsx', header_row=1,
                                normalize_years=True, expected_rows=1312)
        self.load_audit.append(audit)
        
        audit = self.load_table('cashflow', 'cashflow.xlsx', header_row=1,
                                normalize_years=True, expected_rows=1187)
        self.load_audit.append(audit)
        
        audit = self.load_table('financial_ratios', 'financial_ratios.xlsx', header_row=0,
                                normalize_years=True, expected_rows=1184)
        self.load_audit.append(audit)
        
        # 4. Supplementary data
        audit = self.load_table('analysis', 'analysis.xlsx', header_row=1,
                                normalize_years=False, expected_rows=None)
        self.load_audit.append(audit)
        
        audit = self.load_table('documents', 'documents.xlsx', header_row=1,
                                normalize_years=True, expected_rows=1585)
        self.load_audit.append(audit)
        
        audit = self.load_table('prosandcons', 'prosandcons.xlsx', header_row=1,
                                normalize_years=False, expected_rows=None)
        self.load_audit.append(audit)
        
        # 5. Market data (SIMULATED)
        audit = self.load_table('stock_prices', 'stock_prices.xlsx', header_row=0,
                                normalize_years=False, expected_rows=5520)
        self.load_audit.append(audit)
        
        audit = self.load_table('market_cap', 'market_cap.xlsx', header_row=0,
                                normalize_years=False, expected_rows=552)
        self.load_audit.append(audit)
        
        # 6. Peer groups
        audit = self.load_table('peer_groups', 'peer_groups.xlsx', header_row=0,
                                normalize_years=False, expected_rows=56)
        self.load_audit.append(audit)
        
        print("\n" + "="*70)
        print("DATA LOAD COMPLETE")
        print("="*70)
    
    def generate_load_audit(self, output_path: str = None):
        """Generate load_audit.csv report."""
        if output_path is None:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            output_path = os.path.join(OUTPUT_DIR, 'load_audit.csv')
        
        df_audit = pd.DataFrame(self.load_audit)
        df_audit.to_csv(output_path, index=False)
        print(f"\n✓ Load audit saved to: {output_path}")
        
        return df_audit
    
    def generate_validation_failures_report(self, output_path: str = None):
        """Generate validation_failures.csv report."""
        if output_path is None:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            output_path = os.path.join(OUTPUT_DIR, 'validation_failures.csv')
        
        if self.all_validation_failures:
            df_failures = pd.concat(self.all_validation_failures, ignore_index=True)
            df_failures.to_csv(output_path, index=False)
            print(f"✓ Validation failures saved to: {output_path}")
            print(f"  Total failures: {len(df_failures)}")
            print(f"  CRITICAL: {len(df_failures[df_failures['severity'] == 'CRITICAL'])}")
            print(f"  WARNING: {len(df_failures[df_failures['severity'] == 'WARNING'])}")
        else:
            # Create empty file
            pd.DataFrame(columns=['rule_id', 'severity', 'table', 'record_identifier', 
                                  'field', 'message', 'value']).to_csv(output_path, index=False)
            print(f"✓ No validation failures (empty report created)")
    
    def verify_database(self):
        """Verify database integrity."""
        print("\n" + "="*70)
        print("DATABASE VERIFICATION")
        print("="*70)
        
        # Count rows in each table
        print("\nRow Counts:")
        for audit in self.load_audit:
            table = audit['table']
            count = pd.read_sql(f"SELECT COUNT(*) as count FROM {table}", self.conn).iloc[0]['count']
            expected = audit.get('expected_rows', '')
            status = '✓' if (not expected or count == expected) else '⚠'
            print(f"  {status} {table}: {count}" + (f" (expected {expected})" if expected else ""))
        
        # FK integrity check
        print("\nForeign Key Check:")
        # Enable FK enforcement for verification
        self.conn.execute("PRAGMA foreign_keys = ON;")
        self.conn.commit()
        fk_check = pd.read_sql("PRAGMA foreign_key_check", self.conn)
        if fk_check.empty:
            print("  ✓ No FK violations (0 rows)")
        else:
            print(f"  ⚠ FK violations found: {len(fk_check)} rows")
            print(fk_check.head(20))
        
        # Companies count
        companies_count = pd.read_sql("SELECT COUNT(*) as count FROM companies", self.conn).iloc[0]['count']
        print(f"\n✓ Companies table: {companies_count} records" + 
              (" (PASS)" if companies_count == 92 else f" (EXPECTED 92, got {companies_count})"))


def main():
    """Main entry point for loader (used by Makefile)."""
    print("="*70)
    print("BLUESTOCK DATA LOADER — SPRINT 1 DATA FOUNDATION")
    print("="*70)
    
    loader = DataLoader()
    
    try:
        # Create database and schema
        loader.connect()
        loader.create_schema()
        
        # Load all data
        loader.load_all()
        
        # Generate reports
        loader.generate_load_audit()
        loader.generate_validation_failures_report()
        
        # Verify
        loader.verify_database()
        
        print("\n" + "="*70)
        print("✓ DATA LOAD SUCCESSFUL")
        print("="*70)
        
    except Exception as e:
        print(f"\n❌ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
    finally:
        loader.close()


if __name__ == "__main__":
    main()
