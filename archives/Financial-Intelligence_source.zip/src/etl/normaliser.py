"""
Sprint 1 — Data Foundation
Normalisation Module: Year and Ticker Standardisation

This module provides functions to normalize inconsistent data formats
across the 12 Bluestock source files.
"""

import re
from datetime import datetime
from typing import Optional, Union


def normalize_year(year_value: Union[str, int, float, None]) -> Optional[str]:
    """
    Normalize year values to ISO 8601 format: "YYYY-MM"
    
    Handles multiple input formats found in Bluestock data:
    - "Mar 2014", "Dec 2012" → "2014-03", "2012-12"
    - "Mar-13", "Mar-14" → "2013-03", "2014-03"
    - 2019, 2020 (integer) → "2019-03", "2020-03" (assume Mar fiscal year-end)
    - "2020-01-01" (ISO date) → "2020-01"
    
    Args:
        year_value: Input year in various formats
    
    Returns:
        Normalized year string in "YYYY-MM" format, or None if invalid
    
    Examples:
        >>> normalize_year("Mar 2014")
        '2014-03'
        >>> normalize_year("Mar-13")
        '2013-03'
        >>> normalize_year(2019)
        '2019-03'
        >>> normalize_year("2020-01-01")
        '2020-01'
    """
    if year_value is None or (isinstance(year_value, float) and year_value != year_value):  # NaN check
        return None
    
    # Convert to string
    year_str = str(year_value).strip()
    
    if not year_str:
        return None
    
    # Month name to number mapping
    month_map = {
        'jan': '01', 'feb': '02', 'mar': '03', 'apr': '04',
        'may': '05', 'jun': '06', 'jul': '07', 'aug': '08',
        'sep': '09', 'oct': '10', 'nov': '11', 'dec': '12'
    }
    
    # Pattern 1: "Mar 2014", "Dec 2012" (month space year)
    # Also handles edge cases like "Mar 2023 15" or "Mar 2016 9m" by taking first two parts
    match = re.match(r'^([A-Za-z]{3})\s+(\d{4})(?:\s+.*)?$', year_str)
    if match:
        month_name, year = match.groups()
        month_num = month_map.get(month_name.lower())
        if month_num:
            return f"{year}-{month_num}"
    
    # Pattern 2: "Mar-13", "Mar-14" (month-YY format)
    match = re.match(r'^([A-Za-z]{3})-(\d{2})$', year_str)
    if match:
        month_name, year_short = match.groups()
        month_num = month_map.get(month_name.lower())
        if month_num:
            # Assume 20XX for years 00-99
            year_full = f"20{year_short}"
            return f"{year_full}-{month_num}"
    
    # Pattern 3: Integer year (2019, 2020) - assume March fiscal year-end
    if year_str.isdigit() and len(year_str) == 4:
        year = int(year_str)
        if 1900 <= year <= 2100:
            return f"{year}-03"  # Default to March
    
    # Pattern 4: ISO date format "2020-01-01"
    match = re.match(r'^(\d{4})-(\d{2})-(\d{2})$', year_str)
    if match:
        year, month, day = match.groups()
        return f"{year}-{month}"
    
    # Pattern 5: "YYYY-MM" already normalized
    match = re.match(r'^(\d{4})-(\d{2})$', year_str)
    if match:
        return year_str
    
    # Pattern 6: "Sep 2024", "September 2024" (full month name)
    match = re.match(r'^([A-Za-z]+)\s+(\d{4})$', year_str)
    if match:
        month_name, year = match.groups()
        # Try first 3 chars of month name
        month_prefix = month_name[:3].lower()
        month_num = month_map.get(month_prefix)
        if month_num:
            return f"{year}-{month_num}"
    
    # Pattern 7: Float representation like "2013.0"
    try:
        year_float = float(year_str)
        if 1900 <= year_float <= 2100:
            year_int = int(year_float)
            return f"{year_int}-03"  # Default to March
    except ValueError:
        pass
    
    # Pattern 8: Four-digit integer string like "2024"
    if year_str.isdigit() and len(year_str) == 4:
        year_int = int(year_str)
        if 1900 <= year_int <= 2100:
            return f"{year_int}-03"  # Default to March
    
    # Pattern 9: Special period indicators
    year_upper = year_str.upper()
    if year_upper in ['TTM', 'LTM']:  # Trailing Twelve Months, Last Twelve Months
        # Use current year as placeholder (or could use None)
        # For Sprint 1, we'll use a placeholder year 9999-12 to indicate TTM
        return "9999-12"
    
    # Unable to normalize
    return None


# Source-file ticker typos that map onto companies.id.
# AGTL appears only in cashflow.xlsx; years match ATGL P&L (Mar 2018–Mar 2024).
SOURCE_COMPANY_ID_ALIASES = {
    "AGTL": "ATGL",
}


def normalize_ticker(ticker_value: Union[str, None]) -> Optional[str]:
    """
    Normalize company ticker/ID to uppercase, trimmed format.
    
    Handles:
    - Leading/trailing whitespace
    - Case inconsistency
    - Special characters (removes non-alphanumeric except underscore and hyphen)
    
    Args:
        ticker_value: Input ticker symbol
    
    Returns:
        Normalized ticker string in uppercase, or None if invalid
    
    Examples:
        >>> normalize_ticker("  tcs  ")
        'TCS'
        >>> normalize_ticker("reliance")
        'RELIANCE'
        >>> normalize_ticker("ADANI-ENT")
        'ADANI-ENT'
        >>> normalize_ticker("")
        None
    """
    if ticker_value is None or (isinstance(ticker_value, float) and ticker_value != ticker_value):  # NaN check
        return None
    
    # Convert to string and strip whitespace
    ticker_str = str(ticker_value).strip()
    
    if not ticker_str:
        return None
    
    # Convert to uppercase
    ticker_upper = ticker_str.upper()
    
    # Remove invalid characters (keep alphanumeric, underscore, hyphen)
    ticker_clean = re.sub(r'[^A-Z0-9_-]', '', ticker_upper)
    
    if not ticker_clean:
        return None

    return SOURCE_COMPANY_ID_ALIASES.get(ticker_clean, ticker_clean)


def validate_normalized_year(year_str: str) -> bool:
    """
    Validate that a year string is in correct normalized format "YYYY-MM".
    
    Special case: 9999-12 is accepted as the TTM (Trailing Twelve Months) period marker.
    
    Args:
        year_str: Year string to validate
    
    Returns:
        True if valid format, False otherwise
    """
    if not year_str:
        return False
    
    # Special case: 9999-12 represents TTM (Trailing Twelve Months)
    if year_str == '9999-12':
        return True
    
    match = re.match(r'^(\d{4})-(\d{2})$', year_str)
    if not match:
        return False
    
    year, month = match.groups()
    year_int = int(year)
    month_int = int(month)
    
    # Validate ranges (allow 1900-9998 for years, excluding 9999 which is reserved for TTM)
    if not (1900 <= year_int <= 9998):
        return False
    if not (1 <= month_int <= 12):
        return False
    
    return True


def extract_year_from_normalized(year_str: str) -> Optional[int]:
    """
    Extract the year component from a normalized "YYYY-MM" string.
    
    Args:
        year_str: Normalized year string in "YYYY-MM" format
    
    Returns:
        Year as integer, or None if invalid
    
    Examples:
        >>> extract_year_from_normalized("2014-03")
        2014
    """
    if not validate_normalized_year(year_str):
        return None
    
    return int(year_str.split('-')[0])


def extract_month_from_normalized(year_str: str) -> Optional[int]:
    """
    Extract the month component from a normalized "YYYY-MM" string.
    
    Args:
        year_str: Normalized year string in "YYYY-MM" format
    
    Returns:
        Month as integer (1-12), or None if invalid
    
    Examples:
        >>> extract_month_from_normalized("2014-03")
        3
    """
    if not validate_normalized_year(year_str):
        return None
    
    return int(year_str.split('-')[1])
