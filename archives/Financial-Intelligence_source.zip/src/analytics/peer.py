"""
Day 18 — Peer Percentile Rankings
Compute PERCENT_RANK for 10 KPIs within 11 peer groups
Handles D/E inversion, missing values, and missing peer group assignments
"""

import sqlite3
from typing import Optional, Dict, List, Tuple
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class PeerPercentile:
    """
    Compute peer percentile rankings for companies within peer groups.
    
    10 Metrics: ROE, ROCE, NPM, D/E (inverted), FCF, PAT CAGR, Revenue CAGR, EPS CAGR, ICR, Asset Turnover
    
    D/E Special Handling:
    - Lower D/E is better, so we compute PERCENT_RANK as (1 - original_rank)
    - This ensures companies with lower D/E get higher percentile scores
    
    Missing Values:
    - If a metric is NULL for a company-year, that company is excluded from that metric's ranking
    - Missing peer group: company gets message "No peer group assigned"
    """
    
    def __init__(self, db_path: str = "nifty100.db"):
        self.db_path = db_path
        self.conn = None
        self._connect()
        
        # 10 metrics: metric_name -> (source_column, is_inverse)
        # is_inverse: True means lower values are better (D/E), so we invert percentile
        self.metrics = {
            'ROE': ('return_on_equity_pct', False),
            'ROCE': (None, False),  # Computed on-the-fly
            'NPM': ('net_profit_margin_pct', False),
            'D/E_inv': ('debt_to_equity', True),  # Inverted: lower is better
            'FCF': ('free_cash_flow_cr', False),
            'PAT_CAGR_5yr': ('pat_cagr_5yr', False),
            'Revenue_CAGR_5yr': ('revenue_cagr_5yr', False),
            'EPS_CAGR_5yr': ('eps_cagr_5yr', False),
            'ICR': ('interest_coverage', False),
            'Asset_Turnover': ('asset_turnover', False),
        }
        
        # 11 peer groups
        self.peer_groups = [
            'Automobiles',
            'Consumer Finance',
            'FMCG',
            'IT Services',
            'Life Insurance',
            'Oil & Gas',
            'Pharmaceuticals',
            'Power & Utilities',
            'Private Banks',
            'Public Sector Banks',
            'Steel',
        ]
    
    def _connect(self):
        """Connect to SQLite database."""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA foreign_keys = ON")
            logger.info(f"Connected to {self.db_path}")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")
    
    def _compute_roce(self, company_id: str, year: str) -> Optional[float]:
        """
        Compute ROCE for a company-year.
        ROCE = EBIT / (Equity + Debt)
        """
        cursor = self.conn.cursor()
        
        cursor.execute("""
            SELECT bs.equity_capital, bs.reserves, bs.total_assets,
                   pl.net_profit, pl.operating_profit, pl.interest, bs.borrowings
            FROM financial_ratios fr
            LEFT JOIN balancesheet bs ON fr.company_id = bs.company_id AND fr.year = bs.year
            LEFT JOIN profitandloss pl ON fr.company_id = pl.company_id AND fr.year = pl.year
            WHERE fr.company_id = ? AND fr.year = ?
        """, (company_id, year))
        
        row = cursor.fetchone()
        if not row:
            return None
        
        try:
            ebit = row[4]  # operating_profit
            equity = (row[0] or 0) + (row[1] or 0)  # equity_capital + reserves
            debt = row[6] or 0  # borrowings
            
            if not ebit or ebit == 0 or (equity + debt) <= 0:
                return None
            
            roce_pct = (ebit / (equity + debt)) * 100
            return roce_pct
        except Exception as e:
            logger.warning(f"Error computing ROCE for {company_id}/{year}: {e}")
            return None
    
    def _get_metric_value(self, company_id: str, year: str, metric_name: str) -> Optional[float]:
        """
        Retrieve metric value for a company-year.
        For ROCE, compute on-the-fly.
        For D/E, return as-is (inversion handled in percentile calculation).
        """
        if metric_name == 'ROCE':
            return self._compute_roce(company_id, year)
        
        # Get from financial_ratios table
        column_name = self.metrics[metric_name][0]
        if not column_name:
            return None
        
        cursor = self.conn.cursor()
        cursor.execute(
            f"SELECT {column_name} FROM financial_ratios WHERE company_id = ? AND year = ?",
            (company_id, year)
        )
        row = cursor.fetchone()
        return row[0] if row else None
    
    def _get_peer_group_for_company(self, company_id: str) -> Optional[str]:
        """Get peer group assignment for a company (returns first match if multiple)."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT peer_group_name FROM peer_groups WHERE company_id = ? LIMIT 1",
            (company_id,)
        )
        row = cursor.fetchone()
        return row[0] if row else None
    
    def _compute_percentile_rank(
        self,
        value: float,
        all_values: List[Tuple[str, float]],
        is_inverse: bool
    ) -> float:
        """
        Compute PERCENT_RANK for a value within a distribution.
        
        PERCENT_RANK = (number of values < current value) / (total values - 1)
        Ranges from 0.0 to 1.0
        
        If is_inverse=True, invert the percentile: 1 - original_rank
        This makes lower values (like D/E) get higher scores.
        """
        if not all_values or len(all_values) == 0:
            return 0.5
        
        # Sort values
        sorted_values = sorted([v for _, v in all_values])
        total = len(sorted_values)
        
        if total == 1:
            return 1.0
        
        # Count values less than current
        less_than = sum(1 for v in sorted_values if v < value)
        rank = less_than / (total - 1)
        
        # Invert if needed (for D/E where lower is better)
        if is_inverse:
            rank = 1.0 - rank
        
        return max(0.0, min(1.0, rank))  # Clamp to [0, 1]
    
    def populate_peer_percentiles(self) -> Dict:
        """
        Populate peer_percentiles table for all companies, years, and metrics.
        
        Returns:
            dict with summary statistics
        """
        cursor = self.conn.cursor()
        stats = {
            'total_inserted': 0,
            'skipped_no_peer': 0,
            'skipped_missing_value': 0,
            'companies_no_peer': set(),
            'errors': [],
        }
        
        # Clear existing data
        cursor.execute("DELETE FROM peer_percentiles")
        self.conn.commit()
        
        # Get all company-year combinations
        cursor.execute("SELECT DISTINCT company_id, year FROM financial_ratios ORDER BY company_id, year")
        company_years = cursor.fetchall()
        
        for company_id, year in company_years:
            # Get peer group for this company
            peer_group = self._get_peer_group_for_company(company_id)
            if not peer_group:
                stats['skipped_no_peer'] += 1
                stats['companies_no_peer'].add(company_id)
                continue
            
            # For each metric, compute percentile rank within peer group
            for metric_name, (_, is_inverse) in self.metrics.items():
                # Get company's metric value
                value = self._get_metric_value(company_id, year, metric_name)
                if value is None:
                    stats['skipped_missing_value'] += 1
                    continue
                
                # Get all values for this metric, peer group, year
                # (excluding NULLs)
                cursor.execute("""
                    SELECT pg.company_id, fr.year
                    FROM peer_groups pg
                    JOIN financial_ratios fr ON pg.company_id = fr.company_id
                    WHERE pg.peer_group_name = ? AND fr.year = ?
                """, (peer_group, year))
                
                peer_company_years = cursor.fetchall()
                all_values = []
                
                for peer_cid, peer_year in peer_company_years:
                    peer_value = self._get_metric_value(peer_cid, peer_year, metric_name)
                    if peer_value is not None:
                        all_values.append((peer_cid, peer_value))
                
                # Compute percentile rank
                percentile_rank = self._compute_percentile_rank(value, all_values, is_inverse)
                
                # Insert into peer_percentiles table
                try:
                    cursor.execute("""
                        INSERT INTO peer_percentiles
                        (company_id, peer_group_name, metric_name, metric_value, percentile_rank, year)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (company_id, peer_group, metric_name, value, percentile_rank, year))
                    stats['total_inserted'] += 1
                except sqlite3.IntegrityError as e:
                    # Duplicate key or constraint violation
                    logger.warning(f"Constraint error for {company_id}/{peer_group}/{metric_name}/{year}: {e}")
                    stats['errors'].append(str(e))
        
        self.conn.commit()
        
        # Convert set to list for JSON serialization
        stats['companies_no_peer'] = sorted(list(stats['companies_no_peer']))
        
        logger.info(f"Peer percentile population complete:")
        logger.info(f"  - Total inserted: {stats['total_inserted']}")
        logger.info(f"  - Skipped (no peer): {stats['skipped_no_peer']}")
        logger.info(f"  - Skipped (missing value): {stats['skipped_missing_value']}")
        logger.info(f"  - Companies with no peer: {len(stats['companies_no_peer'])}")
        
        return stats
    
    def get_company_peer_percentiles(
        self,
        company_id: str,
        peer_group_name: str,
        year: str
    ) -> List[Dict]:
        """
        Retrieve all percentile ranks for a company in a peer group for a specific year.
        
        Returns:
            List of dicts with: metric_name, metric_value, percentile_rank
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT metric_name, metric_value, percentile_rank
            FROM peer_percentiles
            WHERE company_id = ? AND peer_group_name = ? AND year = ?
            ORDER BY metric_name
        """, (company_id, peer_group_name, year))
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'metric_name': row[0],
                'metric_value': row[1],
                'percentile_rank': row[2],
            })
        return results
    
    def get_peer_group_summary(
        self,
        peer_group_name: str,
        year: str,
        metric_name: str
    ) -> List[Dict]:
        """
        Get all companies' percentile ranks for a metric within a peer group-year.
        Used for generating reports and identifying top/bottom performers.
        
        Returns:
            List of dicts sorted by percentile_rank (descending):
            company_id, company_name, metric_value, percentile_rank
        """
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT pp.company_id, c.company_name, pp.metric_value, pp.percentile_rank
            FROM peer_percentiles pp
            JOIN companies c ON pp.company_id = c.id
            WHERE pp.peer_group_name = ? AND pp.year = ? AND pp.metric_name = ?
            ORDER BY pp.percentile_rank DESC
        """, (peer_group_name, year, metric_name))
        
        results = []
        for row in cursor.fetchall():
            results.append({
                'company_id': row[0],
                'company_name': row[1],
                'metric_value': row[2],
                'percentile_rank': row[3],
            })
        return results
    
    def verify_percentile_distribution(self) -> Dict:
        """
        Verify that percentile ranks are correctly distributed.
        Checks that ranks roughly span [0, 1] for each metric.
        """
        cursor = self.conn.cursor()
        
        verification = {
            'metrics_checked': 0,
            'metrics_ok': 0,
            'metrics_issues': [],
        }
        
        for metric_name in self.metrics.keys():
            cursor.execute("""
                SELECT COUNT(*), MIN(percentile_rank), MAX(percentile_rank), AVG(percentile_rank)
                FROM peer_percentiles
                WHERE metric_name = ?
            """, (metric_name,))
            
            row = cursor.fetchone()
            count, min_rank, max_rank, avg_rank = row[0], row[1], row[2], row[3]
            
            verification['metrics_checked'] += 1
            
            # Check if ranks span a reasonable range
            if count > 0:
                if max_rank <= min_rank:
                    verification['metrics_issues'].append(
                        f"{metric_name}: all values identical (min={min_rank}, max={max_rank})"
                    )
                else:
                    verification['metrics_ok'] += 1
                    logger.info(
                        f"{metric_name}: {count} values, range [{min_rank:.2f}, {max_rank:.2f}], avg={avg_rank:.2f}"
                    )
        
        return verification
