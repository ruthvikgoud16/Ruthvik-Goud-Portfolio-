"""
Sprint 2 — Day 12: Full Financial Ratios Table Population

Populate the financial_ratios table with all 17 KPIs for all 92 companies
across all available years using the Day 08–11 implementations.

This script:
1. Adds missing CAGR columns to financial_ratios if needed
2. Queries all necessary source data
3. Computes all KPIs using existing ratio engines
4. Inserts/updates financial_ratios table
5. Reports coverage statistics
"""

import sqlite3
import sys
import logging
from typing import Optional, Dict, List, Tuple

sys.path.insert(0, '.')

from src.analytics.ratios import ProfitabilityRatios, FinancialsSectorBenchmark
from src.analytics.leverage import LeverageRatios
from src.analytics.cagr import CAGREngine, extract_metric_history
from src.analytics.cashflow_kpis import CashFlowKPIs

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class FinancialRatiosPopulator:
    """
    Populate financial_ratios table with all Day 08–11 KPIs.
    """

    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self._ensure_columns()

    def _ensure_columns(self):
        """Add missing CAGR and composite_quality_score columns if needed."""
        cur = self.conn.cursor()
        cur.execute('PRAGMA table_info(financial_ratios)')
        existing_cols = {row[1] for row in cur.fetchall()}

        required_cols = {
            'revenue_cagr_5yr': 'REAL',
            'pat_cagr_5yr': 'REAL',
            'eps_cagr_5yr': 'REAL',
            'composite_quality_score': 'REAL',
        }

        for col_name, col_type in required_cols.items():
            if col_name not in existing_cols:
                logger.info(f'Adding column: {col_name}')
                cur.execute(f'ALTER TABLE financial_ratios ADD COLUMN {col_name} {col_type}')
        
        self.conn.commit()

    def populate(self) -> Dict:
        """
        Main population workflow. Returns statistics.
        Uses LEFT JOINs to include company-years even when BS or CF data is missing.
        """
        cur = self.conn.cursor()

        # Build Financials sector ROCE benchmark
        bm = self._build_financials_benchmark()

        # Get all company-years to populate (P&L as primary, LEFT JOIN BS/CF/Sectors)
        # This includes all P&L records even if Balance Sheet or Cashflow data is missing.
        # NOTE: 9999-12 is TTM (Trailing 12 Months) — legitimate financial data, included here
        cur.execute('''
            SELECT DISTINCT p.company_id, p.year
            FROM profitandloss p
            LEFT JOIN balancesheet b ON p.company_id=b.company_id AND p.year=b.year
            LEFT JOIN cashflow c ON p.company_id=c.company_id AND p.year=c.year
            LEFT JOIN sectors s ON p.company_id=s.company_id
            WHERE s.company_id IS NOT NULL
            ORDER BY p.company_id, p.year
        ''')
        company_years = cur.fetchall()

        logger.info(f'Processing {len(company_years)} company-year combinations')

        # For CAGR, pre-fetch all historical data by company
        company_history = self._build_company_histories()

        inserted = 0
        updated = 0

        for row in company_years:
            company_id = row['company_id']
            year = row['year']

            kpis = self._compute_kpis(
                company_id, year, company_history, bm
            )

            # Check if row exists
            cur.execute(
                'SELECT id FROM financial_ratios WHERE company_id=? AND year=?',
                (company_id, year)
            )
            existing = cur.fetchone()

            if existing:
                # Update
                self._update_row(existing['id'], kpis)
                updated += 1
            else:
                # Insert
                self._insert_row(company_id, year, kpis)
                inserted += 1

        self.conn.commit()
        logger.info(f'Inserted: {inserted}, Updated: {updated}')

        return {
            'inserted': inserted,
            'updated': updated,
            'total': len(company_years),
        }

    def _build_financials_benchmark(self) -> FinancialsSectorBenchmark:
        """Pre-compute Financials sector ROCE benchmark."""
        cur = self.conn.cursor()
        bm = FinancialsSectorBenchmark()

        cur.execute('''
            SELECT p.company_id, p.year,
                   p.operating_profit, p.other_income,
                   b.equity_capital, b.reserves, b.borrowings
            FROM profitandloss p
            JOIN balancesheet b ON p.company_id=b.company_id AND p.year=b.year
            JOIN sectors s ON p.company_id=s.company_id
            WHERE s.broad_sector='Financials'
        ''')

        for r in cur.fetchall():
            ebit = (r['operating_profit'] or 0) + (r['other_income'] or 0)
            roce = ProfitabilityRatios.roce(
                ebit, r['equity_capital'], r['reserves'], r['borrowings']
            )
            bm.add_observation(r['company_id'], r['year'], roce)

        return bm

    def _build_company_histories(self) -> Dict:
        """
        Pre-fetch all historical data for CAGR calculation.
        Returns {company_id: [rows]}.
        Includes TTM (9999-12) data.
        """
        cur = self.conn.cursor()
        cur.execute('''
            SELECT p.company_id, p.year, p.sales, p.net_profit, p.eps,
                   p.operating_profit, c.operating_activity, c.investing_activity,
                   b.equity_capital, b.reserves, b.borrowings
            FROM profitandloss p
            LEFT JOIN cashflow c ON p.company_id=c.company_id AND p.year=c.year
            LEFT JOIN balancesheet b ON p.company_id=b.company_id AND p.year=b.year
            ORDER BY p.company_id, p.year
        ''')

        histories = {}
        for r in cur.fetchall():
            cid = r['company_id']
            if cid not in histories:
                histories[cid] = []
            histories[cid].append(r)

        return histories

    def _compute_kpis(
        self,
        company_id: str,
        year: str,
        company_history: Dict,
        benchmark: FinancialsSectorBenchmark,
    ) -> Dict:
        """Compute all 17 KPIs for a specific company-year.
        
        Uses LEFT JOIN logic: KPIs are calculated only if their required source
        data is available. If Balance Sheet or Cashflow data is missing, only
        KPIs that depend on available data are populated; others are NULL.
        """
        cur = self.conn.cursor()

        # Fetch current year data with LEFT JOINs to allow missing BS/CF
        cur.execute('''
            SELECT p.company_id, p.year, p.sales, p.net_profit, p.eps,
                   p.operating_profit, p.other_income, p.interest, p.dividend_payout,
                   b.equity_capital, b.reserves, b.borrowings, b.investments,
                   b.total_assets,
                   c.operating_activity, c.investing_activity, c.financing_activity,
                   s.broad_sector
            FROM profitandloss p
            LEFT JOIN balancesheet b ON p.company_id=b.company_id AND p.year=b.year
            LEFT JOIN cashflow c ON p.company_id=c.company_id AND p.year=c.year
            LEFT JOIN sectors s ON p.company_id=s.company_id
            WHERE p.company_id=? AND p.year=?
        ''', (company_id, year))

        r = cur.fetchone()
        if not r:
            return {}

        # Day 08: Profitability (requires P&L, always available with LEFT JOIN)
        npm = ProfitabilityRatios.net_profit_margin(r['net_profit'], r['sales'])
        opm = ProfitabilityRatios.operating_profit_margin(
            r['operating_profit'], r['sales']
        )
        ebit = (r['operating_profit'] or 0) + (r['other_income'] or 0)
        
        # ROE requires Balance Sheet data (equity_capital, reserves)
        if r['equity_capital'] is not None or r['reserves'] is not None:
            roe = ProfitabilityRatios.return_on_equity(
                r['net_profit'], r['equity_capital'], r['reserves']
            )
        else:
            roe = None
        
        # ROCE requires Balance Sheet data
        if r['equity_capital'] is not None or r['reserves'] is not None or r['borrowings'] is not None:
            roce = ProfitabilityRatios.roce(
                ebit, r['equity_capital'], r['reserves'], r['borrowings']
            )
        else:
            roce = None

        # Day 09: Leverage & Efficiency (requires Balance Sheet data)
        if r['equity_capital'] is not None or r['reserves'] is not None or r['borrowings'] is not None:
            de = LeverageRatios.debt_to_equity(
                r['borrowings'], r['equity_capital'], r['reserves']
            )
        else:
            de = None
        
        if r['interest'] is not None and r['interest'] > 0:
            icr = LeverageRatios.interest_coverage_ratio(
                r['operating_profit'], r['other_income'], r['interest']
            )
        else:
            icr = None
        
        # Asset Turnover requires Balance Sheet total_assets
        if r['total_assets'] is not None and r['total_assets'] > 0:
            at = LeverageRatios.asset_turnover(r['sales'], r['total_assets'])
        else:
            at = None

        # Day 11: Cash Flow KPIs (requires Cashflow data)
        if r['operating_activity'] is not None or r['investing_activity'] is not None:
            fcf = CashFlowKPIs.free_cash_flow(
                r['operating_activity'], r['investing_activity']
            )
        else:
            fcf = None
        
        if r['investing_activity'] is not None:
            capex = CashFlowKPIs.capex_intensity(
                r['investing_activity'], r['sales']
            )
        else:
            capex = None

        # Day 10: CAGR (uses historical P&L data from pre-fetched company_history)
        hist = company_history.get(company_id, [])
        hist_through = [row for row in hist if str(row['year']) <= str(year)]
        rev_history = extract_metric_history(hist_through, 'sales')
        pat_history = extract_metric_history(hist_through, 'net_profit')
        eps_history = extract_metric_history(hist_through, 'eps')

        rev_cagr_5yr, _ = CAGREngine.cagr(rev_history, 5, 'Revenue')
        pat_cagr_5yr, _ = CAGREngine.cagr(pat_history, 5, 'PAT')
        eps_cagr_5yr, _ = CAGREngine.cagr(eps_history, 5, 'EPS')

        # Dividend Payout Ratio (requires P&L dividend_payout and net_profit)
        if r['dividend_payout'] is not None and r['net_profit'] is not None and r['net_profit'] > 0:
            dividend_payout_ratio_pct = (r['dividend_payout'] / r['net_profit']) * 100
        else:
            dividend_payout_ratio_pct = None

        # Composite Quality Score
        quality_components = []
        if npm is not None:
            quality_components.append(min(npm / 20.0, 1.0))
        if roe is not None:
            quality_components.append(min(roe / 30.0, 1.0))
        if de is not None:
            quality_components.append(max(1.0 - (de / 3.0), 0.0))
        
        composite = (sum(quality_components) / len(quality_components) * 100) if quality_components else None

        return {
            'net_profit_margin_pct': npm,
            'operating_profit_margin_pct': opm,
            'return_on_equity_pct': roe,
            'debt_to_equity': de,
            'interest_coverage': icr,
            'asset_turnover': at,
            'free_cash_flow_cr': fcf,
            'capex_cr': capex,
            'earnings_per_share': r['eps'],
            'book_value_per_share': None,  # Share count not in source schema
            'dividend_payout_ratio_pct': dividend_payout_ratio_pct,
            'total_debt_cr': r['borrowings'],
            'cash_from_operations_cr': r['operating_activity'],
            'revenue_cagr_5yr': rev_cagr_5yr,
            'pat_cagr_5yr': pat_cagr_5yr,
            'eps_cagr_5yr': eps_cagr_5yr,
            'composite_quality_score': composite,
        }

    def _insert_row(self, company_id: str, year: str, kpis: Dict):
        """Insert a new row into financial_ratios."""
        cur = self.conn.cursor()
        cols = ['company_id', 'year'] + list(kpis.keys())
        vals = [company_id, year] + list(kpis.values())
        placeholders = ','.join(['?'] * len(vals))
        col_str = ','.join(cols)

        cur.execute(
            f'INSERT INTO financial_ratios ({col_str}) VALUES ({placeholders})',
            vals
        )

    def _update_row(self, row_id: int, kpis: Dict):
        """Update an existing row in financial_ratios."""
        cur = self.conn.cursor()
        set_clause = ','.join([f'{k}=?' for k in kpis.keys()])
        vals = list(kpis.values()) + [row_id]
        cur.execute(
            f'UPDATE financial_ratios SET {set_clause} WHERE id=?',
            vals
        )

    def close(self):
        """Close database connection."""
        self.conn.close()


if __name__ == '__main__':
    logger.info('Starting Day 12: Full Financial Ratios Population')
    populator = FinancialRatiosPopulator('nifty100.db')
    stats = populator.populate()
    populator.close()
    logger.info(f'Population complete: {stats}')
