"""
Sprint 2 — Day 11: Cash Flow KPIs & Capital Allocation

Implements cash-flow based analytics:
  - Free Cash Flow (FCF)
  - CFO Quality Score (CFO/PAT ratio averaged over 5 years)
  - CapEx Intensity (capital expenditure relative to sales)
  - FCF Conversion Rate (FCF relative to operating profit)
  - 8-pattern Capital Allocation Classifier

All methods are pure static functions — no database access.
Caller provides the necessary financial data.
"""

import logging
from typing import Optional, List, Tuple

logger = logging.getLogger(__name__)


# =========================================================================
# CLASSIFICATION CONSTANTS
# =========================================================================

CFO_QUALITY_HIGH = "High Quality"
CFO_QUALITY_MODERATE = "Moderate"
CFO_QUALITY_ACCRUAL_RISK = "Accrual Risk"

CAPEX_ASSET_LIGHT = "Asset Light"
CAPEX_MODERATE = "Moderate"
CAPEX_CAPITAL_INTENSIVE = "Capital Intensive"

# Capital Allocation Patterns
PATTERN_REINVESTOR = "Reinvestor"
PATTERN_SHAREHOLDER_RETURNS = "Shareholder Returns"
PATTERN_LIQUIDATING_ASSETS = "Liquidating Assets"
PATTERN_DISTRESS_SIGNAL = "Distress Signal"
PATTERN_GROWTH_FUNDED_BY_DEBT = "Growth Funded by Debt"
PATTERN_CASH_ACCUMULATOR = "Cash Accumulator"
PATTERN_PRE_REVENUE = "Pre-Revenue"
PATTERN_MIXED = "Mixed"


# =========================================================================
# FREE CASH FLOW
# =========================================================================

class CashFlowKPIs:
    """
    Compute cash-flow based financial KPIs.

    All methods are static pure functions.
    """

    @staticmethod
    def free_cash_flow(
        operating_activity: Optional[float],
        investing_activity: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Free Cash Flow (FCF).

        Formula: FCF = operating_activity + investing_activity

        Args:
            operating_activity: Cash from operations (₹ Crores)
            investing_activity: Cash from investments (₹ Crores, typically negative)

        Returns:
            FCF in ₹ Crores. Value may be negative (valid; represents cash outflow).
            Returns None if either input is None.

        Edge case:
            Negative FCF is valid and must NOT be rejected.
            Negative FCF typically indicates the company is investing more than it is
            generating from operations (common for growth companies).
        """
        if operating_activity is None or investing_activity is None:
            return None
        return operating_activity + investing_activity

    # =====================================================================
    # CFO QUALITY SCORE
    # =====================================================================

    @staticmethod
    def cfo_quality_ratio(
        operating_activity: Optional[float],
        net_profit: Optional[float],
    ) -> Optional[float]:
        """
        Calculate CFO/PAT ratio for a single period.

        Formula: CFO / PAT

        Args:
            operating_activity: Cash from operations (₹ Crores)
            net_profit:         Net profit / PAT (₹ Crores)

        Returns:
            Ratio (dimensionless), or None if PAT = 0 or any input is None.

        Edge case (mandatory per specification):
            PAT = 0 or None → return None (cannot assess quality)
        """
        if net_profit is None or net_profit == 0:
            return None
        if operating_activity is None:
            return None
        return operating_activity / net_profit

    @staticmethod
    def cfo_quality_score_5yr(
        historical_ratios: List[Optional[float]],
    ) -> Optional[Tuple[float, str]]:
        """
        Calculate 5-year average CFO/PAT ratio and classify.

        Args:
            historical_ratios: List of CFO/PAT ratios (output of cfo_quality_ratio)
                              May contain None values; None values are ignored.

        Returns:
            Tuple: (average_ratio, classification_label)
              - average_ratio: 5-year average of non-None ratios, or None if no valid data
              - classification_label: "High Quality" | "Moderate" | "Accrual Risk" | None

        Classification:
            > 1.0  → High Quality (CFO exceeds PAT; cash generation superior)
            0.5-1.0 → Moderate (CFO reasonable relative to PAT)
            < 0.5  → Accrual Risk (CFO lags PAT; quality concerns)
        """
        valid_ratios = [r for r in historical_ratios if r is not None]
        if not valid_ratios:
            return None, None

        avg_ratio = sum(valid_ratios) / len(valid_ratios)

        if avg_ratio > 1.0:
            classification = CFO_QUALITY_HIGH
        elif avg_ratio >= 0.5:
            classification = CFO_QUALITY_MODERATE
        else:
            classification = CFO_QUALITY_ACCRUAL_RISK

        return avg_ratio, classification

    # =====================================================================
    # CAPEX INTENSITY
    # =====================================================================

    @staticmethod
    def capex_intensity(
        investing_activity: Optional[float],
        sales: Optional[float],
    ) -> Optional[float]:
        """
        Calculate CapEx Intensity ratio.

        Formula: abs(investing_activity) / sales × 100

        Args:
            investing_activity: Cash from investments (₹ Crores; typically negative)
            sales:              Total sales (₹ Crores)

        Returns:
            CapEx Intensity as percentage, or None if sales ≤ 0 or any input is None.

        Interpretation:
            Uses abs(investing_activity) because investment is typically negative in
            sign (cash outflow) but we want the magnitude of capital expenditure
            relative to revenue generation.
        """
        if sales is None or sales <= 0:
            return None
        if investing_activity is None:
            return None
        return (abs(investing_activity) / sales) * 100

    @staticmethod
    def capex_intensity_classification(capex_pct: Optional[float]) -> Optional[str]:
        """
        Classify CapEx Intensity based on percentage.

        Args:
            capex_pct: CapEx Intensity percentage from capex_intensity()

        Returns:
            "Asset Light" | "Moderate" | "Capital Intensive" | None

        Classification:
            < 3%    → Asset Light (minimal capital requirements)
            3-8%    → Moderate (typical for many industries)
            > 8%    → Capital Intensive (infrastructure, utilities, manufacturing)
        """
        if capex_pct is None:
            return None
        if capex_pct < 3.0:
            return CAPEX_ASSET_LIGHT
        elif capex_pct <= 8.0:
            return CAPEX_MODERATE
        else:
            return CAPEX_CAPITAL_INTENSIVE

    # =====================================================================
    # FCF CONVERSION RATE
    # =====================================================================

    @staticmethod
    def fcf_conversion_rate(
        free_cash_flow: Optional[float],
        operating_profit: Optional[float],
    ) -> Optional[float]:
        """
        Calculate FCF Conversion Rate.

        Formula: FCF / operating_profit × 100

        Args:
            free_cash_flow:    Free Cash Flow from free_cash_flow() (₹ Crores)
            operating_profit:  Operating profit / EBIT (₹ Crores)

        Returns:
            Conversion rate as percentage, or None if operating_profit = 0 or
            any input is None.

        Edge case (mandatory per specification):
            operating_profit = 0 or None → return None
        """
        if operating_profit is None or operating_profit == 0:
            return None
        if free_cash_flow is None:
            return None
        return (free_cash_flow / operating_profit) * 100

    # =====================================================================
    # CAPITAL ALLOCATION CLASSIFIER
    # =====================================================================

    @staticmethod
    def _sign(value: Optional[float]) -> Optional[str]:
        """
        Return sign of a value as a string.

        Args:
            value: Numeric value

        Returns:
            "+" if value > 0
            "-" if value < 0
            "0" if value = 0
            None if value is None
        """
        if value is None:
            return None
        if value > 0:
            return "+"
        elif value < 0:
            return "-"
        else:
            return "0"

    @staticmethod
    def capital_allocation_pattern(
        cfo: Optional[float],
        cfi: Optional[float],
        cff: Optional[float],
        cfo_to_pat_ratio: Optional[float],
    ) -> Tuple[str, str, str, str]:
        """
        Classify capital allocation pattern based on cash-flow signs.

        Args:
            cfo:                  Operating cash flow (₹ Crores)
            cfi:                  Investing cash flow (₹ Crores)
            cff:                  Financing cash flow (₹ Crores)
            cfo_to_pat_ratio:     CFO/PAT ratio for distinguishing Reinvestor vs
                                  Shareholder Returns when (+, -, -)

        Returns:
            Tuple: (cfo_sign, cfi_sign, cff_sign, pattern_label)
              - Signs are "+", "-", "0", or None
              - pattern_label is one of the PATTERN_* constants

        The 8 patterns (per specification):
            (+, -, -) + high CFO/PAT → Shareholder Returns
            (+, -, -) otherwise      → Reinvestor
            (+, +, -) → Liquidating Assets
            (-, +, +) → Distress Signal
            (-, -, +) → Growth Funded by Debt
            (+, +, +) → Cash Accumulator
            (-, -, -) → Pre-Revenue
            (+, -, +) → Mixed
            Other combinations → handle gracefully
        """
        cfo_sign = CashFlowKPIs._sign(cfo)
        cfi_sign = CashFlowKPIs._sign(cfi)
        cff_sign = CashFlowKPIs._sign(cff)

        # Pattern matching
        if cfo_sign == "+" and cfi_sign == "-" and cff_sign == "-":
            # Distinguish Reinvestor vs Shareholder Returns
            # High CFO/PAT (> 1.0) suggests quality earnings driving returns
            if cfo_to_pat_ratio is not None and cfo_to_pat_ratio > 1.0:
                pattern = PATTERN_SHAREHOLDER_RETURNS
            else:
                pattern = PATTERN_REINVESTOR

        elif cfo_sign == "+" and cfi_sign == "+" and cff_sign == "-":
            pattern = PATTERN_LIQUIDATING_ASSETS

        elif cfo_sign == "-" and cfi_sign == "+" and cff_sign == "+":
            pattern = PATTERN_DISTRESS_SIGNAL

        elif cfo_sign == "-" and cfi_sign == "-" and cff_sign == "+":
            pattern = PATTERN_GROWTH_FUNDED_BY_DEBT

        elif cfo_sign == "+" and cfi_sign == "+" and cff_sign == "+":
            pattern = PATTERN_CASH_ACCUMULATOR

        elif cfo_sign == "-" and cfi_sign == "-" and cff_sign == "-":
            pattern = PATTERN_PRE_REVENUE

        elif cfo_sign == "+" and cfi_sign == "-" and cff_sign == "+":
            pattern = PATTERN_MIXED

        else:
            # Unspecified combination; default to Mixed or Unknown
            pattern = f"Other ({cfo_sign},{cfi_sign},{cff_sign})"

        return cfo_sign, cfi_sign, cff_sign, pattern

    @staticmethod
    def compute_all_cashflow_kpis(
        operating_activity: Optional[float],
        investing_activity: Optional[float],
        financing_activity: Optional[float],
        sales: Optional[float],
        operating_profit: Optional[float],
        net_profit: Optional[float],
        cfo_to_pat_historical: Optional[List[Optional[float]]] = None,
    ) -> dict:
        """
        Compute all Day 11 cash-flow KPIs in a single call.

        Args:
            operating_activity: CFO (₹ Crores)
            investing_activity: CFI (₹ Crores)
            financing_activity: CFF (₹ Crores)
            sales:              Total sales (₹ Crores)
            operating_profit:   Operating profit (₹ Crores)
            net_profit:         Net profit (₹ Crores)
            cfo_to_pat_historical: List of CFO/PAT ratios for 5yr averaging (optional)

        Returns:
            Dictionary with keys:
              - free_cash_flow: FCF in ₹ Cr
              - cfo_quality_5yr: (avg_ratio | None, classification | None)
              - capex_intensity_pct: CapEx as % of sales
              - capex_intensity_label: "Asset Light" | "Moderate" | "Capital Intensive" | None
              - fcf_conversion_rate: FCF / operating_profit × 100
              - capital_allocation_pattern: (cfo_sign, cfi_sign, cff_sign, pattern_label)
        """
        fcf = CashFlowKPIs.free_cash_flow(operating_activity, investing_activity)
        cfo_quality = CashFlowKPIs.cfo_quality_score_5yr(
            cfo_to_pat_historical or []
        )
        capex_pct = CashFlowKPIs.capex_intensity(investing_activity, sales)
        capex_label = CashFlowKPIs.capex_intensity_classification(capex_pct)
        fcf_conv = CashFlowKPIs.fcf_conversion_rate(fcf, operating_profit)

        # For capital allocation, compute current CFO/PAT ratio
        current_cfo_pat = CashFlowKPIs.cfo_quality_ratio(
            operating_activity, net_profit
        )
        pattern_result = CashFlowKPIs.capital_allocation_pattern(
            operating_activity, investing_activity, financing_activity,
            current_cfo_pat
        )

        return {
            "free_cash_flow": fcf,
            "cfo_quality_5yr": cfo_quality,
            "capex_intensity_pct": capex_pct,
            "capex_intensity_label": capex_label,
            "fcf_conversion_rate": fcf_conv,
            "capital_allocation_pattern": pattern_result,
        }

    # =====================================================================
    # DAY 31 — DISTRESS & DELEVERAGING FLAGS
    # =====================================================================

    @staticmethod
    def distress_signal(
        operating_activity: Optional[float],
        financing_activity: Optional[float],
    ) -> bool:
        """
        Flag companies raising financing while operations consume cash.

        Rule: CFO < 0 AND CFF > 0 in the observation year.
        """
        if operating_activity is None or financing_activity is None:
            return False
        return operating_activity < 0 and financing_activity > 0

    @staticmethod
    def deleveraging_flag(
        financing_activity: Optional[float],
        borrowings_latest: Optional[float],
        borrowings_prior: Optional[float],
    ) -> bool:
        """
        Flag companies paying down debt: CFF < 0 AND borrowings declining YoY.
        """
        if financing_activity is None or borrowings_latest is None or borrowings_prior is None:
            return False
        return financing_activity < 0 and borrowings_latest < borrowings_prior
