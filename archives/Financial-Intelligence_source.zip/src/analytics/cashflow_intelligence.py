"""
Sprint 5 Days 31–32 — Cash Flow Intelligence + Capital Allocation Report

Reuses Sprint 2 CashFlowKPIs and CAGREngine. Does not replace verified formulas.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd

from src.analytics.cagr import CAGREngine
from src.analytics.cashflow_kpis import CashFlowKPIs
from src.analytics.company_panel import (
    PROJECT_ROOT,
    connect,
    load_companies_sectors,
    load_ratios_history,
    load_statements,
)
from src.nlp.pros_cons_generator import _finite

OUTPUT_XLSX = PROJECT_ROOT / "output" / "cashflow_intelligence.xlsx"
DISTRESS_CSV = PROJECT_ROOT / "output" / "distress_alerts.csv"
PATTERN_CHANGES_CSV = PROJECT_ROOT / "output" / "pattern_changes.csv"
PATTERN_DIST_CSV = PROJECT_ROOT / "output" / "capital_allocation_distribution.csv"
CAPITAL_CSV = PROJECT_ROOT / "output" / "capital_allocation.csv"

COLUMNS = [
    "company_id",
    "sector",
    "cfo_quality_score",
    "cfo_quality_label",
    "capex_intensity_pct",
    "capex_label",
    "fcf_cagr_5yr",
    "fcf_conversion_pct",
    "distress_flag",
    "deleveraging_flag",
    "capital_allocation_label",
]


def _history_pairs(frame: pd.DataFrame, column: str) -> list:
    pairs = []
    for _, row in frame.iterrows():
        pairs.append((str(row["year"]), _finite(row.get(column))))
    return pairs


def build_intelligence(db_path=None) -> pd.DataFrame:
    conn = connect(db_path)
    try:
        companies = load_companies_sectors(conn)
        ratios = load_ratios_history(conn)
        pl, bs, cf = load_statements(conn)
    finally:
        conn.close()

    rows: List[dict] = []
    alerts: List[dict] = []

    for _, company in companies.iterrows():
        cid = company["company_id"]
        sector = company["broad_sector"]
        cf_co = cf[cf["company_id"] == cid]
        pl_co = pl[pl["company_id"] == cid]
        bs_co = bs[bs["company_id"] == cid]
        ratios_co = ratios[ratios["company_id"] == cid]

        if cf_co.empty:
            rows.append(
                {
                    "company_id": cid,
                    "sector": sector,
                    "cfo_quality_score": None,
                    "cfo_quality_label": None,
                    "capex_intensity_pct": None,
                    "capex_label": None,
                    "fcf_cagr_5yr": None,
                    "fcf_conversion_pct": None,
                    "distress_flag": False,
                    "deleveraging_flag": False,
                    "capital_allocation_label": None,
                }
            )
            continue

        latest_cf = cf_co.iloc[-1]
        latest_pl = pl_co.iloc[-1] if not pl_co.empty else None
        latest_bs = bs_co.iloc[-1] if not bs_co.empty else None
        prior_bs = bs_co.iloc[-2] if len(bs_co) >= 2 else None

        cfo = _finite(latest_cf.get("operating_activity"))
        cfi = _finite(latest_cf.get("investing_activity"))
        cff = _finite(latest_cf.get("financing_activity"))
        sales = _finite(latest_pl.get("sales")) if latest_pl is not None else None
        op = _finite(latest_pl.get("operating_profit")) if latest_pl is not None else None
        pat = _finite(latest_pl.get("net_profit")) if latest_pl is not None else None

        # 5-year CFO/PAT history from overlapping years
        merged = pd.merge(
            cf_co[["year", "operating_activity"]],
            pl_co[["year", "net_profit"]],
            on="year",
            how="inner",
        )
        hist_ratios = [
            CashFlowKPIs.cfo_quality_ratio(_finite(r.operating_activity), _finite(r.net_profit))
            for r in merged.tail(5).itertuples(index=False)
        ]
        quality_score, quality_label = CashFlowKPIs.cfo_quality_score_5yr(hist_ratios)

        capex_pct = CashFlowKPIs.capex_intensity(cfi, sales)
        capex_label = CashFlowKPIs.capex_intensity_classification(capex_pct)
        fcf = CashFlowKPIs.free_cash_flow(cfo, cfi)
        fcf_conv = CashFlowKPIs.fcf_conversion_rate(fcf, op)
        _, _, _, pattern = CashFlowKPIs.capital_allocation_pattern(cfo, cfi, cff, CashFlowKPIs.cfo_quality_ratio(cfo, pat))

        fcf_history = []
        for r in cf_co.itertuples(index=False):
            fcf_history.append(
                (
                    str(r.year),
                    CashFlowKPIs.free_cash_flow(_finite(r.operating_activity), _finite(r.investing_activity)),
                )
            )
        fcf_cagr, _fcf_flag = CAGREngine.cagr(fcf_history, 5, "FCF")

        distress = CashFlowKPIs.distress_signal(cfo, cff)
        borrowings_latest = _finite(latest_bs.get("borrowings")) if latest_bs is not None else None
        borrowings_prior = _finite(prior_bs.get("borrowings")) if prior_bs is not None else None
        deleveraging = CashFlowKPIs.deleveraging_flag(cff, borrowings_latest, borrowings_prior)

        rows.append(
            {
                "company_id": cid,
                "sector": sector,
                "cfo_quality_score": quality_score,
                "cfo_quality_label": quality_label,
                "capex_intensity_pct": capex_pct,
                "capex_label": capex_label,
                "fcf_cagr_5yr": fcf_cagr,
                "fcf_conversion_pct": fcf_conv,
                "distress_flag": bool(distress),
                "deleveraging_flag": bool(deleveraging),
                "capital_allocation_label": pattern,
            }
        )

        if distress:
            alerts.append(
                {
                    "company_id": cid,
                    "sector": sector,
                    "year": latest_cf.get("year"),
                    "cfo": cfo,
                    "cff": cff,
                    "net_profit": pat,
                }
            )

    intel = pd.DataFrame(rows, columns=COLUMNS)
    alerts_df = pd.DataFrame(
        alerts,
        columns=["company_id", "sector", "year", "cfo", "cff", "net_profit"],
    )
    return intel, alerts_df


def verify_capital_allocation_csv(path: Path = CAPITAL_CSV) -> Dict:
    df = pd.read_csv(path)
    companies = set(pd.read_sql_query("SELECT id FROM companies", connect())["id"])
    conn = connect()
    cf = pd.read_sql_query("SELECT company_id, year FROM cashflow", conn)
    conn.close()
    from src.analytics.company_panel import _is_fiscal_year

    cf = cf[cf["year"].map(_is_fiscal_year)]
    latest = (
        df.sort_values(["company_id", "year"])
        .groupby("company_id", as_index=False)
        .tail(1)
    )
    dist = latest["pattern_label"].value_counts().rename_axis("pattern_label").reset_index(name="company_count")
    missing_companies = sorted(companies - set(df["company_id"]))
    return {
        "rows": len(df),
        "companies": df["company_id"].nunique(),
        "missing_companies": missing_companies,
        "latest_distribution": dist,
        "unique_patterns": sorted(df["pattern_label"].dropna().unique().tolist()),
    }


def pattern_changes(path: Path = CAPITAL_CSV) -> pd.DataFrame:
    df = pd.read_csv(path)
    df = df.sort_values(["company_id", "year"])
    records = []
    for cid, grp in df.groupby("company_id"):
        grp = grp.reset_index(drop=True)
        if len(grp) < 2:
            continue
        prev = grp.iloc[-2]
        curr = grp.iloc[-1]
        if prev["pattern_label"] != curr["pattern_label"]:
            records.append(
                {
                    "company_id": cid,
                    "from_year": prev["year"],
                    "to_year": curr["year"],
                    "from_pattern": prev["pattern_label"],
                    "to_pattern": curr["pattern_label"],
                }
            )
    return pd.DataFrame(records)


def write_outputs() -> None:
    from src.analytics.capital_allocation import (
        build_capital_allocation,
        write_capital_allocation,
        write_d06_audit,
    )
    from src.etl.repair_cashflow_aliases import repair_aliased_cashflow_rows

    repaired = repair_aliased_cashflow_rows()
    if repaired:
        print(f"repaired cashflow aliases for {repaired}")

    allocation = build_capital_allocation()
    write_capital_allocation()
    write_d06_audit(allocation)

    intel, alerts = build_intelligence()
    OUTPUT_XLSX.parent.mkdir(parents=True, exist_ok=True)
    intel.to_excel(OUTPUT_XLSX, index=False)
    alerts.to_csv(DISTRESS_CSV, index=False)

    audit = verify_capital_allocation_csv()
    audit["latest_distribution"].to_csv(PATTERN_DIST_CSV, index=False)
    changes = pattern_changes()
    changes.to_csv(PATTERN_CHANGES_CSV, index=False)

    print(f"cashflow_intelligence.xlsx rows={len(intel)}")
    print(f"distress_alerts.csv rows={len(alerts)}")
    print(f"capital_allocation companies={audit['companies']} missing={audit['missing_companies']}")
    print("latest-year pattern distribution:")
    print(audit["latest_distribution"].to_string(index=False))
    print(f"pattern_changes.csv rows={len(changes)}")
    print(f"unique pattern labels in source file: {audit['unique_patterns']}")


if __name__ == "__main__":
    write_outputs()
