"""
Sprint 2 — Day 08: Profitability Ratios Engine

Implements core profitability KPIs:
- Net Profit Margin (NPM)
- Operating Profit Margin (OPM) with source cross-check
- Return on Equity (ROE) with negative equity handling
- Return on Assets (ROA)
- Return on Capital Employed (ROCE)

Financials-sector ROCE Benchmark — ENGINEERING INTERPRETATION
=============================================================
The Sprint 2 specification states:
  "For companies in Financials broad_sector — use sector-relative ROCE benchmark
   instead of absolute threshold."

Status: Mentor clarification was requested but NOT received before this
implementation. The specification defines the REQUIREMENT but does NOT define
the benchmark METHODOLOGY (threshold value, calculation method, or scope).

Engineering interpretation adopted (this is NOT an official benchmark):
  - Benchmark = median of valid (non-None) computed ROCE observations for all
    companies with broad_sector = 'Financials' within the SAME reporting year.
  - Per-year scope was chosen over a global scope because "sector-relative"
    most naturally means comparison within the same reporting period, not
    across different macroeconomic conditions.
  - The benchmark is calculated reproducibly from actual database data.
  - It is used for relative assessment/flagging only.
  - The underlying ROCE formula is NOT modified for Financials companies.
  - This interpretation can be revised when official methodology is provided.

Edge cases:
- Zero/negative denominator → None
- Negative equity → None (not negative ratio)
- Zero capital employed → None (ROCE)
- Financials sector: benchmark flags relative position, formula unchanged
"""

import logging
from statistics import median
from typing import Optional, Tuple, Dict, List

logger = logging.getLogger(__name__)


# =========================================================================
# SECTOR CONSTANTS
# =========================================================================

FINANCIALS_BROAD_SECTOR = "Financials"


# =========================================================================
# OPM CROSS-CHECK TOLERANCE
# =========================================================================

OPM_CROSSCHECK_TOLERANCE_PCT = 1.0  # Log if |computed - source| > 1%


# =========================================================================
# PROFITABILITY RATIOS CLASS
# =========================================================================

class ProfitabilityRatios:
    """
    Compute profitability KPIs from financial statements.

    All methods are pure functions (static) — they accept raw numeric inputs
    and return computed values or None on edge-case failure.  No database
    access occurs inside this class; sector data is passed in from outside.
    """

    # =====================================================================
    # NET PROFIT MARGIN
    # =====================================================================

    @staticmethod
    def net_profit_margin(
        net_profit: Optional[float],
        sales: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Net Profit Margin (NPM).

        Formula: (net_profit / sales) × 100

        Args:
            net_profit: Net profit / PAT (₹ Crores)
            sales:      Total sales / revenue (₹ Crores)

        Returns:
            NPM as percentage, or None if sales ≤ 0 or any input is None.

        Edge case (mandatory per specification):
            sales = 0  → return None
            sales < 0  → return None
        """
        if sales is None or sales <= 0:
            return None
        if net_profit is None:
            return None
        return (net_profit / sales) * 100

    # =====================================================================
    # OPERATING PROFIT MARGIN
    # =====================================================================

    @staticmethod
    def operating_profit_margin(
        operating_profit: Optional[float],
        sales: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Operating Profit Margin (OPM).

        Formula: (operating_profit / sales) × 100

        Args:
            operating_profit: EBIT / operating profit (₹ Crores)
            sales:            Total sales / revenue (₹ Crores)

        Returns:
            OPM as percentage, or None if sales ≤ 0 or any input is None.

        Day 08 requirement — OPM cross-check:
            The caller should pass the source opm_percentage to
            opm_crosscheck() after calling this method.  If the difference
            exceeds OPM_CROSSCHECK_TOLERANCE_PCT, the discrepancy is logged.
            The COMPUTED value is always retained; the source is for audit only.
        """
        if sales is None or sales <= 0:
            return None
        if operating_profit is None:
            return None
        return (operating_profit / sales) * 100

    @staticmethod
    def opm_crosscheck(
        computed_opm: Optional[float],
        source_opm: Optional[float],
        company_id: str = "",
        year: str = "",
    ) -> bool:
        """
        Cross-check computed OPM against source opm_percentage.

        Logs a WARNING if |computed - source| > OPM_CROSSCHECK_TOLERANCE_PCT.

        Args:
            computed_opm: Result of operating_profit_margin()
            source_opm:   opm_percentage from profitandloss table
            company_id:   For logging context
            year:         For logging context

        Returns:
            True  — values match within tolerance (or comparison not possible)
            False — values differ by more than tolerance (discrepancy logged)
        """
        if computed_opm is None or source_opm is None:
            return True  # Cannot compare; treat as pass

        diff = abs(computed_opm - source_opm)
        if diff > OPM_CROSSCHECK_TOLERANCE_PCT:
            logger.warning(
                "OPM cross-check discrepancy | company=%s year=%s "
                "computed=%.4f%% source=%.4f%% diff=%.4f%% "
                "(threshold=%.1f%%) — retaining computed value",
                company_id, year, computed_opm, source_opm, diff,
                OPM_CROSSCHECK_TOLERANCE_PCT,
            )
            return False
        return True

    # =====================================================================
    # RETURN ON EQUITY (ROE)
    # =====================================================================

    @staticmethod
    def return_on_equity(
        net_profit: Optional[float],
        equity_capital: Optional[float],
        reserves: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Return on Equity (ROE).

        Formula: (net_profit / (equity_capital + reserves)) × 100

        Args:
            net_profit:     Net profit / PAT (₹ Crores)
            equity_capital: Equity share capital (₹ Crores)
            reserves:       Reserves and surplus (₹ Crores)

        Returns:
            ROE as percentage, or None if:
            - equity_capital + reserves ≤ 0  (mandatory edge case per spec)
            - any input is None

        Edge case (mandatory per specification):
            equity + reserves ≤ 0 → return None (NOT a negative ratio)
        """
        if net_profit is None:
            return None
        if equity_capital is None or reserves is None:
            return None

        total_equity = equity_capital + reserves
        if total_equity <= 0:
            return None

        return (net_profit / total_equity) * 100

    # =====================================================================
    # RETURN ON ASSETS (ROA)
    # =====================================================================

    @staticmethod
    def return_on_assets(
        net_profit: Optional[float],
        total_assets: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Return on Assets (ROA).

        Formula: (net_profit / total_assets) × 100

        Args:
            net_profit:   Net profit / PAT (₹ Crores)
            total_assets: Total assets (₹ Crores)

        Returns:
            ROA as percentage, or None if total_assets ≤ 0 or any input is None.

        Edge case:
            total_assets = 0  → return None
            total_assets < 0  → return None
        """
        if total_assets is None or total_assets <= 0:
            return None
        if net_profit is None:
            return None
        return (net_profit / total_assets) * 100

    # =====================================================================
    # RETURN ON CAPITAL EMPLOYED (ROCE)
    # =====================================================================

    @staticmethod
    def roce(
        ebit: Optional[float],
        equity_capital: Optional[float],
        reserves: Optional[float],
        borrowings: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Return on Capital Employed (ROCE).

        Formula: (EBIT / (equity_capital + reserves + borrowings)) × 100

        Where EBIT = operating_profit + other_income  (caller responsibility).

        Args:
            ebit:           Earnings Before Interest & Tax (₹ Crores)
            equity_capital: Equity share capital (₹ Crores)
            reserves:       Reserves and surplus (₹ Crores)
            borrowings:     Total borrowings (₹ Crores)

        Returns:
            ROCE as percentage, or None if:
            - capital_employed ≤ 0
            - any input is None

        IMPORTANT — Financials sector carve-out:
            The ROCE formula is IDENTICAL for Financials and non-Financials
            companies.  The sector carve-out affects the benchmark comparison
            only (see FinancialsSectorBenchmark).  Do NOT modify this method
            for Financials companies.
        """
        if ebit is None:
            return None
        if equity_capital is None or reserves is None or borrowings is None:
            return None

        capital_employed = equity_capital + reserves + borrowings
        if capital_employed <= 0:
            return None

        return (ebit / capital_employed) * 100

    # =====================================================================
    # VALIDATION UTILITIES
    # =====================================================================

    @staticmethod
    def validate_inputs(**kwargs) -> Tuple[bool, Optional[str]]:
        """
        Validate that required numeric inputs are provided and non-null.

        Args:
            **kwargs: Named parameters to check

        Returns:
            Tuple: (is_valid, error_message)
        """
        for name, value in kwargs.items():
            if value is None:
                return False, f"Missing required input: {name}"
            if not isinstance(value, (int, float)):
                return False, (
                    f"Invalid type for {name}: expected numeric, "
                    f"got {type(value).__name__}"
                )
        return True, None


# =========================================================================
# FINANCIALS SECTOR BENCHMARK
# =========================================================================

class FinancialsSectorBenchmark:
    """
    Sector-relative ROCE benchmark for Financials-sector companies.

    ENGINEERING INTERPRETATION — NOT AN OFFICIAL BENCHMARK
    -------------------------------------------------------
    Mentor clarification was requested but not received before this
    implementation.  The Sprint 2 specification defines the requirement
    ("use sector-relative ROCE benchmark") but does NOT define:
      - The benchmark value
      - The benchmark calculation methodology
      - Whether the scope should be per-year or global

    Engineering interpretation:
      benchmark(year) = median of all valid computed ROCE values for
      companies with broad_sector = 'Financials' in that same year.

    Rationale for per-year scope:
      "Sector-relative" most naturally means relative to peers in the same
      reporting period.  Mixing years would conflate companies operating in
      different macroeconomic environments (e.g., pre-COVID vs post-COVID
      ROCEs for Indian banks differ materially).

    This class accepts pre-computed ROCE values (computed externally via
    ProfitabilityRatios.roce()) rather than re-computing them, to avoid
    any duplication of formula logic.

    Usage:
        benchmark = FinancialsSectorBenchmark()
        benchmark.add_observation(company_id, year, roce_value)
        ...
        bmark = benchmark.get_benchmark(year)
        is_above = benchmark.is_above_benchmark(roce_value, year)
    """

    def __init__(self) -> None:
        # {year: [roce_value, ...]}
        self._observations: Dict[str, List[float]] = {}

    def add_observation(
        self,
        company_id: str,
        year: str,
        roce_value: Optional[float],
    ) -> None:
        """
        Register a Financials-company ROCE observation for a given year.

        Invalid (None) ROCE values are silently ignored; they do not
        contribute to the benchmark calculation.

        Args:
            company_id:  Company ticker (for traceability)
            year:        Normalized year string (YYYY-MM)
            roce_value:  Computed ROCE (%) — pass None to skip
        """
        if roce_value is None:
            return
        if year not in self._observations:
            self._observations[year] = []
        self._observations[year].append(roce_value)

    def get_benchmark(self, year: str) -> Optional[float]:
        """
        Return the per-year median ROCE benchmark for Financials companies.

        Args:
            year: Normalized year string (YYYY-MM)

        Returns:
            Median ROCE (%) for that year, or None if no valid observations.
        """
        values = self._observations.get(year, [])
        if not values:
            return None
        return median(values)

    def is_above_benchmark(
        self,
        roce_value: Optional[float],
        year: str,
    ) -> Optional[bool]:
        """
        Check whether a Financials company's ROCE is above the sector median.

        Args:
            roce_value: Computed ROCE for the company-year (%)
            year:       Normalized year string (YYYY-MM)

        Returns:
            True  — ROCE > sector median benchmark
            False — ROCE ≤ sector median benchmark
            None  — cannot assess (ROCE is None, or no benchmark for year)
        """
        if roce_value is None:
            return None
        benchmark = self.get_benchmark(year)
        if benchmark is None:
            return None
        return roce_value > benchmark

    def all_benchmarks(self) -> Dict[str, Optional[float]]:
        """
        Return a dict of {year: median_roce} for all years with observations.

        Useful for verification and reporting.
        """
        return {year: self.get_benchmark(year) for year in sorted(self._observations)}

    def observation_count(self, year: str) -> int:
        """Return the number of valid ROCE observations used for a given year."""
        return len(self._observations.get(year, []))

    @staticmethod
    def is_financials_company(broad_sector: Optional[str]) -> bool:
        """
        Return True if the company belongs to the Financials broad sector.

        Args:
            broad_sector: The broad_sector value from the sectors table.

        Returns:
            True if broad_sector == 'Financials' (case-sensitive per DB values).
            False otherwise, including None input.
        """
        return broad_sector == FINANCIALS_BROAD_SECTOR
