"""
Sprint 2 — Day 10: CAGR Engine (Compound Annual Growth Rate)

Implements CAGR calculations for Revenue, PAT (net profit), and EPS across
three observation windows: 3-year, 5-year, and 10-year.

Edge Cases:
  The standard CAGR formula: ((end/start)^(1/n) - 1) × 100
  applies only when both start and end values are positive and non-zero.

  This module handles 6 distinct edge cases:
    1. Positive → Positive (normal CAGR)
    2. Positive → Negative (DECLINE_TO_LOSS)
    3. Negative → Positive (TURNAROUND)
    4. Negative → Negative (BOTH_NEGATIVE)
    5. Zero base or insufficient non-zero values (ZERO_BASE)
    6. Insufficient historical data (INSUFFICIENT)

  Each computed CAGR is accompanied by a separate flag column indicating
  the edge case classification. This allows downstream analytics to filter,
  group, or adjust interpretation based on quality of the CAGR measurement.

Design:
  - Pure functions only — no database access inside this module.
  - Caller provides sorted list of (year, value) tuples.
  - Returns (cagr_pct, flag_label) tuple.
  - All results are independently verifiable from input data.
"""

import logging
from typing import Optional, List, Tuple, Any

logger = logging.getLogger(__name__)


# =========================================================================
# EDGE CASE FLAGS
# =========================================================================

FLAG_NORMAL = "NORMAL"                  # Positive → Positive (standard CAGR)
FLAG_DECLINE_TO_LOSS = "DECLINE_TO_LOSS"  # Positive → Negative
FLAG_TURNAROUND = "TURNAROUND"          # Negative → Positive
FLAG_BOTH_NEGATIVE = "BOTH_NEGATIVE"    # Negative → Negative
FLAG_ZERO_BASE = "ZERO_BASE"            # Zero or insufficient positive values
FLAG_INSUFFICIENT = "INSUFFICIENT"      # Not enough data points for window


# =========================================================================
# CAGR CALCULATION
# =========================================================================

class CAGREngine:
    """
    Compute Compound Annual Growth Rate (CAGR) with comprehensive edge-case
    handling and classification.

    All methods are static pure functions.  The caller is responsible for:
      - Providing sorted (year, value) tuples in chronological order
      - Specifying the observation window (3, 5, 10 years)
      - Interpreting the edge-case flags in results

    No assumptions are made about data quality; all edge cases are handled
    explicitly with descriptive flags for downstream decision-making.
    """

    @staticmethod
    def _validate_and_sort_history(
        history: List[Tuple[str, Optional[float]]],
    ) -> Tuple[bool, Optional[str], List[Tuple[str, float]]]:
        """
        Validate and prepare a history list for CAGR calculation.

        Args:
            history: List of (year_str, value) tuples. Values may be None.

        Returns:
            Tuple: (is_valid, error_msg, cleaned_list)
              - is_valid: True if valid, False otherwise
              - error_msg: Description of validation issue (if invalid)
              - cleaned_list: Non-None (year, value) pairs in sorted order

        Validation rules:
          - Must have at least 1 data point
          - All years must be strings
          - All values must be numeric or None
          - Duplicates removed (last occurrence kept)
        """
        if not history:
            return False, "Empty history list", []

        cleaned = {}
        for year, value in history:
            if not isinstance(year, str):
                return False, f"Invalid year type: {type(year).__name__}", []
            if value is not None and not isinstance(value, (int, float)):
                return False, f"Invalid value type for {year}: {type(value).__name__}", []
            if value is not None:
                cleaned[year] = value

        if not cleaned:
            return False, "No non-None values in history", []

        sorted_history = sorted(cleaned.items(), key=lambda x: x[0])
        return True, None, sorted_history

    @staticmethod
    def cagr(
        history: List[Tuple[str, Optional[float]]],
        window_years: int,
        metric_name: str = "value",
    ) -> Tuple[Optional[float], str]:
        """
        Calculate CAGR over a specified number of years with edge-case handling.

        Args:
            history:       List of (year_str, value) tuples, chronological order.
                           Values may be None; None values are skipped.
            window_years:  Number of years for CAGR window (3, 5, 10, etc.)
            metric_name:   Name of metric for logging (e.g., "Revenue", "PAT", "EPS")

        Returns:
            Tuple: (cagr_pct, flag_label)
              - cagr_pct: CAGR percentage, or None if not computable
              - flag_label: Edge case classification (see FLAG_* constants)

        Rules:
            1. If the exact start fiscal period (end year minus window_years,
               same month, annual rows only; TTM/9999 excluded) is missing
               → (None, FLAG_INSUFFICIENT)
            2. If start = 0 → (None, FLAG_ZERO_BASE)
            3. If start > 0 and end ≥ 0 → normal CAGR formula
               - Returns (cagr, FLAG_NORMAL)
            4. If start > 0 and end < 0 → (None, FLAG_DECLINE_TO_LOSS)
            5. If start < 0 and end > 0 → (None, FLAG_TURNAROUND)
               [Both negative outcomes return None because CAGR is not meaningful;
                the flag indicates the company's trajectory for business understanding]
            6. If start < 0 and end < 0 → (None, FLAG_BOTH_NEGATIVE)

        Edge case rationale:
            - DECLINE_TO_LOSS, TURNAROUND, BOTH_NEGATIVE all return None CAGR
              because the formula ((end/start)^(1/n) - 1) produces mathematically
              invalid or misleading results when start ≤ 0.
            - Flagging allows business users to identify and filter these cases.
        """
        is_valid, error_msg, sorted_history = CAGREngine._validate_and_sort_history(history)
        if not is_valid:
            logger.debug(f"CAGR validation failed for {metric_name}: {error_msg}")
            return None, FLAG_INSUFFICIENT

        endpoints = CAGREngine._window_endpoints(sorted_history, window_years)
        if endpoints is None:
            logger.debug(
                f"CAGR {window_years}yr for {metric_name}: no exact {window_years}-year "
                f"fiscal start for the latest annual period"
            )
            return None, FLAG_INSUFFICIENT

        start_year, start_value, end_year, end_value = endpoints

        # Edge case 1: Zero or negative start value
        if start_value is None or start_value == 0:
            return None, FLAG_ZERO_BASE
        if start_value < 0:
            if end_value is None or end_value == 0:
                return None, FLAG_BOTH_NEGATIVE
            elif end_value < 0:
                return None, FLAG_BOTH_NEGATIVE
            else:  # end_value > 0
                return None, FLAG_TURNAROUND

        # Start is positive; check end value
        if end_value is None or end_value == 0:
            # Treat as zero; indicate decline-to-loss if was negative
            if end_value is None:
                return None, FLAG_INSUFFICIENT
            # end_value = 0, start > 0 → treat as loss
            return None, FLAG_DECLINE_TO_LOSS
        if end_value < 0:
            return None, FLAG_DECLINE_TO_LOSS

        # Normal case: both start and end are positive
        cagr_pct = ((end_value / start_value) ** (1.0 / window_years) - 1.0) * 100.0
        return cagr_pct, FLAG_NORMAL

    @staticmethod
    def compute_all_windows(
        history: List[Tuple[str, Optional[float]]],
        metric_name: str = "value",
    ) -> dict:
        """
        Compute CAGR for 3-year, 5-year, and 10-year windows in a single call.

        Args:
            history:     List of (year_str, value) tuples
            metric_name: Name of metric for logging

        Returns:
            Dictionary with keys:
              - "cagr_3yr": (float | None, flag_str)
              - "cagr_5yr": (float | None, flag_str)
              - "cagr_10yr": (float | None, flag_str)

        Example:
            history = [("2013-03", 100), ("2014-03", 110), ("2015-03", 121), ...]
            result = CAGREngine.compute_all_windows(history, "Revenue")
            # result = {
            #   "cagr_3yr": (3.145, "NORMAL"),
            #   "cagr_5yr": (2.871, "NORMAL"),
            #   "cagr_10yr": (None, "INSUFFICIENT"),
            # }
        """
        return {
            "cagr_3yr": CAGREngine.cagr(history, 3, metric_name),
            "cagr_5yr": CAGREngine.cagr(history, 5, metric_name),
            "cagr_10yr": CAGREngine.cagr(history, 10, metric_name),
        }

    @staticmethod
    def _is_annual_fiscal_year(year: str) -> bool:
        """True for labels like 2024-03. False for TTM / 9999 sentinels."""
        if year is None:
            return False
        text = str(year).strip().upper()
        if not text or "TTM" in text or text.startswith("9999"):
            return False
        parts = text.split("-")
        if len(parts) != 2 or len(parts[0]) != 4 or not parts[0].isdigit():
            return False
        calendar_year = int(parts[0])
        return 1900 <= calendar_year < 2100

    @staticmethod
    def _window_endpoints(
        sorted_history: List[Tuple[str, float]],
        window_years: int,
    ) -> Optional[Tuple[str, float, str, float]]:
        """
        Canonical N-year CAGR endpoints.

        End = latest annual fiscal period (TTM excluded).
        Start = the observation whose year-month is exactly N fiscal years earlier.
        Do not stretch to the first available observation if that start year is missing.
        Intermediate years are not required when both endpoints exist.
        """
        if window_years < 1:
            return None
        annual = [
            (year, value)
            for year, value in sorted_history
            if CAGREngine._is_annual_fiscal_year(year)
        ]
        if len(annual) < 2:
            return None
        end_year, end_value = annual[-1]
        year_part, month_part = end_year.split("-", 1)
        start_year = f"{int(year_part) - window_years}-{month_part}"
        lookup = {year: value for year, value in annual}
        if start_year not in lookup:
            return None
        return start_year, lookup[start_year], end_year, end_value

    @staticmethod
    def classify_trajectory(start_value: Optional[float], end_value: Optional[float]) -> str:
        """
        Return a human-readable trajectory label based on start/end values.

        Useful for summarizing a company's growth pattern independently of
        the CAGR flag.

        Args:
            start_value: Initial value
            end_value:   Final value

        Returns:
            One of: "Strong Growth", "Decline", "Turnaround", "Contraction",
            "Marginal Growth", "Flat", "Unknown"
        """
        if start_value is None or end_value is None:
            return "Unknown"

        if start_value == 0:
            if end_value > 0:
                return "Startup"
            return "Unknown"

        ratio = end_value / start_value

        if start_value > 0 and end_value > 0:
            if ratio > 1.5:
                return "Strong Growth"
            elif ratio > 1.1:
                return "Steady Growth"
            elif ratio >= 1.0:
                return "Marginal Growth"
            elif ratio > 0.8:
                return "Mild Decline"
            else:
                return "Decline"
        elif start_value > 0 and end_value < 0:
            return "Decline to Loss"
        elif start_value < 0 and end_value > 0:
            return "Turnaround"
        elif start_value < 0 and end_value < 0:
            if abs(end_value) < abs(start_value):
                return "Improving Losses"
            else:
                return "Worsening Losses"
        else:
            return "Unknown"


# =========================================================================
# CONVENIENCE: EXTRACT SORTED HISTORY FOR A METRIC
# =========================================================================

def extract_metric_history(
    metric_rows: List[Any],
    metric_key: str,
    year_key: str = "year",
) -> List[Tuple[str, Optional[float]]]:
    """
    Extract and sort a metric's history from a list of row dictionaries or
    sqlite3.Row objects.

    Typical use:
        rows = db.query("SELECT year, sales, ... FROM profitandloss WHERE company_id=?")
        history = extract_metric_history(rows, "sales")
        cagr_3yr, flag = CAGREngine.cagr(history, 3)

    Args:
        metric_rows: List of dictionaries or sqlite3.Row objects with
                     at least year_key and metric_key
        metric_key:  Key to extract (e.g., "sales", "net_profit", "eps")
        year_key:    Key for year string (default: "year")

    Returns:
        List of (year_str, value) tuples, sorted chronologically
    """
    history = []
    for row in metric_rows:
        # Support both dict-like objects and sqlite3.Row
        try:
            year = row[year_key] if isinstance(row, dict) else row[year_key]
            value = row[metric_key] if isinstance(row, dict) else row[metric_key]
        except (KeyError, TypeError):
            try:
                year = row.get(year_key)
                value = row.get(metric_key)
            except AttributeError:
                continue
        if year is not None:
            history.append((year, value))
    return sorted(history, key=lambda x: x[0])
