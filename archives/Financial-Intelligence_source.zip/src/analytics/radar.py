"""
Day 19 — Radar Chart Generation for Peer Group Visualization
Generate polar/radar charts for each company showing 8 key metrics
with peer group average (or Nifty 100 average for non-peer companies) overlay
"""

import sqlite3
import numpy as np
import matplotlib.pyplot as plt
from typing import Optional, Dict, List, Tuple
from pathlib import Path
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class RadarChartGenerator:
    """
    Generate radar charts for companies comparing against peer groups or Nifty 100 average.
    
    8 Metrics (axes):
    1. ROE (Return on Equity) — %
    2. ROCE (Return on Capital Employed) — %
    3. NPM (Net Profit Margin) — %
    4. D/E (Debt-to-Equity) — ratio (inverted for display)
    5. FCF (Free Cash Flow) — ₹ Crores
    6. PAT CAGR 5yr (Net Profit CAGR) — %
    7. Revenue CAGR 5yr — %
    8. Composite Quality Score — 0-100
    
    Each metric is normalized to [0, 100] for radar visualization.
    """
    
    def __init__(self, db_path: str = "nifty100.db", output_dir: str = "reports/radar_charts"):
        self.db_path = db_path
        self.output_dir = Path(output_dir)
        self.conn = None
        self._connect()
        
        # Create output directory if needed
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 8 metrics for radar
        self.metrics = [
            'return_on_equity_pct',
            'ROCE',  # Computed on-the-fly
            'net_profit_margin_pct',
            'debt_to_equity',  # Will be inverted for display
            'free_cash_flow_cr',
            'pat_cagr_5yr',
            'revenue_cagr_5yr',
            'composite_quality_score',
        ]
        
        self.metric_labels = [
            'ROE (%)',
            'ROCE (%)',
            'NPM (%)',
            'D/E',
            'FCF (₹Cr)',
            'PAT CAGR (%)',
            'Rev CAGR (%)',
            'Quality Score',
        ]
        
        # 11 peer groups
        self.peer_groups = [
            'Automobiles', 'Consumer Finance', 'FMCG', 'IT Services', 'Life Insurance',
            'Oil & Gas', 'Pharmaceuticals', 'Power & Utilities', 'Private Banks',
            'Public Sector Banks', 'Steel',
        ]
    
    def _connect(self):
        """Connect to SQLite database."""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            self.conn.execute("PRAGMA foreign_keys = ON")
            logger.info(f"Connected to {self.db_path}")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            logger.info("Database connection closed")
    
    def _compute_roce(self, company_id: str, year: str) -> Optional[float]:
        """Compute ROCE for a company-year."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT bs.equity_capital, bs.reserves, bs.total_assets,
                   pl.net_profit, pl.operating_profit, pl.interest, bs.borrowings
            FROM financial_ratios fr
            LEFT JOIN balancesheet bs ON fr.company_id = bs.company_id AND fr.year = bs.year
            LEFT JOIN profitandloss pl ON fr.company_id = pl.company_id AND fr.year = pl.year
            WHERE fr.company_id = ? AND fr.year = ?
        """, (company_id, year))
        
        row = cursor.fetchone()
        if not row:
            return None
        
        try:
            ebit = row[4]  # operating_profit
            equity = (row[0] or 0) + (row[1] or 0)
            debt = row[6] or 0
            
            if not ebit or (equity + debt) <= 0:
                return None
            
            roce_pct = (ebit / (equity + debt)) * 100
            return roce_pct
        except Exception as e:
            logger.warning(f"Error computing ROCE for {company_id}/{year}: {e}")
            return None
    
    def _get_metric_value(self, company_id: str, year: str, metric: str) -> Optional[float]:
        """Get metric value for a company-year."""
        if metric == 'ROCE':
            return self._compute_roce(company_id, year)
        
        cursor = self.conn.cursor()
        cursor.execute(
            f"SELECT {metric} FROM financial_ratios WHERE company_id = ? AND year = ?",
            (company_id, year)
        )
        row = cursor.fetchone()
        return row[0] if row else None
    
    def _get_latest_year(self, company_id: str) -> Optional[str]:
        """Get latest year for a company (non-TTM if available)."""
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT year FROM financial_ratios 
            WHERE company_id = ? AND year != '9999-12'
            ORDER BY year DESC LIMIT 1
        """, (company_id,))
        row = cursor.fetchone()
        return row[0] if row else None
    
    def _get_peer_group(self, company_id: str) -> Optional[str]:
        """Get peer group for a company."""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT peer_group_name FROM peer_groups WHERE company_id = ? LIMIT 1",
            (company_id,)
        )
        row = cursor.fetchone()
        return row[0] if row else None
    
    def _normalize_values(
        self,
        values: Dict[str, Optional[float]],
        all_values_by_metric: Dict[str, List[float]]
    ) -> Dict[str, float]:
        """
        Normalize metric values to [0, 100] using min-max normalization.
        
        For D/E (lower is better), invert: normalized = 100 - min_max_normalized
        """
        normalized = {}
        
        for i, metric in enumerate(self.metrics):
            value = values.get(metric)
            
            if value is None:
                # Missing value → midpoint
                normalized[metric] = 50.0
                continue
            
            # Invert D/E for display (lower D/E = higher score)
            if metric == 'debt_to_equity':
                value = 1.0 / (1.0 + value)  # Transform to [0, 1]
                value = value * 100  # Scale to [0, 100]
                normalized[metric] = value
                continue
            
            # Min-max normalization for other metrics
            all_vals = all_values_by_metric.get(metric, [])
            if not all_vals or len(all_vals) == 0:
                normalized[metric] = 50.0
                continue
            
            min_val = min(all_vals)
            max_val = max(all_vals)
            
            if min_val == max_val:
                # All values identical
                normalized[metric] = 50.0
            else:
                normalized_val = ((value - min_val) / (max_val - min_val)) * 100
                normalized[metric] = max(0.0, min(100.0, normalized_val))
        
        return normalized
    
    def _get_all_peer_values(
        self,
        peer_group: str,
        year: str
    ) -> Dict[str, List[float]]:
        """Get all metric values for a peer group in a year."""
        cursor = self.conn.cursor()
        
        # Get all companies in peer group
        cursor.execute(
            "SELECT company_id FROM peer_groups WHERE peer_group_name = ?",
            (peer_group,)
        )
        company_ids = [row[0] for row in cursor.fetchall()]
        
        all_values = {metric: [] for metric in self.metrics}
        
        for company_id in company_ids:
            for metric in self.metrics:
                value = self._get_metric_value(company_id, year, metric)
                if value is not None:
                    all_values[metric].append(value)
        
        return all_values
    
    def _get_all_nifty100_values(self, year: str) -> Dict[str, List[float]]:
        """Get all metric values across all 92 companies."""
        cursor = self.conn.cursor()
        cursor.execute("SELECT DISTINCT id FROM companies")
        all_company_ids = [row[0] for row in cursor.fetchall()]
        
        all_values = {metric: [] for metric in self.metrics}
        
        for company_id in all_company_ids:
            for metric in self.metrics:
                value = self._get_metric_value(company_id, year, metric)
                if value is not None:
                    all_values[metric].append(value)
        
        return all_values
    
    def _compute_peer_averages(
        self,
        all_values_by_metric: Dict[str, List[float]]
    ) -> Dict[str, float]:
        """Compute average for each metric from all values."""
        averages = {}
        for metric in self.metrics:
            vals = all_values_by_metric.get(metric, [])
            averages[metric] = np.mean(vals) if vals else None
        return averages
    
    def _plot_radar_chart(
        self,
        company_id: str,
        company_name: str,
        company_values: Dict[str, float],
        peer_avg_values: Optional[Dict[str, float]] = None,
        peer_group_name: Optional[str] = None
    ) -> None:
        """
        Plot and save radar chart.
        
        Args:
            company_id: Company ticker
            company_name: Full company name
            company_values: Normalized metric values for company [0, 100]
            peer_avg_values: Optional normalized peer average values
            peer_group_name: Peer group name (if applicable)
        """
        # Setup figure
        fig = plt.figure(figsize=(10, 10), dpi=100)
        ax = fig.add_subplot(111, projection='polar')
        
        # Number of axes
        num_axes = len(self.metrics)
        angles = np.linspace(0, 2 * np.pi, num_axes, endpoint=False).tolist()
        angles += angles[:1]  # Close the circle
        
        # Prepare values for plotting
        company_vals = [company_values.get(m, 50) for m in self.metrics]
        company_vals += company_vals[:1]
        
        # Plot company radar
        ax.plot(angles, company_vals, 'o-', linewidth=2, label='Company', color='#2E86AB')
        ax.fill(angles, company_vals, alpha=0.25, color='#2E86AB')
        
        # Plot peer average overlay if provided
        if peer_avg_values:
            peer_vals = [peer_avg_values.get(m, 50) for m in self.metrics]
            peer_vals += peer_vals[:1]
            ax.plot(angles, peer_vals, 'o--', linewidth=2, label='Peer Average', color='#A23B72')
        
        # Set axis labels
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(self.metric_labels, size=9)
        
        # Set radial limits
        ax.set_ylim(0, 100)
        ax.set_yticks([20, 40, 60, 80, 100])
        ax.set_yticklabels(['20', '40', '60', '80', '100'], size=8)
        
        # Grid
        ax.grid(True, linestyle='-', alpha=0.3)
        
        # Title and legend
        title = f"{company_name} ({company_id})"
        if peer_group_name:
            title += f"\n{peer_group_name} Peer Group"
        else:
            title += "\n(Nifty 100 Average)"
        
        ax.set_title(title, size=12, weight='bold', pad=20)
        ax.legend(loc='upper right', bbox_to_anchor=(1.2, 1.1))
        
        # Save PNG
        output_path = self.output_dir / f"{company_id}_radar.png"
        fig.savefig(output_path, format='png', bbox_inches='tight', dpi=100)
        plt.close(fig)
        
        logger.info(f"Generated chart: {company_id} → {output_path}")
    
    def generate_peer_group_charts(self, peer_group_name: str) -> int:
        """
        Generate radar charts for all companies in a peer group.
        
        Returns:
            Number of charts generated
        """
        cursor = self.conn.cursor()
        
        # Get latest year
        cursor.execute("SELECT DISTINCT year FROM financial_ratios ORDER BY year DESC LIMIT 1")
        year = cursor.fetchone()[0]
        
        # Get all companies in peer group
        cursor.execute(
            "SELECT company_id FROM peer_groups WHERE peer_group_name = ? ORDER BY company_id",
            (peer_group_name,)
        )
        company_ids = [row[0] for row in cursor.fetchall()]
        
        # Get all values for normalization
        all_peer_values = self._get_all_peer_values(peer_group_name, year)
        peer_averages = self._compute_peer_averages(all_peer_values)
        
        charts_generated = 0
        
        for company_id in company_ids:
            # Get company values
            company_values = {}
            has_data = False
            for metric in self.metrics:
                val = self._get_metric_value(company_id, year, metric)
                company_values[metric] = val
                if val is not None:
                    has_data = True
            
            if not has_data:
                logger.warning(f"Skipping {company_id}: no metric data for {year}")
                continue
            
            # Normalize values
            normalized_company = self._normalize_values(company_values, all_peer_values)
            normalized_peer_avg = self._normalize_values(peer_averages, all_peer_values)
            
            # Get company name
            cursor.execute("SELECT company_name FROM companies WHERE id = ?", (company_id,))
            name_row = cursor.fetchone()
            company_name = name_row[0] if name_row else company_id
            
            # Generate chart
            self._plot_radar_chart(
                company_id=company_id,
                company_name=company_name,
                company_values=normalized_company,
                peer_avg_values=normalized_peer_avg,
                peer_group_name=peer_group_name
            )
            charts_generated += 1
        
        logger.info(f"Generated {charts_generated} charts for {peer_group_name}")
        return charts_generated
    
    def generate_non_peer_charts(self) -> int:
        """
        Generate radar charts for companies not in any peer group.
        Uses Nifty 100 average as comparison baseline.
        
        Returns:
            Number of charts generated
        """
        cursor = self.conn.cursor()
        
        # Get companies without peer group
        cursor.execute("""
            SELECT DISTINCT c.id
            FROM companies c
            WHERE NOT EXISTS (SELECT 1 FROM peer_groups pg WHERE pg.company_id = c.id)
            ORDER BY c.id
        """)
        company_ids = [row[0] for row in cursor.fetchall()]
        
        # Get latest year
        cursor.execute("SELECT DISTINCT year FROM financial_ratios ORDER BY year DESC LIMIT 1")
        year = cursor.fetchone()[0]
        
        # Get all Nifty 100 values for normalization
        all_nifty100_values = self._get_all_nifty100_values(year)
        nifty100_averages = self._compute_peer_averages(all_nifty100_values)
        
        charts_generated = 0
        
        for company_id in company_ids:
            # Get company values
            company_values = {}
            has_data = False
            for metric in self.metrics:
                val = self._get_metric_value(company_id, year, metric)
                company_values[metric] = val
                if val is not None:
                    has_data = True
            
            if not has_data:
                logger.warning(f"Skipping {company_id}: no metric data for {year}")
                continue
            
            # Normalize values
            normalized_company = self._normalize_values(company_values, all_nifty100_values)
            normalized_nifty100_avg = self._normalize_values(nifty100_averages, all_nifty100_values)
            
            # Get company name
            cursor.execute("SELECT company_name FROM companies WHERE id = ?", (company_id,))
            name_row = cursor.fetchone()
            company_name = name_row[0] if name_row else company_id
            
            # Generate chart
            self._plot_radar_chart(
                company_id=company_id,
                company_name=company_name,
                company_values=normalized_company,
                peer_avg_values=normalized_nifty100_avg,
                peer_group_name=None  # Indicates Nifty 100 average used
            )
            charts_generated += 1
        
        logger.info(f"Generated {charts_generated} charts for non-peer companies")
        return charts_generated
    
    def generate_all_charts(self) -> Dict:
        """
        Generate radar charts for all 92 companies (56 peer + 36 non-peer).
        
        Returns:
            Dictionary with generation statistics
        """
        stats = {
            'peer_group_charts': 0,
            'non_peer_charts': 0,
            'total_charts': 0,
            'errors': [],
        }
        
        logger.info("Starting radar chart generation for all companies...")
        
        # Generate peer group charts
        for peer_group in self.peer_groups:
            try:
                count = self.generate_peer_group_charts(peer_group)
                stats['peer_group_charts'] += count
            except Exception as e:
                logger.error(f"Error generating charts for {peer_group}: {e}")
                stats['errors'].append(f"{peer_group}: {str(e)}")
        
        # Generate non-peer charts
        try:
            count = self.generate_non_peer_charts()
            stats['non_peer_charts'] = count
        except Exception as e:
            logger.error(f"Error generating non-peer charts: {e}")
            stats['errors'].append(f"Non-peer: {str(e)}")
        
        stats['total_charts'] = stats['peer_group_charts'] + stats['non_peer_charts']
        
        logger.info(f"Radar chart generation complete:")
        logger.info(f"  - Peer group charts: {stats['peer_group_charts']}")
        logger.info(f"  - Non-peer charts: {stats['non_peer_charts']}")
        logger.info(f"  - Total charts: {stats['total_charts']}")
        if stats['errors']:
            logger.info(f"  - Errors: {len(stats['errors'])}")
        
        return stats
