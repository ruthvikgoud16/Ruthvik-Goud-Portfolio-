"""Sprint 2 D-06 — capital_allocation.csv from annual cash-flow signs."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import pandas as pd

from src.analytics.cashflow_kpis import CashFlowKPIs
from src.analytics.company_panel import PROJECT_ROOT, connect
from src.nlp.pros_cons_generator import _finite

OUTPUT_PATH = PROJECT_ROOT / "output" / "capital_allocation.csv"
AUDIT_PATH = PROJECT_ROOT / "output" / "D06_CAPITAL_ALLOCATION_FINAL_AUDIT.csv"


def build_capital_allocation(db_path: Optional[Path] = None) -> pd.DataFrame:
    conn = connect(db_path)
    cf = pd.read_sql_query(
        """
        SELECT company_id, year, operating_activity, investing_activity, financing_activity
        FROM cashflow
        WHERE year GLOB '20*'
        ORDER BY company_id, year
        """,
        conn,
    )
    pl = pd.read_sql_query(
        """
        SELECT company_id, year, net_profit
        FROM profitandloss
        WHERE year GLOB '20*'
        """,
        conn,
    )
    conn.close()
    merged = cf.merge(pl, on=["company_id", "year"], how="left")
    records = []
    for _, row in merged.iterrows():
        cfo = _finite(row.get("operating_activity"))
        cfi = _finite(row.get("investing_activity"))
        cff = _finite(row.get("financing_activity"))
        pat = _finite(row.get("net_profit"))
        ratio = CashFlowKPIs.cfo_quality_ratio(cfo, pat)
        cfo_s, cfi_s, cff_s, label = CashFlowKPIs.capital_allocation_pattern(cfo, cfi, cff, ratio)
        records.append(
            {
                "company_id": row["company_id"],
                "year": row["year"],
                "cfo_sign": cfo_s,
                "cfi_sign": cfi_s,
                "cff_sign": cff_s,
                "pattern_label": label,
            }
        )
    return pd.DataFrame(records)


def write_capital_allocation(path: Path = OUTPUT_PATH, db_path: Optional[Path] = None) -> Path:
    df = build_capital_allocation(db_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return path


def write_d06_audit(allocation: pd.DataFrame, db_path: Optional[Path] = None, path: Path = AUDIT_PATH) -> Path:
    conn = connect(db_path)
    companies = pd.read_sql_query("SELECT id AS company_id FROM companies ORDER BY id", conn)
    source = pd.read_sql_query(
        "SELECT company_id, year FROM cashflow WHERE year GLOB '20*'",
        conn,
    )
    conn.close()
    rows = []
    for cid in companies["company_id"]:
        src = source[source["company_id"] == cid]
        out = allocation[allocation["company_id"] == cid]
        src_n = int(src["year"].nunique()) if not src.empty else 0
        out_n = int(out["year"].nunique()) if not out.empty else 0
        first = None if src.empty else str(sorted(src["year"].astype(str))[0])
        last = None if src.empty else str(sorted(src["year"].astype(str))[-1])
        if src_n == 0:
            status = "SOURCE_MISSING"
            reason = "No annual cashflow rows in SQLite after source load/alias repair"
        elif out_n == src_n:
            status = "COMPLETE"
            reason = "All source annual cashflow years present in capital_allocation.csv"
        elif out_n < src_n:
            status = "PARTIAL"
            reason = "Output has fewer years than source cashflow"
        else:
            status = "EXTRA"
            reason = "Output has years not in source cashflow"
        rows.append(
            {
                "company_id": cid,
                "ticker": cid,
                "source_year_count": src_n,
                "output_year_count": out_n,
                "first_source_year": first,
                "last_source_year": last,
                "status": status,
                "reason": reason,
            }
        )
    audit = pd.DataFrame(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    audit.to_csv(path, index=False)
    return path
