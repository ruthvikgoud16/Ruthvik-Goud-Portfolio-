"""
Valuation Module - FCF Yield, P/E Analysis, and Overvaluation Flags

This module calculates valuation metrics for the Nifty 100 universe:
- FCF Yield: Free Cash Flow / Market Cap
- Sector Median P/E: 5-year median P/E ratio by sector
- P/E vs Sector Median: Relative valuation comparison
- Flags: Caution (>1.5x), Discount (<0.7x), Fair (otherwise)

Data Sources:
- FCF: financial_ratios.free_cash_flow_cr (Sprint 2 calculation: CFO + CFI)
- Market Cap: market_cap.market_cap_crore
- P/E, P/B, EV/EBITDA: market_cap table
- Sectors: sectors.broad_sector
"""

import sqlite3
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, Tuple
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class ValuationEngine:
    """
    Production-quality valuation calculation engine.
    
    Separates concerns:
    1. Data loading
    2. Period selection
    3. FCF yield calculation
    4. Sector median P/E calculation
    5. P/E comparison calculation
    6. Flag classification
    7. Result assembly
    8. Excel/CSV export
    """
    
    def __init__(self, db_path: str = None):
        """
        Initialize valuation engine.
        
        Args:
            db_path: Path to SQLite database (defaults to project root)
        """
        if db_path is None:
            # Default to project root nifty100.db
            project_root = Path(__file__).parent.parent.parent
            db_path = project_root / 'nifty100.db'
        
        self.db_path = str(db_path)
        self.valuation_df = None
        self.sector_medians = None
        
    def _get_connection(self) -> sqlite3.Connection:
        """Get database connection."""
        return sqlite3.connect(self.db_path)
    
    def load_latest_valuation_data(self) -> pd.DataFrame:
        """
        Load latest valuation data for all companies.
        
        Period Selection Rule:
        - financial_ratios: Use latest year per company (excludes 9999-12 sentinel)
        - market_cap: Use year=2024 (latest calendar year)
        - Matching: financial_ratios 2024-03 corresponds to market_cap 2024
        
        Returns:
            DataFrame with company_id, company_name, sector, FCF, market_cap, P/E, P/B, EV/EBITDA
        """
        logger.info("Loading latest valuation data...")
        
        conn = self._get_connection()
        
        # Query combines latest financial_ratios with market_cap 2024
        query = """
            SELECT 
                c.id as company_id,
                c.company_name,
                s.broad_sector as sector,
                fr.free_cash_flow_cr as fcf_cr,
                mc.market_cap_crore,
                mc.pe_ratio,
                mc.pb_ratio,
                mc.ev_ebitda,
                fr.year as financial_year
            FROM companies c
            JOIN sectors s ON c.id = s.company_id
            LEFT JOIN (
                -- Get latest financial year per company (excludes sentinel)
                SELECT 
                    company_id,
                    year,
                    free_cash_flow_cr,
                    ROW_NUMBER() OVER (PARTITION BY company_id ORDER BY year DESC) as rn
                FROM financial_ratios
                WHERE year != '9999-12'
            ) fr ON c.id = fr.company_id AND fr.rn = 1
            LEFT JOIN market_cap mc ON c.id = mc.company_id AND mc.year = 2024
            ORDER BY c.id
        """
        
        df = pd.read_sql_query(query, conn)
        conn.close()
        
        logger.info(f"Loaded data for {len(df)} companies")
        logger.info(f"Financial years: {df['financial_year'].value_counts().to_dict()}")
        
        return df
    
    def calculate_fcf_yield(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Calculate FCF Yield = (FCF / Market Cap) * 100.
        
        Formula: FCF_yield_pct = (free_cash_flow_cr / market_cap_crore) * 100
        
        Handles:
        - NULL FCF: Returns NULL
        - NULL market cap: Returns NULL
        - Zero market cap: Returns NULL (avoid division by zero)
        - Negative FCF: Preserved (valid for cash-burning companies)
        
        Args:
            df: DataFrame with fcf_cr and market_cap_crore columns
        
        Returns:
            DataFrame with added FCF_yield_pct column
        """
        logger.info("Calculating FCF Yield...")
        
        # Use unrounded values for calculation
        df['FCF_yield_pct'] = np.where(
            (df['fcf_cr'].notna()) & (df['market_cap_crore'].notna()) & (df['market_cap_crore'] > 0),
            (df['fcf_cr'] / df['market_cap_crore']) * 100,
            np.nan
        )
        
        # Log statistics
        valid_yields = df['FCF_yield_pct'].dropna()
        logger.info(f"FCF Yield calculated for {len(valid_yields)}/{len(df)} companies")
        logger.info(f"FCF Yield range: {valid_yields.min():.2f}% to {valid_yields.max():.2f}%")
        logger.info(f"Negative FCF companies: {(df['fcf_cr'] < 0).sum()}")
        
        return df
    
    def load_historical_pe_data(self, years: int = 5) -> pd.DataFrame:
        """
        Load historical P/E data for sector median calculation.
        
        Args:
            years: Number of years for median (default 5: 2020-2024)
        
        Returns:
            DataFrame with company_id, sector, year, pe_ratio
        """
        logger.info(f"Loading {years}-year historical P/E data...")
        
        conn = self._get_connection()
        
        # Get last N years
        latest_year = 2024
        start_year = latest_year - years + 1
        
        query = """
            SELECT 
                c.id as company_id,
                s.broad_sector as sector,
                mc.year,
                mc.pe_ratio
            FROM companies c
            JOIN sectors s ON c.id = s.company_id
            JOIN market_cap mc ON c.id = mc.company_id
            WHERE mc.year BETWEEN ? AND ?
            AND mc.pe_ratio IS NOT NULL
            AND mc.pe_ratio > 0
            ORDER BY c.id, mc.year DESC
        """
        
        df = pd.read_sql_query(query, conn, params=(start_year, latest_year))
        conn.close()
        
        logger.info(f"Loaded {len(df)} company-year P/E observations")
        logger.info(f"Years covered: {sorted(df['year'].unique())}")
        
        return df
    
    def calculate_sector_median_pe(self, historical_pe_df: pd.DataFrame) -> Dict[str, float]:
        """
        Calculate 5-year median P/E for each sector.
        
        Methodology:
        - For each sector, compute median P/E across all company-year observations
        - Uses all available 5-year data (2020-2024)
        - Only positive P/E values included
        
        Args:
            historical_pe_df: DataFrame with sector, year, pe_ratio
        
        Returns:
            Dict mapping sector -> 5yr_median_PE
        """
        logger.info("Calculating sector 5-year median P/E...")
        
        # Group by sector and calculate median across all years
        sector_medians = historical_pe_df.groupby('sector')['pe_ratio'].median().to_dict()
        
        logger.info(f"Calculated medians for {len(sector_medians)} sectors:")
        for sector, median_pe in sorted(sector_medians.items()):
            logger.info(f"  {sector}: {median_pe:.2f}")
        
        return sector_medians
    
    def calculate_pe_comparison(self, df: pd.DataFrame, sector_medians: Dict[str, float]) -> pd.DataFrame:
        """
        Calculate P/E vs Sector Median percentage.
        
        Formula: PE_vs_sector_median_pct = (P/E / 5yr_median_PE - 1) * 100
        
        Handles:
        - NULL P/E: Returns NULL
        - NULL sector median: Returns NULL
        - Zero sector median: Returns NULL (avoid division by zero)
        
        Uses unrounded numerical values for calculation.
        
        Args:
            df: DataFrame with pe_ratio and sector columns
            sector_medians: Dict of sector -> median P/E
        
        Returns:
            DataFrame with added 5yr_median_PE and PE_vs_sector_median_pct columns
        """
        logger.info("Calculating P/E vs Sector Median...")
        
        # Map sector medians
        df['5yr_median_PE'] = df['sector'].map(sector_medians)
        
        # Calculate comparison using unrounded values
        df['PE_vs_sector_median_pct'] = np.where(
            (df['pe_ratio'].notna()) & 
            (df['5yr_median_PE'].notna()) & 
            (df['5yr_median_PE'] > 0),
            ((df['pe_ratio'] / df['5yr_median_PE']) - 1) * 100,
            np.nan
        )
        
        # Log statistics
        valid_comparisons = df['PE_vs_sector_median_pct'].dropna()
        logger.info(f"P/E comparison calculated for {len(valid_comparisons)}/{len(df)} companies")
        logger.info(f"Range: {valid_comparisons.min():.2f}% to {valid_comparisons.max():.2f}%")
        
        return df
    
    def classify_valuation_flag(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Classify companies into Caution/Discount/Fair flags.
        
        Exact Sprint 4 thresholds:
        - Caution: P/E > sector_median × 1.5 (strictly greater than)
        - Discount: P/E < sector_median × 0.7 (strictly less than)
        - Fair: otherwise (including boundaries)
        
        Boundary behavior:
        - P/E exactly = sector_median × 1.5 → Fair
        - P/E exactly = sector_median × 0.7 → Fair
        
        Uses unrounded P/E values for threshold comparison.
        
        Args:
            df: DataFrame with pe_ratio and 5yr_median_PE columns
        
        Returns:
            DataFrame with added flag column
        """
        logger.info("Classifying valuation flags...")
        
        def classify_row(row):
            """Classify a single row."""
            if pd.isna(row['pe_ratio']) or pd.isna(row['5yr_median_PE']):
                return np.nan
            
            threshold_caution = row['5yr_median_PE'] * 1.5
            threshold_discount = row['5yr_median_PE'] * 0.7
            
            # Use strict inequalities per spec
            if row['pe_ratio'] > threshold_caution:
                return 'Caution'
            elif row['pe_ratio'] < threshold_discount:
                return 'Discount'
            else:
                return 'Fair'
        
        df['flag'] = df.apply(classify_row, axis=1)
        
        # Log distribution
        flag_counts = df['flag'].value_counts()
        logger.info(f"Flag distribution:")
        for flag, count in flag_counts.items():
            logger.info(f"  {flag}: {count} companies")
        
        return df
    
    def assemble_valuation_summary(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Assemble final valuation summary with exact required columns.
        
        Required columns (in order):
        1. company_id
        2. company_name
        3. sector
        4. P/E
        5. P/B
        6. EV/EBITDA
        7. FCF_yield_pct
        8. 5yr_median_PE
        9. PE_vs_sector_median_pct
        10. flag
        
        Args:
            df: DataFrame with all calculated fields
        
        Returns:
            DataFrame with exact required columns and formatting
        """
        logger.info("Assembling valuation summary...")
        
        # Select and rename columns to match exact spec
        summary = df[[
            'company_id',
            'company_name',
            'sector',
            'pe_ratio',
            'pb_ratio',
            'ev_ebitda',
            'FCF_yield_pct',
            '5yr_median_PE',
            'PE_vs_sector_median_pct',
            'flag'
        ]].copy()
        
        # Rename to exact output names
        summary.columns = [
            'company_id',
            'company_name',
            'sector',
            'P/E',
            'P/B',
            'EV/EBITDA',
            'FCF_yield_pct',
            '5yr_median_PE',
            'PE_vs_sector_median_pct',
            'flag'
        ]
        
        # Sort by company_id for deterministic output
        summary = summary.sort_values('company_id').reset_index(drop=True)
        
        logger.info(f"Assembled summary for {len(summary)} companies")
        
        return summary
    
    def export_to_excel(self, summary_df: pd.DataFrame, output_path: str):
        """
        Export valuation summary to Excel with formatting.
        
        Features:
        - Freeze header row
        - Format percentages (FCF_yield_pct, PE_vs_sector_median_pct)
        - Format numeric columns
        - Auto-adjust column widths
        
        Args:
            summary_df: Valuation summary DataFrame
            output_path: Path to output Excel file
        """
        logger.info(f"Exporting to Excel: {output_path}")
        
        with pd.ExcelWriter(output_path, engine='openpyxl') as writer:
            summary_df.to_excel(writer, sheet_name='Valuation Summary', index=False)
            
            # Get workbook and worksheet
            workbook = writer.book
            worksheet = writer.sheets['Valuation Summary']
            
            # Freeze header row
            worksheet.freeze_panes = 'A2'
            
            # Format columns
            from openpyxl.styles import numbers
            
            for row in worksheet.iter_rows(min_row=2, max_row=worksheet.max_row):
                # Format P/E, P/B, EV/EBITDA (columns 4, 5, 6) as numbers with 2 decimals
                for cell in [row[3], row[4], row[5]]:
                    cell.number_format = '0.00'
                
                # Format FCF_yield_pct (column 7) as percentage
                row[6].number_format = '0.00'
                
                # Format 5yr_median_PE (column 8) as number
                row[7].number_format = '0.00'
                
                # Format PE_vs_sector_median_pct (column 9) as percentage
                row[8].number_format = '0.00'
            
            # Auto-adjust column widths
            for column in worksheet.columns:
                max_length = 0
                column_letter = column[0].column_letter
                for cell in column:
                    try:
                        if len(str(cell.value)) > max_length:
                            max_length = len(str(cell.value))
                    except:
                        pass
                adjusted_width = min(max_length + 2, 50)
                worksheet.column_dimensions[column_letter].width = adjusted_width
        
        logger.info(f"Excel export complete: {len(summary_df)} rows")
    
    def export_flags_csv(self, summary_df: pd.DataFrame, output_path: str):
        """
        Export Caution and Discount flags to CSV (excludes Fair).
        
        Requirements:
        - Only Caution and Discount companies
        - No Fair companies
        - No index column
        - UTF-8 encoding
        - Deterministic column ordering
        - Values reconcile with Excel output
        
        Args:
            summary_df: Valuation summary DataFrame
            output_path: Path to output CSV file
        """
        logger.info(f"Exporting flags CSV: {output_path}")
        
        # Filter to only Caution and Discount
        flags_df = summary_df[summary_df['flag'].isin(['Caution', 'Discount'])].copy()
        
        logger.info(f"Exporting {len(flags_df)} companies with flags (Caution/Discount only)")
        logger.info(f"  Caution: {(flags_df['flag'] == 'Caution').sum()}")
        logger.info(f"  Discount: {(flags_df['flag'] == 'Discount').sum()}")
        
        # Export to CSV
        flags_df.to_csv(output_path, index=False, encoding='utf-8')
        
        logger.info(f"CSV export complete: {len(flags_df)} rows")
    
    def run_full_valuation(self, output_dir: str = 'output') -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Execute complete valuation analysis pipeline.
        
        Steps:
        1. Load latest valuation data
        2. Calculate FCF yield
        3. Load historical P/E data
        4. Calculate sector median P/E
        5. Calculate P/E comparison
        6. Classify valuation flags
        7. Assemble summary
        8. Export to Excel
        9. Export flags to CSV
        
        Args:
            output_dir: Directory for output files
        
        Returns:
            Tuple of (valuation_summary_df, valuation_flags_df)
        """
        logger.info("=" * 60)
        logger.info("Starting Full Valuation Analysis")
        logger.info("=" * 60)
        
        # Step 1: Load data
        df = self.load_latest_valuation_data()
        
        # Step 2: Calculate FCF yield
        df = self.calculate_fcf_yield(df)
        
        # Step 3-4: Historical P/E and sector medians
        historical_pe_df = self.load_historical_pe_data(years=5)
        sector_medians = self.calculate_sector_median_pe(historical_pe_df)
        self.sector_medians = sector_medians
        
        # Step 5: P/E comparison
        df = self.calculate_pe_comparison(df, sector_medians)
        
        # Step 6: Classify flags
        df = self.classify_valuation_flag(df)
        
        # Step 7: Assemble summary
        summary_df = self.assemble_valuation_summary(df)
        self.valuation_df = summary_df
        
        # Step 8-9: Export outputs
        output_path_excel = Path(output_dir) / 'valuation_summary.xlsx'
        output_path_csv = Path(output_dir) / 'valuation_flags.csv'
        
        self.export_to_excel(summary_df, str(output_path_excel))
        self.export_flags_csv(summary_df, str(output_path_csv))
        
        # Create flags DataFrame for return
        flags_df = summary_df[summary_df['flag'].isin(['Caution', 'Discount'])].copy()
        
        logger.info("=" * 60)
        logger.info("Valuation Analysis Complete")
        logger.info(f"Total companies: {len(summary_df)}")
        logger.info(f"Flagged companies: {len(flags_df)}")
        logger.info("=" * 60)
        
        return summary_df, flags_df


def main():
    """Main execution function."""
    # Initialize engine
    engine = ValuationEngine()
    
    # Run full valuation
    summary_df, flags_df = engine.run_full_valuation()
    
    print("\nValuation Summary Statistics:")
    print(f"Total companies: {len(summary_df)}")
    print(f"\nFlag distribution:")
    print(summary_df['flag'].value_counts())
    print(f"\nOutputs generated:")
    print("  - output/valuation_summary.xlsx")
    print("  - output/valuation_flags.csv")


if __name__ == '__main__':
    main()
