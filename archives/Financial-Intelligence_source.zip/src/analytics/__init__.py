"""
Sprint 2 — Analytics Package
Profitability ratios, leverage ratios, CAGR engine, and cash flow KPIs.
"""
