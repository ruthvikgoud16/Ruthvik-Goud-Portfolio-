"""
Sprint 2 — Day 09: Leverage & Efficiency Ratios

Implements the following KPIs exactly as specified in the Day 09 requirements:

  - Debt-to-Equity (D/E)
  - High Leverage Flag  (non-Financials only, D/E > 5)
  - Interest Coverage Ratio (ICR)
  - ICR Label             ("Debt Free" when interest = 0)
  - ICR Warning Flag      (ICR < 1.5 → at-risk)
  - Net Debt
  - Asset Turnover

Design rules followed:
  * Pure functions only — no database access inside this module.
  * Sector classification is imported from ratios.py (FinancialsSectorBenchmark.
    is_financials_company) to avoid duplicating the constant.
  * All edge cases match the specification literally.
  * No business rules are invented beyond what the spec states.
  * All engineering decisions are documented inline.
"""

import logging
from typing import Optional, Tuple

from src.analytics.ratios import FinancialsSectorBenchmark

logger = logging.getLogger(__name__)


# =========================================================================
# THRESHOLD CONSTANTS — specified values only, no invented rules
# =========================================================================

HIGH_LEVERAGE_DE_THRESHOLD: float = 5.0   # D/E > 5 triggers flag for non-Financials
ICR_AT_RISK_THRESHOLD: float = 1.5        # ICR < 1.5 triggers at-risk warning
ICR_DEBT_FREE_LABEL: str = "Debt Free"    # Label when interest = 0


# =========================================================================
# LEVERAGE & EFFICIENCY RATIOS CLASS
# =========================================================================

class LeverageRatios:
    """
    Compute leverage and efficiency KPIs from financial statements.

    All methods are pure static functions.  Sector information is passed in
    from the caller — this class does not query the database.
    """

    # =====================================================================
    # DEBT-TO-EQUITY
    # =====================================================================

    @staticmethod
    def debt_to_equity(
        borrowings: Optional[float],
        equity_capital: Optional[float],
        reserves: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Debt-to-Equity ratio (D/E).

        Formula: borrowings / (equity_capital + reserves)

        Args:
            borrowings:     Total borrowings (₹ Crores)
            equity_capital: Equity share capital (₹ Crores)
            reserves:       Reserves and surplus (₹ Crores)

        Returns:
            D/E ratio, or:
            - 0.0   if borrowings = 0  (debt-free, per specification)
            - None  if denominator (equity + reserves) is invalid (≤ 0 or None)
            - None  if borrowings is None

        Edge cases (mandatory per specification):
            borrowings = 0      → return 0.0  (NOT None)
            equity + reserves ≤ 0 → return None  (invalid denominator)

        Note on negative equity + reserves:
            The specification only requires safe handling of the invalid
            denominator.  Returning None is consistent with the convention
            established for ROE in ratios.py (Day 08).
        """
        if borrowings is None:
            return None

        # Spec: borrowings = 0 → return 0 (not None)
        if borrowings == 0:
            return 0.0

        if equity_capital is None or reserves is None:
            return None

        total_equity = equity_capital + reserves
        if total_equity <= 0:
            return None

        return borrowings / total_equity

    # =====================================================================
    # HIGH LEVERAGE FLAG
    # =====================================================================

    @staticmethod
    def high_leverage_flag(
        de_ratio: Optional[float],
        broad_sector: Optional[str],
    ) -> bool:
        """
        Determine whether a company's D/E ratio triggers the high-leverage flag.

        Rules (exactly per specification):
            Flag = True  if D/E > HIGH_LEVERAGE_DE_THRESHOLD (5.0)
                         AND company is NOT in Financials broad_sector
            Flag = False otherwise — including:
                         - D/E ≤ 5
                         - D/E is None (cannot assess)
                         - Company is in Financials sector (warning suppressed)

        Args:
            de_ratio:     Computed D/E ratio from debt_to_equity()
            broad_sector: broad_sector value from sectors table

        Returns:
            True  — high leverage detected (non-Financials, D/E > 5)
            False — not flagged

        Important:
            The actual D/E calculation is NOT modified for Financials companies.
            Only the flag is suppressed.  This matches the specification:
            "suppress the standard high-leverage WARNING" for Financials.
        """
        if de_ratio is None:
            return False

        # Financials companies: suppress warning regardless of D/E value
        if FinancialsSectorBenchmark.is_financials_company(broad_sector):
            return False

        return de_ratio > HIGH_LEVERAGE_DE_THRESHOLD

    # =====================================================================
    # INTEREST COVERAGE RATIO (ICR)
    # =====================================================================

    @staticmethod
    def interest_coverage_ratio(
        operating_profit: Optional[float],
        other_income: Optional[float],
        interest: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Interest Coverage Ratio (ICR).

        Formula: (operating_profit + other_income) / interest

        Args:
            operating_profit: Operating profit / EBIT component (₹ Crores)
            other_income:     Other / non-operating income (₹ Crores); treat
                              as 0 if None (consistent with EBIT convention
                              used in ROCE calculation)
            interest:         Interest expense (₹ Crores)

        Returns:
            ICR (dimensionless), or:
            - None  if interest = 0   (per specification: return None)
            - None  if interest is None
            - None  if operating_profit is None

        Edge case (mandatory per specification):
            interest = 0 → return None
            Caller should then invoke icr_label() which returns "Debt Free".

        Note:
            other_income is COALESCED to 0 before calculation to handle NULL
            values from the database, consistent with how EBIT is assembled
            for ROCE (Day 08 caller convention).
        """
        if operating_profit is None:
            return None
        if interest is None or interest == 0:
            return None

        numerator = operating_profit + (other_income or 0.0)
        return numerator / interest

    # =====================================================================
    # ICR LABEL
    # =====================================================================

    @staticmethod
    def icr_label(
        icr_value: Optional[float],
        interest: Optional[float],
    ) -> Optional[str]:
        """
        Return the human-readable ICR label.

        Rules (per specification):
            If ICR is None AND interest = 0 → "Debt Free"
            Otherwise                        → None (no label needed)

        Args:
            icr_value: Result of interest_coverage_ratio()
            interest:  Interest expense from P&L (₹ Crores)

        Returns:
            "Debt Free" when the company has no interest expense (interest = 0),
            None otherwise.

        Note:
            The label is separate from the ICR value.  Both are stored/reported
            independently.  A company can have ICR = None AND label = "Debt Free"
            simultaneously — that is the correct and intended state.
        """
        if icr_value is None and (interest is None or interest == 0):
            return ICR_DEBT_FREE_LABEL
        return None

    # =====================================================================
    # ICR WARNING FLAG
    # =====================================================================

    @staticmethod
    def icr_warning(icr_value: Optional[float]) -> bool:
        """
        Determine whether a company is at risk of not covering interest payments.

        Rule (per specification):
            Flag = True  if ICR < ICR_AT_RISK_THRESHOLD (1.5)
            Flag = False if ICR ≥ 1.5
            Flag = False if ICR is None  (debt-free or data missing; no warning)

        Args:
            icr_value: Result of interest_coverage_ratio()

        Returns:
            True  — company at risk (ICR < 1.5)
            False — not at risk

        Note:
            The specification says "if ICR < 1.5 → at-risk flag".  False is
            returned for None ICR because a debt-free company (interest = 0,
            ICR = None) is not at risk; it has no interest to cover.
            A company where ICR cannot be computed due to missing data is also
            not positively flagged — absence of evidence is not evidence of risk.
        """
        if icr_value is None:
            return False
        return icr_value < ICR_AT_RISK_THRESHOLD

    # =====================================================================
    # NET DEBT
    # =====================================================================

    @staticmethod
    def net_debt(
        borrowings: Optional[float],
        investments: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Net Debt.

        Formula: borrowings - investments

        Per specification, investments is used as the liquid-asset proxy.

        Args:
            borrowings:   Total borrowings (₹ Crores)
            investments:  Investments from balance sheet (₹ Crores);
                          treated as 0 if None (no investments on record)

        Returns:
            Net debt in ₹ Crores.
            - Negative net debt = net cash position (borrowings < investments)
            - None if borrowings is None

        Edge cases:
            borrowings is None   → return None
            investments is None  → treat as 0 (no investments = no liquid-asset offset)
        """
        if borrowings is None:
            return None
        return borrowings - (investments or 0.0)

    # =====================================================================
    # ASSET TURNOVER
    # =====================================================================

    @staticmethod
    def asset_turnover(
        sales: Optional[float],
        total_assets: Optional[float],
    ) -> Optional[float]:
        """
        Calculate Asset Turnover ratio.

        Formula: sales / total_assets

        Args:
            sales:        Total revenue / sales (₹ Crores)
            total_assets: Total assets (₹ Crores)

        Returns:
            Asset turnover (times), or None if total_assets ≤ 0 or any input is None.

        Edge case (mandatory per specification):
            total_assets = 0 → return None
            total_assets < 0 → return None  (invalid; return None consistently)
        """
        if total_assets is None or total_assets <= 0:
            return None
        if sales is None:
            return None
        return sales / total_assets

    # =====================================================================
    # COMBINED ASSESSMENT (convenience)
    # =====================================================================

    @staticmethod
    def compute_all(
        borrowings: Optional[float],
        equity_capital: Optional[float],
        reserves: Optional[float],
        operating_profit: Optional[float],
        other_income: Optional[float],
        interest: Optional[float],
        investments: Optional[float],
        sales: Optional[float],
        total_assets: Optional[float],
        broad_sector: Optional[str],
    ) -> dict:
        """
        Compute all Day 09 KPIs in a single call and return as a dictionary.

        This is a convenience wrapper for batch processing.  Each individual
        ratio function is called independently — no short-circuiting.

        Returns a dict with keys:
            debt_to_equity          (float | None)
            high_leverage_flag      (bool)
            interest_coverage       (float | None)
            icr_label               (str | None)
            icr_warning             (bool)
            net_debt                (float | None)
            asset_turnover          (float | None)
        """
        de = LeverageRatios.debt_to_equity(borrowings, equity_capital, reserves)
        icr = LeverageRatios.interest_coverage_ratio(
            operating_profit, other_income, interest
        )
        return {
            "debt_to_equity":     de,
            "high_leverage_flag": LeverageRatios.high_leverage_flag(de, broad_sector),
            "interest_coverage":  icr,
            "icr_label":          LeverageRatios.icr_label(icr, interest),
            "icr_warning":        LeverageRatios.icr_warning(icr),
            "net_debt":           LeverageRatios.net_debt(borrowings, investments),
            "asset_turnover":     LeverageRatios.asset_turnover(sales, total_assets),
        }
