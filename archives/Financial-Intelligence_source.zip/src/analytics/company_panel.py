"""
Shared latest-year and history panel for Sprint 5 modules.

Loads real SQLite rows only. TTM / sentinel years (e.g. 9999-12) are excluded.
Missing source values stay None — never fabricated.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DB = PROJECT_ROOT / "nifty100.db"


def connect(db_path: Optional[Path] = None) -> sqlite3.Connection:
    path = Path(db_path) if db_path else DEFAULT_DB
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    return conn


def _is_fiscal_year(year: Optional[str]) -> bool:
    if year is None:
        return False
    text = str(year)
    return len(text) >= 4 and text[:4].isdigit() and int(text[:4]) < 2100


def keep_primary_fiscal_rows(df: pd.DataFrame) -> pd.DataFrame:
    """
    One row per company calendar year.

    Extra intra-year snapshots (e.g. 2024-09 beside a March year-end) break
    consecutive-year rules. Prefer each company's modal fiscal month.
    TTM / sentinel years are already excluded by `_is_fiscal_year`.
    """
    if df.empty or "year" not in df.columns or "company_id" not in df.columns:
        return df
    out = df.copy()
    out["_cal"] = out["year"].astype(str).str[:4]
    out["_mon"] = out["year"].astype(str).str[5:7]
    modal = out.groupby("company_id")["_mon"].agg(
        lambda s: s.mode().iloc[0] if not s.mode().empty else s.iloc[-1]
    )
    out["_modal"] = out["company_id"].map(modal)
    out["_rank"] = (out["_mon"] != out["_modal"]).astype(int)
    out.sort_values(["company_id", "_cal", "_rank", "year"], inplace=True)
    out = out.drop_duplicates(["company_id", "_cal"], keep="first")
    out = out.drop(columns=["_cal", "_mon", "_modal", "_rank"])
    out.sort_values(["company_id", "year"], inplace=True)
    out.reset_index(drop=True, inplace=True)
    return out


def load_ratios_history(conn: sqlite3.Connection) -> pd.DataFrame:
    df = pd.read_sql_query(
        "SELECT * FROM financial_ratios",
        conn,
    )
    df = df[df["year"].map(_is_fiscal_year)].copy()
    return keep_primary_fiscal_rows(df)


def load_statements(conn: sqlite3.Connection) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    pl = pd.read_sql_query("SELECT * FROM profitandloss", conn)
    bs = pd.read_sql_query("SELECT * FROM balancesheet", conn)
    cf = pd.read_sql_query("SELECT * FROM cashflow", conn)
    frames = []
    for frame in (pl, bs, cf):
        frame.drop(frame[~frame["year"].map(_is_fiscal_year)].index, inplace=True)
        frames.append(keep_primary_fiscal_rows(frame))
    return frames[0], frames[1], frames[2]


def load_companies_sectors(conn: sqlite3.Connection) -> pd.DataFrame:
    return pd.read_sql_query(
        """
        SELECT
            c.id AS company_id,
            c.company_name,
            c.about_company,
            c.roce_percentage AS source_roce_pct,
            c.roe_percentage AS source_roe_pct,
            s.broad_sector,
            s.sub_sector
        FROM companies c
        LEFT JOIN sectors s ON s.company_id = c.id
        ORDER BY c.id
        """,
        conn,
    )


def latest_dividend_yield(conn: sqlite3.Connection) -> Dict[str, Optional[float]]:
    df = pd.read_sql_query(
        """
        SELECT m.company_id, m.dividend_yield_pct
        FROM market_cap m
        JOIN (
            SELECT company_id, MAX(year) AS year
            FROM market_cap
            GROUP BY company_id
        ) t ON m.company_id = t.company_id AND m.year = t.year
        """,
        conn,
    )
    return dict(zip(df["company_id"], df["dividend_yield_pct"]))


def company_tail(df: pd.DataFrame, company_id: str, n: int) -> pd.DataFrame:
    subset = df[df["company_id"] == company_id]
    return subset.tail(n)


def consecutive_numeric(values: List[Optional[float]], n: int) -> Optional[List[float]]:
    """Return the last n values if they are all non-null."""
    if len(values) < n:
        return None
    tail = values[-n:]
    cleaned: List[float] = []
    for value in tail:
        if value is None or (isinstance(value, float) and pd.isna(value)):
            return None
        cleaned.append(float(value))
    return cleaned


def strictly_monotonic(values: List[float], increasing: bool) -> bool:
    if len(values) < 2:
        return False
    for i in range(len(values) - 1):
        if increasing and not (values[i + 1] > values[i]):
            return False
        if not increasing and not (values[i + 1] < values[i]):
            return False
    return True


def year_count(df: pd.DataFrame, company_id: str) -> int:
    return int(df[df["company_id"] == company_id]["year"].nunique())
