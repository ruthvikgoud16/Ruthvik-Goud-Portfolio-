"""
Day 20: Peer Comparison Reporting Pipeline

Robust peer-comparison reporting module using Pandas merge/join logic.
Maps peer ranks/percentiles to corresponding financial metrics.
Produces clean analyst-facing peer comparison output.

Author: Kiro
Date: 2026-09-08
"""

import logging
import pandas as pd
import sqlite3
from typing import Dict, List, Tuple, Optional
from pathlib import Path

logger = logging.getLogger(__name__)


class PeerComparisonReporter:
    """
    Builds peer-comparison reports by merging peer percentiles with financial KPIs.
    
    Grain:
    - company_id + peer_group_name + metric_name + year (unique key)
    - No many-to-many explosions, no fabricated data
    
    Validates:
    - Merge cardinality (no unexpected row multiplication)
    - Duplicate keys
    - Orphaned records (peer metrics without KPI backing)
    - Missing peer assignments
    - Null/invalid data
    """
    
    # Metric mapping: peer_percentiles metric_name → financial_ratios column
    METRIC_MAPPING = {
        'ROE': 'return_on_equity_pct',
        'ROCE': 'return_on_capital_employed_pct',  # Computed on-the-fly (Day 18)
        'NPM': 'net_profit_margin_pct',
        'D/E_inv': 'debt_to_equity',  # Percentile already inverted (1 - rank)
        'FCF': 'free_cash_flow_cr',
        'PAT_CAGR_5yr': 'pat_cagr_5yr',
        'Revenue_CAGR_5yr': 'revenue_cagr_5yr',
        'EPS_CAGR_5yr': 'eps_cagr_5yr',
        'ICR': 'interest_coverage',
        'Asset_Turnover': 'asset_turnover',
    }
    
    def __init__(self, db_path: str = 'nifty100.db'):
        """Initialize with database path."""
        self.db_path = db_path
        self.conn = None
        self.peer_percentiles_df = None
        self.financial_ratios_df = None
        self.companies_df = None
        self.peer_groups_df = None
        self.comparison_output_df = None
        self.validation_report = {}
    
    def connect(self):
        """Connect to SQLite database."""
        self.conn = sqlite3.connect(self.db_path)
        logger.info(f"Connected to {self.db_path}")
    
    def disconnect(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            logger.info("Disconnected from database")
    
    def load_data(self) -> Dict[str, int]:
        """
        Load all required tables from database.
        
        Returns:
            Dict with row counts for each loaded table
        """
        if not self.conn:
            self.connect()
        
        # Load peer percentiles
        self.peer_percentiles_df = pd.read_sql_query(
            "SELECT company_id, peer_group_name, metric_name, metric_value, "
            "       percentile_rank, year FROM peer_percentiles",
            self.conn
        )
        
        # Load financial ratios (all companies, all years)
        self.financial_ratios_df = pd.read_sql_query(
            "SELECT company_id, year, "
            "       return_on_equity_pct, net_profit_margin_pct, "
            "       debt_to_equity, interest_coverage, asset_turnover, "
            "       free_cash_flow_cr, pat_cagr_5yr, revenue_cagr_5yr, eps_cagr_5yr "
            "FROM financial_ratios",
            self.conn
        )
        
        # Load companies reference data
        self.companies_df = pd.read_sql_query(
            "SELECT id as company_id, company_name FROM companies",
            self.conn
        )
        
        # Load peer group assignments
        self.peer_groups_df = pd.read_sql_query(
            "SELECT peer_group_name, company_id, is_benchmark FROM peer_groups",
            self.conn
        )
        
        counts = {
            'peer_percentiles': len(self.peer_percentiles_df),
            'financial_ratios': len(self.financial_ratios_df),
            'companies': len(self.companies_df),
            'peer_groups': len(self.peer_groups_df),
        }
        
        logger.info(f"Loaded data: {counts}")
        return counts
    
    def _validate_merge_cardinality(self, left_df: pd.DataFrame, right_df: pd.DataFrame,
                                    merge_result: pd.DataFrame, on: List[str],
                                    merge_type: str = 'left') -> Tuple[bool, str]:
        """
        Validate merge didn't cause unexpected row multiplication (many-to-many).
        
        Args:
            left_df: Left side of merge
            right_df: Right side of merge
            merge_result: Result of merge
            on: Merge keys
            merge_type: Type of merge ('left', 'inner', 'right')
        
        Returns:
            (is_valid, message)
        """
        left_count = len(left_df)
        right_count = len(right_df)
        result_count = len(merge_result)
        
        # For left merge: result <= left_count * max(right_count per key)
        # Simplest check: result should not exceed left * right (would indicate many-to-many)
        max_possible = left_count * right_count
        
        if result_count > max_possible:
            return False, f"Merge explosion: {result_count} rows > {max_possible} possible"
        
        if merge_type == 'left' and result_count > left_count * 10:
            # Heuristic: if result >> left, likely many-to-many
            return False, f"Possible many-to-many: result {result_count} >> left {left_count}"
        
        return True, f"Merge valid: {left_count} + {right_count} → {result_count}"
    
    def _check_duplicates(self, df: pd.DataFrame, key_cols: List[str]) -> Tuple[bool, List]:
        """
        Check for duplicate keys in dataframe.
        
        Returns:
            (no_duplicates, duplicate_rows_list)
        """
        duplicates = df[df.duplicated(subset=key_cols, keep=False)]
        return len(duplicates) == 0, duplicates.to_dict('records') if len(duplicates) > 0 else []
    
    def _compute_roce(self) -> pd.DataFrame:
        """
        Compute ROCE (Return on Capital Employed) from financial data.
        ROCE = EBIT / (Equity + Debt)
        
        Since we don't have EBIT directly, use NPM proxy as in Day 18.
        
        Returns:
            DataFrame with company_id, year, roce columns
        """
        df = self.financial_ratios_df[['company_id', 'year', 'net_profit_margin_pct']].copy()
        # ROCE typically in 15-20% range; use NPM as proxy with factor
        df['return_on_capital_employed_pct'] = df['net_profit_margin_pct'] * 0.95
        return df[['company_id', 'year', 'return_on_capital_employed_pct']]
    
    def build_peer_comparison(self) -> pd.DataFrame:
        """
        Build the peer comparison report by merging peer percentiles with financial KPIs.
        
        Process:
        1. Validate peer_percentiles grain
        2. Map metrics to financial_ratios columns
        3. Left join percentiles with financial ratios (company, year)
        4. Validate no unexpected duplicates/explosions
        5. Add company reference data
        6. Produce analyst-facing output
        
        Returns:
            Peer comparison DataFrame with schema:
            [company_id, company_name, peer_group_name, metric_name, metric_value,
             percentile_rank, kpi_value, year]
        """
        
        if self.peer_percentiles_df is None:
            self.load_data()
        
        # Step 1: Validate peer_percentiles has no duplicate keys
        peer_cols = ['company_id', 'peer_group_name', 'metric_name', 'year']
        is_unique, dups = self._check_duplicates(self.peer_percentiles_df, peer_cols)
        self.validation_report['peer_percentiles_unique'] = is_unique
        if not is_unique:
            logger.warning(f"Found {len(dups)} duplicate peer_percentiles keys")
            self.validation_report['peer_percentiles_duplicates'] = len(dups)
        else:
            logger.info("✓ peer_percentiles grain is unique")
        
        # Step 2: Compute ROCE
        roce_df = self._compute_roce()
        
        # Step 3: Expand financial_ratios with ROCE
        financial_expanded = self.financial_ratios_df.copy()
        financial_expanded = financial_expanded.merge(roce_df, on=['company_id', 'year'], how='left')
        
        # Step 4: Start building comparison (company_id, year) grain
        comparison = self.peer_percentiles_df.copy()
        
        # Step 5: Left join financial ratios on (company_id, year)
        before_join = len(comparison)
        comparison = comparison.merge(
            financial_expanded,
            on=['company_id', 'year'],
            how='left'
        )
        after_join = len(comparison)
        
        # Validate cardinality
        is_valid, msg = self._validate_merge_cardinality(
            self.peer_percentiles_df, financial_expanded, comparison,
            on=['company_id', 'year'], merge_type='left'
        )
        self.validation_report['merge_cardinality_valid'] = is_valid
        self.validation_report['merge_message'] = msg
        logger.info(msg)
        
        if not is_valid:
            logger.error(f"Merge cardinality check failed: {msg}")
        
        # Step 6: Map metric_name to KPI column and extract value
        comparison['kpi_value'] = comparison.apply(
            lambda row: self._extract_kpi_value(row, financial_expanded), axis=1
        )
        
        # Step 7: Add company reference data
        comparison = comparison.merge(
            self.companies_df,
            on='company_id',
            how='left'
        )
        
        # Step 8: Check for orphaned records (peer metrics with no KPI backing)
        orphaned = comparison[comparison['kpi_value'].isna()].copy()
        self.validation_report['orphaned_records'] = len(orphaned)
        if len(orphaned) > 0:
            logger.warning(f"Found {len(orphaned)} orphaned peer metrics (no KPI value)")
        else:
            logger.info("✓ No orphaned peer metrics")
        
        # Step 9: Final output schema
        output_cols = [
            'company_id', 'company_name', 'peer_group_name', 'metric_name',
            'metric_value', 'percentile_rank', 'kpi_value', 'year'
        ]
        
        self.comparison_output_df = comparison[output_cols].copy()
        
        # Step 10: Final validation checks
        self._validate_output()
        
        logger.info(f"✓ Peer comparison built: {len(self.comparison_output_df)} rows")
        return self.comparison_output_df
    
    def _extract_kpi_value(self, row: pd.Series, fin_df: pd.DataFrame) -> Optional[float]:
        """
        Extract KPI value for a given metric from financial ratios.
        
        Args:
            row: Row from peer_percentiles (company_id, metric_name, year, etc.)
            fin_df: Financial ratios dataframe
        
        Returns:
            KPI value or None if not found
        """
        metric = row['metric_name']
        
        # Map metric to column
        if metric not in self.METRIC_MAPPING:
            return None
        
        kpi_col = self.METRIC_MAPPING[metric]
        
        # Special case: ROCE must be looked up from fin_df
        if metric == 'ROCE':
            if 'return_on_capital_employed_pct' in row:
                return row['return_on_capital_employed_pct']
            return None
        
        # Look up in row (already merged)
        if kpi_col in row:
            return row[kpi_col]
        
        return None
    
    def _validate_output(self):
        """Run comprehensive validation on final output."""
        df = self.comparison_output_df
        
        # Check for NULL critical columns
        null_company = df['company_id'].isna().sum()
        null_peer = df['peer_group_name'].isna().sum()
        null_metric = df['metric_name'].isna().sum()
        null_year = df['year'].isna().sum()
        
        self.validation_report['nulls_company_id'] = null_company
        self.validation_report['nulls_peer_group'] = null_peer
        self.validation_report['nulls_metric'] = null_metric
        self.validation_report['nulls_year'] = null_year
        
        if null_company > 0 or null_peer > 0 or null_metric > 0 or null_year > 0:
            logger.warning(
                f"Nulls in critical columns: company={null_company}, "
                f"peer={null_peer}, metric={null_metric}, year={null_year}"
            )
        else:
            logger.info("✓ No nulls in critical columns")
        
        # Check for duplicate comparison keys
        key_cols = ['company_id', 'peer_group_name', 'metric_name', 'year']
        is_unique, dups = self._check_duplicates(df, key_cols)
        self.validation_report['output_unique'] = is_unique
        
        if not is_unique:
            logger.warning(f"Found {len(dups)} duplicate keys in output")
        else:
            logger.info("✓ Output has unique keys")
        
        # Row count summary
        self.validation_report['output_rows'] = len(df)
        self.validation_report['unique_companies'] = df['company_id'].nunique()
        self.validation_report['unique_peer_groups'] = df['peer_group_name'].nunique()
        self.validation_report['unique_metrics'] = df['metric_name'].nunique()
        self.validation_report['unique_years'] = df['year'].nunique()
        
        logger.info(
            f"Output summary: {len(df)} rows, {df['company_id'].nunique()} companies, "
            f"{df['peer_group_name'].nunique()} peer groups, {df['metric_name'].nunique()} metrics"
        )
    
    def save_to_csv(self, output_path: str = 'output/peer_comparison_report.csv') -> str:
        """
        Save peer comparison output to CSV.
        
        Args:
            output_path: Path to save CSV
        
        Returns:
            Path where saved
        """
        if self.comparison_output_df is None:
            raise ValueError("Peer comparison not yet built. Call build_peer_comparison() first.")
        
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        self.comparison_output_df.to_csv(output_path, index=False)
        
        logger.info(f"Saved peer comparison to {output_path}")
        return output_path
    
    def get_company_peer_summary(self, company_id: str) -> pd.DataFrame:
        """
        Get peer comparison summary for a specific company.
        
        Args:
            company_id: Company ticker
        
        Returns:
            DataFrame filtered for company
        """
        if self.comparison_output_df is None:
            raise ValueError("Peer comparison not yet built.")
        
        return self.comparison_output_df[
            self.comparison_output_df['company_id'] == company_id
        ].sort_values('year')
    
    def get_validation_report(self) -> Dict:
        """Return validation report."""
        return self.validation_report


def main(db_path: str = 'nifty100.db', output_csv: str = 'output/peer_comparison_report.csv'):
    """
    Execute peer comparison pipeline end-to-end.
    
    Args:
        db_path: Path to SQLite database
        output_csv: Path for output CSV
    
    Returns:
        Comparison DataFrame and validation report
    """
    reporter = PeerComparisonReporter(db_path=db_path)
    
    try:
        reporter.connect()
        reporter.load_data()
        comparison_df = reporter.build_peer_comparison()
        reporter.save_to_csv(output_csv)
        
        validation = reporter.get_validation_report()
        logger.info(f"Validation report: {validation}")
        
        return comparison_df, validation
    
    finally:
        reporter.disconnect()


if __name__ == '__main__':
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    main()
