"""
Day 36–37 — KMeans clustering, profiling, outliers, and portfolio statistics.

Features (latest fiscal year):
  ROE, D/E, revenue CAGR 5yr, FCF CAGR 5yr, OPM
Missing values are imputed with the company's broad-sector median, then
universe median if the sector median is also missing.
"""

from __future__ import annotations

from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from src.analytics.company_panel import (
    PROJECT_ROOT,
    connect,
    load_companies_sectors,
    load_ratios_history,
)
from src.nlp.pros_cons_generator import _finite

FEATURE_COLS = [
    "return_on_equity_pct",
    "debt_to_equity",
    "revenue_cagr_5yr",
    "fcf_cagr_5yr",
    "operating_profit_margin_pct",
]

STAT_KPIS = [
    "return_on_equity_pct",
    "debt_to_equity",
    "revenue_cagr_5yr",
    "pat_cagr_5yr",
    "operating_profit_margin_pct",
    "net_profit_margin_pct",
    "free_cash_flow_cr",
    "interest_coverage",
    "asset_turnover",
    "eps_cagr_5yr",
]

RANDOM_STATE = 42
N_CLUSTERS = 5


def _latest_feature_frame() -> pd.DataFrame:
    conn = connect()
    companies = load_companies_sectors(conn)
    ratios = load_ratios_history(conn)
    conn.close()
    latest = ratios.sort_values(["company_id", "year"]).groupby("company_id").tail(1)
    intel_path = PROJECT_ROOT / "output" / "cashflow_intelligence.xlsx"
    fcf = pd.DataFrame(columns=["company_id", "fcf_cagr_5yr"])
    if intel_path.exists():
        intel = pd.read_excel(intel_path)
        fcf = intel[["company_id", "fcf_cagr_5yr"]]
    merged = companies.merge(latest, on="company_id", how="left").merge(fcf, on="company_id", how="left")
    return merged


def impute_sector_median(df: pd.DataFrame, columns: List[str]) -> pd.DataFrame:
    """Impute each column with sector median, then universe median."""
    out = df.copy()
    for col in columns:
        out[col] = pd.to_numeric(out[col], errors="coerce")
        sector_med = out.groupby("broad_sector")[col].transform("median")
        out[col] = out[col].fillna(sector_med)
        out[col] = out[col].fillna(out[col].median())
        out[col] = out[col].fillna(0.0)
    return out


def fit_kmeans(df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray, StandardScaler, KMeans, np.ndarray]:
    X = df[FEATURE_COLS].to_numpy(dtype=float)
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    model = KMeans(n_clusters=N_CLUSTERS, random_state=RANDOM_STATE, n_init=10)
    labels = model.fit_predict(Xs)
    distances = np.linalg.norm(Xs - model.cluster_centers_[labels], axis=1)
    return labels, distances, scaler, model, Xs


def elbow_inertias(Xs: np.ndarray, k_min: int = 2, k_max: int = 10) -> List[Tuple[int, float]]:
    rows = []
    for k in range(k_min, k_max + 1):
        km = KMeans(n_clusters=k, random_state=RANDOM_STATE, n_init=10)
        km.fit(Xs)
        rows.append((k, float(km.inertia_)))
    return rows


def name_clusters(df: pd.DataFrame) -> Dict[int, str]:
    """Assign archetype names from cluster medians (means are skewed by source ROE outliers)."""
    stats = df.groupby("cluster_id")[FEATURE_COLS].median()
    remaining = set(stats.index.tolist())
    names: Dict[int, str] = {}

    distressed = max(remaining, key=lambda c: stats.loc[c, "debt_to_equity"])
    names[distressed] = "Distressed or Turnaround"
    remaining.remove(distressed)

    hq = max(
        remaining,
        key=lambda c: stats.loc[c, "return_on_equity_pct"] + stats.loc[c, "operating_profit_margin_pct"],
    )
    names[hq] = "High-Quality Compounders"
    remaining.remove(hq)

    growth = max(remaining, key=lambda c: stats.loc[c, "revenue_cagr_5yr"])
    names[growth] = "Emerging Growth"
    remaining.remove(growth)

    defensive = min(remaining, key=lambda c: stats.loc[c, "debt_to_equity"])
    names[defensive] = "Defensive Dividend Payers"
    remaining.remove(defensive)

    names[remaining.pop()] = "Value Cyclicals"
    return names


def run_clustering() -> pd.DataFrame:
    raw = _latest_feature_frame()
    imputed = impute_sector_median(raw, FEATURE_COLS)
    labels, distances, scaler, model, Xs = fit_kmeans(imputed)
    imputed["cluster_id"] = labels
    imputed["distance_from_centroid"] = distances
    names = name_clusters(imputed)
    imputed["cluster_name"] = imputed["cluster_id"].map(names)
    return imputed, Xs, names


def write_elbow_plot(Xs: np.ndarray, path: Path) -> Path:
    pairs = elbow_inertias(Xs)
    ks, inertias = zip(*pairs)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig, ax = plt.subplots(figsize=(8, 5))
    ax.plot(ks, inertias, marker="o", color="#0B1F3A")
    ax.axvline(5, color="#C9A227", linestyle="--", label="k=5 (spec)")
    ax.set_xlabel("k")
    ax.set_ylabel("Inertia")
    ax.set_title("KMeans elbow (random_state=42)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=140)
    plt.close(fig)
    return path


def write_cluster_outputs() -> Dict[str, Path]:
    df, Xs, names = run_clustering()
    labels_path = PROJECT_ROOT / "output" / "cluster_labels.csv"
    labels_path.parent.mkdir(parents=True, exist_ok=True)
    out = df[["company_id", "cluster_id", "cluster_name", "distance_from_centroid"]].sort_values("company_id")
    out.to_csv(labels_path, index=False)

    profile_rows = []
    for cid, grp in df.groupby("cluster_id"):
        row = {
            "cluster_id": int(cid),
            "cluster_name": names[int(cid)],
            "n_companies": int(len(grp)),
        }
        for col in FEATURE_COLS:
            row[f"{col}_mean"] = float(grp[col].mean())
            row[f"{col}_median"] = float(grp[col].median())
        profile_rows.append(row)
    profile = pd.DataFrame(profile_rows).sort_values("cluster_id")
    profile_path = PROJECT_ROOT / "output" / "cluster_profiles.csv"
    profile.to_csv(profile_path, index=False)

    elbow_path = write_elbow_plot(Xs, PROJECT_ROOT / "reports" / "elbow_plot.png")

    latest = df.copy()
    corr = latest[STAT_KPIS].apply(pd.to_numeric, errors="coerce").corr(method="pearson")
    heat_path = PROJECT_ROOT / "reports" / "correlation_heatmap.png"
    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="coolwarm", center=0, ax=ax)
    ax.set_title("Pearson correlation — 10 KPIs, latest year (pairwise)")
    fig.tight_layout()
    fig.savefig(heat_path, dpi=140)
    plt.close(fig)

    outlier_rows = []
    for metric in STAT_KPIS:
        for sector, grp in latest.groupby("broad_sector"):
            series = pd.to_numeric(grp[metric], errors="coerce")
            std = series.std(ddof=0)
            mean = series.mean()
            if std is None or pd.isna(std) or std == 0:
                continue
            z = (series - mean) / std
            for company_id, value, zscore in zip(grp["company_id"], series, z):
                if pd.notna(zscore) and abs(float(zscore)) > 3:
                    outlier_rows.append(
                        {
                            "company_id": company_id,
                            "metric": metric,
                            "value": None if pd.isna(value) else float(value),
                            "z_score": float(zscore),
                            "sector": sector,
                            "sector_mean": float(mean),
                            "sector_std": float(std),
                        }
                    )
    outliers = pd.DataFrame(outlier_rows)
    outlier_path = PROJECT_ROOT / "output" / "outlier_report.csv"
    outliers.to_csv(outlier_path, index=False)

    stats_rows = []
    for metric in STAT_KPIS:
        s = pd.to_numeric(latest[metric], errors="coerce").dropna()
        stats_rows.append(
            {
                "metric": metric,
                "P10": float(s.quantile(0.10)),
                "P25": float(s.quantile(0.25)),
                "P50": float(s.quantile(0.50)),
                "P75": float(s.quantile(0.75)),
                "P90": float(s.quantile(0.90)),
                "Mean": float(s.mean()),
                "Std": float(s.std(ddof=0)),
                "n": int(s.count()),
            }
        )
    stats_path = PROJECT_ROOT / "output" / "portfolio_stats.csv"
    pd.DataFrame(stats_rows).to_csv(stats_path, index=False)

    from src.api.db import apply_indexes, get_connection

    conn = get_connection()
    apply_indexes(conn)
    conn.close()
    print(profile.to_string(index=False))
    print(f"outliers={len(outliers)}")
    return {
        "labels": labels_path,
        "profiles": profile_path,
        "elbow": elbow_path,
        "heatmap": heat_path,
        "outliers": outlier_path,
        "stats": stats_path,
    }


if __name__ == "__main__":
    write_cluster_outputs()
