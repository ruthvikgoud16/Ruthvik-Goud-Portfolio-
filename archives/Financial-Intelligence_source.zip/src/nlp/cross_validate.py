"""
Day 29 Cross-Validation Pipeline
=================================

Cross-validates parsed analysis values against existing verified analytics engines:
- compounded_sales_growth ↔ Revenue CAGR from financial_ratios
- compounded_profit_growth ↔ PAT CAGR from financial_ratios
- roe ↔ Average ROE from financial_ratios
- stock_price_cagr ↔ Independent calculation from stock_prices table

Divergence threshold: 5% (material divergence)
"""

import pandas as pd
import sqlite3
from pathlib import Path
from typing import Dict, List, Any

class CrossValidator:
    """Cross-validates parsed analysis values against financial data"""
    
    DIVERGENCE_THRESHOLD = 5.0  # 5% divergence = material difference
    
    def __init__(self, db_path: str):
        self.db_path = db_path
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        
    def get_revenue_cagr(self, company_id: str) -> Dict[str, Any]:
        """Get revenue CAGR from financial_ratios table"""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT revenue_cagr_5yr FROM financial_ratios WHERE company_id = ? LIMIT 1",
            (company_id,)
        )
        row = cursor.fetchone()
        if row:
            return {
                'company_id': company_id,
                'metric': 'revenue_cagr_5yr',
                'value': row[0],
                'source': 'financial_ratios',
            }
        return None
    
    def get_pat_cagr(self, company_id: str) -> Dict[str, Any]:
        """Get PAT CAGR from financial_ratios table"""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT pat_cagr_5yr FROM financial_ratios WHERE company_id = ? LIMIT 1",
            (company_id,)
        )
        row = cursor.fetchone()
        if row:
            return {
                'company_id': company_id,
                'metric': 'pat_cagr_5yr',
                'value': row[0],
                'source': 'financial_ratios',
            }
        return None
    
    def get_average_roe(self, company_id: str) -> Dict[str, Any]:
        """Get average ROE from financial_ratios table"""
        cursor = self.conn.cursor()
        cursor.execute(
            "SELECT AVG(return_on_equity_pct) as avg_roe FROM financial_ratios WHERE company_id = ?",
            (company_id,)
        )
        row = cursor.fetchone()
        if row and row[0]:
            return {
                'company_id': company_id,
                'metric': 'average_roe',
                'value': row[0],
                'source': 'financial_ratios',
            }
        return None
    
    def calculate_stock_price_cagr(self, company_id: str, years: int) -> Dict[str, Any]:
        """Calculate stock price CAGR independently from stock_prices table"""
        cursor = self.conn.cursor()
        
        # Get oldest and newest prices
        cursor.execute("""
            SELECT MIN(date) as oldest_date, MAX(date) as newest_date
            FROM stock_prices
            WHERE company_id = ?
        """, (company_id,))
        
        date_row = cursor.fetchone()
        if not date_row or not date_row[0] or not date_row[1]:
            return None
        
        oldest_date = date_row[0]
        newest_date = date_row[1]
        
        # Get prices for those dates
        cursor.execute("""
            SELECT price FROM stock_prices
            WHERE company_id = ? AND date = ?
            LIMIT 1
        """, (company_id, oldest_date))
        oldest_price_row = cursor.fetchone()
        
        cursor.execute("""
            SELECT price FROM stock_prices
            WHERE company_id = ? AND date = ?
            LIMIT 1
        """, (company_id, newest_date))
        newest_price_row = cursor.fetchone()
        
        if not oldest_price_row or not newest_price_row:
            return None
        
        oldest_price = oldest_price_row[0]
        newest_price = newest_price_row[0]
        
        if oldest_price <= 0:
            return None
        
        # Calculate CAGR: (ending/beginning)^(1/years) - 1
        try:
            cagr_pct = ((newest_price / oldest_price) ** (1.0 / years) - 1) * 100
            return {
                'company_id': company_id,
                'metric': 'stock_price_cagr',
                'value': cagr_pct,
                'source': 'stock_prices_calc',
                'oldest_date': oldest_date,
                'newest_date': newest_date,
                'oldest_price': oldest_price,
                'newest_price': newest_price,
                'years': years,
            }
        except:
            return None
    
    def compare_values(self, parsed_value: float, reference_value: float, field_name: str) -> Dict[str, Any]:
        """Compare two values and determine if divergence is material"""
        if parsed_value is None or reference_value is None:
            return {
                'parsed': parsed_value,
                'reference': reference_value,
                'divergence_pct': None,
                'is_divergent': False,
                'reason': 'Missing value',
            }
        
        # Calculate absolute divergence
        if reference_value == 0:
            divergence_pct = abs(parsed_value - reference_value)
        else:
            divergence_pct = abs((parsed_value - reference_value) / reference_value * 100)
        
        is_divergent = divergence_pct > self.DIVERGENCE_THRESHOLD
        
        return {
            'parsed': parsed_value,
            'reference': reference_value,
            'divergence_pct': divergence_pct,
            'is_divergent': is_divergent,
            'threshold': self.DIVERGENCE_THRESHOLD,
        }
    
    def validate_parsed_row(self, parsed_row: Dict[str, Any]) -> Dict[str, Any]:
        """Validate a single parsed row against financial data"""
        company_id = parsed_row['company_id']
        metric_type = parsed_row['metric_type']
        parsed_value = parsed_row['value_pct']
        period_years = parsed_row['period_years']
        
        validation = {
            'id': parsed_row['id'],
            'company_id': company_id,
            'metric_type': metric_type,
            'parsed_value': parsed_value,
            'reference_value': None,
            'reference_source': None,
            'divergence_pct': None,
            'is_divergent': False,
            'validation_notes': None,
        }
        
        try:
            if metric_type == 'compounded_sales_growth':
                # Compare against 5-year revenue CAGR
                ref_data = self.get_revenue_cagr(company_id)
                if ref_data and ref_data['value'] is not None:
                    comparison = self.compare_values(parsed_value, ref_data['value'], 'sales_growth')
                    validation['reference_value'] = ref_data['value']
                    validation['reference_source'] = 'financial_ratios.revenue_cagr_5yr'
                    validation['divergence_pct'] = comparison['divergence_pct']
                    validation['is_divergent'] = comparison['is_divergent']
                    validation['validation_notes'] = 'Compared against 5-year revenue CAGR'
                else:
                    validation['validation_notes'] = 'No reference revenue CAGR found'
            
            elif metric_type == 'compounded_profit_growth':
                # Compare against 5-year PAT CAGR
                ref_data = self.get_pat_cagr(company_id)
                if ref_data and ref_data['value'] is not None:
                    comparison = self.compare_values(parsed_value, ref_data['value'], 'profit_growth')
                    validation['reference_value'] = ref_data['value']
                    validation['reference_source'] = 'financial_ratios.pat_cagr_5yr'
                    validation['divergence_pct'] = comparison['divergence_pct']
                    validation['is_divergent'] = comparison['is_divergent']
                    validation['validation_notes'] = 'Compared against 5-year PAT CAGR'
                else:
                    validation['validation_notes'] = 'No reference PAT CAGR found'
            
            elif metric_type == 'roe':
                # Compare against average ROE
                ref_data = self.get_average_roe(company_id)
                if ref_data and ref_data['value'] is not None:
                    comparison = self.compare_values(parsed_value, ref_data['value'], 'roe')
                    validation['reference_value'] = ref_data['value']
                    validation['reference_source'] = 'financial_ratios.return_on_equity_pct (average)'
                    validation['divergence_pct'] = comparison['divergence_pct']
                    validation['is_divergent'] = comparison['is_divergent']
                    validation['validation_notes'] = 'Compared against average ROE'
                else:
                    validation['validation_notes'] = 'No reference ROE found'
            
            elif metric_type == 'stock_price_cagr':
                # Calculate independent CAGR from stock prices
                if period_years:
                    ref_data = self.calculate_stock_price_cagr(company_id, period_years)
                    if ref_data and ref_data['value'] is not None:
                        comparison = self.compare_values(parsed_value, ref_data['value'], 'stock_cagr')
                        validation['reference_value'] = ref_data['value']
                        validation['reference_source'] = 'stock_prices (independent calculation)'
                        validation['divergence_pct'] = comparison['divergence_pct']
                        validation['is_divergent'] = comparison['is_divergent']
                        validation['validation_notes'] = f"Independently calculated from stock prices ({ref_data.get('oldest_date')} to {ref_data.get('newest_date')})"
                    else:
                        validation['validation_notes'] = 'Insufficient stock price data for independent calculation'
                else:
                    validation['validation_notes'] = 'Period years not available for stock CAGR calculation'
        
        except Exception as e:
            validation['validation_notes'] = f'Validation error: {str(e)}'
        
        return validation
    
    def close(self):
        """Close database connection"""
        self.conn.close()


def cross_validate_analysis(parsed_csv_path: str, db_path: str, output_path: str):
    """
    Cross-validate all parsed analysis rows
    
    Args:
        parsed_csv_path: Path to analysis_parsed.csv
        db_path: Path to nifty100.db
        output_path: Path for output CSV
    """
    print("Loading parsed analysis data...")
    parsed_df = pd.read_csv(parsed_csv_path)
    print(f"  Loaded {len(parsed_df)} parsed rows")
    print()
    
    validator = CrossValidator(db_path)
    
    print("Cross-validating against financial data...")
    validations = []
    divergences = []
    
    for idx, row in parsed_df.iterrows():
        validation = validator.validate_parsed_row(row.to_dict())
        validations.append(validation)
        
        if validation['is_divergent']:
            divergences.append(validation)
    
    validator.close()
    
    # Write validation results
    val_df = pd.DataFrame(validations)
    val_df.to_csv(output_path, index=False)
    
    print(f"  ✓ Wrote {len(validations)} validation results to {output_path}")
    print()
    
    # Summary
    print("Cross-Validation Summary:")
    print(f"  Total validations: {len(validations)}")
    print(f"  Validations with reference data: {len([v for v in validations if v['reference_value'] is not None])}")
    print(f"  Divergences detected: {len(divergences)}")
    
    if divergences:
        print()
        print("Divergence Details:")
        for div in divergences[:10]:  # Show first 10
            print(f"  {div['company_id']} {div['metric_type']}: parsed={div['parsed_value']:.2f}%, ref={div['reference_value']:.2f}%, diff={div['divergence_pct']:.2f}%")
        if len(divergences) > 10:
            print(f"  ... and {len(divergences) - 10} more")
    
    return validations, divergences


if __name__ == '__main__':
    cross_validate_analysis(
        'output/analysis_parsed.csv',
        'nifty100.db',
        'output/analysis_cross_validation.csv'
    )
