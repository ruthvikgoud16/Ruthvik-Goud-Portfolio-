"""Independent 12+12 rule audit for D-14. Does not invent signals."""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import pandas as pd

from src.analytics.company_panel import PROJECT_ROOT, consecutive_numeric, strictly_monotonic
from src.analytics.leverage import LeverageRatios
from src.analytics.ratios import ProfitabilityRatios
from src.nlp.pros_cons_generator import (
    CompanyContext,
    _finite,
    _series_col,
    build_contexts,
    connect,
    evaluate_cons,
    evaluate_pros,
)

AUDIT_PATH = PROJECT_ROOT / "output" / "D14_RULE_AUDIT.csv"
FINAL_AUDIT_PATH = PROJECT_ROOT / "output" / "D14_PROS_CONS_FINAL_AUDIT.csv"


def _audit_row(
    ctx: CompanyContext,
    rule_id: str,
    rule_type: str,
    raw_signal,
    calculated_signal,
    threshold,
    generated: bool,
    reason: str,
    confidence_pct=None,
) -> dict:
    return {
        "company_id": ctx.company_id,
        "ticker": ctx.company_id,
        "rule_id": rule_id,
        "rule_type": rule_type,
        "raw_signal": raw_signal,
        "calculated_signal": calculated_signal,
        "threshold": threshold,
        "confidence_pct": confidence_pct if generated else None,
        "generated": generated,
        "reason": reason,
    }


def audit_company(ctx: CompanyContext) -> List[dict]:
    generated = {(r["rule_id"], r["confidence_pct"]) for r in evaluate_pros(ctx) + evaluate_cons(ctx)}
    gen_ids = {rid for rid, _ in generated}
    conf = {rid: conf for rid, conf in generated}
    latest = ctx.latest_ratios
    latest_pl = ctx.latest_pl
    latest_bs = ctx.latest_bs
    prior_bs = ctx.bs.iloc[-2] if len(ctx.bs) >= 2 else None
    sector = ctx.sector or ""
    rows: List[dict] = []

    def fired(rule_id: str) -> bool:
        return rule_id in gen_ids

    roe_3 = consecutive_numeric(_series_col(ctx.ratios, "return_on_equity_pct"), 3)
    rows.append(_audit_row(
        ctx, "pro_01", "pro",
        raw_signal=None if roe_3 is None else min(roe_3),
        calculated_signal=None if roe_3 is None else all(v > 20 for v in roe_3),
        threshold="ROE>20 last 3 years",
        generated=fired("pro_01"),
        reason="insufficient 3 annual ROE values" if roe_3 is None else ("all three >20" if all(v > 20 for v in roe_3) else "not all three ROE>20"),
        confidence_pct=conf.get("pro_01"),
    ))

    fcf_5 = consecutive_numeric(_series_col(ctx.ratios, "free_cash_flow_cr"), 5)
    rows.append(_audit_row(
        ctx, "pro_02", "pro",
        raw_signal=None if fcf_5 is None else min(fcf_5),
        calculated_signal=None if fcf_5 is None else all(v > 0 for v in fcf_5),
        threshold="FCF>0 last 5 years",
        generated=fired("pro_02"),
        reason="insufficient 5 FCF years" if fcf_5 is None else ("all positive" if all(v > 0 for v in fcf_5) else "not 5 consecutive positive FCF"),
        confidence_pct=conf.get("pro_02"),
    ))

    de = _finite(latest["debt_to_equity"]) if latest is not None else None
    rows.append(_audit_row(
        ctx, "pro_03", "pro",
        raw_signal=de,
        calculated_signal=de is not None and abs(de) <= 1e-9,
        threshold="D/E=0",
        generated=fired("pro_03"),
        reason="D/E missing" if de is None else ("debt-free D/E" if abs(de) <= 1e-9 else "D/E not zero"),
        confidence_pct=conf.get("pro_03"),
    ))

    rev_cagr = _finite(latest["revenue_cagr_5yr"]) if latest is not None else None
    rows.append(_audit_row(
        ctx, "pro_04", "pro",
        raw_signal=rev_cagr,
        calculated_signal=rev_cagr is not None and rev_cagr > 15,
        threshold="revenue_cagr_5yr>15",
        generated=fired("pro_04"),
        reason="CAGR unavailable" if rev_cagr is None else ("above 15" if rev_cagr > 15 else "not above 15"),
        confidence_pct=conf.get("pro_04"),
    ))

    opm = _finite(latest["operating_profit_margin_pct"]) if latest is not None else None
    rows.append(_audit_row(
        ctx, "pro_05", "pro",
        raw_signal=opm,
        calculated_signal=opm is not None and opm > 25,
        threshold="OPM>25",
        generated=fired("pro_05"),
        reason="OPM missing" if opm is None else ("above 25" if opm > 25 else "not above 25"),
        confidence_pct=conf.get("pro_05"),
    ))

    pat_cagr = _finite(latest["pat_cagr_5yr"]) if latest is not None else None
    rows.append(_audit_row(
        ctx, "pro_06", "pro",
        raw_signal=pat_cagr,
        calculated_signal=pat_cagr is not None and pat_cagr > 20,
        threshold="pat_cagr_5yr>20",
        generated=fired("pro_06"),
        reason="PAT CAGR unavailable" if pat_cagr is None else ("above 20" if pat_cagr > 20 else "not above 20"),
        confidence_pct=conf.get("pro_06"),
    ))

    icr = _finite(latest["interest_coverage"]) if latest is not None else None
    interest = _finite(latest_pl.get("interest")) if latest_pl is not None else None
    debt_free = (de is not None and abs(de) <= 1e-9) or (interest is not None and interest == 0.0)
    rows.append(_audit_row(
        ctx, "pro_07", "pro",
        raw_signal=icr if icr is not None else interest,
        calculated_signal=(icr is not None and icr > 10) or debt_free,
        threshold="ICR>10 or Debt Free (D/E=0 or interest=0)",
        generated=fired("pro_07"),
        reason="ICR<=10 and not debt-free" if not ((icr is not None and icr > 10) or debt_free) else "ICR>10 or debt-free",
        confidence_pct=conf.get("pro_07"),
    ))

    fcf_latest = _finite(latest["free_cash_flow_cr"]) if latest is not None else None
    dy = _finite(ctx.dividend_yield_pct)
    rows.append(_audit_row(
        ctx, "pro_08", "pro",
        raw_signal=dy,
        calculated_signal=dy is not None and dy > 2 and fcf_latest is not None and fcf_latest > 0,
        threshold="div_yield>2 and FCF>0",
        generated=fired("pro_08"),
        reason="yield or FCF missing/below threshold",
        confidence_pct=conf.get("pro_08"),
    ))

    eps_cagr = _finite(latest["eps_cagr_5yr"]) if latest is not None else None
    rows.append(_audit_row(
        ctx, "pro_09", "pro",
        raw_signal=eps_cagr,
        calculated_signal=eps_cagr is not None and eps_cagr > 15,
        threshold="eps_cagr_5yr>15",
        generated=fired("pro_09"),
        reason="EPS CAGR unavailable or <=15",
        confidence_pct=conf.get("pro_09"),
    ))

    roe_hist = consecutive_numeric(_series_col(ctx.ratios, "return_on_equity_pct"), 4)
    rows.append(_audit_row(
        ctx, "pro_10", "pro",
        raw_signal=None if roe_hist is None else roe_hist[-1] - roe_hist[0],
        calculated_signal=roe_hist is not None and strictly_monotonic(roe_hist, True),
        threshold="ROE strictly rising last 4 years",
        generated=fired("pro_10"),
        reason="not 4-year strictly rising ROE",
        confidence_pct=conf.get("pro_10"),
    ))

    rows.append(_audit_row(
        ctx, "pro_11", "pro",
        raw_signal=None if pat_cagr is None or rev_cagr is None else pat_cagr - rev_cagr,
        calculated_signal=pat_cagr is not None and rev_cagr is not None and pat_cagr > rev_cagr,
        threshold="pat_cagr_5yr>revenue_cagr_5yr",
        generated=fired("pro_11"),
        reason="PAT CAGR not greater than revenue CAGR or CAGR missing",
        confidence_pct=conf.get("pro_11"),
    ))

    assets_ok = False
    if latest_bs is not None and prior_bs is not None:
        a0 = _finite(prior_bs.get("total_assets"))
        a1 = _finite(latest_bs.get("total_assets"))
        d0 = _finite(prior_bs.get("borrowings"))
        d1 = _finite(latest_bs.get("borrowings"))
        assets_ok = a0 is not None and a1 is not None and d0 is not None and d1 is not None and a1 > a0 and d1 < d0
    rows.append(_audit_row(
        ctx, "pro_12", "pro",
        raw_signal=None,
        calculated_signal=assets_ok,
        threshold="assets up AND borrowings down",
        generated=fired("pro_12"),
        reason="assets/debt trend not met or missing",
        confidence_pct=conf.get("pro_12"),
    ))

    rows.append(_audit_row(
        ctx, "con_01", "con",
        raw_signal=de,
        calculated_signal=de is not None and de > 2 and sector != "Financials",
        threshold="D/E>2 non-Financials",
        generated=fired("con_01"),
        reason="Financials excluded or D/E<=2 or missing",
        confidence_pct=conf.get("con_01"),
    ))

    fcf_3 = consecutive_numeric(_series_col(ctx.ratios, "free_cash_flow_cr"), 3)
    rows.append(_audit_row(
        ctx, "con_02", "con",
        raw_signal=None if fcf_3 is None else max(fcf_3),
        calculated_signal=fcf_3 is not None and all(v < 0 for v in fcf_3),
        threshold="FCF<0 last 3 years",
        generated=fired("con_02"),
        reason="not 3 consecutive negative FCF",
        confidence_pct=conf.get("con_02"),
    ))

    opm_hist = consecutive_numeric(_series_col(ctx.ratios, "operating_profit_margin_pct"), 4)
    rows.append(_audit_row(
        ctx, "con_03", "con",
        raw_signal=None if opm_hist is None else opm_hist[-1] - opm_hist[0],
        calculated_signal=opm_hist is not None and strictly_monotonic(opm_hist, False),
        threshold="OPM strictly falling last 4 years",
        generated=fired("con_03"),
        reason="not 4-year declining OPM",
        confidence_pct=conf.get("con_03"),
    ))

    npm = _finite(latest_pl.get("net_profit")) if latest_pl is not None else None
    rows.append(_audit_row(
        ctx, "con_04", "con",
        raw_signal=npm,
        calculated_signal=npm is not None and npm < 0,
        threshold="net_profit<0 latest year",
        generated=fired("con_04"),
        reason="latest PAT not negative",
        confidence_pct=conf.get("con_04"),
    ))

    sales_hist = consecutive_numeric(_series_col(ctx.pl, "sales"), 3)
    rows.append(_audit_row(
        ctx, "con_05", "con",
        raw_signal=None if sales_hist is None else sales_hist[-1] - sales_hist[0],
        calculated_signal=sales_hist is not None and strictly_monotonic(sales_hist, False),
        threshold="sales strictly falling last 3 years",
        generated=fired("con_05"),
        reason="not 2+ years revenue contraction",
        confidence_pct=conf.get("con_05"),
    ))

    rows.append(_audit_row(
        ctx, "con_06", "con",
        raw_signal=icr,
        calculated_signal=icr is not None and icr < 1.5,
        threshold="ICR<1.5",
        generated=fired("con_06"),
        reason="ICR missing (including Debt Free) or >=1.5",
        confidence_pct=conf.get("con_06"),
    ))

    payout = _finite(latest["dividend_payout_ratio_pct"]) if latest is not None else None
    rows.append(_audit_row(
        ctx, "con_07", "con",
        raw_signal=payout,
        calculated_signal=payout is not None and payout > 100,
        threshold="payout>100",
        generated=fired("con_07"),
        reason="payout missing or <=100",
        confidence_pct=conf.get("con_07"),
    ))

    de_hist = consecutive_numeric(_series_col(ctx.ratios, "debt_to_equity"), 4)
    rows.append(_audit_row(
        ctx, "con_08", "con",
        raw_signal=None if de_hist is None else de_hist[-1] - de_hist[0],
        calculated_signal=de_hist is not None and strictly_monotonic(de_hist, True),
        threshold="D/E strictly rising last 4 years",
        generated=fired("con_08"),
        reason="not 3-year rising D/E",
        confidence_pct=conf.get("con_08"),
    ))

    eps_hist = consecutive_numeric(_series_col(ctx.pl, "eps"), 4)
    rows.append(_audit_row(
        ctx, "con_09", "con",
        raw_signal=None if eps_hist is None else eps_hist[-1] - eps_hist[0],
        calculated_signal=eps_hist is not None and strictly_monotonic(eps_hist, False),
        threshold="EPS strictly falling last 4 years",
        generated=fired("con_09"),
        reason="not 3-year declining EPS",
        confidence_pct=conf.get("con_09"),
    ))

    roce = None
    if latest_pl is not None and latest_bs is not None:
        op = _finite(latest_pl.get("operating_profit"))
        oi = _finite(latest_pl.get("other_income")) or 0.0
        ebit = (op + oi) if op is not None else None
        roce = ProfitabilityRatios.roce(
            ebit,
            _finite(latest_bs.get("equity_capital")),
            _finite(latest_bs.get("reserves")),
            _finite(latest_bs.get("borrowings")),
        )
    if roce is None:
        roce = _finite(ctx.source_roce_pct)
    rows.append(_audit_row(
        ctx, "con_10", "con",
        raw_signal=roce,
        calculated_signal=roce is not None and roce < 10,
        threshold="ROCE<10",
        generated=fired("con_10"),
        reason="ROCE missing or >=10",
        confidence_pct=conf.get("con_10"),
    ))

    nd_ok = False
    nd_ratio = None
    if latest_bs is not None and latest_pl is not None:
        net_debt = LeverageRatios.net_debt(
            _finite(latest_bs.get("borrowings")),
            _finite(latest_bs.get("investments")),
        )
        op = _finite(latest_pl.get("operating_profit"))
        dep = _finite(latest_pl.get("depreciation")) or 0.0
        ebitda = (op + dep) if op is not None else None
        if net_debt is not None and ebitda is not None and ebitda > 0:
            nd_ratio = net_debt / ebitda
            nd_ok = net_debt > 3.0 * ebitda
    rows.append(_audit_row(
        ctx, "con_11", "con",
        raw_signal=nd_ratio,
        calculated_signal=nd_ok,
        threshold="net_debt>3x EBITDA",
        generated=fired("con_11"),
        reason="net debt/EBITDA missing or <=3",
        confidence_pct=conf.get("con_11"),
    ))

    rows.append(_audit_row(
        ctx, "con_12", "con",
        raw_signal=rev_cagr,
        calculated_signal=rev_cagr is not None and rev_cagr < 5,
        threshold="revenue_cagr_5yr<5",
        generated=fired("con_12"),
        reason="CAGR missing or >=5",
        confidence_pct=conf.get("con_12"),
    ))
    return rows


def write_d14_audits(generated: pd.DataFrame, company_ids) -> None:
    conn = connect()
    contexts = build_contexts(conn)
    conn.close()
    records = []
    for ctx in contexts:
        records.extend(audit_company(ctx))
    pd.DataFrame(records).to_csv(AUDIT_PATH, index=False)
    from src.nlp.pros_cons_generator import write_final_audit

    write_final_audit(generated, company_ids, FINAL_AUDIT_PATH)
