"""
Day 30 — Auto Pros/Cons Generator

Implements the 12 pro rules and 12 con rules from the Sprint 5 specification.
Uses Ratio Engine / cash-flow KPIs already stored in nifty100.db.

Only rows with confidence_pct > 60 are written.
No fabricated companies or metrics.
"""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Dict, List, Optional, Sequence

import pandas as pd

from src.analytics.cashflow_kpis import CashFlowKPIs
from src.analytics.company_panel import (
    DEFAULT_DB,
    PROJECT_ROOT,
    company_tail,
    consecutive_numeric,
    connect,
    latest_dividend_yield,
    load_companies_sectors,
    load_ratios_history,
    load_statements,
    strictly_monotonic,
)
from src.analytics.leverage import LeverageRatios
from src.analytics.ratios import ProfitabilityRatios

OUTPUT_PATH = PROJECT_ROOT / "output" / "pros_cons_generated.csv"
CONFIDENCE_MIN = 60.0  # exclusive per spec: include only if confidence > 60%

PRO_TEXT = {
    1: "Consistently high return on equity above 20% demonstrates exceptional capital efficiency",
    2: "Strong free cash flow generation over 5 years signals healthy business fundamentals",
    3: "Debt-free balance sheet provides financial flexibility and eliminates interest burden",
    4: "Revenue growing at above 15% CAGR over 5 years reflects strong business momentum",
    5: "Operating profit margin above 25% indicates strong pricing power and cost discipline",
    6: "Net profit compounding at above 20% over 5 years creates significant shareholder value",
    7: "Very high interest coverage ratio reflects negligible financial stress from debt servicing",
    8: "Consistent dividend yield above 2% backed by positive free cash flow",
    9: "Earnings per share growing above 15% CAGR indicates strong earnings quality and compounding",
    10: "Return on equity improving for 3 consecutive years shows strengthening business quality",
    11: "Revenue growing slower than profits shows improving operating leverage and scale benefits",
    12: "Growing asset base funded by internal accruals reflects self-sustaining growth",
}

CON_TEXT = {
    1: "Debt-to-equity ratio of {x} is elevated for a non-financial company and warrants monitoring",
    2: "Free cash flow negative for 3 consecutive years raises concern about cash generation quality",
    3: "Operating margins declining for 3 consecutive years suggest pricing or cost pressure",
    4: "Company reported a net loss in the most recent financial year",
    5: "Revenue contraction over 2 consecutive years indicates demand weakness or market share loss",
    6: "Interest coverage ratio below 1.5x indicates the company is at risk of not meeting its debt obligations",
    7: "Dividend payout ratio above 100% means the company is paying dividends from reserves, which is unsustainable",
    8: "Rising debt-to-equity ratio over 3 years suggests increasing financial leverage risk",
    9: "Earnings per share declining for 3 consecutive years reflects deteriorating profitability",
    10: "Return on capital employed below 10% suggests the business is not generating sufficient returns on invested capital",
    11: "Net debt exceeding 3 times EBITDA is a high leverage ratio and limits financial flexibility",
    12: "Revenue growing at below 5% over 5 years lags inflation and suggests limited business momentum",
}


def _finite(value) -> Optional[float]:
    if value is None:
        return None
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if pd.isna(number):
        return None
    return number


def _clip_confidence(score: float) -> float:
    return round(min(100.0, max(61.0, score)), 2)


def strength_above(value: float, threshold: float, scale: float) -> float:
    """Map how far a value exceeds a threshold onto 61–100."""
    excess = (value - threshold) / scale if scale else 0.0
    return _clip_confidence(70.0 + 30.0 * max(0.0, min(1.0, excess)))


def strength_below(value: float, threshold: float, scale: float) -> float:
    shortfall = (threshold - value) / scale if scale else 0.0
    return _clip_confidence(70.0 + 30.0 * max(0.0, min(1.0, shortfall)))


@dataclass
class CompanyContext:
    company_id: str
    sector: Optional[str]
    ratios: pd.DataFrame
    pl: pd.DataFrame
    bs: pd.DataFrame
    cf: pd.DataFrame
    dividend_yield_pct: Optional[float]
    source_roce_pct: Optional[float]

    @property
    def latest_ratios(self) -> Optional[pd.Series]:
        if self.ratios.empty:
            return None
        return self.ratios.iloc[-1]

    @property
    def latest_pl(self) -> Optional[pd.Series]:
        if self.pl.empty:
            return None
        return self.pl.iloc[-1]

    @property
    def latest_bs(self) -> Optional[pd.Series]:
        if self.bs.empty:
            return None
        return self.bs.iloc[-1]


def _series_col(frame: pd.DataFrame, column: str) -> List[Optional[float]]:
    if frame.empty or column not in frame.columns:
        return []
    return [_finite(v) for v in frame[column].tolist()]


def evaluate_pros(ctx: CompanyContext) -> List[dict]:
    rows: List[dict] = []
    latest = ctx.latest_ratios
    latest_pl = ctx.latest_pl
    latest_bs = ctx.latest_bs
    prior_bs = ctx.bs.iloc[-2] if len(ctx.bs) >= 2 else None

    # Pro 1: ROE > 20% for last 3 years
    roe_3 = consecutive_numeric(_series_col(ctx.ratios, "return_on_equity_pct"), 3)
    if roe_3 is not None and all(v > 20.0 for v in roe_3):
        rows.append(_row(ctx, "pro", 1, PRO_TEXT[1], strength_above(min(roe_3), 20.0, 20.0)))

    # Pro 2: FCF positive 5 consecutive years
    fcf_5 = consecutive_numeric(_series_col(ctx.ratios, "free_cash_flow_cr"), 5)
    if fcf_5 is not None and all(v > 0 for v in fcf_5):
        rows.append(_row(ctx, "pro", 2, PRO_TEXT[2], strength_above(min(fcf_5), 0.0, 5000.0)))

    # Pro 3: D/E = 0 latest year (treat floating-point zeros as debt-free)
    de = _finite(latest["debt_to_equity"]) if latest is not None else None
    interest = _finite(latest_pl.get("interest")) if latest_pl is not None else None
    debt_free_de = de is not None and abs(de) <= 1e-9
    debt_free_interest = interest is not None and interest == 0.0
    debt_free = debt_free_de or debt_free_interest
    if debt_free_de:
        rows.append(_row(ctx, "pro", 3, PRO_TEXT[3], 95.0))

    # Pro 4: Revenue CAGR > 15%
    rev_cagr = _finite(latest["revenue_cagr_5yr"]) if latest is not None else None
    if rev_cagr is not None and rev_cagr > 15.0:
        rows.append(_row(ctx, "pro", 4, PRO_TEXT[4], strength_above(rev_cagr, 15.0, 25.0)))

    # Pro 5: OPM > 25% latest
    opm = _finite(latest["operating_profit_margin_pct"]) if latest is not None else None
    if opm is not None and opm > 25.0:
        rows.append(_row(ctx, "pro", 5, PRO_TEXT[5], strength_above(opm, 25.0, 25.0)))

    # Pro 6: PAT CAGR > 20%
    pat_cagr = _finite(latest["pat_cagr_5yr"]) if latest is not None else None
    if pat_cagr is not None and pat_cagr > 20.0:
        rows.append(_row(ctx, "pro", 6, PRO_TEXT[6], strength_above(pat_cagr, 20.0, 30.0)))

    # Pro 7: ICR > 10 or Debt Free
    icr = _finite(latest["interest_coverage"]) if latest is not None else None
    if (icr is not None and icr > 10.0) or debt_free:
        score = 92.0 if debt_free else strength_above(icr or 0.0, 10.0, 40.0)
        rows.append(_row(ctx, "pro", 7, PRO_TEXT[7], score))

    # Pro 8: Dividend yield > 2% and FCF positive
    fcf_latest = _finite(latest["free_cash_flow_cr"]) if latest is not None else None
    dy = _finite(ctx.dividend_yield_pct)
    if dy is not None and dy > 2.0 and fcf_latest is not None and fcf_latest > 0:
        rows.append(_row(ctx, "pro", 8, PRO_TEXT[8], strength_above(dy, 2.0, 3.0)))

    # Pro 9: EPS CAGR > 15%
    eps_cagr = _finite(latest["eps_cagr_5yr"]) if latest is not None else None
    if eps_cagr is not None and eps_cagr > 15.0:
        rows.append(_row(ctx, "pro", 9, PRO_TEXT[9], strength_above(eps_cagr, 15.0, 25.0)))

    # Pro 10: ROE improving 3 consecutive years → last 4 observations strictly rising
    roe_hist = consecutive_numeric(_series_col(ctx.ratios, "return_on_equity_pct"), 4)
    if roe_hist is not None and strictly_monotonic(roe_hist, increasing=True):
        rows.append(_row(ctx, "pro", 10, PRO_TEXT[10], strength_above(roe_hist[-1] - roe_hist[0], 0.0, 10.0)))

    # Pro 11: operating leverage — PAT CAGR > Revenue CAGR (text is source of truth)
    if (
        rev_cagr is not None
        and pat_cagr is not None
        and pat_cagr > rev_cagr
    ):
        rows.append(
            _row(
                ctx,
                "pro",
                11,
                PRO_TEXT[11],
                strength_above(pat_cagr - rev_cagr, 0.0, 15.0),
            )
        )

    # Pro 12: assets growing AND debt declining
    if latest_bs is not None and prior_bs is not None:
        assets_now = _finite(latest_bs.get("total_assets"))
        assets_prior = _finite(prior_bs.get("total_assets"))
        debt_now = _finite(latest_bs.get("borrowings"))
        debt_prior = _finite(prior_bs.get("borrowings"))
        if (
            assets_now is not None
            and assets_prior is not None
            and debt_now is not None
            and debt_prior is not None
            and assets_now > assets_prior
            and debt_now < debt_prior
        ):
            rows.append(_row(ctx, "pro", 12, PRO_TEXT[12], 78.0))

    return rows


def evaluate_cons(ctx: CompanyContext) -> List[dict]:
    rows: List[dict] = []
    latest = ctx.latest_ratios
    latest_pl = ctx.latest_pl
    latest_bs = ctx.latest_bs
    latest_cf = ctx.cf.iloc[-1] if not ctx.cf.empty else None
    sector = ctx.sector or ""

    de = _finite(latest["debt_to_equity"]) if latest is not None else None
    # Con 1: D/E > 2 for non-financials
    if de is not None and de > 2.0 and sector != "Financials":
        text = CON_TEXT[1].format(x=f"{de:.2f}")
        rows.append(_row(ctx, "con", 1, text, strength_above(de, 2.0, 3.0)))

    # Con 2: FCF negative 3 consecutive years
    fcf_3 = consecutive_numeric(_series_col(ctx.ratios, "free_cash_flow_cr"), 3)
    if fcf_3 is not None and all(v < 0 for v in fcf_3):
        rows.append(_row(ctx, "con", 2, CON_TEXT[2], strength_below(max(fcf_3), 0.0, 5000.0)))

    # Con 3: OPM declining 3 consecutive years → last 4 values strictly falling
    opm_hist = consecutive_numeric(_series_col(ctx.ratios, "operating_profit_margin_pct"), 4)
    if opm_hist is not None and strictly_monotonic(opm_hist, increasing=False):
        rows.append(_row(ctx, "con", 3, CON_TEXT[3], 80.0))

    # Con 4: net profit negative latest year
    npm = _finite(latest_pl.get("net_profit")) if latest_pl is not None else None
    if npm is not None and npm < 0:
        rows.append(_row(ctx, "con", 4, CON_TEXT[4], strength_below(npm, 0.0, 5000.0)))

    # Con 5: revenue declining 2+ years → last 3 sales strictly falling
    sales_hist = consecutive_numeric(_series_col(ctx.pl, "sales"), 3)
    if sales_hist is not None and strictly_monotonic(sales_hist, increasing=False):
        rows.append(_row(ctx, "con", 5, CON_TEXT[5], 82.0))

    # Con 6: ICR < 1.5
    icr = _finite(latest["interest_coverage"]) if latest is not None else None
    if icr is not None and icr < 1.5:
        rows.append(_row(ctx, "con", 6, CON_TEXT[6], strength_below(icr, 1.5, 1.5)))

    # Con 7: dividend payout > 100%
    payout = _finite(latest["dividend_payout_ratio_pct"]) if latest is not None else None
    if payout is not None and payout > 100.0:
        rows.append(_row(ctx, "con", 7, CON_TEXT[7], strength_above(payout, 100.0, 50.0)))

    # Con 8: D/E rising 3 consecutive years
    de_hist = consecutive_numeric(_series_col(ctx.ratios, "debt_to_equity"), 4)
    if de_hist is not None and strictly_monotonic(de_hist, increasing=True):
        rows.append(_row(ctx, "con", 8, CON_TEXT[8], 76.0))

    # Con 9: EPS declining 3 consecutive years
    eps_hist = consecutive_numeric(_series_col(ctx.pl, "eps"), 4)
    if eps_hist is not None and strictly_monotonic(eps_hist, increasing=False):
        rows.append(_row(ctx, "con", 9, CON_TEXT[9], 78.0))

    # Con 10: ROCE < 10% — computed from statements, fallback to source roce
    roce = None
    if latest_pl is not None and latest_bs is not None:
        ebit = None
        op = _finite(latest_pl.get("operating_profit"))
        oi = _finite(latest_pl.get("other_income")) or 0.0
        if op is not None:
            ebit = op + oi
        roce = ProfitabilityRatios.roce(
            ebit,
            _finite(latest_bs.get("equity_capital")),
            _finite(latest_bs.get("reserves")),
            _finite(latest_bs.get("borrowings")),
        )
    if roce is None:
        roce = _finite(ctx.source_roce_pct)
    if roce is not None and roce < 10.0:
        rows.append(_row(ctx, "con", 10, CON_TEXT[10], strength_below(roce, 10.0, 10.0)))

    # Con 11: Net Debt > 3x EBITDA
    if latest_bs is not None and latest_pl is not None:
        net_debt = LeverageRatios.net_debt(
            _finite(latest_bs.get("borrowings")),
            _finite(latest_bs.get("investments")),
        )
        op = _finite(latest_pl.get("operating_profit"))
        dep = _finite(latest_pl.get("depreciation")) or 0.0
        ebitda = (op + dep) if op is not None else None
        if net_debt is not None and ebitda is not None and ebitda > 0 and net_debt > 3.0 * ebitda:
            ratio = net_debt / ebitda
            rows.append(_row(ctx, "con", 11, CON_TEXT[11], strength_above(ratio, 3.0, 3.0)))

    # Con 12: Revenue CAGR < 5%
    rev_cagr = _finite(latest["revenue_cagr_5yr"]) if latest is not None else None
    if rev_cagr is not None and rev_cagr < 5.0:
        rows.append(_row(ctx, "con", 12, CON_TEXT[12], strength_below(rev_cagr, 5.0, 10.0)))

    return rows


def _row(ctx: CompanyContext, kind: str, rule_id: int, text: str, confidence: float) -> dict:
    return {
        "company_id": ctx.company_id,
        "type": kind,
        "rule_id": f"{kind}_{rule_id:02d}",
        "text": text,
        "confidence_pct": _clip_confidence(confidence),
    }


def build_contexts(conn: sqlite3.Connection) -> List[CompanyContext]:
    companies = load_companies_sectors(conn)
    ratios = load_ratios_history(conn)
    pl, bs, cf = load_statements(conn)
    yields = latest_dividend_yield(conn)
    contexts: List[CompanyContext] = []
    for _, row in companies.iterrows():
        cid = row["company_id"]
        contexts.append(
            CompanyContext(
                company_id=cid,
                sector=row["broad_sector"],
                ratios=ratios[ratios["company_id"] == cid].copy(),
                pl=pl[pl["company_id"] == cid].copy(),
                bs=bs[bs["company_id"] == cid].copy(),
                cf=cf[cf["company_id"] == cid].copy(),
                dividend_yield_pct=yields.get(cid),
                source_roce_pct=_finite(row["source_roce_pct"]),
            )
        )
    return contexts


def generate_pros_cons(db_path: Optional[Path] = None) -> pd.DataFrame:
    conn = connect(db_path)
    try:
        contexts = build_contexts(conn)
        records: List[dict] = []
        for ctx in contexts:
            records.extend(evaluate_pros(ctx))
            records.extend(evaluate_cons(ctx))
    finally:
        conn.close()

    df = pd.DataFrame(records, columns=["company_id", "type", "rule_id", "text", "confidence_pct"])
    if not df.empty:
        df = df[df["confidence_pct"] > CONFIDENCE_MIN].copy()
        df.sort_values(["company_id", "type", "rule_id"], inplace=True)
        df.reset_index(drop=True, inplace=True)
    return df


def write_final_audit(df: pd.DataFrame, company_ids: Sequence[str], path: Path) -> Path:
    conn = connect()
    names = {
        r[0]: r[0]
        for r in conn.execute("SELECT id FROM companies")
    }
    conn.close()
    rows = []
    for cid in company_ids:
        subset = df[df["company_id"] == cid] if not df.empty else df
        pro_count = int(((subset["type"] == "pro").sum()) if not subset.empty else 0)
        con_count = int(((subset["type"] == "con").sum()) if not subset.empty else 0)
        missing_pro = pro_count < 1
        missing_con = con_count < 1
        if missing_pro and missing_con:
            explanation = (
                "No official pro or con rule fired on the latest annual fiscal series "
                "after TTM exclusion and primary year-end selection. Not filled with generic text."
            )
        elif missing_pro:
            explanation = (
                "None of the 12 official pro rules met their numeric thresholds on the "
                "latest annual data. Source limitation; no fabricated pro."
            )
        elif missing_con:
            explanation = (
                "None of the 12 official con rules met their numeric thresholds on the "
                "latest annual data. Source limitation; no fabricated con."
            )
        else:
            explanation = "At least one official pro and one official con fired."
        rows.append(
            {
                "company_id": cid,
                "ticker": names.get(cid, cid),
                "pro_count": pro_count,
                "con_count": con_count,
                "missing_pro": missing_pro,
                "missing_con": missing_con,
                "explanation": explanation,
            }
        )
    audit = pd.DataFrame(rows)
    path.parent.mkdir(parents=True, exist_ok=True)
    audit.to_csv(path, index=False)
    return path


def coverage_report(df: pd.DataFrame, company_ids: Sequence[str]) -> Dict[str, List[str]]:
    missing_pro = []
    missing_con = []
    for cid in company_ids:
        subset = df[df["company_id"] == cid] if not df.empty else df
        types = set(subset["type"].tolist()) if not subset.empty else set()
        if "pro" not in types:
            missing_pro.append(cid)
        if "con" not in types:
            missing_con.append(cid)
    return {"missing_pro": missing_pro, "missing_con": missing_con}


def write_output(df: pd.DataFrame, path: Path = OUTPUT_PATH) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return path


def main() -> None:
    df = generate_pros_cons()
    conn = connect()
    ids = [r[0] for r in conn.execute("SELECT id FROM companies ORDER BY id")]
    conn.close()
    write_output(df)
    audit_path = PROJECT_ROOT / "output" / "PROS_CONS_FINAL_AUDIT.csv"
    write_final_audit(df, ids, audit_path)
    from src.nlp.rule_audit import write_d14_audits

    write_d14_audits(df, ids)
    cov = coverage_report(df, ids)
    print(f"Wrote {len(df)} rows to {OUTPUT_PATH}")
    print(f"Companies: {len(ids)}")
    print(f"Unique companies in output: {df['company_id'].nunique() if not df.empty else 0}")
    print(f"Missing pro: {len(cov['missing_pro'])} {cov['missing_pro']}")
    print(f"Missing con: {len(cov['missing_con'])} {cov['missing_con']}")


if __name__ == "__main__":
    main()
