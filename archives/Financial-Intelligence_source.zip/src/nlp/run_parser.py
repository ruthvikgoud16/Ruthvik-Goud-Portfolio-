"""
Day 29 NLP Parser Execution
===========================

Loads analysis.xlsx, parses all rows, generates:
- output/analysis_parsed.csv: Structured parsed results
- output/nlp_parse_failures.csv: Parse failures and debug info
"""

import sys
import pandas as pd
from pathlib import Path
from parser import AnalysisParser, parse_analysis_dataframe

def main():
    print("=" * 70)
    print("Day 29 NLP Analysis Text Parser")
    print("=" * 70)
    print()

    # Load analysis.xlsx
    print("1. Loading analysis.xlsx...")
    source = Path(__file__).resolve().parents[2] / "project_reference" / "source_data" / "excel" / "analysis.xlsx"
    df = pd.read_excel(source, header=0)
    
    # Rename columns
    df.columns = ['id', 'company_id', 'compounded_sales_growth', 'compounded_profit_growth', 'stock_price_cagr', 'roe']
    
    # Remove header row
    df = df[df['id'] != 'id'].reset_index(drop=True)
    
    print(f"   Loaded {len(df)} analysis rows")
    print(f"   Companies: {sorted(df['company_id'].unique())}")
    print()

    # Parse all rows
    print("2. Parsing analysis text fields...")
    parsed_rows, failures = parse_analysis_dataframe(df)
    
    print(f"   Parsed {len(parsed_rows)} rows")
    print(f"   Parse failures: {len(failures)}")
    print()

    # Generate analysis_parsed.csv
    print("3. Generating analysis_parsed.csv...")
    
    # Flatten parsed results
    flat_rows = []
    for parsed in parsed_rows:
        for field_name, field_result in parsed['fields'].items():
            if field_result['is_valid']:
                flat_rows.append({
                    'id': parsed['id'],
                    'company_id': parsed['company_id'],
                    'metric_type': field_name,
                    'period': field_result['period'],
                    'period_years': field_result['period_years'],
                    'value_pct': field_result['value_pct'],
                })
    
    parsed_df = pd.DataFrame(flat_rows)
    output_dir = Path('output')
    output_dir.mkdir(exist_ok=True)
    
    parsed_df.to_csv(output_dir / 'analysis_parsed.csv', index=False)
    print(f"   ✓ Wrote {len(parsed_df)} successful parses to analysis_parsed.csv")
    print()

    # Generate nlp_parse_failures.csv
    print("4. Generating nlp_parse_failures.csv...")
    
    if failures:
        failures_df = pd.DataFrame(failures)
        failures_df.to_csv(output_dir / 'nlp_parse_failures.csv', index=False)
        print(f"   ✓ Wrote {len(failures_df)} failures to nlp_parse_failures.csv")
    else:
        # Create empty file with schema
        failures_df = pd.DataFrame(columns=['row_id', 'company_id', 'field', 'raw_text', 'reason'])
        failures_df.to_csv(output_dir / 'nlp_parse_failures.csv', index=False)
        print(f"   ✓ Created empty nlp_parse_failures.csv (no failures)")
    print()

    # Coverage statistics
    print("5. Coverage Statistics")
    print("-" * 70)
    total_fields = len(df) * 4  # 4 fields per row
    successful_parses = len(parsed_df)
    failed_parses = len(failures)
    
    print(f"   Total source rows: {len(df)}")
    print(f"   Total fields: {total_fields}")
    print(f"   Successful parses: {successful_parses}")
    print(f"   Failed parses: {failed_parses}")
    print(f"   Success rate: {100 * successful_parses / total_fields:.1f}%")
    print()

    print(f"   Unique companies in source: {df['company_id'].nunique()}")
    print(f"   Unique companies in parsed: {parsed_df['company_id'].nunique()}")
    print()

    print(f"   Metrics parsed:")
    for metric in parsed_df['metric_type'].unique():
        count = len(parsed_df[parsed_df['metric_type'] == metric])
        print(f"     - {metric}: {count} rows")
    print()

    print("=" * 70)
    print("✓ Day 29 NLP Parser Complete")
    print("=" * 70)

if __name__ == '__main__':
    main()
