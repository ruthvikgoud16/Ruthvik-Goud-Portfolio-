"""
Day 29 NLP Text Parser for Analysis Table
==========================================

Parses free-text financial analysis fields into structured analytical rows.
Supports multiple period formats: "10 Years: 21%", "TTM: 43%", "1 Year: -2%", "Last Year: 12%"

Handles:
- Multi-word year formats (e.g., "10 Years", "1 Year", "Last Year", "TTM")
- Inconsistent spacing and optional colons
- Negative percentages
- Decimal percentages
- Empty/null values

No fabricated values. Every parse failure recorded and logged.
"""

import re
from dataclasses import dataclass
from typing import Optional, Dict, Any, Tuple
import logging

logger = logging.getLogger(__name__)


@dataclass
class ParseResult:
    """Structured parse result"""
    period: Optional[str] = None
    period_years: Optional[int] = None
    value_pct: Optional[float] = None
    is_valid: bool = False
    failure_reason: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'period': self.period,
            'period_years': self.period_years,
            'value_pct': self.value_pct,
            'is_valid': self.is_valid,
            'failure_reason': self.failure_reason,
        }


class AnalysisParser:
    """
    Deterministic parser for analysis text fields.
    
    Supported formats (discovered from analysis.xlsx):
    - "10 Years: 21%"
    - "5 Years:       24%"
    - "3 Years:       17%"
    - "TTM:            43%"
    - "1 Year:         -2%"
    - "Last Year:      12%"
    """

    # Regex patterns for different format types
    PATTERNS = [
        # Standard numeric years: "10 Years: 21%"
        {
            'name': 'numeric_years',
            'pattern': r'^\s*(\d+)\s+Years?\s*:?\s*([-+]?\d+(?:\.\d+)?)\s*%?\s*$',
            'period_group': 1,
            'value_group': 2,
        },
        # TTM format: "TTM: 43%"
        {
            'name': 'ttm',
            'pattern': r'^\s*TTM\s*:?\s*([-+]?\d+(?:\.\d+)?)\s*%?\s*$',
            'period_group': None,
            'value_group': 1,
            'period_value': 'TTM',
        },
        # Last Year format: "Last Year: 12%"
        {
            'name': 'last_year',
            'pattern': r'^\s*Last\s+Year\s*:?\s*([-+]?\d+(?:\.\d+)?)\s*%?\s*$',
            'period_group': None,
            'value_group': 1,
            'period_value': 'Last Year',
        },
        # Singular Year: "1 Year: -2%"
        {
            'name': 'singular_year',
            'pattern': r'^\s*(\d+)\s+Year\s*:?\s*([-+]?\d+(?:\.\d+)?)\s*%?\s*$',
            'period_group': 1,
            'value_group': 2,
        },
    ]

    @staticmethod
    def parse_period_value(raw_text: Optional[str]) -> ParseResult:
        """
        Parse a single analysis text field.
        
        Args:
            raw_text: Raw text from analysis table (e.g., "10 Years: 21%")
            
        Returns:
            ParseResult with extracted period, value, and status
        """
        # Handle None/null
        if raw_text is None or raw_text == '':
            return ParseResult(failure_reason='Null or empty input')

        # Convert to string and strip
        text = str(raw_text).strip()

        if not text or text == '':
            return ParseResult(failure_reason='Empty after strip')

        # Try each pattern
        for pattern_spec in AnalysisParser.PATTERNS:
            pattern = pattern_spec['pattern']
            try:
                match = re.match(pattern, text, re.IGNORECASE)
                if match:
                    # Extract value
                    value_group = pattern_spec['value_group']
                    value_str = match.group(value_group)
                    try:
                        value_pct = float(value_str)
                    except (ValueError, IndexError):
                        return ParseResult(failure_reason=f'Failed to convert value to float: {value_str}')

                    # Extract period
                    period_group = pattern_spec['period_group']
                    if period_group is not None:
                        try:
                            period_years = int(match.group(period_group))
                            period = f"{period_years} Years"
                        except (ValueError, IndexError):
                            return ParseResult(failure_reason='Failed to extract numeric years')
                    else:
                        period = pattern_spec.get('period_value', 'Unknown')
                        period_years = None

                    return ParseResult(
                        period=period,
                        period_years=period_years,
                        value_pct=value_pct,
                        is_valid=True,
                    )
            except Exception as e:
                # Continue to next pattern on exception
                continue

        # No pattern matched
        return ParseResult(failure_reason=f'No pattern matched. Text: {text}')

    @staticmethod
    def parse_analysis_row(row_dict: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse a full analysis row (all 4 fields).
        
        Args:
            row_dict: Dictionary with id, company_id, and 4 text fields
            
        Returns:
            Dictionary with parsed results and failure tracking
        """
        parsed = {
            'id': row_dict.get('id'),
            'company_id': row_dict.get('company_id'),
            'fields': {},
            'failures': [],
        }

        field_names = [
            'compounded_sales_growth',
            'compounded_profit_growth',
            'stock_price_cagr',
            'roe',
        ]

        for field in field_names:
            raw_value = row_dict.get(field)
            result = AnalysisParser.parse_period_value(raw_value)

            parsed['fields'][field] = result.to_dict()

            if not result.is_valid:
                parsed['failures'].append({
                    'field': field,
                    'raw_text': raw_value,
                    'reason': result.failure_reason,
                })

        return parsed


def parse_analysis_dataframe(df):
    """
    Parse all rows in analysis DataFrame.
    
    Args:
        df: pandas DataFrame with analysis data
        
    Returns:
        Tuple of (parsed_rows, failure_summaries)
    """
    parsed_rows = []
    failures = []

    for idx, row in df.iterrows():
        row_dict = {
            'id': row.get('id'),
            'company_id': row.get('company_id'),
            'compounded_sales_growth': row.get('compounded_sales_growth'),
            'compounded_profit_growth': row.get('compounded_profit_growth'),
            'stock_price_cagr': row.get('stock_price_cagr'),
            'roe': row.get('roe'),
        }

        parsed = AnalysisParser.parse_analysis_row(row_dict)
        parsed_rows.append(parsed)

        # Collect failures
        if parsed['failures']:
            for failure in parsed['failures']:
                failures.append({
                    'row_id': row_dict['id'],
                    'company_id': row_dict['company_id'],
                    **failure,
                })

    return parsed_rows, failures
