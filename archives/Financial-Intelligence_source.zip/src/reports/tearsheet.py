"""Day 33 — 2-page company tearsheet (ReportLab)."""

from __future__ import annotations

import io
from pathlib import Path
from typing import Optional

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image,
    KeepTogether,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from src.nlp.pros_cons_generator import _finite
from src.reports.data import kpi_value, load_company_bundle

NAVY = colors.HexColor("#0B1F3A")
GREEN = colors.HexColor("#1B7A4E")
RED = colors.HexColor("#B42318")
LIGHT = colors.HexColor("#F4F6FA")
GOLD = colors.HexColor("#C9A227")

PAGE_W, PAGE_H = A4


def _fmt(value: Optional[float], suffix: str = "", money: bool = False) -> str:
    if value is None:
        return "n/a"
    if money:
        return f"{value:,.0f} Cr"
    return f"{value:.1f}{suffix}"


def _chart_to_image(fig, width, height) -> Image:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=140, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    buf.seek(0)
    return Image(buf, width=width, height=height)


def _revenue_profit_chart(bundle: dict, width, height) -> Optional[Image]:
    pl = bundle["pl"].tail(10)
    if pl.empty:
        return None
    years = [str(y)[:4] for y in pl["year"]]
    fig, ax = plt.subplots(figsize=(7.2, 2.6))
    x = range(len(years))
    width_bar = 0.38
    ax.bar([i - width_bar / 2 for i in x], pl["sales"].fillna(0), width_bar, label="Revenue", color="#0B1F3A")
    ax.bar([i + width_bar / 2 for i in x], pl["net_profit"].fillna(0), width_bar, label="Net Profit", color="#C9A227")
    ax.set_xticks(list(x))
    ax.set_xticklabels(years, rotation=45, fontsize=7)
    ax.set_ylabel("₹ Cr", fontsize=8)
    ax.legend(fontsize=7, frameon=False)
    ax.set_title("Revenue & Net Profit (up to 10 years)", fontsize=9)
    fig.tight_layout()
    return _chart_to_image(fig, width, height)


def _roe_roce_chart(bundle: dict, width, height) -> Optional[Image]:
    ratios = bundle["ratios"].tail(10)
    if ratios.empty:
        return None
    years = [str(y)[:4] for y in ratios["year"]]
    fig, ax1 = plt.subplots(figsize=(7.2, 2.4))
    ax1.plot(years, ratios["return_on_equity_pct"], marker="o", color="#0B1F3A", label="ROE %")
    ax1.set_ylabel("ROE %", fontsize=8, color="#0B1F3A")
    ax2 = ax1.twinx()
    # ROCE series computed only for latest in bundle; plot source-equivalent from ratios if absent
    if "return_on_capital_employed_pct" in ratios.columns:
        ax2.plot(years, ratios["return_on_capital_employed_pct"], marker="s", color="#C9A227", label="ROCE %")
    else:
        ax2.axhline(bundle["roce"] or 0, color="#C9A227", linestyle="--", label="ROCE (latest)")
    ax2.set_ylabel("ROCE %", fontsize=8, color="#C9A227")
    ax1.set_title("ROE trend and latest ROCE", fontsize=9)
    ax1.tick_params(axis="x", labelrotation=45, labelsize=7)
    fig.tight_layout()
    return _chart_to_image(fig, width, height)


def _bs_chart(bundle: dict, width, height) -> Optional[Image]:
    bs = bundle["bs"].tail(8)
    if bs.empty:
        return None
    years = [str(y)[:4] for y in bs["year"]]
    equity = (bs["equity_capital"].fillna(0) + bs["reserves"].fillna(0)).tolist()
    borrowings = bs["borrowings"].fillna(0).tolist()
    other = bs["other_liabilities"].fillna(0).tolist()
    fig, ax = plt.subplots(figsize=(7.2, 2.6))
    ax.bar(years, equity, label="Equity", color="#1B7A4E")
    ax.bar(years, borrowings, bottom=equity, label="Borrowings", color="#B42318")
    bottom2 = [e + b for e, b in zip(equity, borrowings)]
    ax.bar(years, other, bottom=bottom2, label="Other liabilities", color="#6B7280")
    ax.set_title("Balance sheet composition", fontsize=9)
    ax.tick_params(axis="x", labelrotation=45, labelsize=7)
    ax.legend(fontsize=7, frameon=False)
    fig.tight_layout()
    return _chart_to_image(fig, width, height)


def _cf_waterfall(bundle: dict, width, height) -> Optional[Image]:
    cf = bundle["latest_cf"]
    if cf is None:
        return None
    labels = ["CFO", "CFI", "CFF", "Net"]
    values = [
        _finite(cf.get("operating_activity")) or 0.0,
        _finite(cf.get("investing_activity")) or 0.0,
        _finite(cf.get("financing_activity")) or 0.0,
        _finite(cf.get("net_cash_flow")) or 0.0,
    ]
    fig, ax = plt.subplots(figsize=(7.2, 2.4))
    bar_colors = ["#1B7A4E" if v >= 0 else "#B42318" for v in values]
    ax.bar(labels, values, color=bar_colors)
    ax.axhline(0, color="#111827", linewidth=0.6)
    ax.set_title(f"Cash flow waterfall ({cf.get('year')})", fontsize=9)
    fig.tight_layout()
    return _chart_to_image(fig, width, height)


def _styles():
    base = getSampleStyleSheet()
    styles = {
        "header": ParagraphStyle(
            "header",
            parent=base["Normal"],
            textColor=colors.white,
            fontSize=14,
            leading=18,
            fontName="Helvetica-Bold",
        ),
        "sub": ParagraphStyle(
            "sub",
            parent=base["Normal"],
            textColor=colors.white,
            fontSize=9,
            leading=12,
        ),
        "tile_label": ParagraphStyle(
            "tile_label",
            parent=base["Normal"],
            fontSize=7,
            textColor=colors.HexColor("#4B5563"),
            alignment=TA_CENTER,
        ),
        "tile_value": ParagraphStyle(
            "tile_value",
            parent=base["Normal"],
            fontSize=11,
            leading=13,
            fontName="Helvetica-Bold",
            alignment=TA_CENTER,
            textColor=NAVY,
        ),
        "body": ParagraphStyle(
            "body",
            parent=base["Normal"],
            fontSize=8,
            leading=11,
            wordWrap="CJK",
        ),
        "section": ParagraphStyle(
            "section",
            parent=base["Normal"],
            fontSize=10,
            fontName="Helvetica-Bold",
            textColor=NAVY,
            spaceBefore=4,
            spaceAfter=4,
        ),
        "badge": ParagraphStyle(
            "badge",
            parent=base["Normal"],
            fontSize=9,
            fontName="Helvetica-Bold",
            alignment=TA_CENTER,
            textColor=NAVY,
        ),
    }
    return styles


def build_tearsheet(company_id: str, output_path: Path) -> Path:
    bundle = load_company_bundle(company_id)
    if bundle is None:
        raise ValueError(f"Unknown company {company_id}")
    styles = _styles()
    output_path.parent.mkdir(parents=True, exist_ok=True)

    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=12 * mm,
        rightMargin=12 * mm,
        topMargin=12 * mm,
        bottomMargin=12 * mm,
        title=f"{company_id} tearsheet",
    )

    header_data = [[
        Paragraph(f"{bundle['company_name']}", styles["header"]),
        Paragraph(f"{company_id}<br/>{bundle['sector'] or 'Unclassified'}", styles["sub"]),
    ]]
    header = Table(header_data, colWidths=[130 * mm, 50 * mm])
    header.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), NAVY),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
    ]))

    tiles = [
        ("ROE", _fmt(kpi_value(bundle, "return_on_equity_pct"), "%")),
        ("NPM", _fmt(kpi_value(bundle, "net_profit_margin_pct"), "%")),
        ("D/E", _fmt(kpi_value(bundle, "debt_to_equity"))),
        ("FCF", _fmt(kpi_value(bundle, "free_cash_flow_cr"), money=True)),
        ("Rev CAGR 5y", _fmt(kpi_value(bundle, "revenue_cagr_5yr"), "%")),
        ("ROCE", _fmt(bundle["roce"], "%")),
    ]
    tile_cells = []
    row1 = []
    row2 = []
    for i, (label, value) in enumerate(tiles):
        cell = [Paragraph(label, styles["tile_label"]), Paragraph(str(value), styles["tile_value"])]
        inner = Table([[cell[0]], [cell[1]]], colWidths=[58 * mm])
        inner.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, -1), LIGHT),
            ("BOX", (0, 0), (-1, -1), 0.4, colors.HexColor("#D1D5DB")),
            ("TOPPADDING", (0, 0), (-1, -1), 6),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
            ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ]))
        (row1 if i < 3 else row2).append(inner)
    tile_table = Table([row1, row2], colWidths=[60 * mm] * 3)
    tile_table.setStyle(TableStyle([
        ("LEFTPADDING", (0, 0), (-1, -1), 2),
        ("RIGHTPADDING", (0, 0), (-1, -1), 2),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))

    story = [header, Spacer(1, 6), tile_table, Spacer(1, 6)]
    chart1 = _revenue_profit_chart(bundle, 170 * mm, 58 * mm)
    chart2 = _roe_roce_chart(bundle, 170 * mm, 52 * mm)
    if chart1:
        story.append(chart1)
    if chart2:
        story.append(chart2)

    def after_first_page(canvas, doc_):
        canvas.saveState()
        canvas.setFillColor(NAVY)
        canvas.rect(0, 0, PAGE_W, 10 * mm, fill=1, stroke=0)
        canvas.setFillColor(colors.white)
        canvas.setFont("Helvetica", 8)
        canvas.drawString(12 * mm, 3.5 * mm, f"N100 tearsheet · {company_id} · page {doc_.page}")
        canvas.restoreState()

    # Page 2 via page break
    from reportlab.platypus import PageBreak

    story.append(PageBreak())
    story.append(Paragraph("Balance sheet, cash flow, and qualitative signals", styles["section"]))
    bs_chart = _bs_chart(bundle, 170 * mm, 55 * mm)
    cf_chart = _cf_waterfall(bundle, 170 * mm, 50 * mm)
    if bs_chart:
        story.append(bs_chart)
    if cf_chart:
        story.append(cf_chart)

    badge_text = bundle.get("capital_label") or "Pattern n/a (insufficient cash-flow signs)"
    badge = Table([[Paragraph(f"Capital allocation: {badge_text}", styles["badge"])]], colWidths=[180 * mm])
    badge.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#FEF3C7")),
        ("BOX", (0, 0), (-1, -1), 0.6, GOLD),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(Spacer(1, 4))
    story.append(badge)
    story.append(Spacer(1, 6))

    def bullet_block(title, items, color):
        header_p = Paragraph(title, ParagraphStyle("h", parent=styles["section"], textColor=color))
        if not items:
            body = Paragraph(
                "No rule-triggered item above 60% confidence for this company in the latest year.",
                styles["body"],
            )
            return [header_p, body]
        lines = [header_p]
        for item in items:
            lines.append(Paragraph(f"• {item}", styles["body"]))
        return lines

    story.extend(bullet_block("Pros (rule engine)", bundle["pros"], GREEN))
    story.append(Spacer(1, 4))
    story.extend(bullet_block("Cons (rule engine)", bundle["cons"], RED))

    doc.build(story, onFirstPage=after_first_page, onLaterPages=after_first_page)
    return output_path
