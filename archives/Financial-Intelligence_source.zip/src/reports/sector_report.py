"""Day 34 — sector PDF reports (one file per actual broad_sector)."""

from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from src.nlp.pros_cons_generator import _finite
from src.reports.data import sector_medians

NAVY = colors.HexColor("#0B1F3A")

METRIC_COLS = [
    ("return_on_equity_pct", "ROE %"),
    ("net_profit_margin_pct", "NPM %"),
    ("operating_profit_margin_pct", "OPM %"),
    ("debt_to_equity", "D/E"),
    ("free_cash_flow_cr", "FCF Cr"),
    ("revenue_cagr_5yr", "Rev CAGR"),
    ("pat_cagr_5yr", "PAT CAGR"),
    ("interest_coverage", "ICR"),
]


def _fmt(v):
    if v is None or (isinstance(v, float) and (v != v)):
        return "n/a"
    try:
        return f"{float(v):.1f}"
    except (TypeError, ValueError):
        return "n/a"


def build_sector_report(sector: str, output_path: Path) -> Path:
    df = sector_medians()
    subset = df[df["broad_sector"] == sector].copy()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    title = ParagraphStyle("t", parent=styles["Title"], fontSize=16, textColor=NAVY, leading=20)
    body = ParagraphStyle("b", parent=styles["Normal"], fontSize=8, leading=10, wordWrap="CJK")
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=12 * mm,
        rightMargin=12 * mm,
        topMargin=14 * mm,
        bottomMargin=12 * mm,
        title=f"{sector} sector report",
    )
    story = [
        Paragraph(f"{sector}", title),
        Paragraph(
            f"{len(subset)} Nifty 100 companies in this broad sector (source: sectors table). "
            "Median KPIs use each company's latest fiscal year in financial_ratios.",
            body,
        ),
        Spacer(1, 8),
    ]
    med_row = ["Median"]
    for col, _label in METRIC_COLS:
        med_row.append(_fmt(subset[col].median() if col in subset.columns else None))
    cell = ParagraphStyle("cell", parent=body, fontSize=7, leading=9, alignment=1)
    header = [Paragraph("Company", cell)] + [Paragraph(label, cell) for _c, label in METRIC_COLS]
    data = [header, [Paragraph(str(x), cell) for x in med_row]]
    best_roe = subset["return_on_equity_pct"].max() if not subset.empty else None
    worst_roe = subset["return_on_equity_pct"].min() if not subset.empty else None
    for _, row in subset.sort_values("company_id").iterrows():
        cells = [Paragraph(str(row["company_id"]), cell)]
        for col, _ in METRIC_COLS:
            cells.append(Paragraph(_fmt(row.get(col)), cell))
        data.append(cells)

    table = Table(data, repeatRows=1, colWidths=[28 * mm] + [20 * mm] * 8)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("BACKGROUND", (0, 1), (-1, 1), colors.HexColor("#E5E7EB")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#D1D5DB")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3),
        ("RIGHTPADDING", (0, 0), (-1, -1), 3),
    ]))
    story.append(table)
    story.append(Spacer(1, 8))
    if best_roe is not None:
        best = subset.loc[subset["return_on_equity_pct"].idxmax(), "company_id"]
        worst = subset.loc[subset["return_on_equity_pct"].idxmin(), "company_id"]
        story.append(Paragraph(
            f"Best ROE in sector: {best} ({_fmt(best_roe)}%). "
            f"Lowest ROE in sector: {worst} ({_fmt(worst_roe)}%). "
            "Extreme ROE values can reflect source balance-sheet denominators (Sprint 2 caveat).",
            body,
        ))
    doc.build(story)
    return output_path
