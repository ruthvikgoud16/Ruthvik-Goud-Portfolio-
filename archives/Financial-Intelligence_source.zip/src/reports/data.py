"""Shared report data assembled from SQLite + Sprint 5 outputs."""

from __future__ import annotations

from pathlib import Path
from typing import List, Optional

import pandas as pd

from src.analytics.company_panel import (
    PROJECT_ROOT,
    connect,
    load_companies_sectors,
    load_ratios_history,
    load_statements,
)
from src.analytics.ratios import ProfitabilityRatios
from src.nlp.pros_cons_generator import _finite

PROS_CONS_CSV = PROJECT_ROOT / "output" / "pros_cons_generated.csv"
INTEL_XLSX = PROJECT_ROOT / "output" / "cashflow_intelligence.xlsx"


def pl_year_count(conn, company_id: str) -> int:
    cur = conn.execute(
        "SELECT COUNT(DISTINCT year) FROM profitandloss WHERE company_id = ?",
        (company_id,),
    )
    return int(cur.fetchone()[0])


def load_company_bundle(company_id: str) -> Optional[dict]:
    conn = connect()
    try:
        companies = load_companies_sectors(conn)
        row = companies[companies["company_id"] == company_id]
        if row.empty:
            return None
        meta = row.iloc[0]
        ratios = load_ratios_history(conn)
        pl, bs, cf = load_statements(conn)
        n_years = pl_year_count(conn, company_id)
    finally:
        conn.close()

    r = ratios[ratios["company_id"] == company_id]
    p = pl[pl["company_id"] == company_id]
    b = bs[bs["company_id"] == company_id]
    c = cf[cf["company_id"] == company_id]
    latest_r = r.iloc[-1] if not r.empty else None
    latest_p = p.iloc[-1] if not p.empty else None
    latest_b = b.iloc[-1] if not b.empty else None
    latest_c = c.iloc[-1] if not c.empty else None

    roce = None
    if latest_p is not None and latest_b is not None:
        op = _finite(latest_p.get("operating_profit"))
        oi = _finite(latest_p.get("other_income")) or 0.0
        ebit = (op + oi) if op is not None else None
        roce = ProfitabilityRatios.roce(
            ebit,
            _finite(latest_b.get("equity_capital")),
            _finite(latest_b.get("reserves")),
            _finite(latest_b.get("borrowings")),
        )
    if roce is None:
        roce = _finite(meta.get("source_roce_pct"))

    intel_row = None
    if INTEL_XLSX.exists():
        intel = pd.read_excel(INTEL_XLSX)
        hit = intel[intel["company_id"] == company_id]
        if not hit.empty:
            intel_row = hit.iloc[0].to_dict()

    bullets = {"pro": [], "con": []}
    if PROS_CONS_CSV.exists():
        pc = pd.read_csv(PROS_CONS_CSV)
        subset = pc[pc["company_id"] == company_id].sort_values("confidence_pct", ascending=False)
        for kind in ("pro", "con"):
            bullets[kind] = subset[subset["type"] == kind]["text"].head(5).tolist()

    return {
        "company_id": company_id,
        "company_name": meta["company_name"],
        "sector": meta["broad_sector"],
        "n_pl_years": n_years,
        "ratios": r,
        "pl": p,
        "bs": b,
        "cf": c,
        "latest_ratios": latest_r,
        "latest_pl": latest_p,
        "latest_bs": latest_b,
        "latest_cf": latest_c,
        "roce": roce,
        "intelligence": intel_row,
        "pros": bullets["pro"],
        "cons": bullets["con"],
        "capital_label": None if intel_row is None else intel_row.get("capital_allocation_label"),
    }


def kpi_value(bundle: dict, key: str) -> Optional[float]:
    latest = bundle.get("latest_ratios")
    if latest is None:
        return None
    return _finite(latest.get(key))


def all_company_ids() -> List[str]:
    conn = connect()
    ids = [r[0] for r in conn.execute("SELECT id FROM companies ORDER BY id")]
    conn.close()
    return ids


def sector_medians() -> pd.DataFrame:
    conn = connect()
    companies = load_companies_sectors(conn)
    ratios = load_ratios_history(conn)
    conn.close()
    latest = ratios.sort_values(["company_id", "year"]).groupby("company_id").tail(1)
    merged = latest.merge(companies[["company_id", "broad_sector", "company_name"]], on="company_id", how="left")
    return merged
