"""D-17 sector PDF coverage audit — 10 authoritative broad_sector values."""

from __future__ import annotations

import re
from pathlib import Path

import pandas as pd

from src.analytics.company_panel import PROJECT_ROOT, connect
from src.reports.run_batch import SECTOR_DIR, generate_sector_reports

AUDIT_CSV = PROJECT_ROOT / "output" / "D17_SECTOR_FINAL_AUDIT.csv"
RECON_MD = PROJECT_ROOT / "output" / "D17_SECTOR_RECONCILIATION.md"


def _pdf_pages(path: Path) -> int:
    data = path.read_bytes()
    counts = [int(n) for n in re.findall(rb"/Count\s+(\d+)", data)]
    return max(counts) if counts else 0


def _pdf_text(path: Path) -> str:
    import base64
    import zlib

    data = path.read_bytes()
    chunks = []
    for match in re.finditer(
        rb"/Filter\s*\[\s*/ASCII85Decode\s*/FlateDecode\s*\]\s*/Length\s+\d+\s*>>\s*stream\r?\n(.*?)endstream",
        data,
        re.S,
    ):
        payload = match.group(1).strip()
        try:
            decoded = base64.a85decode(payload, adobe=True)
            chunks.append(zlib.decompress(decoded).decode("latin-1", "ignore"))
        except Exception:
            continue
    return "\n".join(chunks)


def write_d17_artifacts() -> pd.DataFrame:
    conn = connect()
    sectors = pd.read_sql_query(
        """
        SELECT s.broad_sector AS sector, COUNT(*) AS company_count
        FROM sectors s
        GROUP BY s.broad_sector
        ORDER BY s.broad_sector
        """,
        conn,
    )
    assigned = pd.read_sql_query("SELECT company_id, broad_sector FROM sectors", conn)
    n_co = conn.execute("SELECT COUNT(*) FROM companies").fetchone()[0]
    conn.close()

    generate_sector_reports()
    rows = []
    for _, row in sectors.iterrows():
        sector = row["sector"]
        slug = str(sector).replace(" ", "_")
        filename = f"{slug}_report.pdf"
        path = SECTOR_DIR / filename
        pages = _pdf_pages(path) if path.exists() else 0
        size = path.stat().st_size if path.exists() else 0
        names = assigned.loc[assigned["broad_sector"] == sector, "company_id"].tolist()
        blob = _pdf_text(path) if path.exists() else ""
        missing_ids = [cid for cid in names if cid not in blob]
        ok = (
            path.exists()
            and pages >= 1
            and size > 1000
            and "Median" in blob
            and not missing_ids
        )
        rows.append(
            {
                "sector": sector,
                "company_count": int(row["company_count"]),
                "report_filename": filename,
                "status": "PASS" if ok else "FAIL",
                "source_field": "sectors.broad_sector / sectors.xlsx",
                "reason": (
                    "one PDF per authoritative broad_sector; all company_ids embedded"
                    if ok
                    else f"pages={pages} size={size} missing_ids={missing_ids}"
                ),
            }
        )

    pdfs = sorted(p.name for p in SECTOR_DIR.glob("*_report.pdf"))
    expected = sorted(str(s).replace(" ", "_") + "_report.pdf" for s in sectors["sector"])
    extra = sorted(set(pdfs) - set(expected))
    missing = sorted(set(expected) - set(pdfs))

    audit = pd.DataFrame(rows)
    AUDIT_CSV.parent.mkdir(parents=True, exist_ok=True)
    audit.to_csv(AUDIT_CSV, index=False)

    lines = [
        "# D-17 sector reconciliation",
        "",
        "Authoritative field: `sectors.broad_sector` loaded from `sectors.xlsx`.",
        f"Companies in universe: {n_co}. Assigned in sectors table: {len(assigned)}.",
        f"Distinct broad_sector values: {len(sectors)} (not 11).",
        "",
        "An 11th GICS sector was not invented. Peer groups (11) are a different taxonomy.",
        "Power & Utilities names sit under Energy as a sub_sector.",
        "",
        "| sector | companies | PDF |",
        "|---|---|---|",
    ]
    for _, row in audit.iterrows():
        lines.append(f"| {row['sector']} | {row['company_count']} | {row['report_filename']} |")
    lines.extend(
        [
            "",
            f"PDF files on disk: {len(pdfs)}. Expected: {len(expected)}.",
            f"Extra PDFs: {extra or 'none'}. Missing PDFs: {missing or 'none'}.",
            f"Duplicate company assignments: {int(assigned.duplicated('company_id').sum())}.",
            "",
            "11-sector requirement: **cannot be satisfied from source data** without a sponsor mapping.",
        ]
    )
    RECON_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return audit
