"""Generate the 10+ page analyst guide PDF."""

from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer

from src.analytics.company_panel import PROJECT_ROOT


def build_analyst_guide(path: Path = None) -> Path:
    dest = path or (PROJECT_ROOT / "docs" / "analyst_guide.pdf")
    dest.parent.mkdir(parents=True, exist_ok=True)
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Heading1"], fontSize=16, spaceAfter=10)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], fontSize=13, spaceAfter=8)
    body = ParagraphStyle("body", parent=styles["Normal"], fontSize=10, leading=14, spaceAfter=8)
    story = []

    pages = [
        [
            (h1, "N100 Financial Intelligence — Analyst Guide"),
            (body, "This guide explains how to run and use the Nifty 100 analytics platform: Streamlit dashboard, screener, PDF tearsheets, and the FastAPI service. All figures come from nifty100.db. Do not treat missing source values as zeros."),
            (h2, "1. Environment"),
            (body, "Python 3.9+, a virtualenv, and `pip install -r requirements.txt`. The SQLite file nifty100.db must sit at the project root. Activate the venv before any command in this guide."),
            (body, "Project root (example): /Users/ruthvikgoud/Financial-Intelligence"),
        ],
        [
            (h1, "2. Starting the dashboard"),
            (body, "From the project root run: streamlit run src/dashboard/app.py"),
            (body, "The app listens on http://localhost:8501. There is no login in the MVP. Use the sidebar to switch among the eight screens: Home, Company Profile, Screener, Peer Comparison, Trend Analysis, Sector Analysis, Capital Allocation, Annual Reports."),
            (body, "If the database path is wrong, the Home screen will show empty KPIs. Confirm nifty100.db exists and that you launched Streamlit from the project root (or rely on the dashboard DB helper, which resolves the path from source files)."),
        ],
        [
            (h1, "3. Using the Streamlit screener"),
            (body, "Open the Screener screen. Sidebar sliders map to FilterEngine metrics (ROE, D/E, FCF, CAGRs, valuation). Presets (Quality Compounder, Value, Growth, Dividend, Debt-Free, Turnaround) load config/screener_config.yaml."),
            (body, "Quality Compounder uses ROE ≥ 15, D/E ≤ 1, FCF ≥ 0, 5-year revenue CAGR ≥ 10. Financials are carved out of the D/E cap inside FilterEngine. Results can be downloaded as CSV; the download is the filtered DataFrame, not a new calculation."),
            (body, "If a preset returns fewer names than you expect, inspect missing KPIs: a company with null ROE is dropped by a minimum-ROE filter. That is a source-data limitation."),
        ],
        [
            (h1, "4. Company Profile and other screens"),
            (body, "Company Profile: search by ticker, then inspect KPI tiles, P&L, balance sheet, cash flow, and rule-based pros/cons (Sprint 5). Trend Analysis plots history. Sector Analysis uses broad_sector from the sectors table (10 groups, not 11). Capital Allocation uses Sprint 2 pattern labels. Annual Reports lists URLs; DIVISLAB may have none."),
            (body, "Valuation badges (Caution / Discount) come from output/valuation_flags.csv produced in Sprint 4. Extreme ROE/ROCE tiles can reflect source denominator issues documented in Sprint 2."),
        ],
        [
            (h1, "5. Generating PDF tearsheets"),
            (body, "Batch command: PYTHONPATH=. python -m src.reports.run_batch"),
            (body, "Outputs: reports/tearsheets/<TICKER>_tearsheet.pdf (2 pages), reports/sector/<SECTOR>_report.pdf, reports/portfolio/portfolio_summary.pdf. Companies with fewer than 3 P&L years are skipped and listed in output/skipped_tearsheets.csv. In this dataset every company has ≥3 years, so 92 tearsheets were produced."),
            (body, "Do not hand-edit PDFs. Re-run the batch after regenerating pros_cons_generated.csv or cashflow_intelligence.xlsx so page 2 stays consistent."),
        ],
        [
            (h1, "6. Starting the API"),
            (body, "uvicorn src.api.main:app --port 8000"),
            (body, "OpenAPI UI: http://localhost:8000/docs  Spec file: docs/openapi.json  Postman: docs/postman_collection.json"),
            (body, "CORS is open (internal MVP). Every request is logged with method, path, and duration. Health: GET /api/v1/health must return status=ok and db_row_counts for the 10 core tables."),
        ],
        [
            (h1, "7. Example curl commands"),
            (body, "curl -s http://localhost:8000/api/v1/health"),
            (body, "curl -s http://localhost:8000/api/v1/companies/TCS"),
            (body, "curl -s 'http://localhost:8000/api/v1/screener?min_roe=15&max_de=1'"),
            (body, "curl -s http://localhost:8000/api/v1/sectors"),
            (body, "curl -s -o TCS_tearsheet.pdf http://localhost:8000/api/v1/companies/TCS/tearsheet"),
            (body, "Unknown tickers return HTTP 404. Non-numeric screener parameters return HTTP 400."),
        ],
        [
            (h1, "8. Clustering and portfolio stats"),
            (body, "PYTHONPATH=. python -m src.analytics.clustering writes output/cluster_labels.csv (92 rows, cluster_id 0–4), reports/elbow_plot.png, reports/correlation_heatmap.png, output/outlier_report.csv, output/portfolio_stats.csv."),
            (body, "k=5 is the specified model. The elbow plot is informational; extreme source ROE values can isolate a tiny cluster. Cluster names are assigned from medians of the five input features and should be read with the Sprint 2 ROE caveat."),
        ],
        [
            (h1, "9. Tests and quality gates"),
            (body, "pytest -q runs the full suite. pytest tests/ --html=reports/testing/pytest_report.html writes the HTML report. Do not delete older tests to obtain a green run."),
            (body, "Acceptance gates AC-01…AC-20 are recorded in docs/acceptance_checklist.pdf and output/DAY45_ACCEPTANCE_GATES.md. Some gates remain caveated (sector count 10 vs 11; pros/cons coverage; validation_failures column names)."),
        ],
        [
            (h1, "10. Troubleshooting"),
            (body, "Empty dashboard: missing nifty100.db or running Streamlit from another cwd without the path helper."),
            (body, "API import errors: set PYTHONPATH=. or install the project deps in the same venv."),
            (body, "Tearsheet 404: run the Day 34 batch first."),
            (body, "Screener mismatch vs Excel: compare against FilterEngine, not a restated spreadsheet. output/screener_output.xlsx is the Sprint 3 export."),
            (body, "Never fill missing financials with invented numbers. Prefer nulls and documented caveats."),
        ],
        [
            (h1, "11. Command cheat-sheet"),
            (body, "ETL (do not rebuild casually): see Makefile target load."),
            (body, "Dashboard: streamlit run src/dashboard/app.py"),
            (body, "API: uvicorn src.api.main:app --port 8000"),
            (body, "Tests: PYTHONPATH=. pytest -q"),
            (body, "Reports: PYTHONPATH=. python -m src.reports.run_batch"),
            (body, "Clustering: PYTHONPATH=. python -m src.analytics.clustering"),
            (body, "End of guide. Version 1.0.0-sprint6."),
        ],
    ]
    for i, blocks in enumerate(pages):
        for style, text in blocks:
            story.append(Paragraph(text, style))
            story.append(Spacer(1, 4))
        if i != len(pages) - 1:
            story.append(PageBreak())

    doc = SimpleDocTemplate(str(dest), pagesize=A4, title="N100 Analyst Guide")
    doc.build(story)
    return dest


if __name__ == "__main__":
    path = build_analyst_guide()
    print(path)
