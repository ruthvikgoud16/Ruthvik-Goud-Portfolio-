"""Batch generation for Sprint 5 Days 33–35 reports."""

from __future__ import annotations

import csv
from pathlib import Path

from src.analytics.company_panel import PROJECT_ROOT, connect
from src.reports.data import all_company_ids, load_company_bundle, sector_medians
from src.reports.portfolio import build_portfolio_summary
from src.reports.sector_report import build_sector_report
from src.reports.tearsheet import build_tearsheet

TEARSHEET_DIR = PROJECT_ROOT / "reports" / "tearsheets"
SECTOR_DIR = PROJECT_ROOT / "reports" / "sector"
PORTFOLIO_PATH = PROJECT_ROOT / "reports" / "portfolio" / "portfolio_summary.pdf"
SKIPPED_CSV = PROJECT_ROOT / "output" / "skipped_tearsheets.csv"
MIN_YEARS = 3
MIN_TEARSHEET_BYTES = 30 * 1024


def generate_tearsheets(tickers=None) -> dict:
    TEARSHEET_DIR.mkdir(parents=True, exist_ok=True)
    skipped = []
    written = []
    ids = tickers or all_company_ids()
    for cid in ids:
        bundle = load_company_bundle(cid)
        n_years = 0 if bundle is None else bundle["n_pl_years"]
        if n_years < MIN_YEARS:
            skipped.append({"company_id": cid, "pl_years": n_years, "reason": "fewer than 3 years of P&L data"})
            continue
        path = TEARSHEET_DIR / f"{cid}_tearsheet.pdf"
        build_tearsheet(cid, path)
        written.append(path)
    SKIPPED_CSV.parent.mkdir(parents=True, exist_ok=True)
    with SKIPPED_CSV.open("w", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=["company_id", "pl_years", "reason"])
        writer.writeheader()
        writer.writerows(skipped)
    undersized = [p.name for p in written if p.stat().st_size < MIN_TEARSHEET_BYTES]
    return {"written": len(written), "skipped": skipped, "undersized": undersized}


def generate_sector_reports() -> list:
    SECTOR_DIR.mkdir(parents=True, exist_ok=True)
    df = sector_medians()
    sectors = sorted(s for s in df["broad_sector"].dropna().unique())
    paths = []
    for sector in sectors:
        slug = str(sector).replace(" ", "_")
        path = SECTOR_DIR / f"{slug}_report.pdf"
        build_sector_report(sector, path)
        paths.append(path)
    return paths


def generate_portfolio() -> Path:
    return build_portfolio_summary(PORTFOLIO_PATH)


def main(sample_only: bool = False) -> None:
    sample = ["TCS", "HDFCBANK", "RELIANCE", "SUNPHARMA", "TATASTEEL"] if sample_only else None
    result = generate_tearsheets(sample)
    print(f"tearsheets written={result['written']} skipped={result['skipped']} undersized={result['undersized']}")
    if not sample_only:
        sectors = generate_sector_reports()
        print(f"sector reports={len(sectors)} {[p.name for p in sectors]}")
        portfolio = generate_portfolio()
        print(f"portfolio={portfolio} size={portfolio.stat().st_size}")


if __name__ == "__main__":
    import sys
    main(sample_only="--sample" in sys.argv)
