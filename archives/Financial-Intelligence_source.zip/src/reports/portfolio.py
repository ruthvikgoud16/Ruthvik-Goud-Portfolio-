"""Day 35 — portfolio summary PDF (one page per ticker)."""

from __future__ import annotations

from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from src.nlp.pros_cons_generator import _finite
from src.reports.data import all_company_ids, load_company_bundle

NAVY = colors.HexColor("#0B1F3A")

KPI_KEYS = [
    ("return_on_equity_pct", "ROE %"),
    ("net_profit_margin_pct", "NPM %"),
    ("debt_to_equity", "D/E"),
    ("free_cash_flow_cr", "FCF Cr"),
    ("revenue_cagr_5yr", "Rev CAGR 5y"),
    ("operating_profit_margin_pct", "OPM %"),
]


def _arrow(latest, prior) -> str:
    if latest is None or prior is None:
        return "→"
    if prior == 0:
        return "→"
    change_pct = (latest - prior) / abs(prior) * 100
    if change_pct > 2:
        return "↑"
    if change_pct < -2:
        return "↓"
    return "→"


def _fmt(v):
    if v is None:
        return "n/a"
    return f"{v:.1f}"


def _page_flow(company_id: str, styles):
    bundle = load_company_bundle(company_id)
    if bundle is None:
        return [Paragraph(company_id, styles["title"])]
    ratios = bundle["ratios"]
    latest = bundle["latest_ratios"]
    prior = ratios.iloc[-2] if len(ratios) >= 2 else None
    story = [
        Paragraph(f"{bundle['company_name']} ({company_id})", styles["title"]),
        Paragraph(f"Sector: {bundle['sector'] or 'n/a'}", styles["body"]),
        Spacer(1, 8),
    ]
    header = ["KPI", "Latest", "Trend"]
    data = [header]
    for key, label in KPI_KEYS:
        latest_v = _finite(latest.get(key)) if latest is not None else None
        prior_v = _finite(prior.get(key)) if prior is not None else None
        data.append([label, _fmt(latest_v), _arrow(latest_v, prior_v)])
    table = Table(data, colWidths=[70 * mm, 50 * mm, 30 * mm])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#D1D5DB")),
        ("ALIGN", (0, 0), (-1, -1), "LEFT"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(table)
    story.append(Spacer(1, 10))
    cap = bundle.get("capital_label") or "n/a"
    story.append(Paragraph(f"Capital allocation (latest year): {cap}", styles["body"]))
    return story


def build_portfolio_summary(output_path: Path) -> Path:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    styles_base = getSampleStyleSheet()
    styles = {
        "title": ParagraphStyle("t", parent=styles_base["Title"], fontSize=16, textColor=NAVY, leading=20),
        "body": ParagraphStyle("b", parent=styles_base["Normal"], fontSize=10, leading=13, wordWrap="CJK"),
    }
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=16 * mm,
        rightMargin=16 * mm,
        topMargin=16 * mm,
        bottomMargin=16 * mm,
        title="N100 portfolio summary",
    )
    story = []
    ids = all_company_ids()
    for i, cid in enumerate(ids):
        story.extend(_page_flow(cid, styles))
        if i != len(ids) - 1:
            story.append(PageBreak())
    doc.build(story)
    return output_path
