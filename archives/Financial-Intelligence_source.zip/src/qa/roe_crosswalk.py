"""Cross-check engine ROE against companies.roe_percentage without rewriting source."""

from __future__ import annotations

from pathlib import Path
from typing import Optional, Tuple

import pandas as pd

from src.analytics.company_panel import PROJECT_ROOT, connect

OUTPUT_PATH = PROJECT_ROOT / "output" / "ROE_CROSS_VALIDATION_FINAL.csv"
MATCH_PP = 5.0


def classify_roe(source_roe: Optional[float], engine_roe: Optional[float]) -> Tuple[str, str]:
    if source_roe is None and engine_roe is None:
        return "FAIL", "both source workbook ROE and engine ROE are missing"
    if source_roe is None:
        return (
            "SOURCE_ANOMALY",
            "companies.roe_percentage is blank in the source workbook; engine ROE from PAT/(equity+reserves) retained",
        )
    if engine_roe is None:
        return (
            "SOURCE_ANOMALY",
            "engine ROE cannot be computed (missing equity/reserves on the latest annual balance sheet); source workbook value retained",
        )
    delta = abs(engine_roe - source_roe)
    if delta <= MATCH_PP:
        return "PASS", "within 5 percentage points of companies.roe_percentage"
    if 0 < source_roe < 2 and engine_roe > 10 and abs(engine_roe - source_roe * 100) <= MATCH_PP:
        return (
            "SOURCE_ANOMALY",
            "source value looks like a decimal/unit mismatch (e.g. 0.52 vs ~52%) "
            "versus engine PAT/(equity_capital+reserves)×100; source field preserved",
        )
    if abs(engine_roe) > 500:
        return (
            "SOURCE_ANOMALY",
            "engine ROE is extreme because source equity/reserves produce a tiny "
            "denominator; companies.roe_percentage retained as the workbook figure",
        )
    return (
        "SOURCE_ANOMALY",
        "workbook companies.roe_percentage uses a different definition or vintage "
        "than Sprint 2 PAT/(equity_capital+reserves)×100; both values preserved",
    )


def build_roe_crosswalk() -> pd.DataFrame:
    conn = connect()
    df = pd.read_sql_query(
        """
        SELECT
            c.id AS company_id,
            c.id AS ticker,
            c.roe_percentage AS source_roe,
            (
                SELECT fr.return_on_equity_pct
                FROM financial_ratios fr
                WHERE fr.company_id = c.id
                  AND fr.year GLOB '20*'
                  AND fr.return_on_equity_pct IS NOT NULL
                ORDER BY fr.year DESC
                LIMIT 1
            ) AS engine_roe
        FROM companies c
        ORDER BY c.id
        """,
        conn,
    )
    conn.close()
    statuses = []
    reasons = []
    diffs = []
    for _, row in df.iterrows():
        src = None if pd.isna(row["source_roe"]) else float(row["source_roe"])
        eng = None if pd.isna(row["engine_roe"]) else float(row["engine_roe"])
        status, reason = classify_roe(src, eng)
        statuses.append(status)
        reasons.append(reason)
        if src is None or eng is None:
            diffs.append(None)
        else:
            diffs.append(eng - src)
    df["difference_pct_points"] = diffs
    df["status"] = statuses
    df["reason"] = reasons
    return df[
        [
            "company_id",
            "ticker",
            "source_roe",
            "engine_roe",
            "difference_pct_points",
            "status",
            "reason",
        ]
    ]


def write_roe_crosswalk(path: Path = OUTPUT_PATH) -> Path:
    df = build_roe_crosswalk()
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    return path


if __name__ == "__main__":
    out = write_roe_crosswalk()
    df = pd.read_csv(out)
    print(df["status"].value_counts().to_string())
    print("wrote", out)
