"""FastAPI application — N100 Financial Intelligence API."""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from src.analytics.company_panel import PROJECT_ROOT
from src.api.routers import companies, documents, health, peers, portfolio, screener, sectors, valuation

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("n100.api")

app = FastAPI(
    title="N100 Financial Intelligence API",
    version="1.0.0-sprint6",
    description="REST API over nifty100.db for the Nifty 100 analytics platform.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.exception_handler(RequestValidationError)
async def invalid_params(_request: Request, exc: RequestValidationError):
    """Map FastAPI 422 validation errors to HTTP 400 as specified for the screener."""
    return JSONResponse(status_code=400, content={"detail": "Invalid parameter values", "errors": exc.errors()})


@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Log method, path, and response time for every request."""
    start = time.perf_counter()
    response = await call_next(request)
    elapsed_ms = (time.perf_counter() - start) * 1000
    logger.info("%s %s %.1fms status=%s", request.method, request.url.path, elapsed_ms, response.status_code)
    response.headers["X-Response-Time-ms"] = "{0:.1f}".format(elapsed_ms)
    return response


app.include_router(health.router, prefix="/api/v1", tags=["health"])
app.include_router(companies.router, prefix="/api/v1", tags=["companies"])
app.include_router(screener.router, prefix="/api/v1", tags=["screener"])
app.include_router(sectors.router, prefix="/api/v1", tags=["sectors"])
app.include_router(peers.router, prefix="/api/v1", tags=["peers"])
app.include_router(valuation.router, prefix="/api/v1", tags=["valuation"])
app.include_router(portfolio.router, prefix="/api/v1", tags=["portfolio"])
app.include_router(documents.router, prefix="/api/v1", tags=["documents"])


def export_openapi(path: Path = None) -> Path:
    """Write OpenAPI 3 spec to docs/openapi.json."""
    dest = path or (PROJECT_ROOT / "docs" / "openapi.json")
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(json.dumps(app.openapi(), indent=2), encoding="utf-8")
    return dest


def export_postman(path: Path = None) -> Path:
    """Minimal Postman collection generated from OpenAPI paths."""
    dest = path or (PROJECT_ROOT / "docs" / "postman_collection.json")
    spec = app.openapi()
    items = []
    for route, methods in spec.get("paths", {}).items():
        for method, body in methods.items():
            items.append(
                {
                    "name": body.get("summary") or "{0} {1}".format(method.upper(), route),
                    "request": {
                        "method": method.upper(),
                        "header": [],
                        "url": "http://localhost:8000{0}".format(route),
                    },
                }
            )
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(
        json.dumps({"info": {"name": "N100 API", "schema": "https://schema.getpostman.com/json/collection/v2.1.0/collection.json"}, "item": items}, indent=2),
        encoding="utf-8",
    )
    return dest
