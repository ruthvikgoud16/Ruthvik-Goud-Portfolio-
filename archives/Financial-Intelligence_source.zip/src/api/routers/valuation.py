"""Market-cap / valuation history."""

from fastapi import APIRouter, HTTPException

from src.api.db import get_connection, rows_to_dicts

router = APIRouter()


@router.get("/market-cap/{ticker}")
def market_cap_history(ticker: str):
    """Valuation multiples 2019–2024 from market_cap."""
    conn = get_connection()
    exists = conn.execute("SELECT 1 FROM companies WHERE id = ?", (ticker,)).fetchone()
    if not exists:
        conn.close()
        raise HTTPException(status_code=404, detail="Ticker not found: {0}".format(ticker))
    rows = rows_to_dicts(
        conn.execute(
            """
            SELECT company_id, year, pe_ratio, pb_ratio, ev_ebitda, dividend_yield_pct,
                   market_cap_crore, enterprise_value_crore
            FROM market_cap
            WHERE company_id = ? AND year BETWEEN 2019 AND 2024
            ORDER BY year
            """,
            (ticker,),
        ).fetchall()
    )
    conn.close()
    return {"ticker": ticker, "rows": rows}
