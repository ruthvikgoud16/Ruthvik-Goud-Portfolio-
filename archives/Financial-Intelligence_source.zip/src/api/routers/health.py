"""Health check."""

import time

from fastapi import APIRouter

from src.api.db import CORE_TABLES, get_connection

router = APIRouter()
STARTED = time.time()
VERSION = "1.0.0-sprint6"


@router.get("/health")
def health():
    """Server health with core-table row counts and uptime."""
    conn = get_connection()
    counts = {}
    for table in CORE_TABLES:
        try:
            counts[table] = conn.execute("SELECT COUNT(*) FROM {0}".format(table)).fetchone()[0]
        except Exception:
            counts[table] = None
    conn.close()
    return {
        "status": "ok",
        "db_row_counts": counts,
        "uptime_seconds": round(time.time() - STARTED, 3),
        "version": VERSION,
    }
