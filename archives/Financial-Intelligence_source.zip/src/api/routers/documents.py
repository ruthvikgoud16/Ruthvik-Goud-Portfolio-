"""Documents router (company document routes live under companies)."""

from fastapi import APIRouter

router = APIRouter()
