"""Peer-group percentiles."""

from fastapi import APIRouter, HTTPException

from src.api.db import get_connection, rows_to_dicts

router = APIRouter()


@router.get("/peers/{group_name}")
def peer_group(group_name: str):
    """Members of a peer group with percentile ranks for stored metrics."""
    conn = get_connection()
    members = rows_to_dicts(
        conn.execute(
            "SELECT DISTINCT company_id FROM peer_groups WHERE peer_group_name = ? ORDER BY company_id",
            (group_name,),
        ).fetchall()
    )
    if not members:
        conn.close()
        raise HTTPException(status_code=404, detail="Unknown peer group: {0}".format(group_name))
    year_row = conn.execute(
        "SELECT MAX(year) AS year FROM peer_percentiles WHERE peer_group_name = ?",
        (group_name,),
    ).fetchone()
    year = year_row["year"] if year_row else None
    out = []
    for member in members:
        ticker = member["company_id"]
        ranks = rows_to_dicts(
            conn.execute(
                """
                SELECT metric_name, percentile_rank
                FROM peer_percentiles
                WHERE company_id = ? AND peer_group_name = ?
                  AND (? IS NULL OR year = ?)
                """,
                (ticker, group_name, year, year),
            ).fetchall()
        )
        out.append({"company_id": ticker, "year": year, "percentiles": ranks})
    conn.close()
    return {"peer_group": group_name, "count": len(out), "companies": out}
