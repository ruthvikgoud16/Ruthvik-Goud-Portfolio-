"""Screener API wrapping the verified FilterEngine."""

from typing import Optional

import pandas as pd
from fastapi import APIRouter, HTTPException

from src.analytics.company_panel import PROJECT_ROOT
from src.screener.engine import FilterEngine

router = APIRouter()


@router.get("/screener")
def screener(
    min_roe: Optional[float] = None,
    max_de: Optional[float] = None,
    min_fcf: Optional[float] = None,
    sector: Optional[str] = None,
    min_rev_cagr_5yr: Optional[float] = None,
    min_pat_cagr_5yr: Optional[float] = None,
    max_pe: Optional[float] = None,
):
    """Ranked screener using Sprint 3 FilterEngine."""
    for name, value in [
        ("min_roe", min_roe),
        ("max_de", max_de),
        ("min_fcf", min_fcf),
        ("min_rev_cagr_5yr", min_rev_cagr_5yr),
        ("min_pat_cagr_5yr", min_pat_cagr_5yr),
        ("max_pe", max_pe),
    ]:
        if value is None:
            continue
        try:
            float(value)
        except (TypeError, ValueError):
            raise HTTPException(status_code=400, detail="Invalid {0}".format(name))
        if name.startswith("min_") and value < -1e6:
            raise HTTPException(status_code=400, detail="Invalid {0}".format(name))

    filters = {}
    if min_roe is not None:
        filters["roe_min"] = min_roe
    if max_de is not None:
        filters["de_max"] = max_de
    if min_fcf is not None:
        filters["fcf_min"] = min_fcf
    if min_rev_cagr_5yr is not None:
        filters["revenue_cagr_5yr_min"] = min_rev_cagr_5yr
    if min_pat_cagr_5yr is not None:
        filters["pat_cagr_5yr_min"] = min_pat_cagr_5yr
    if max_pe is not None:
        filters["pe_max"] = max_pe

    engine = FilterEngine(str(PROJECT_ROOT / "nifty100.db"))
    try:
        df = engine.apply_filters(filters)
    except ValueError as exc:
        engine.close()
        raise HTTPException(status_code=400, detail=str(exc))
    engine.close()
    if sector:
        col = "broad_sector" if "broad_sector" in df.columns else None
        if col:
            df = df[df[col].astype(str).str.contains(sector, case=False, na=False)]
        elif "sector" in df.columns:
            df = df[df["sector"].astype(str).str.contains(sector, case=False, na=False)]
    df = df.replace([float("inf"), float("-inf")], pd.NA)
    records = df.where(df.notna(), None).to_dict(orient="records")
    # numpy inf can survive as Python inf
    clean = []
    for rec in records:
        clean.append({k: (None if isinstance(v, float) and (v != v or abs(v) == float("inf")) else v) for k, v in rec.items()})
    return {"count": len(clean), "results": clean}
