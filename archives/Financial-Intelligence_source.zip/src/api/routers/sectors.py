"""Sector list and members."""

from fastapi import APIRouter, HTTPException

from src.api.db import get_connection, latest_ratio_year, rows_to_dicts

router = APIRouter()


@router.get("/sectors")
def list_sectors():
    """Return one row per distinct broad_sector actually present in SQLite."""
    conn = get_connection()
    rows = rows_to_dicts(
        conn.execute(
            """
            SELECT
                s.broad_sector AS sector,
                COUNT(*) AS company_count,
                AVG(c.roe_percentage) AS median_roe_proxy,
                (
                    SELECT AVG(mc.pe_ratio)
                    FROM market_cap mc
                    JOIN sectors s2 ON s2.company_id = mc.company_id
                    WHERE s2.broad_sector = s.broad_sector
                      AND mc.year = (SELECT MAX(year) FROM market_cap)
                ) AS median_pe,
                (
                    SELECT AVG(fr.debt_to_equity)
                    FROM financial_ratios fr
                    JOIN sectors s3 ON s3.company_id = fr.company_id
                    WHERE s3.broad_sector = s.broad_sector
                      AND fr.year GLOB '20*'
                ) AS median_de
            FROM sectors s
            JOIN companies c ON c.id = s.company_id
            GROUP BY s.broad_sector
            ORDER BY s.broad_sector
            """
        ).fetchall()
    )
    # Replace mean proxies with true medians in Python (SQLite has no median)
    out = []
    for row in rows:
        sector = row["sector"]
        members = conn.execute(
            """
            SELECT c.roe_percentage, fr.debt_to_equity, mc.pe_ratio
            FROM sectors s
            JOIN companies c ON c.id = s.company_id
            LEFT JOIN financial_ratios fr
              ON fr.company_id = s.company_id
             AND fr.year = (
                 SELECT MAX(year) FROM financial_ratios
                 WHERE company_id = s.company_id AND year GLOB '20*'
             )
            LEFT JOIN market_cap mc
              ON mc.company_id = s.company_id
             AND mc.year = (SELECT MAX(year) FROM market_cap)
            WHERE s.broad_sector = ?
            """,
            (sector,),
        ).fetchall()
        import pandas as pd

        frame = pd.DataFrame([dict(m) for m in members])
        out.append(
            {
                "sector": sector,
                "company_count": int(row["company_count"]),
                "median_roe": None if frame.empty else _median(frame["roe_percentage"]),
                "median_pe": None if frame.empty else _median(frame["pe_ratio"]),
                "median_de": None if frame.empty else _median(frame["debt_to_equity"]),
            }
        )
    conn.close()
    return {"count": len(out), "sectors": out}


def _median(series):
    s = series.dropna()
    if s.empty:
        return None
    return float(s.median())


@router.get("/sectors/{sector}/companies")
def sector_companies(sector: str):
    """Companies in a broad sector with latest-year KPIs."""
    conn = get_connection()
    aliases = {
        "IT": "Information Technology",
        "Information Technology": "Information Technology",
    }
    resolved = aliases.get(sector, sector)
    exists = conn.execute(
        "SELECT 1 FROM sectors WHERE broad_sector = ? LIMIT 1",
        (resolved,),
    ).fetchone()
    if not exists:
        # substring match
        hit = conn.execute(
            "SELECT DISTINCT broad_sector FROM sectors WHERE broad_sector LIKE ?",
            (f"%{sector}%",),
        ).fetchone()
        if not hit:
            conn.close()
            raise HTTPException(status_code=404, detail="Unknown sector: {0}".format(sector))
        resolved = hit["broad_sector"]
    rows = rows_to_dicts(
        conn.execute(
            """
            SELECT c.id, c.company_name, s.broad_sector, s.sub_sector,
                   fr.year, fr.return_on_equity_pct, fr.debt_to_equity,
                   fr.revenue_cagr_5yr, fr.free_cash_flow_cr, fr.net_profit_margin_pct
            FROM sectors s
            JOIN companies c ON c.id = s.company_id
            LEFT JOIN financial_ratios fr
              ON fr.company_id = c.id
             AND fr.year = (
                 SELECT MAX(year) FROM financial_ratios
                 WHERE company_id = c.id AND year GLOB '20*'
             )
            WHERE s.broad_sector = ?
            ORDER BY c.id
            """,
            (resolved,),
        ).fetchall()
    )
    conn.close()
    return {"sector": resolved, "count": len(rows), "companies": rows}
