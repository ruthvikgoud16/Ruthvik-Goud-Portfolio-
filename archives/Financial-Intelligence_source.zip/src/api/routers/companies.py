"""Company list, profile, statements, ratios, tearsheet, documents."""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse

from src.analytics.company_panel import PROJECT_ROOT, _is_fiscal_year
from src.api.db import apply_year_window, get_connection, latest_ratio_year, rows_to_dicts

router = APIRouter()


@router.get("/companies")
def list_companies(
    sector: Optional[str] = None,
    market_cap_category: Optional[str] = None,
    search: Optional[str] = None,
):
    """List all companies with sector and latest profitability fields."""
    conn = get_connection()
    sql = """
        SELECT
            c.id,
            c.company_name,
            s.broad_sector,
            s.sub_sector,
            s.market_cap_category,
            c.roe_percentage AS roe_pct,
            c.roce_percentage AS roce_pct
        FROM companies c
        LEFT JOIN sectors s ON s.company_id = c.id
        WHERE 1=1
    """
    params = []
    if sector:
        sql += " AND (s.broad_sector = ? OR s.broad_sector LIKE ?)"
        params.extend([sector, f"%{sector}%"])
    if market_cap_category:
        sql += " AND s.market_cap_category = ?"
        params.append(market_cap_category)
    if search:
        sql += " AND (c.id LIKE ? OR c.company_name LIKE ?)"
        like = f"%{search}%"
        params.extend([like, like])
    sql += " ORDER BY c.id"
    rows = rows_to_dicts(conn.execute(sql, params).fetchall())
    conn.close()
    return {"count": len(rows), "companies": rows}


@router.get("/companies/{ticker}")
def company_profile(ticker: str):
    """Full company profile plus latest-year KPIs."""
    conn = get_connection()
    company = conn.execute("SELECT * FROM companies WHERE id = ?", (ticker,)).fetchone()
    if company is None:
        conn.close()
        raise HTTPException(status_code=404, detail=f"Ticker not found: {ticker}")
    sector = conn.execute("SELECT * FROM sectors WHERE company_id = ?", (ticker,)).fetchone()
    year = latest_ratio_year(conn, ticker)
    kpis = None
    if year:
        kpis = conn.execute(
            "SELECT * FROM financial_ratios WHERE company_id = ? AND year = ?",
            (ticker, year),
        ).fetchone()
    conn.close()
    return {
        "company": dict(company),
        "sector": dict(sector) if sector else None,
        "latest_year": year,
        "latest_kpis": dict(kpis) if kpis else None,
    }


def _history(table: str, ticker: str, from_year: Optional[str], to_year: Optional[str]):
    conn = get_connection()
    exists = conn.execute("SELECT 1 FROM companies WHERE id = ?", (ticker,)).fetchone()
    if not exists:
        conn.close()
        raise HTTPException(status_code=404, detail=f"Ticker not found: {ticker}")
    rows = rows_to_dicts(
        conn.execute(
            f"SELECT * FROM {table} WHERE company_id = ? ORDER BY year",
            (ticker,),
        ).fetchall()
    )
    conn.close()
    rows = [r for r in rows if _is_fiscal_year(r.get("year"))]
    return apply_year_window(rows, from_year, to_year)


@router.get("/companies/{ticker}/pl")
def company_pl(ticker: str, from_year: Optional[str] = None, to_year: Optional[str] = None):
    """P&L history with optional YYYY-MM window."""
    return {"ticker": ticker, "rows": _history("profitandloss", ticker, from_year, to_year)}


@router.get("/companies/{ticker}/bs")
def company_bs(ticker: str, from_year: Optional[str] = None, to_year: Optional[str] = None):
    """Balance-sheet history with optional YYYY-MM window."""
    return {"ticker": ticker, "rows": _history("balancesheet", ticker, from_year, to_year)}


@router.get("/companies/{ticker}/cashflow")
def company_cashflow(ticker: str, from_year: Optional[str] = None, to_year: Optional[str] = None):
    """Cash-flow history with optional YYYY-MM window."""
    return {"ticker": ticker, "rows": _history("cashflow", ticker, from_year, to_year)}


@router.get("/companies/{ticker}/ratios")
def company_ratios(ticker: str, year: Optional[str] = None):
    """Computed KPIs per year, or a single year if specified."""
    conn = get_connection()
    exists = conn.execute("SELECT 1 FROM companies WHERE id = ?", (ticker,)).fetchone()
    if not exists:
        conn.close()
        raise HTTPException(status_code=404, detail=f"Ticker not found: {ticker}")
    if year:
        rows = rows_to_dicts(
            conn.execute(
                "SELECT * FROM financial_ratios WHERE company_id = ? AND year = ? ORDER BY year",
                (ticker, year),
            ).fetchall()
        )
    else:
        rows = rows_to_dicts(
            conn.execute(
                "SELECT * FROM financial_ratios WHERE company_id = ? ORDER BY year",
                (ticker,),
            ).fetchall()
        )
    conn.close()
    rows = [r for r in rows if _is_fiscal_year(r.get("year"))]
    return {"ticker": ticker, "rows": rows}


@router.get("/companies/{ticker}/tearsheet")
def company_tearsheet(ticker: str):
    """Download the pre-generated 2-page tearsheet PDF."""
    path = PROJECT_ROOT / "reports" / "tearsheets" / f"{ticker}_tearsheet.pdf"
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Tearsheet not found for {ticker}")
    return FileResponse(path, media_type="application/pdf", filename=path.name)


@router.get("/companies/{ticker}/documents")
def company_documents(ticker: str):
    """Annual-report links with a format-based URL validity flag (no live HTTP)."""
    conn = get_connection()
    exists = conn.execute("SELECT 1 FROM companies WHERE id = ?", (ticker,)).fetchone()
    if not exists:
        conn.close()
        raise HTTPException(status_code=404, detail=f"Ticker not found: {ticker}")
    rows = rows_to_dicts(
        conn.execute(
            "SELECT company_id, year, annual_report FROM documents WHERE company_id = ? ORDER BY year",
            (ticker,),
        ).fetchall()
    )
    conn.close()
    for row in rows:
        url = row.get("annual_report")
        row["is_url_valid"] = bool(url) and str(url).lower().startswith("http")
    return {"ticker": ticker, "documents": rows}


@router.get("/companies/{ticker}/peers/compare")
def company_peer_compare(ticker: str):
    """Radar-style 8-metric company vs peer-group average."""
    from src.analytics.radar import RadarChartGenerator

    gen = RadarChartGenerator(str(PROJECT_ROOT / "nifty100.db"))
    conn = get_connection()
    exists = conn.execute("SELECT 1 FROM companies WHERE id = ?", (ticker,)).fetchone()
    if not exists:
        conn.close()
        raise HTTPException(status_code=404, detail="Ticker not found: {0}".format(ticker))
    year = latest_ratio_year(conn, ticker)
    group = gen._get_peer_group(ticker)
    axes = list(gen.metric_labels)
    keys = list(gen.metrics)

    def values_for(cid):
        if not year:
            return {k: None for k in keys}
        row = conn.execute(
            "SELECT * FROM financial_ratios WHERE company_id = ? AND year = ?",
            (cid, year),
        ).fetchone()
        out = {}
        for key in keys:
            if key == "ROCE":
                out[key] = gen._compute_roce(cid, year)
            elif row is None:
                out[key] = None
            else:
                out[key] = row[key] if key in row.keys() else None
        return out

    company = values_for(ticker)
    peer_ids = []
    if group:
        peer_ids = [
            r["company_id"]
            for r in conn.execute(
                "SELECT company_id FROM peer_groups WHERE peer_group_name = ?",
                (group,),
            ).fetchall()
        ]
        benchmark = group
    else:
        peer_ids = [r["id"] for r in conn.execute("SELECT id FROM companies").fetchall()]
        benchmark = "Nifty 100"
    acc = {k: [] for k in keys}
    for pid in peer_ids:
        vals = values_for(pid)
        for k, v in vals.items():
            if v is not None:
                acc[k].append(float(v))
    peer_avg = {k: (sum(v) / len(v) if v else None) for k, v in acc.items()}
    conn.close()
    gen.close()
    return {
        "ticker": ticker,
        "peer_group": group,
        "benchmark": benchmark,
        "company": company,
        "peer_average": peer_avg,
        "axes": axes,
    }
