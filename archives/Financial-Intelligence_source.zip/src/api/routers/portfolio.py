"""Portfolio statistics endpoint."""

from pathlib import Path

import pandas as pd
from fastapi import APIRouter

from src.analytics.company_panel import PROJECT_ROOT

router = APIRouter()


@router.get("/portfolio/stats")
def portfolio_stats():
    """P10–P90 table generated on Day 37."""
    path = PROJECT_ROOT / "output" / "portfolio_stats.csv"
    if not path.exists():
        return {"metrics": []}
    df = pd.read_csv(path)
    return {"metrics": df.to_dict(orient="records")}
