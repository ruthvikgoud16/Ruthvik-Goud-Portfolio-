"""SQLite helpers for the FastAPI layer."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.analytics.company_panel import DEFAULT_DB, _is_fiscal_year

def apply_indexes(conn: sqlite3.Connection) -> None:
    """Add company_id/year indexes on large tables if missing."""
    statements = [
        "CREATE INDEX IF NOT EXISTS idx_pl_company_year ON profitandloss(company_id, year)",
        "CREATE INDEX IF NOT EXISTS idx_bs_company_year ON balancesheet(company_id, year)",
        "CREATE INDEX IF NOT EXISTS idx_cf_company_year ON cashflow(company_id, year)",
        "CREATE INDEX IF NOT EXISTS idx_fr_company_year ON financial_ratios(company_id, year)",
        "CREATE INDEX IF NOT EXISTS idx_mc_company_year ON market_cap(company_id, year)",
        "CREATE INDEX IF NOT EXISTS idx_sp_company ON stock_prices(company_id)",
        "CREATE INDEX IF NOT EXISTS idx_doc_company ON documents(company_id, year)",
        "CREATE INDEX IF NOT EXISTS idx_pg_company ON peer_groups(company_id)",
    ]
    for sql in statements:
        conn.execute(sql)
    conn.commit()


CORE_TABLES = [
    "companies",
    "sectors",
    "profitandloss",
    "balancesheet",
    "cashflow",
    "financial_ratios",
    "analysis",
    "documents",
    "prosandcons",
    "stock_prices",
]


def get_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    """Open a read-only-friendly SQLite connection with row dicts."""
    conn = sqlite3.connect(str(db_path or DEFAULT_DB), timeout=15)
    conn.row_factory = sqlite3.Row
    return conn


def rows_to_dicts(rows) -> List[Dict[str, Any]]:
    return [dict(r) for r in rows]


def latest_ratio_year(conn: sqlite3.Connection, ticker: str) -> Optional[str]:
    cur = conn.execute(
        "SELECT year FROM financial_ratios WHERE company_id = ? ORDER BY year DESC",
        (ticker,),
    )
    for row in cur.fetchall():
        if _is_fiscal_year(row["year"]):
            return row["year"]
    return None


def apply_year_window(rows: List[Dict[str, Any]], from_year: Optional[str], to_year: Optional[str]):
    out = []
    for row in rows:
        year = str(row.get("year") or "")
        if from_year and year < from_year:
            continue
        if to_year and year > to_year:
            continue
        out.append(row)
    return out
