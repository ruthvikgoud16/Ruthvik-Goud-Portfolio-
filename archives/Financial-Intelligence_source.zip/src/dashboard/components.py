"""Reusable Streamlit UI primitives for the N100 dashboard."""

from __future__ import annotations

from typing import Iterable, Optional, Sequence

import pandas as pd
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.theme import GLOBAL_CSS


def inject_theme() -> None:
    st.markdown(GLOBAL_CSS, unsafe_allow_html=True)


def render_top_header() -> None:
    st.markdown(
        """
        <div class="n100-topbar">
            <div class="kicker">N100 FINANCIAL INTELLIGENCE</div>
            <h1>N100 Financial Intelligence</h1>
            <div class="sub">Market intelligence · Valuation · Quality · Risk</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_sidebar_brand() -> None:
    st.sidebar.markdown(
        """
        <div class="n100-brand">
            <div class="mark">N100</div>
            <h2>Financial Intelligence</h2>
            <p>Nifty 100 research terminal</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_page_header(title: str, subtitle: str) -> None:
    st.markdown(f'<div class="n100-page-title">{title}</div>', unsafe_allow_html=True)
    st.markdown(f'<div class="n100-page-sub">{subtitle}</div>', unsafe_allow_html=True)


def render_section_header(title: str) -> None:
    st.markdown(f'<div class="n100-section">{title}</div>', unsafe_allow_html=True)


def render_kpi_card(label: str, value: str) -> str:
    return (
        f'<div class="n100-kpi"><div class="lbl">{label}</div>'
        f'<div class="val">{value}</div></div>'
    )


def render_kpi_row(items: Sequence[tuple[str, str]]) -> None:
    cards = "".join(render_kpi_card(label, value) for label, value in items)
    st.markdown(f'<div class="n100-kpi-grid">{cards}</div>', unsafe_allow_html=True)


def render_status_badge(text: str, kind: str = "neu") -> str:
    return f'<span class="n100-badge {kind}">{text}</span>'


def render_empty_state(message: str) -> None:
    st.markdown(f'<div class="n100-empty">{message}</div>', unsafe_allow_html=True)


def render_warning(message: str) -> None:
    st.markdown(f'<div class="n100-warn">{message}</div>', unsafe_allow_html=True)


def render_error(message: str) -> None:
    st.markdown(f'<div class="n100-error">{message}</div>', unsafe_allow_html=True)


def render_company_header(name: str, ticker: str, sector: str, peer_group: str) -> None:
    meta = " · ".join(
        part for part in (ticker, sector or "N/A", peer_group or "N/A") if part
    )
    st.markdown(
        f"""
        <div class="n100-co-head n100-card" style="margin-bottom:0.9rem;">
            <h2>{name}</h2>
            <div class="meta">{meta}</div>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_metric_table(df: pd.DataFrame) -> None:
    st.dataframe(df, use_container_width=True, hide_index=True)


def render_download_button(label: str, data: str, file_name: str, mime: str = "text/csv") -> None:
    st.download_button(label=label, data=data, file_name=file_name, mime=mime)


def split_bullets(raw: Optional[str]) -> list[str]:
    if not raw or not str(raw).strip():
        return []
    text = str(raw).replace("\r", "\n")
    parts: list[str] = []
    for chunk in text.replace(";", "\n").split("\n"):
        item = chunk.strip(" •-\t")
        if item:
            parts.append(item)
    return parts


def render_badge_list(items: Iterable[str], kind: str) -> None:
    html = "".join(render_status_badge(item, kind) for item in items)
    if html:
        st.markdown(html, unsafe_allow_html=True)
    else:
        render_empty_state("N/A — source data unavailable.")
