"""Home screen — market-wide overview."""

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.components import (
    render_empty_state,
    render_error,
    render_kpi_row,
    render_page_header,
    render_section_header,
    render_warning,
)
from src.dashboard.theme import PLOTLY_COLORS, plotly_layout
from src.dashboard.utils import db


def _format_metric_value(value, metric_type="default"):
    if metric_type == "percentage":
        return fmt.pct(value)
    if metric_type == "ratio":
        return fmt.ratio(value)
    if metric_type == "integer":
        return fmt.integer(value)
    return fmt.score(value)


def _insight_row(df: pd.DataFrame, column: str, how: str):
    if df is None or df.empty or column not in df.columns:
        return None
    series = df[column].dropna()
    if series.empty:
        return None
    idx = series.idxmax() if how == "max" else series.idxmin()
    row = df.loc[idx]
    return row, float(series.loc[idx])


def render():
    render_page_header(
        "N100 Financial Intelligence Platform",
        "Market-wide quality, valuation, growth and risk overview.",
    )

    available_years = db.get_available_fiscal_years()
    if not available_years:
        render_error("Unable to load this section. Check the data service.")
        return

    selected_year = st.sidebar.selectbox(
        "Data year",
        available_years,
        index=0,
        help="Fiscal year used for home KPIs and quality ranking",
    )
    st.sidebar.caption(f"Showing {selected_year}")

    with st.spinner("Loading company analytics…"):
        kpis = db.get_home_kpis(year=selected_year)
        sector_data = db.get_sector_breakdown()
        top_companies = db.get_top_companies_by_quality(year=selected_year, limit=5)
        screener = db.get_screener_data()

    render_kpi_row(
        [
            ("Average ROE", fmt.pct(kpis.get("average_roe"))),
            ("Median P/E", fmt.ratio(kpis.get("median_pe"))),
            ("Median D/E", fmt.ratio(kpis.get("median_de"))),
            ("Companies", fmt.integer(kpis.get("total_companies"))),
            ("Median 5Y Revenue CAGR", fmt.pct(kpis.get("median_revenue_cagr"))),
            ("Debt-Free Companies", fmt.integer(kpis.get("debt_free_count"))),
        ]
    )

    left, right = st.columns((1.15, 1), gap="large")

    with left:
        render_section_header("Sector distribution")
        if len(sector_data) > 0:
            fig = go.Figure(
                data=[
                    go.Pie(
                        labels=sector_data["broad_sector"],
                        values=sector_data["company_count"],
                        hole=0.55,
                        textposition="outside",
                        textinfo="label+value",
                        marker=dict(colors=PLOTLY_COLORS, line=dict(color="#FFFFFF", width=1)),
                        hovertemplate="<b>%{label}</b><br>Companies: %{value}<extra></extra>",
                    )
                ]
            )
            plotly_layout(fig, height=380)
            fig.update_layout(showlegend=False, margin=dict(l=10, r=10, t=10, b=10))
            st.plotly_chart(fig, use_container_width=True)
        else:
            render_warning("No sector data available")

    with right:
        render_section_header("Top quality companies")
        if len(top_companies) > 0:
            display_df = top_companies[
                ["company_id", "company_name", "sector", "composite_quality_score"]
            ].copy()
            display_df.columns = ["Ticker", "Company", "Sector", "Quality"]
            display_df["Quality"] = display_df["Quality"].map(fmt.score)
            st.dataframe(display_df, use_container_width=True, hide_index=True)
            st.caption(
                f"Highest composite quality scores for {selected_year}. "
                f"Top-5 average: {fmt.score(top_companies['composite_quality_score'].mean())}."
            )
        else:
            render_warning(f"No quality score data available for year {selected_year}")

    render_section_header("Market intelligence snapshot")
    st.caption("Derived only from loaded screener metrics. Missing fields are omitted, not zero-filled.")

    cards = []
    quality = _insight_row(screener, "composite_quality_score", "max")
    if quality:
        row, val = quality
        cards.append(("Strongest quality", f"{row['company_id']} · {fmt.score(val)}"))
    growth = _insight_row(screener, "revenue_cagr_5yr", "max")
    if growth:
        row, val = growth
        cards.append(("Fastest 5Y revenue CAGR", f"{row['company_id']} · {fmt.pct(val)}"))
    leverage = _insight_row(screener, "debt_to_equity", "max")
    if leverage:
        row, val = leverage
        cards.append(("Highest leverage (D/E)", f"{row['company_id']} · {fmt.ratio(val)}"))
    cash = _insight_row(screener, "free_cash_flow_cr", "max")
    if cash:
        row, val = cash
        cards.append(("Strongest cash generation (FCF)", f"{row['company_id']} · {fmt.inr_cr(val)}"))

    if cards:
        cols = st.columns(len(cards))
        for col, (title, body) in zip(cols, cards):
            with col:
                st.markdown(
                    f'<div class="n100-card"><div class="lbl" style="font-size:0.72rem;letter-spacing:0.06em;'
                    f'text-transform:uppercase;color:#5B6B7C;font-weight:600;">{title}</div>'
                    f'<div style="font-family:IBM Plex Mono,monospace;margin-top:0.35rem;">{body}</div></div>',
                    unsafe_allow_html=True,
                )
    else:
        render_empty_state("No annual data available for this metric.")

    st.markdown("")
    if st.button("Explore the universe — open screener"):
        st.session_state["n100_nav"] = "Screener"
        st.rerun()

    st.caption(f"Dashboard data as of {selected_year} | Latest stored year: {db.get_latest_year()}")
