"""Company Profile screen — single-name research."""

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.components import (
    render_badge_list,
    render_company_header,
    render_empty_state,
    render_error,
    render_kpi_row,
    render_page_header,
    render_section_header,
    render_warning,
    split_bullets,
)
from src.dashboard.theme import ACCENT, PRIMARY, plotly_layout
from src.dashboard.utils import db


def _format_metric_value(value, metric_type="default"):
    if value is None or pd.isna(value):
        return "N/A"
    if metric_type == "percentage":
        return fmt.pct(value)
    if metric_type == "ratio":
        return fmt.ratio(value)
    if metric_type == "currency":
        return fmt.inr_cr(value)
    if metric_type == "integer":
        return fmt.integer(value)
    return fmt.score(value)


def _peer_group_for(ticker: str) -> str:
    for group in db.get_all_peer_groups() or []:
        peers = db.get_peers(group)
        if peers is not None and not peers.empty and ticker in set(peers["company_id"]):
            return group
    return "N/A"


def render():
    render_page_header(
        "Company Profile",
        "Single-name quality, valuation, profitability and cash-flow snapshot.",
    )

    companies_df = db.get_companies()
    if len(companies_df) == 0:
        render_error("Unable to load this section. Check the data service.")
        return

    search_options = [f"{row['id']} - {row['company_name']}" for _, row in companies_df.iterrows()]
    search_options.sort()

    col_h1, col_h2 = st.columns((2.2, 1))
    with col_h2:
        selected_option = st.selectbox(
            "Search company",
            search_options,
            help="Type a ticker or name",
        )

    if not selected_option:
        render_empty_state("Select a company to view detailed analysis.")
        return

    selected_ticker = selected_option.split(" - ")[0]
    if not db.validate_ticker(selected_ticker):
        render_error("Company not found in the N100 universe.")
        return

    with st.spinner("Loading company analytics…"):
        company_name = db.get_company_name(selected_ticker)
        company_info = companies_df[companies_df["id"] == selected_ticker].iloc[0]
        sector_info = db.get_company_sector_info(selected_ticker)
        peer_group = _peer_group_for(selected_ticker)
        ratios_df = db.get_ratios(selected_ticker)
        pl_df = db.get_pl(selected_ticker)
        cf_df = db.get_cf(selected_ticker)
        valuation = db.get_valuation(selected_ticker)
        screener = db.get_screener_data()
        screener_row = screener[screener["company_id"] == selected_ticker] if not screener.empty else pd.DataFrame()

    with col_h1:
        render_company_header(
            company_name or selected_ticker,
            selected_ticker,
            sector_info.get("broad_sector") or "N/A",
            peer_group,
        )

    if company_info.get("about_company"):
        with st.expander("About the company", expanded=False):
            st.write(company_info["about_company"])

    if len(ratios_df) == 0:
        render_warning("No annual data available for this metric.")
        return

    annual = ratios_df[ratios_df["year"].astype(str) != "9999-12"]
    latest_source = annual if len(annual) else ratios_df
    latest_row = latest_source.iloc[0]
    latest_year = latest_row["year"]

    pe = pb = None
    if not screener_row.empty:
        pe = screener_row.iloc[0].get("pe_ratio")
        pb = screener_row.iloc[0].get("pb_ratio")
    if not valuation.empty:
        vrow = valuation.iloc[0]
        pe = vrow.get("pe_ratio", pe) if "pe_ratio" in vrow else pe
        pb = vrow.get("pb_ratio", pb) if "pb_ratio" in vrow else pb

    render_section_header(f"Fundamental snapshot · {latest_year}")
    render_kpi_row(
        [
            ("ROE", fmt.pct(latest_row.get("return_on_equity_pct"))),
            ("ROCE", "N/A"),
            ("P/E", fmt.ratio(pe)),
            ("P/B", fmt.ratio(pb)),
            ("D/E", fmt.ratio(latest_row.get("debt_to_equity"))),
            ("FCF", fmt.inr_cr(latest_row.get("free_cash_flow_cr"))),
        ]
    )
    st.caption(
        "ROCE is not stored on financial_ratios; the field is shown as N/A rather than inferred. "
        "P/E and P/B use market_cap / valuation outputs when present."
    )

    left, right = st.columns(2, gap="large")

    with left:
        render_section_header("Revenue / net profit")
        if len(pl_df) > 0:
            pl_df_sorted = pl_df.sort_values("year", ascending=True).copy()
            pl_df_sorted["year_label"] = pl_df_sorted["year"].str[:4]
            fig = go.Figure()
            fig.add_trace(
                go.Bar(
                    x=pl_df_sorted["year_label"],
                    y=pl_df_sorted["sales"],
                    name="Revenue",
                    marker_color=PRIMARY,
                    hovertemplate="Year: %{x}<br>Revenue: ₹%{y:,.0f} Cr<extra></extra>",
                )
            )
            fig.add_trace(
                go.Bar(
                    x=pl_df_sorted["year_label"],
                    y=pl_df_sorted["net_profit"],
                    name="Net profit",
                    marker_color=ACCENT,
                    hovertemplate="Year: %{x}<br>Net profit: ₹%{y:,.0f} Cr<extra></extra>",
                )
            )
            fig.update_layout(barmode="group")
            plotly_layout(fig, height=380)
            fig.update_xaxes(title="Fiscal year")
            fig.update_yaxes(title="₹ Crore")
            st.plotly_chart(fig, use_container_width=True)
            years_available = len(pl_df_sorted)
            if years_available < 10:
                st.caption(f"Data available for {years_available} fiscal years.")
        else:
            render_warning("No P&L data available for this company")

    with right:
        render_section_header("ROE trend")
        ratios_sorted = ratios_df[ratios_df["year"].astype(str) != "9999-12"].sort_values("year", ascending=True).copy()
        ratios_sorted["year_label"] = ratios_sorted["year"].str[:4]
        if len(ratios_sorted) > 0 and "return_on_equity_pct" in ratios_sorted.columns:
            fig = go.Figure()
            fig.add_trace(
                go.Scatter(
                    x=ratios_sorted["year_label"],
                    y=ratios_sorted["return_on_equity_pct"],
                    name="ROE",
                    mode="lines+markers",
                    line=dict(color=PRIMARY, width=2),
                    hovertemplate="Year: %{x}<br>ROE: %{y:.1f}%<extra></extra>",
                )
            )
            plotly_layout(fig, height=380)
            fig.update_xaxes(title="Fiscal year")
            fig.update_yaxes(title="ROE (%)")
            st.plotly_chart(fig, use_container_width=True)
            st.caption("ROCE series is omitted because the source table does not store ROCE.")
        else:
            render_warning("No return ratio data available")

    render_section_header("Pros / cons")
    proscons = db.get_company_proscons(selected_ticker)
    pcol, ccol = st.columns(2)
    with pcol:
        st.markdown("**Pros**")
        render_badge_list(split_bullets(proscons.get("pros")), "pos")
    with ccol:
        st.markdown("**Cons**")
        render_badge_list(split_bullets(proscons.get("cons")), "neg")

    render_section_header("Balance sheet / cash flow")
    cf_latest = cf_df.iloc[0] if len(cf_df) else None
    summary_items = [
        ("CFO", fmt.inr_cr(cf_latest.get("cash_from_operations_cr") if cf_latest is not None else None)),
        ("FCF", fmt.inr_cr(latest_row.get("free_cash_flow_cr"))),
        ("Capex", fmt.inr_cr(latest_row.get("capex_cr") if "capex_cr" in latest_row else (cf_latest.get("capex_cr") if cf_latest is not None else None))),
        ("Total debt", fmt.inr_cr(latest_row.get("total_debt_cr"))),
        ("Interest coverage", fmt.ratio(latest_row.get("interest_coverage"))),
        ("Book value / share", fmt.score(latest_row.get("book_value_per_share"))),
    ]
    render_kpi_row(summary_items)

    with st.expander("Detailed ratio history"):
        show = ratios_df.copy()
        st.dataframe(show, use_container_width=True, hide_index=True)
    with st.expander("P&L history"):
        if len(pl_df):
            st.dataframe(pl_df, use_container_width=True, hide_index=True)
        else:
            render_empty_state("No annual data available for this metric.")
    with st.expander("Cash-flow history"):
        if len(cf_df):
            st.dataframe(cf_df, use_container_width=True, hide_index=True)
        else:
            render_empty_state("No annual data available for this metric.")
