"""Dashboard pages package."""
