"""Trend Analysis screen - Time-series analysis."""

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.components import (
    render_empty_state,
    render_error,
    render_page_header,
    render_section_header,
    render_warning,
)
from src.dashboard.theme import PLOTLY_COLORS, plotly_layout
from src.dashboard.utils import db


def calculate_yoy_change(df: pd.DataFrame, metric: str) -> pd.Series:
    df_sorted = df.sort_values("year")
    yoy = df_sorted[metric].pct_change() * 100
    yoy = yoy.iloc[::-1].reset_index(drop=True)
    return yoy


def render():
    render_page_header(
        "Trend Analysis",
        "Fiscal-year series for a selected company and up to three stored metrics.",
    )

    companies = db.get_companies()
    if companies.empty:
        render_error("Unable to load this section. Check the data service.")
        return

    st.sidebar.markdown("---")
    company_options = companies["id"].tolist()
    company_names = {row["id"]: f"{row['id']} — {row['company_name']}" for _, row in companies.iterrows()}
    selected_ticker = st.sidebar.selectbox(
        "Company",
        company_options,
        format_func=lambda x: company_names.get(x, x),
    )
    if not selected_ticker:
        render_empty_state("Please select a company to view trends.")
        return

    available_metrics = db.get_available_trend_metrics()
    selected_metrics = st.sidebar.multiselect(
        "Metrics (max 3)",
        available_metrics,
        default=[available_metrics[0]] if available_metrics else [],
        max_selections=3,
    )
    if not selected_metrics:
        render_warning("Please select at least 1 metric")
        return
    if len(selected_metrics) > 3:
        render_error("Maximum 3 metrics allowed")
        return

    trend_data = db.get_trend_data(selected_ticker, selected_metrics)
    if trend_data.empty:
        render_warning(f"No trend data available for {selected_ticker}")
        return

    trend_data = trend_data.head(10)
    st.caption(f"Data available for {len(trend_data)} year(s).")

    fig = go.Figure()
    interpretations = []

    for idx, metric in enumerate(selected_metrics):
        if metric not in trend_data.columns:
            render_warning(f"Metric '{metric}' not found in data")
            continue
        metric_data = trend_data[["year", metric]].dropna()
        if metric_data.empty:
            render_warning(f"No data available for {metric}")
            continue
        metric_data = metric_data.sort_values("year")
        yoy_changes = []
        for i in range(len(metric_data)):
            if i == 0:
                yoy_changes.append(None)
            else:
                prev_val = metric_data.iloc[i - 1][metric]
                curr_val = metric_data.iloc[i][metric]
                if pd.notna(prev_val) and pd.notna(curr_val) and prev_val != 0:
                    yoy_changes.append(((curr_val - prev_val) / prev_val) * 100)
                else:
                    yoy_changes.append(None)

        hover_texts = []
        for year, value, yoy in zip(metric_data["year"], metric_data[metric], yoy_changes):
            text = f"<b>{year}</b><br>{metric}: {value:,.2f}"
            text += f"<br>YoY: {yoy:+.1f}%" if yoy is not None else "<br>YoY: N/A"
            hover_texts.append(text)

        fig.add_trace(
            go.Scatter(
                x=metric_data["year"],
                y=metric_data[metric],
                mode="lines+markers",
                name=metric,
                line=dict(color=PLOTLY_COLORS[idx % len(PLOTLY_COLORS)], width=2),
                marker=dict(size=7),
                hovertext=hover_texts,
                hoverinfo="text",
            )
        )

        if yoy_changes and yoy_changes[-1] is not None:
            last_year = metric_data.iloc[-1]["year"]
            interpretations.append(
                f"{metric} changed {yoy_changes[-1]:+.1f}% in {last_year} versus the prior fiscal year in this series."
            )
        elif yoy_changes:
            interpretations.append(f"{metric}: YoY for the latest point is N/A — source data unavailable.")

    company_name = db.get_company_name(selected_ticker)
    plotly_layout(fig, height=480, title=f"{company_name} — trend")
    fig.update_xaxes(title="Fiscal year")
    fig.update_yaxes(title="Value")
    fig.update_layout(hovermode="x unified")
    st.plotly_chart(fig, use_container_width=True)

    render_section_header("Trend interpretation")
    if interpretations:
        for line in interpretations:
            st.markdown(f"- {line}")
    else:
        render_empty_state("No annual data available for this metric.")

    render_section_header("Historical data")
    display_df = trend_data[["year"] + selected_metrics].copy()
    for metric in selected_metrics:
        if metric in display_df.columns:
            display_df[metric] = display_df[metric].apply(lambda x: f"{x:,.2f}" if pd.notna(x) else "N/A")
    st.dataframe(display_df, use_container_width=True, hide_index=True)
