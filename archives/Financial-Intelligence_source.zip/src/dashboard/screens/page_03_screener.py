"""Screener screen - Stock filtering and results."""

import pandas as pd
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.components import (
    render_download_button,
    render_empty_state,
    render_error,
    render_page_header,
    render_section_header,
)
from src.dashboard.utils import db

PRESETS = {
    "Quality": {
        "roe_min": 15.0,
        "de_max": 1.0,
        "fcf_min": 0,
        "revenue_cagr_min": 10.0,
    },
    "Value": {
        "pe_max": 20,
        "pb_max": 3.0,
        "de_max": 2.0,
        "div_yield_min": 1.0,
    },
    "Growth": {
        "pat_cagr_min": 20.0,
        "revenue_cagr_min": 15.0,
        "de_max": 2.0,
    },
    "Dividend": {
        "div_yield_min": 2.0,
        "fcf_min": 0,
    },
    "Debt-Free": {
        "de_max": 0,
        "roe_min": 12.0,
    },
    "Turnaround": {
        "revenue_cagr_min": 10.0,
        "fcf_min": 0,
    },
}


def apply_filters(df, filters):
    """Apply screener filters to DataFrame."""
    result = df.copy()

    if filters.get("roe_min") is not None:
        result = result[result["return_on_equity_pct"] >= filters["roe_min"]]

    if filters.get("de_max") is not None:
        result = result[result["debt_to_equity"] <= filters["de_max"]]

    if filters.get("fcf_min") is not None:
        result = result[result["free_cash_flow_cr"] >= filters["fcf_min"]]

    if filters.get("revenue_cagr_min") is not None:
        result = result[result["revenue_cagr_5yr"] >= filters["revenue_cagr_min"]]

    if filters.get("pat_cagr_min") is not None:
        result = result[result["pat_cagr_5yr"] >= filters["pat_cagr_min"]]

    if filters.get("opm_min") is not None:
        result = result[result["operating_profit_margin_pct"] >= filters["opm_min"]]

    if filters.get("pe_max") is not None:
        result = result[result["pe_ratio"] <= filters["pe_max"]]

    if filters.get("pb_max") is not None:
        result = result[result["pb_ratio"] <= filters["pb_max"]]

    if filters.get("div_yield_min") is not None:
        result = result[result["dividend_yield_pct"] >= filters["div_yield_min"]]

    if filters.get("icr_min") is not None:
        debt_free = result["debt_to_equity"] == 0
        has_icr = result["interest_coverage"] >= filters["icr_min"]
        result = result[debt_free | has_icr]

    return result


def render():
    render_page_header(
        "Stock Screener",
        "Filter the N100 universe by quality, growth, valuation and financial strength.",
    )

    screener_data = db.get_screener_data()
    if screener_data.empty:
        render_error("Unable to load this section. Check the data service.")
        return

    st.sidebar.markdown("---")
    st.sidebar.caption("Presets")
    selected_preset = st.sidebar.radio(
        "Preset",
        ["Custom"] + list(PRESETS.keys()),
        horizontal=False,
        label_visibility="collapsed",
    )
    default_filters = PRESETS.get(selected_preset, {}) if selected_preset != "Custom" else {}

    render_section_header("Filters")
    q, g, v = st.columns(3)
    with q:
        st.markdown("**Quality**")
        filters = {}
        filters["roe_min"] = st.slider("ROE min (%)", 0.0, 50.0, float(default_filters.get("roe_min", 0.0)), 1.0)
        filters["opm_min"] = st.slider("OPM min (%)", -40.0, 100.0, float(default_filters.get("opm_min", -40.0)), 1.0)
        filters["icr_min"] = st.slider("ICR min", 0.0, 100.0, float(default_filters.get("icr_min", 0.0)), 1.0)
    with g:
        st.markdown("**Growth**")
        filters["revenue_cagr_min"] = st.slider(
            "Revenue CAGR min (%)", -20.0, 100.0, float(default_filters.get("revenue_cagr_min", -20.0)), 1.0
        )
        filters["pat_cagr_min"] = st.slider(
            "PAT CAGR min (%)", -50.0, 100.0, float(default_filters.get("pat_cagr_min", -50.0)), 1.0
        )
        st.markdown("**Balance sheet**")
        filters["de_max"] = st.slider("D/E max", 0.0, 5.0, float(default_filters.get("de_max", 5.0)), 0.1)
    with v:
        st.markdown("**Valuation**")
        filters["pe_max"] = st.slider("P/E max", 0.0, 100.0, float(default_filters.get("pe_max", 100.0)), 1.0)
        filters["pb_max"] = st.slider("P/B max", 0.0, 20.0, float(default_filters.get("pb_max", 20.0)), 0.5)
        filters["div_yield_min"] = st.slider(
            "Dividend yield min (%)", 0.0, 10.0, float(default_filters.get("div_yield_min", 0.0)), 0.1
        )
        st.markdown("**Cash flow**")
        filters["fcf_min"] = st.slider(
            "FCF min (₹ Cr)", -10000.0, 50000.0, float(default_filters.get("fcf_min", -10000.0)), 1000.0
        )

    filtered_data = apply_filters(screener_data, filters)
    render_section_header(f"{len(filtered_data)} companies match your criteria")

    if len(filtered_data) == 0:
        render_empty_state("No companies match the current filter criteria. Try adjusting the sliders.")
        return

    display_cols = [
        "company_id",
        "company_name",
        "sector",
        "composite_quality_score",
        "return_on_equity_pct",
        "debt_to_equity",
        "revenue_cagr_5yr",
        "pe_ratio",
        "free_cash_flow_cr",
    ]
    result_df = filtered_data[display_cols].copy()
    result_df.columns = ["Ticker", "Company", "Sector", "Quality", "ROE", "D/E", "Growth", "P/E", "FCF"]
    result_df["Quality"] = result_df["Quality"].map(fmt.score)
    result_df["ROE"] = result_df["ROE"].map(fmt.pct)
    result_df["D/E"] = result_df["D/E"].map(fmt.ratio)
    result_df["Growth"] = result_df["Growth"].map(fmt.pct)
    result_df["P/E"] = result_df["P/E"].map(fmt.ratio)
    result_df["FCF"] = result_df["FCF"].map(fmt.inr_cr)

    st.dataframe(result_df, use_container_width=True, hide_index=True)
    render_download_button(
        "Download CSV",
        filtered_data[display_cols].to_csv(index=False),
        "screener_results.csv",
    )
