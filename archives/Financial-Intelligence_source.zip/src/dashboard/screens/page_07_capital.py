"""Capital Allocation Map."""

from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.components import (
    render_empty_state,
    render_error,
    render_page_header,
    render_section_header,
)
from src.dashboard.theme import PATTERN_COLORS, plotly_layout
from src.dashboard.utils import db


def render():
    render_page_header(
        "Capital Allocation Intelligence",
        "Latest-year cash-flow pattern map. Size is market cap when present.",
    )

    cap_data = db.get_capital_allocation_data()
    if cap_data.empty:
        render_error("Unable to load this section. Check the data service.")
        return

    st.caption(f"Showing capital allocation patterns for {len(cap_data)} companies (latest year).")
    pattern_counts = cap_data["pattern_label"].value_counts()

    color_map = {k: PATTERN_COLORS.get(k, "#5B6B7C") for k in cap_data["pattern_label"].unique()}

    fig = px.treemap(
        cap_data,
        path=["pattern_label", "company_id"],
        values="size_metric",
        color="pattern_label",
        color_discrete_map=color_map,
        hover_data={"company_name": True, "pattern_label": True, "size_metric": ":,.0f", "year": True},
    )
    fig.update_traces(
        textposition="middle center",
        textfont_size=11,
        hovertemplate="<b>%{label}</b><br>Pattern: %{customdata[1]}<br>Market cap: ₹%{customdata[2]:,.0f} Cr<br>Year: %{customdata[3]}<extra></extra>",
    )
    plotly_layout(fig, height=520)
    fig.update_layout(margin=dict(t=20, l=0, r=0, b=0), showlegend=False)
    st.plotly_chart(fig, use_container_width=True)

    render_section_header("Pattern summary")
    cols = st.columns(min(4, max(1, len(pattern_counts))))
    for i, (pattern, count) in enumerate(pattern_counts.items()):
        with cols[i % len(cols)]:
            st.markdown(
                f'<div class="n100-card"><div style="font-size:0.72rem;color:#5B6B7C;">{pattern}</div>'
                f'<div style="font-family:IBM Plex Mono,monospace;font-size:1.2rem;">{int(count)}</div></div>',
                unsafe_allow_html=True,
            )

    render_section_header("Companies in selected pattern")
    selected_pattern = st.selectbox("Pattern", sorted(cap_data["pattern_label"].unique()))
    if selected_pattern:
        pattern_companies = cap_data[cap_data["pattern_label"] == selected_pattern].copy()
        pattern_companies = pattern_companies.sort_values("size_metric", ascending=False)
        display_df = pattern_companies[["company_id", "company_name", "size_metric", "year"]].copy()
        display_df.columns = ["Ticker", "Company", "Market cap", "Latest year"]
        display_df["Market cap"] = display_df["Market cap"].apply(
            lambda x: fmt.inr_cr(x) if pd.notna(x) and x >= 100 else "N/A"
        )
        st.dataframe(display_df, use_container_width=True, hide_index=True)

    changes_path = Path(__file__).resolve().parents[3] / "output" / "pattern_changes.csv"
    render_section_header("Historical pattern changes")
    if changes_path.exists():
        changes = pd.read_csv(changes_path)
        st.dataframe(changes, use_container_width=True, hide_index=True)
    else:
        render_empty_state("No annual data available for this metric.")

    with st.expander("Pattern definitions"):
        st.markdown(
            """
**Based on cash flow signs (CFO, CFI, CFF):**

- **Shareholder Returns** (+, -, -): Generates cash, invests, returns to shareholders
- **Reinvestor** (+, -, +): Generates cash, invests, may take debt
- **Growth Funded by Debt** (-, -, +): Burns cash, invests, relies on external funding
- **Liquidating Assets** (+, +, -): Sells assets, returns cash to shareholders
- **Cash Accumulator** (+, +, +): Generates cash, sells assets, takes debt (hoarding)
- **Distress Signal** (-, +, -): Burns cash, sells assets, repays debt
- **Mixed**: Positive CFO, negative CFI, positive CFF (growth + shareholder returns)
- **Pre-Revenue**: Company not yet generating consistent operations
- **Other patterns**: Various combinations not fitting standard categories

*CFO = Cash from Operations, CFI = Cash from Investing, CFF = Cash from Financing*
            """
        )
    st.caption(
        f"Data source: Sprint 2 capital allocation analysis. "
        f"{len(cap_data)} companies mapped to {len(pattern_counts)} unique patterns."
    )
