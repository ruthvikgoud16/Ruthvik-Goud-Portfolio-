"""Reports document center."""

from pathlib import Path

import pandas as pd
import streamlit as st

from src.dashboard.components import (
    render_empty_state,
    render_error,
    render_page_header,
    render_section_header,
    render_warning,
)
from src.dashboard.utils import db

PROJECT_ROOT = Path(__file__).resolve().parents[3]


def check_url_status(url: str, timeout: int = 5) -> tuple:
    import requests

    try:
        response = requests.head(url, timeout=timeout, allow_redirects=True)
        if response.status_code == 404:
            return (False, 404, "Report unavailable")
        if response.status_code == 200:
            return (True, 200, "")
        return (False, response.status_code, f"HTTP {response.status_code}")
    except requests.exceptions.Timeout:
        return (False, None, "Timeout")
    except requests.exceptions.ConnectionError:
        return (False, None, "Connection error")
    except requests.exceptions.RequestException as e:
        return (False, None, str(e))


def _count(path: Path, pattern: str) -> int:
    if not path.exists():
        return 0
    return len(list(path.glob(pattern)))


def render():
    render_page_header(
        "Reports",
        "Generated research documents for companies, sectors and the portfolio.",
    )

    tear_n = _count(PROJECT_ROOT / "reports" / "tearsheets", "*_tearsheet.pdf")
    sector_n = _count(PROJECT_ROOT / "reports" / "sector", "*_report.pdf")
    port_n = 1 if (PROJECT_ROOT / "reports" / "portfolio" / "portfolio_summary.pdf").exists() else 0

    c1, c2, c3 = st.columns(3)
    with c1:
        st.markdown(
            f'<div class="n100-card"><div style="font-size:0.72rem;letter-spacing:0.08em;color:#5B6B7C;">COMPANY TEARSHEET</div>'
            f"<h3 style='margin:0.35rem 0;'>Company tearsheets</h3>"
            f"<p style='color:#5B6B7C;font-size:0.9rem;'>One PDF per N100 name with KPIs and statements.</p>"
            f"<div style='font-family:IBM Plex Mono,monospace;'>{tear_n} available</div></div>",
            unsafe_allow_html=True,
        )
    with c2:
        st.markdown(
            f'<div class="n100-card"><div style="font-size:0.72rem;letter-spacing:0.08em;color:#5B6B7C;">SECTOR REPORTS</div>'
            f"<h3 style='margin:0.35rem 0;'>Sector reports</h3>"
            f"<p style='color:#5B6B7C;font-size:0.9rem;'>Ten broad-sector summaries. No extra sector is invented.</p>"
            f"<div style='font-family:IBM Plex Mono,monospace;'>{sector_n} available</div></div>",
            unsafe_allow_html=True,
        )
    with c3:
        st.markdown(
            f'<div class="n100-card"><div style="font-size:0.72rem;letter-spacing:0.08em;color:#5B6B7C;">PORTFOLIO</div>'
            f"<h3 style='margin:0.35rem 0;'>Portfolio summary</h3>"
            f"<p style='color:#5B6B7C;font-size:0.9rem;'>Universe-level allocation and quality snapshot.</p>"
            f"<div style='font-family:IBM Plex Mono,monospace;'>{port_n} available</div></div>",
            unsafe_allow_html=True,
        )

    companies = db.get_companies()
    if companies.empty:
        render_error("Unable to load this section. Check the data service.")
        return

    st.sidebar.markdown("---")
    company_options = companies["id"].tolist()
    company_names = {row["id"]: f"{row['id']} — {row['company_name']}" for _, row in companies.iterrows()}
    selected_ticker = st.sidebar.selectbox(
        "Company",
        company_options,
        format_func=lambda x: company_names.get(x, x),
    )
    if not selected_ticker:
        render_empty_state("Please select a company to view annual reports.")
        return

    reports = db.get_annual_reports(selected_ticker)
    company_name = db.get_company_name(selected_ticker)
    render_section_header(f"Filed annual reports — {company_name}")

    if reports.empty:
        render_warning(f"No annual reports available for {selected_ticker}")
        st.caption("This company may not have reports in the database, or reports may not be documented yet.")
        return

    st.caption(f"{len(reports)} annual report(s) in source documents.")
    check_urls = st.sidebar.checkbox(
        "Verify report availability",
        value=False,
        help="HEAD-request each PDF URL (may be slow)",
    )

    for _, row in reports.iterrows():
        year = row["year"]
        url = row["annual_report"]
        cols = st.columns((1, 3, 1))
        with cols[0]:
            st.markdown(f"**{year}**")
        with cols[1]:
            if pd.notna(url) and url:
                st.markdown(f"[Open PDF]({url})")
                if check_urls:
                    with st.spinner(f"Checking {year}..."):
                        is_valid, status_code, error_msg = check_url_status(url)
                        if status_code == 404:
                            st.error("Report unavailable (HTTP 404)")
                        elif not is_valid:
                            st.warning(error_msg)
                        elif status_code == 200:
                            st.success("Report accessible")
            else:
                st.caption("No URL available")
        with cols[2]:
            st.caption("BSE India")

    render_section_header("Report list")
    display_df = reports.copy()
    display_df.columns = ["Year", "Report URL"]
    display_df["Report URL"] = display_df["Report URL"].apply(lambda x: x if pd.notna(x) else "N/A")
    st.dataframe(display_df, use_container_width=True, hide_index=True)
    st.caption(
        "Annual reports sourced from BSE India. URLs may change or become unavailable over time. "
        f"Total reports: {len(reports)}."
    )
