"""Peer Comparison screen - Radar charts and peer analysis."""

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.components import (
    render_empty_state,
    render_error,
    render_kpi_row,
    render_page_header,
    render_section_header,
    render_status_badge,
    render_warning,
)
from src.dashboard.theme import ACCENT, PRIMARY, plotly_layout
from src.dashboard.utils import db


def _vs_median(value, median) -> str:
    if value is None or pd.isna(value) or median is None or pd.isna(median):
        return render_status_badge("N/A", "neu")
    if median == 0:
        return render_status_badge("near median", "neu")
    delta = (float(value) - float(median)) / abs(float(median))
    if abs(delta) <= 0.05:
        return render_status_badge("near median", "neu")
    if delta > 0:
        return render_status_badge("above median", "pos")
    return render_status_badge("below median", "neg")


def render():
    render_page_header(
        "Peer Comparison",
        "Company versus peer-group median on quality, profitability and leverage.",
    )

    peer_groups = db.get_all_peer_groups()
    if not peer_groups:
        render_error("Unable to load this section. Check the data service.")
        return

    st.sidebar.markdown("---")
    selected_group = st.sidebar.selectbox("Peer group", peer_groups)
    if not selected_group:
        render_empty_state("Please select a peer group.")
        return

    peer_companies = db.get_peers(selected_group)
    if peer_companies.empty:
        render_warning(f"No companies found in {selected_group}")
        return

    company_options = peer_companies["company_id"].tolist()
    selected_company = st.sidebar.selectbox(
        "Company",
        company_options,
        format_func=lambda x: f"{x} — {db.get_company_name(x)}",
    )

    render_section_header(f"Peer overview · {selected_group}")
    radar_data = db.get_peer_radar_data(selected_group)
    metrics = ["ROE", "ROCE", "NPM", "D/E", "FCF", "PAT CAGR", "Revenue CAGR", "Quality Score"]

    if radar_data.empty:
        render_warning("Insufficient data for radar chart")
    else:
        company_data = radar_data[radar_data["company_id"] == selected_company]
        if company_data.empty:
            render_warning(f"No radar data available for {selected_company}")
        else:
            company_pivot = (
                company_data.pivot_table(index="metric", values="value", aggfunc="first")
                .reindex(metrics)
                .squeeze()
            )
            peer_pivot = radar_data.groupby("metric")["value"].mean().reindex(metrics)
            if int(pd.Series(company_pivot).isna().sum()) > 5:
                render_warning(
                    f"Insufficient metrics available for {selected_company} "
                    f"(only {int(company_pivot.notna().sum())}/8)"
                )
            else:
                company_values = company_pivot.fillna(0).tolist()
                peer_values = peer_pivot.fillna(0).tolist()
                fig = go.Figure()
                fig.add_trace(
                    go.Scatterpolar(
                        r=company_values,
                        theta=metrics,
                        fill="toself",
                        name=selected_company,
                        line=dict(color=PRIMARY, width=2),
                    )
                )
                fig.add_trace(
                    go.Scatterpolar(
                        r=peer_values,
                        theta=metrics,
                        fill="toself",
                        name="Peer average",
                        line=dict(color=ACCENT, width=2, dash="dash"),
                    )
                )
                fig.update_layout(
                    polar=dict(
                        radialaxis=dict(visible=True, range=[0, 100], gridcolor="#EEF2F6"),
                        bgcolor="#FFFFFF",
                    ),
                    showlegend=True,
                    height=480,
                    title=f"{db.get_company_name(selected_company)} vs {selected_group} (percentile 0–100)",
                    paper_bgcolor="rgba(0,0,0,0)",
                    font=dict(family="IBM Plex Sans", size=12),
                    margin=dict(l=40, r=40, t=60, b=40),
                )
                st.plotly_chart(fig, use_container_width=True)
                missing_metrics = company_pivot[company_pivot.isna()].index.tolist()
                if missing_metrics:
                    st.caption(f"Missing percentile inputs (plotted as 0 on the radar only): {', '.join(missing_metrics)}")

    render_section_header("Company vs peer median")
    peer_metrics = db.get_peer_group_metrics(selected_group)
    if peer_metrics.empty:
        render_warning("No metrics available for peer group")
        return

    numeric_cols = [c for c in peer_metrics.columns if c not in ("company_id", "Company")]
    medians = peer_metrics[numeric_cols].median(numeric_only=True)
    focus = peer_metrics[peer_metrics["company_id"] == selected_company]
    if not focus.empty:
        row = focus.iloc[0]
        chips = []
        for col in numeric_cols:
            chips.append(
                f"<div class='n100-card' style='margin-bottom:0.45rem;'><div style='font-size:0.72rem;color:#5B6B7C;'>{col}</div>"
                f"<div style='font-family:IBM Plex Mono,monospace;'>{fmt.score(row[col]) if col != 'D/E' else fmt.ratio(row[col])}</div>"
                f"{_vs_median(row[col], medians.get(col))}</div>"
            )
        st.markdown(
            "<div style='display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0.55rem;'>"
            + "".join(chips)
            + "</div>",
            unsafe_allow_html=True,
        )

    def highlight_selected(row):
        if row["company_id"] == selected_company:
            return ["background-color: #EEF2F6"] * len(row)
        return [""] * len(row)

    styled_df = peer_metrics.style.apply(highlight_selected, axis=1)
    st.dataframe(styled_df, use_container_width=True, hide_index=True)

    bench = peer_companies[peer_companies["is_benchmark"] == "True"] if "is_benchmark" in peer_companies.columns else pd.DataFrame()
    avg_quality = peer_metrics["Quality Score"].mean() if "Quality Score" in peer_metrics.columns else None
    render_kpi_row(
        [
            ("Companies in group", fmt.integer(len(peer_metrics))),
            ("Benchmark", bench["company_id"].iloc[0] if not bench.empty else "None"),
            ("Avg quality score", fmt.score(avg_quality)),
        ]
    )
