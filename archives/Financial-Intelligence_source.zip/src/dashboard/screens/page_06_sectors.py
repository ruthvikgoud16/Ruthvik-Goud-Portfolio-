"""Sector Analysis screen."""

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from src.dashboard import formatters as fmt
from src.dashboard.components import (
    render_empty_state,
    render_error,
    render_kpi_row,
    render_page_header,
    render_section_header,
    render_warning,
)
from src.dashboard.theme import PLOTLY_COLORS, PRIMARY, plotly_layout
from src.dashboard.utils import db


def _sector_slice(universe: pd.DataFrame, sector: str) -> pd.DataFrame:
    if universe is None or universe.empty or "sector" not in universe.columns:
        return pd.DataFrame()
    return universe[universe["sector"] == sector]


def render():
    render_page_header(
        "Sector Analytics",
        "Ten authoritative broad sectors. Peer groups are a separate taxonomy.",
    )

    sectors = db.get_all_sectors()
    if not sectors:
        render_error("Unable to load this section. Check the data service.")
        return

    st.sidebar.markdown("---")
    selected_sector = st.sidebar.selectbox("Sector", sectors)
    if not selected_sector:
        render_empty_state("Please select a sector.")
        return

    sector_data = db.get_sector_companies(selected_sector)
    if sector_data.empty:
        render_warning(f"No data available for {selected_sector}")
        return

    medians = db.get_sector_medians(selected_sector) or {}
    universe = db.get_screener_data()
    slice_df = _sector_slice(universe, selected_sector)
    sector_pe = slice_df["pe_ratio"].median() if not slice_df.empty else None
    sector_cagr = slice_df["revenue_cagr_5yr"].median() if not slice_df.empty else None
    n100_roe = universe["return_on_equity_pct"].median() if not universe.empty else None
    n100_de = universe["debt_to_equity"].median() if not universe.empty else None
    n100_cagr = universe["revenue_cagr_5yr"].median() if not universe.empty else None

    render_section_header("Sector snapshot")
    render_kpi_row(
        [
            ("Companies", fmt.integer(len(sector_data))),
            ("Median ROE", fmt.pct(medians.get("ROE %"))),
            ("Median P/E", fmt.ratio(sector_pe)),
            ("Median growth", fmt.pct(sector_cagr)),
            ("Median D/E", fmt.ratio(medians.get("D/E"))),
        ]
    )

    render_section_header("Revenue vs ROE")
    bubble_data = sector_data.dropna(subset=["revenue", "roe"])
    if bubble_data.empty:
        render_warning("Insufficient data for bubble chart (need Revenue and ROE)")
    else:
        bubble_data = bubble_data.copy()
        has_mcap = bubble_data["market_cap_crore"].notna()
        if not has_mcap.any():
            st.caption("Market cap data not available — equal-sized bubbles.")
            bubble_data["bubble_size"] = 100
        else:
            median_mcap = bubble_data.loc[has_mcap, "market_cap_crore"].median()
            bubble_data["bubble_size"] = bubble_data["market_cap_crore"].fillna(median_mcap)

        fig = px.scatter(
            bubble_data,
            x="revenue",
            y="roe",
            size="bubble_size",
            color="sub_sector",
            hover_name="company_id",
            color_discrete_sequence=PLOTLY_COLORS,
            labels={
                "revenue": "Revenue (₹ Crore)",
                "roe": "Return on equity (%)",
                "sub_sector": "Sub-sector",
            },
        )
        fig.update_traces(marker=dict(line=dict(width=1, color="white"), opacity=0.78))
        plotly_layout(fig, height=480, title=f"{selected_sector} — bubble size = market cap")
        st.plotly_chart(fig, use_container_width=True)

    render_section_header("Sector vs N100")
    compare = pd.DataFrame(
        {
            "Metric": ["Median ROE", "Median D/E", "Median 5Y revenue CAGR"],
            "Sector": [medians.get("ROE %"), medians.get("D/E"), sector_cagr],
            "N100": [n100_roe, n100_de, n100_cagr],
        }
    )
    fig_bar = go.Figure()
    fig_bar.add_trace(go.Bar(name="Sector", x=compare["Metric"], y=compare["Sector"], marker_color=PRIMARY))
    fig_bar.add_trace(go.Bar(name="N100", x=compare["Metric"], y=compare["N100"], marker_color="#8AA4B7"))
    fig_bar.update_layout(barmode="group")
    plotly_layout(fig_bar, height=360)
    st.plotly_chart(fig_bar, use_container_width=True)
    st.caption("Bars use medians of currently loaded fields. Missing medians are omitted from the series.")

    render_section_header("Top companies in sector")
    ranked = sector_data.sort_values("roe", ascending=False, na_position="last")
    display_df = ranked[
        ["company_id", "company_name", "sub_sector", "revenue", "roe", "market_cap_crore"]
    ].copy()
    display_df.columns = ["Ticker", "Company", "Sub-sector", "Revenue", "ROE", "Market cap"]
    display_df["Revenue"] = display_df["Revenue"].map(fmt.inr_cr)
    display_df["ROE"] = display_df["ROE"].map(fmt.pct)
    display_df["Market cap"] = display_df["Market cap"].map(fmt.inr_cr)
    st.dataframe(display_df, use_container_width=True, hide_index=True)
