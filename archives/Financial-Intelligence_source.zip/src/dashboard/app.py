"""
N100 Financial Intelligence — Streamlit dashboard shell.
Eight screens; SQLite-backed. UI only lives here and in screens/.
"""

from pathlib import Path
import sys

import streamlit as st

project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))
sys.path.insert(0, str(Path(__file__).parent))

from src.dashboard.components import inject_theme, render_sidebar_brand, render_top_header

st.set_page_config(
    page_title="N100 Financial Intelligence",
    page_icon="◆",
    layout="wide",
    initial_sidebar_state="expanded",
)

NAV_PAGES = [
    "Home",
    "Company Profile",
    "Screener",
    "Peer Comparison",
    "Trend Analysis",
    "Sector Analysis",
    "Capital Allocation",
    "Annual Reports",
]


def main():
    inject_theme()
    render_top_header()
    render_sidebar_brand()

    st.sidebar.caption("Workspace")
    page = st.sidebar.radio(
        "Select Screen",
        NAV_PAGES,
        label_visibility="collapsed",
        key="n100_nav",
    )

    st.sidebar.markdown("---")
    st.sidebar.caption("About")
    st.sidebar.markdown(
        '<p style="font-size:0.78rem;color:#8AA4B7;line-height:1.45;">'
        "Direct SQLite research views for 92 Nifty 100 names. "
        "Fiscal year and company controls appear below when a screen needs them. "
        "Missing source fields display as N/A."
        "</p>",
        unsafe_allow_html=True,
    )

    if page == "Home":
        from screens import page_01_home
        page_01_home.render()
    elif page == "Company Profile":
        from screens import page_02_profile
        page_02_profile.render()
    elif page == "Screener":
        from screens import page_03_screener
        page_03_screener.render()
    elif page == "Peer Comparison":
        from screens import page_04_peers
        page_04_peers.render()
    elif page == "Trend Analysis":
        from screens import page_05_trends
        page_05_trends.render()
    elif page == "Sector Analysis":
        from screens import page_06_sectors
        page_06_sectors.render()
    elif page == "Capital Allocation":
        from screens import page_07_capital
        page_07_capital.render()
    elif page == "Annual Reports":
        from screens import page_08_reports
        page_08_reports.render()


if __name__ == "__main__":
    main()
