"""Consistent numerical display. Missing values stay N/A (never coerced to 0)."""

from __future__ import annotations

from typing import Any

import pandas as pd


def _missing(value: Any) -> bool:
    if value is None:
        return True
    try:
        if pd.isna(value):
            return True
    except (TypeError, ValueError):
        pass
    return False


def pct(value: Any, digits: int = 1) -> str:
    if _missing(value):
        return "N/A"
    return f"{float(value):.{digits}f}%"


def ratio(value: Any, digits: int = 2) -> str:
    if _missing(value):
        return "N/A"
    return f"{float(value):.{digits}f}x"


def inr_cr(value: Any) -> str:
    if _missing(value):
        return "N/A"
    return f"₹{float(value):,.0f} Cr"


def integer(value: Any) -> str:
    if _missing(value):
        return "N/A"
    return f"{int(round(float(value)))}"


def score(value: Any) -> str:
    if _missing(value):
        return "N/A"
    return f"{float(value):.1f}"


def text_or_na(value: Any) -> str:
    if _missing(value) or str(value).strip() == "":
        return "N/A"
    return str(value)
