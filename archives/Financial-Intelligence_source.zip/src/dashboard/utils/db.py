"""
Dashboard database access layer with caching.

All database queries are cached with TTL=600 seconds (10 minutes).
Provides a clean interface to the SQLite database for all dashboard pages.
"""

import sqlite3
import os
from pathlib import Path
from typing import Optional, List, Dict, Any
import pandas as pd
import streamlit as st
import logging

logger = logging.getLogger(__name__)


def _get_db_path() -> str:
    """
    Resolve the SQLite database path relative to project root.
    
    Works correctly regardless of where streamlit run is invoked from.
    
    Returns:
        str: Absolute path to nifty100.db
    
    Raises:
        FileNotFoundError: If database does not exist
    """
    # Get the directory of this file (src/dashboard/utils/)
    current_file = Path(__file__).resolve()
    # Go up to project root (src/dashboard/utils -> src/dashboard -> src -> project_root)
    project_root = current_file.parent.parent.parent.parent
    db_path = project_root / "nifty100.db"
    
    if not db_path.exists():
        raise FileNotFoundError(f"Database not found at {db_path}")
    
    return str(db_path)


def _get_connection() -> sqlite3.Connection:
    """
    Get a read-only SQLite connection.
    
    Returns:
        sqlite3.Connection: Database connection
    """
    db_path = _get_db_path()
    conn = sqlite3.connect(db_path, timeout=10.0)
    conn.row_factory = sqlite3.Row  # Return rows as dictionaries
    return conn


@st.cache_data(ttl=600)
def get_companies() -> pd.DataFrame:
    """
    Get all companies from the database.
    
    Returns:
        DataFrame with columns: id (ticker), company_name, and other company attributes
    """
    try:
        conn = _get_connection()
        df = pd.read_sql_query(
            "SELECT id, company_name, about_company, website, nse_profile, bse_profile FROM companies ORDER BY id",
            conn
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching companies: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_ratios(ticker: str, year: Optional[str] = None) -> pd.DataFrame:
    """
    Get financial ratios for a company.
    
    Args:
        ticker: Company ticker/ID (e.g., 'TCS')
        year: Optional year filter (e.g., '2024-03'). If None, return all years.
    
    Returns:
        DataFrame with financial ratios
    """
    try:
        conn = _get_connection()
        if year:
            df = pd.read_sql_query(
                """
                SELECT * FROM financial_ratios 
                WHERE company_id = ? AND year = ?
                ORDER BY year DESC
                """,
                conn,
                params=(ticker, year)
            )
        else:
            df = pd.read_sql_query(
                """
                SELECT * FROM financial_ratios 
                WHERE company_id = ?
                ORDER BY year DESC
                """,
                conn,
                params=(ticker,)
            )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching ratios for {ticker}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_pl(ticker: str) -> pd.DataFrame:
    """
    Get profit & loss data for a company.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        DataFrame with P&L data (sales, net_profit, etc.)
    """
    try:
        conn = _get_connection()
        df = pd.read_sql_query(
            """
            SELECT company_id, year, sales, net_profit, operating_profit, eps
            FROM profitandloss 
            WHERE company_id = ?
            ORDER BY year DESC
            """,
            conn,
            params=(ticker,)
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching P&L for {ticker}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_bs(ticker: str) -> pd.DataFrame:
    """
    Get balance sheet data for a company.
    
    Note: Balance sheet table structure may vary. This returns available data.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        DataFrame with balance sheet data
    """
    try:
        conn = _get_connection()
        # Query to explore available balance sheet data
        df = pd.read_sql_query(
            """
            SELECT * FROM financial_ratios
            WHERE company_id = ?
            ORDER BY year DESC
            """,
            conn,
            params=(ticker,)
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching balance sheet for {ticker}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_cf(ticker: str) -> pd.DataFrame:
    """
    Get cash flow data for a company.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        DataFrame with cash flow data
    """
    try:
        conn = _get_connection()
        df = pd.read_sql_query(
            """
            SELECT company_id, year, cash_from_operations_cr, free_cash_flow_cr, capex_cr
            FROM financial_ratios
            WHERE company_id = ?
            ORDER BY year DESC
            """,
            conn,
            params=(ticker,)
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching cash flow for {ticker}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_sectors() -> pd.DataFrame:
    """
    Get all unique sectors from companies table.
    
    Returns:
        DataFrame with sector information
    """
    try:
        conn = _get_connection()
        # Get unique sectors - companies table doesn't have a sector column
        # Instead, extract from broader dataset or return empty
        df = pd.read_sql_query(
            """
            SELECT DISTINCT company_id FROM companies
            ORDER BY company_id
            """,
            conn
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching sectors: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_peers(group_name: str) -> pd.DataFrame:
    """
    Get all companies in a peer group.
    
    Args:
        group_name: Peer group name (e.g., 'IT Services', 'Private Banks')
    
    Returns:
        DataFrame with companies in the peer group
    """
    try:
        conn = _get_connection()
        df = pd.read_sql_query(
            """
            SELECT company_id, peer_group_name, is_benchmark
            FROM peer_groups
            WHERE peer_group_name = ?
            ORDER BY company_id
            """,
            conn,
            params=(group_name,)
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching peers for group {group_name}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_valuation(ticker: str) -> pd.DataFrame:
    """
    Get valuation data for a company from Day 26 valuation outputs.
    
    Returns valuation metrics:
    - P/E, P/B, EV/EBITDA
    - FCF_yield_pct
    - 5yr_median_PE (sector median)
    - PE_vs_sector_median_pct
    - flag (Caution/Discount/Fair)
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        DataFrame with valuation data (single row or empty if not found)
    """
    try:
        import os
        # Load valuation summary from Day 26 output
        valuation_file = os.path.join(os.path.dirname(_get_db_path()), 'output', 'valuation_summary.xlsx')
        
        if not os.path.exists(valuation_file):
            logger.warning(f"Valuation file not found: {valuation_file}")
            return pd.DataFrame()
        
        # Read and filter for ticker
        df = pd.read_excel(valuation_file)
        result = df[df['company_id'] == ticker]
        
        if result.empty:
            logger.info(f"No valuation data found for {ticker}")
        
        return result
    except Exception as e:
        logger.error(f"Error loading valuation for {ticker}: {e}")
        return pd.DataFrame()


def get_all_peer_groups() -> List[str]:
    """
    Get all unique peer group names.
    
    Returns:
        List of peer group names
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT peer_group_name FROM peer_groups ORDER BY peer_group_name")
        groups = [row[0] for row in cursor.fetchall()]
        conn.close()
        return groups
    except Exception as e:
        logger.error(f"Error fetching peer groups: {e}")
        return []


@st.cache_data(ttl=600)
def get_sector_breakdown() -> pd.DataFrame:
    """
    Get sector breakdown with company counts.
    
    Returns:
        DataFrame with columns: broad_sector, company_count
    """
    try:
        conn = _get_connection()
        df = pd.read_sql_query(
            """
            SELECT broad_sector, COUNT(*) as company_count
            FROM sectors
            GROUP BY broad_sector
            ORDER BY company_count DESC
            """,
            conn
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching sector breakdown: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_top_companies_by_quality(year: Optional[str] = None, limit: int = 5) -> pd.DataFrame:
    """
    Get top companies by composite quality score.
    
    Args:
        year: Optional year filter (e.g., '2024-09'). If None, use latest year.
        limit: Number of companies to return (default 5)
    
    Returns:
        DataFrame with company_id, company_name, sector, composite_quality_score
    """
    try:
        conn = _get_connection()
        
        if year is None:
            # Get the latest year that is not TTM
            year_query = "SELECT MAX(year) FROM financial_ratios WHERE year != '9999-12'"
            cursor = conn.cursor()
            cursor.execute(year_query)
            result = cursor.fetchone()
            year = result[0] if result and result[0] else None
            
            if not year:
                return pd.DataFrame()
        
        df = pd.read_sql_query(
            """
            SELECT 
                c.id as company_id,
                c.company_name,
                s.broad_sector as sector,
                fr.composite_quality_score,
                fr.year
            FROM financial_ratios fr
            JOIN companies c ON c.id = fr.company_id
            JOIN sectors s ON s.company_id = fr.company_id
            WHERE fr.year = ? AND fr.composite_quality_score IS NOT NULL
            ORDER BY fr.composite_quality_score DESC
            LIMIT ?
            """,
            conn,
            params=(year, limit)
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching top companies: {e}")
        return pd.DataFrame()


def get_home_kpis(year: Optional[str] = None) -> Dict[str, Any]:
    """
    Compute home screen KPIs for a given year.
    
    Args:
        year: Year to compute for (e.g., '2024-09'). If None, use latest available year.
    
    Returns:
        Dict with keys: average_roe, median_pe, median_de, total_companies, 
                        median_revenue_cagr, debt_free_count, year_used
    """
    try:
        conn = _get_connection()
        
        if year is None:
            # Get latest year
            cursor = conn.cursor()
            cursor.execute("SELECT MAX(year) FROM financial_ratios WHERE year != '9999-12'")
            result = cursor.fetchone()
            year = result[0] if result and result[0] else None
            
            if not year:
                return {
                    'average_roe': None,
                    'median_pe': None,
                    'median_de': None,
                    'total_companies': 0,
                    'median_revenue_cagr': None,
                    'debt_free_count': 0,
                    'year_used': None
                }
        
        # Fetch all KPI data for the year
        df = pd.read_sql_query(
            """
            SELECT 
                return_on_equity_pct,
                debt_to_equity,
                revenue_cagr_5yr,
                composite_quality_score
            FROM financial_ratios
            WHERE year = ? AND return_on_equity_pct IS NOT NULL
            """,
            conn,
            params=(year,)
        )
        
        # Calculate KPIs
        average_roe = df['return_on_equity_pct'].mean() if len(df) > 0 else None
        median_de = df['debt_to_equity'].median() if len(df) > 0 else None
        median_revenue_cagr = df['revenue_cagr_5yr'].median() if len(df) > 0 else None
        
        # Count debt-free companies (D/E is 0 or very close to 0)
        debt_free_count = len(df[df['debt_to_equity'] <= 0.01]) if len(df) > 0 else 0
        
        # Total companies in database
        total_companies = 92
        
        # Note: P/E ratio not directly available in financial_ratios
        # It requires market_cap data (Day 26 feature)
        # For now, set to None and display N/A
        median_pe = None
        
        conn.close()
        
        return {
            'average_roe': average_roe,
            'median_pe': median_pe,
            'median_de': median_de,
            'total_companies': total_companies,
            'median_revenue_cagr': median_revenue_cagr,
            'debt_free_count': debt_free_count,
            'year_used': year
        }
    
    except Exception as e:
        logger.error(f"Error computing home KPIs: {e}")
        return {
            'average_roe': None,
            'median_pe': None,
            'median_de': None,
            'total_companies': 0,
            'median_revenue_cagr': None,
            'debt_free_count': 0,
            'year_used': None
        }


def get_available_fiscal_years() -> List[str]:
    """
    Get all available fiscal years, formatted for user display.
    
    Returns:
        List of years in format that can be displayed to users
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT DISTINCT year FROM financial_ratios WHERE year != '9999-12' ORDER BY year DESC"
        )
        years = [row[0] for row in cursor.fetchall()]
        conn.close()
        return years
    except Exception as e:
        logger.error(f"Error fetching available years: {e}")
        return []


def get_company_sector_info(ticker: str) -> Dict[str, str]:
    """
    Get sector and sub-sector information for a company.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        Dict with keys: broad_sector, sub_sector
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT broad_sector, sub_sector FROM sectors WHERE company_id = ?",
            (ticker,)
        )
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'broad_sector': result[0],
                'sub_sector': result[1]
            }
        else:
            return {
                'broad_sector': None,
                'sub_sector': None
            }
    except Exception as e:
        logger.error(f"Error fetching sector info for {ticker}: {e}")
        return {
            'broad_sector': None,
            'sub_sector': None
        }


def get_company_proscons(ticker: str) -> Dict[str, Optional[str]]:
    """
    Get pros and cons for a company.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        Dict with keys: pros, cons (both may be None if not available)
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT pros, cons FROM prosandcons WHERE company_id = ?",
            (ticker,)
        )
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return {
                'pros': result[0] if result[0] else None,
                'cons': result[1] if result[1] else None
            }
        else:
            return {
                'pros': None,
                'cons': None
            }
    except Exception as e:
        logger.error(f"Error fetching pros/cons for {ticker}: {e}")
        return {
            'pros': None,
            'cons': None
        }


@st.cache_data(ttl=600)
def get_screener_data() -> pd.DataFrame:
    """
    Get comprehensive dataset for screener with all filterable metrics.
    
    Returns:
        DataFrame with company_id, name, sector, and all screener metrics
    """
    try:
        conn = _get_connection()
        
        # Join financial_ratios, market_cap, companies, and sectors
        df = pd.read_sql_query(
            """
            SELECT
                c.id as company_id,
                c.company_name,
                s.broad_sector as sector,
                fr.return_on_equity_pct,
                fr.debt_to_equity,
                fr.free_cash_flow_cr,
                fr.revenue_cagr_5yr,
                fr.pat_cagr_5yr,
                fr.operating_profit_margin_pct,
                fr.interest_coverage,
                fr.composite_quality_score,
                mc.pe_ratio,
                mc.pb_ratio,
                mc.dividend_yield_pct
            FROM companies c
            JOIN financial_ratios fr ON c.id = fr.company_id
            JOIN sectors s ON c.id = s.company_id
            LEFT JOIN market_cap mc ON c.id = mc.company_id
            WHERE fr.year = (
                SELECT MAX(year) FROM financial_ratios 
                WHERE company_id = c.id AND year != '9999-12'
            )
            AND (mc.year IS NULL OR mc.year = (
                SELECT MAX(year) FROM market_cap WHERE company_id = c.id
            ))
            ORDER BY c.company_name
            """,
            conn
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching screener data: {e}")
        return pd.DataFrame()


def validate_ticker(ticker: str) -> bool:
    """
    Check if a ticker exists in the database.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        bool: True if ticker exists, False otherwise
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1 FROM companies WHERE id = ? LIMIT 1", (ticker,))
        exists = cursor.fetchone() is not None
        conn.close()
        return exists
    except Exception as e:
        logger.error(f"Error validating ticker {ticker}: {e}")
        return False


def get_company_name(ticker: str) -> Optional[str]:
    """
    Get company name for a ticker.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        Company name or None if not found
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT company_name FROM companies WHERE id = ?", (ticker,))
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else None
    except Exception as e:
        logger.error(f"Error getting company name for {ticker}: {e}")
        return None


def get_latest_year() -> Optional[str]:
    """
    Get the latest available year in the dataset.
    
    Returns:
        Latest year string (e.g., '2024-03') or None
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(year) FROM financial_ratios WHERE year != '9999-12'")
        result = cursor.fetchone()
        conn.close()
        return result[0] if result and result[0] else None
    except Exception as e:
        logger.error(f"Error getting latest year: {e}")
        return None


def get_available_years(ticker: str) -> List[str]:
    """
    Get all available years for a company.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        List of years in descending order
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT DISTINCT year FROM financial_ratios WHERE company_id = ? ORDER BY year DESC",
            (ticker,)
        )
        years = [row[0] for row in cursor.fetchall()]
        conn.close()
        return years
    except Exception as e:
        logger.error(f"Error getting years for {ticker}: {e}")
        return []



@st.cache_data(ttl=600)
def get_company_name(ticker: str) -> str:
    """
    Get company name for a ticker.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        Company name or ticker if not found
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT company_name FROM companies WHERE id = ?",
            (ticker,)
        )
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return result[0]
        else:
            return ticker
    except Exception as e:
        logger.error(f"Error fetching company name for {ticker}: {e}")
        return ticker


@st.cache_data(ttl=600)
def get_peers(peer_group: str) -> pd.DataFrame:
    """
    Get all companies in a peer group.
    
    Args:
        peer_group: Peer group name
    
    Returns:
        DataFrame with company_id, is_benchmark columns
    """
    try:
        conn = _get_connection()
        df = pd.read_sql_query(
            """
            SELECT company_id, is_benchmark
            FROM peer_groups
            WHERE peer_group_name = ?
            ORDER BY company_id
            """,
            conn,
            params=(peer_group,)
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching peers for {peer_group}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_peer_radar_data(peer_group: str) -> pd.DataFrame:
    """
    Get radar chart data for a peer group (8 metrics, normalized 0-100).
    
    Args:
        peer_group: Peer group name
    
    Returns:
        DataFrame with company_id, metric, value columns
    """
    try:
        conn = _get_connection()
        
        # Get companies in peer group
        cursor = conn.cursor()
        cursor.execute(
            "SELECT company_id FROM peer_groups WHERE peer_group_name = ?",
            (peer_group,)
        )
        company_ids = [row[0] for row in cursor.fetchall()]
        
        if not company_ids:
            return pd.DataFrame()
        
        # Get metrics for these companies from peer_percentiles
        # Use percentile_rank * 100 as normalized value
        df = pd.read_sql_query(
            """
            SELECT 
                company_id,
                CASE metric_name
                    WHEN 'ROE' THEN 'ROE'
                    WHEN 'ROCE' THEN 'ROCE'
                    WHEN 'NPM' THEN 'NPM'
                    WHEN 'D/E_inv' THEN 'D/E'
                    WHEN 'FCF' THEN 'FCF'
                    WHEN 'PAT_CAGR_5yr' THEN 'PAT CAGR'
                    WHEN 'Revenue_CAGR_5yr' THEN 'Revenue CAGR'
                    ELSE metric_name
                END as metric,
                percentile_rank * 100 as value
            FROM peer_percentiles
            WHERE peer_group_name = ?
            AND company_id IN ({})
            AND metric_name IN ('ROE', 'ROCE', 'NPM', 'D/E_inv', 'FCF', 'PAT_CAGR_5yr', 'Revenue_CAGR_5yr')
            AND year != '9999-12'
            AND year = (SELECT MAX(year) FROM peer_percentiles WHERE peer_group_name = ? AND year != '9999-12')
            """.format(','.join('?' * len(company_ids))),
            conn,
            params=(peer_group, *company_ids, peer_group)
        )
        
        # Add composite quality score (already 0-100)
        quality_df = pd.read_sql_query(
            """
            SELECT 
                company_id,
                'Quality Score' as metric,
                composite_quality_score as value
            FROM financial_ratios
            WHERE company_id IN ({})
            AND year = (SELECT MAX(year) FROM financial_ratios WHERE company_id = financial_ratios.company_id AND year != '9999-12')
            """.format(','.join('?' * len(company_ids))),
            conn,
            params=tuple(company_ids)
        )
        
        df = pd.concat([df, quality_df], ignore_index=True)
        
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching peer radar data: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_peer_group_metrics(peer_group: str) -> pd.DataFrame:
    """
    Get detailed metrics for all companies in a peer group.
    
    Args:
        peer_group: Peer group name
    
    Returns:
        DataFrame with company_id, name, and key metrics
    """
    try:
        conn = _get_connection()
        
        df = pd.read_sql_query(
            """
            SELECT
                c.id as company_id,
                c.company_name as Company,
                fr.return_on_equity_pct as 'ROE %',
                fr.net_profit_margin_pct as 'NPM %',
                fr.debt_to_equity as 'D/E',
                fr.free_cash_flow_cr as 'FCF ₹Cr',
                fr.revenue_cagr_5yr as 'Rev CAGR %',
                fr.pat_cagr_5yr as 'PAT CAGR %',
                fr.composite_quality_score as 'Quality Score'
            FROM companies c
            JOIN peer_groups pg ON c.id = pg.company_id
            JOIN financial_ratios fr ON c.id = fr.company_id
            WHERE pg.peer_group_name = ?
            AND fr.year = (
                SELECT MAX(year) FROM financial_ratios 
                WHERE company_id = c.id AND year != '9999-12'
            )
            ORDER BY fr.composite_quality_score DESC
            """,
            conn,
            params=(peer_group,)
        )
        
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching peer group metrics: {e}")
        return pd.DataFrame()



@st.cache_data(ttl=600)
def get_trend_data(ticker: str, metrics: List[str]) -> pd.DataFrame:
    """
    Get time-series data for selected metrics for a company.
    
    Args:
        ticker: Company ticker/ID
        metrics: List of metric names to retrieve
    
    Returns:
        DataFrame with year and selected metric columns
    """
    try:
        conn = _get_connection()
        
        # Map metric display names to database columns
        metric_mapping = {
            'Revenue': ('profitandloss', 'sales'),
            'Net Profit': ('profitandloss', 'net_profit'),
            'ROE %': ('financial_ratios', 'return_on_equity_pct'),
            'NPM %': ('financial_ratios', 'net_profit_margin_pct'),
            'D/E': ('financial_ratios', 'debt_to_equity'),
            'FCF': ('financial_ratios', 'free_cash_flow_cr'),
            'OPM %': ('financial_ratios', 'operating_profit_margin_pct'),
            'EPS': ('profitandloss', 'eps'),
        }
        
        # Start with base query from profitandloss
        pl_metrics = [m for m in metrics if metric_mapping.get(m, ('', ''))[0] == 'profitandloss']
        fr_metrics = [m for m in metrics if metric_mapping.get(m, ('', ''))[0] == 'financial_ratios']
        
        if not pl_metrics and not fr_metrics:
            return pd.DataFrame()
        
        # Build query
        select_cols = ['pl.year']
        
        for metric in metrics:
            table, col = metric_mapping.get(metric, ('', ''))
            if table == 'profitandloss':
                select_cols.append(f'pl.{col} as "{metric}"')
            elif table == 'financial_ratios':
                select_cols.append(f'fr.{col} as "{metric}"')
        
        query = f"""
            SELECT {', '.join(select_cols)}
            FROM profitandloss pl
            LEFT JOIN financial_ratios fr ON pl.company_id = fr.company_id AND pl.year = fr.year
            WHERE pl.company_id = ?
            AND pl.year != '9999-12'
            AND fr.year != '9999-12'
            ORDER BY pl.year DESC
        """
        
        df = pd.read_sql_query(query, conn, params=(ticker,))
        conn.close()
        
        return df
    except Exception as e:
        logger.error(f"Error fetching trend data for {ticker}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_available_trend_metrics() -> List[str]:
    """
    Get list of available metrics for trend analysis.
    
    Returns:
        List of metric display names
    """
    return [
        'Revenue',
        'Net Profit',
        'ROE %',
        'NPM %',
        'D/E',
        'FCF',
        'OPM %',
        'EPS'
    ]



@st.cache_data(ttl=600)
def get_sector_companies(sector: str) -> pd.DataFrame:
    """
    Get companies in a specific sector with key metrics for bubble chart.
    
    Args:
        sector: Broad sector name
    
    Returns:
        DataFrame with company_id, name, sub_sector, revenue, roe, market_cap
    """
    try:
        conn = _get_connection()
        
        df = pd.read_sql_query(
            """
            SELECT 
                c.id as company_id,
                c.company_name,
                s.sub_sector,
                pl.sales as revenue,
                fr.return_on_equity_pct as roe,
                mc.market_cap_crore
            FROM companies c
            JOIN sectors s ON c.id = s.company_id
            LEFT JOIN profitandloss pl ON c.id = pl.company_id
            LEFT JOIN financial_ratios fr ON c.id = fr.company_id AND pl.year = fr.year
            LEFT JOIN market_cap mc ON c.id = mc.company_id
            WHERE s.broad_sector = ?
            AND pl.year = (SELECT MAX(year) FROM profitandloss WHERE company_id = c.id AND year != '9999-12')
            AND fr.year = (SELECT MAX(year) FROM financial_ratios WHERE company_id = c.id AND year != '9999-12')
            AND (mc.year IS NULL OR mc.year = (SELECT MAX(year) FROM market_cap WHERE company_id = c.id))
            ORDER BY c.company_name
            """,
            conn,
            params=(sector,)
        )
        
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching sector companies for {sector}: {e}")
        return pd.DataFrame()


@st.cache_data(ttl=600)
def get_sector_medians(sector: str) -> Dict[str, float]:
    """
    Get median KPI values for a sector.
    
    Args:
        sector: Broad sector name
    
    Returns:
        Dict with median values for key metrics
    """
    try:
        conn = _get_connection()
        
        # Get all metrics for sector companies
        df = pd.read_sql_query(
            """
            SELECT 
                fr.return_on_equity_pct,
                fr.net_profit_margin_pct,
                fr.debt_to_equity,
                fr.free_cash_flow_cr,
                pl.sales as revenue,
                pl.net_profit
            FROM companies c
            JOIN sectors s ON c.id = s.company_id
            JOIN financial_ratios fr ON c.id = fr.company_id
            JOIN profitandloss pl ON c.id = pl.company_id AND fr.year = pl.year
            WHERE s.broad_sector = ?
            AND fr.year = (SELECT MAX(year) FROM financial_ratios WHERE company_id = c.id AND year != '9999-12')
            """,
            conn,
            params=(sector,)
        )
        
        conn.close()
        
        if df.empty:
            return {}
        
        # Calculate medians
        medians = {
            'ROE %': df['return_on_equity_pct'].median() if df['return_on_equity_pct'].notna().any() else None,
            'NPM %': df['net_profit_margin_pct'].median() if df['net_profit_margin_pct'].notna().any() else None,
            'D/E': df['debt_to_equity'].median() if df['debt_to_equity'].notna().any() else None,
            'Median Revenue (₹Cr)': df['revenue'].median() if df['revenue'].notna().any() else None,
            'Median Net Profit (₹Cr)': df['net_profit'].median() if df['net_profit'].notna().any() else None,
        }
        
        return medians
    except Exception as e:
        logger.error(f"Error calculating sector medians for {sector}: {e}")
        return {}


@st.cache_data(ttl=600)
def get_all_sectors() -> List[str]:
    """
    Get list of all unique broad sectors.
    
    Returns:
        List of sector names
    """
    try:
        conn = _get_connection()
        cursor = conn.cursor()
        cursor.execute(
            "SELECT DISTINCT broad_sector FROM sectors ORDER BY broad_sector"
        )
        sectors = [row[0] for row in cursor.fetchall() if row[0]]
        conn.close()
        return sectors
    except Exception as e:
        logger.error(f"Error fetching sectors: {e}")
        return []



@st.cache_data(ttl=600)
def get_capital_allocation_data() -> pd.DataFrame:
    """
    Get capital allocation patterns for all companies (latest year).
    
    Returns:
        DataFrame with company_id, company_name, pattern_label, size_metric
    """
    try:
        # Read from capital allocation CSV
        import os
        csv_path = os.path.join(os.path.dirname(_get_db_path()), 'output', 'capital_allocation.csv')
        
        if not os.path.exists(csv_path):
            logger.error(f"Capital allocation file not found: {csv_path}")
            return pd.DataFrame()
        
        df = pd.read_csv(csv_path)
        
        # Get latest year per company
        latest = df.sort_values('year').groupby('company_id').last().reset_index()
        
        # Get company names and market cap for sizing
        conn = _get_connection()
        companies = pd.read_sql_query(
            "SELECT id, company_name FROM companies",
            conn
        )
        
        # Get market cap for treemap sizing
        market_caps = pd.read_sql_query(
            """
            SELECT company_id, market_cap_crore
            FROM market_cap
            WHERE year = (SELECT MAX(year) FROM market_cap WHERE company_id = market_cap.company_id)
            """,
            conn
        )
        
        conn.close()
        
        # Merge
        result = latest.merge(companies, left_on='company_id', right_on='id', how='left')
        result = result.merge(market_caps, on='company_id', how='left')
        
        # Use market cap as size, default to 100 for missing
        result['size_metric'] = result['market_cap_crore'].fillna(100)
        
        return result[['company_id', 'company_name', 'pattern_label', 'size_metric', 'year']]
    
    except Exception as e:
        logger.error(f"Error loading capital allocation data: {e}")
        return pd.DataFrame()



@st.cache_data(ttl=600)
def get_annual_reports(ticker: str) -> pd.DataFrame:
    """
    Get annual reports for a company.
    
    Args:
        ticker: Company ticker/ID
    
    Returns:
        DataFrame with year and annual_report URL columns
    """
    try:
        conn = _get_connection()
        df = pd.read_sql_query(
            """
            SELECT year, annual_report
            FROM documents
            WHERE company_id = ?
            AND annual_report IS NOT NULL
            ORDER BY year DESC
            """,
            conn,
            params=(ticker,)
        )
        conn.close()
        return df
    except Exception as e:
        logger.error(f"Error fetching annual reports for {ticker}: {e}")
        return pd.DataFrame()
