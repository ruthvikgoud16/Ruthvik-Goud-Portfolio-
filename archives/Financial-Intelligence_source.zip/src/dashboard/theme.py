"""Shared visual language for the N100 Streamlit dashboard."""

from __future__ import annotations

NAVY = "#0B1F33"
NAVY_MID = "#123049"
PRIMARY = "#1B4F72"
ACCENT = "#2A6F97"
SURFACE = "#F4F6F8"
CARD = "#FFFFFF"
INK = "#1A2332"
MUTED = "#5B6B7C"
LINE = "#D7DEE7"
POSITIVE = "#1F7A4D"
NEGATIVE = "#B42318"
WARNING = "#B45309"
INFO = "#1B4F72"

PLOTLY_COLORS = [
    "#1B4F72",
    "#2A6F97",
    "#1F7A4D",
    "#B45309",
    "#5B6B7C",
    "#8AA4B7",
    "#3D5A73",
    "#6B8F71",
]

PATTERN_COLORS = {
    "Shareholder Returns": "#1B4F72",
    "Reinvestor": "#2A6F97",
    "Growth Funded by Debt": "#B45309",
    "Liquidating Assets": "#5B6B7C",
    "Cash Accumulator": "#3D5A73",
    "Distress Signal": "#B42318",
    "Mixed": "#6B8F71",
    "Pre-Revenue": "#8AA4B7",
}

GLOBAL_CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500&display=swap');

html, body, [class*="css"] {
    font-family: "IBM Plex Sans", "Segoe UI", sans-serif;
    color: #1A2332;
}

.stApp {
    background: #F4F6F8;
}

#MainMenu {visibility: hidden;}
footer {visibility: hidden;}
header[data-testid="stHeader"] {background: transparent;}

.block-container {
    padding-top: 1.15rem;
    padding-bottom: 2.5rem;
    max-width: 1280px;
}

[data-testid="stSidebar"] {
    background: #0B1F33;
    border-right: 1px solid #123049;
}
[data-testid="stSidebar"] * {
    color: #E8EEF4 !important;
}
[data-testid="stSidebar"] .stRadio label {
    font-size: 0.92rem;
    letter-spacing: 0.01em;
}
[data-testid="stSidebar"] [data-baseweb="radio"] {
    background: transparent;
}
[data-testid="stSidebar"] hr {
    border-color: #2A4158;
}
[data-testid="stSidebar"] .stSelectbox div[data-baseweb="select"] > div,
[data-testid="stSidebar"] .stMultiSelect div[data-baseweb="select"] > div {
    background: #123049;
    color: #E8EEF4;
}

.n100-brand {
    padding: 0.35rem 0 0.85rem 0;
    border-bottom: 1px solid #2A4158;
    margin-bottom: 0.85rem;
}
.n100-brand .mark {
    font-size: 0.68rem;
    letter-spacing: 0.16em;
    font-weight: 700;
    color: #8AA4B7 !important;
}
.n100-brand h2 {
    font-size: 1.02rem !important;
    font-weight: 700 !important;
    color: #FFFFFF !important;
    margin: 0.25rem 0 0.15rem 0 !important;
    line-height: 1.25 !important;
}
.n100-brand p {
    font-size: 0.72rem !important;
    color: #8AA4B7 !important;
    margin: 0 !important;
}

.n100-topbar {
    background: #0B1F33;
    color: #E8EEF4;
    padding: 0.85rem 1.15rem;
    border-radius: 8px;
    margin-bottom: 1.1rem;
    border: 1px solid #123049;
}
.n100-topbar .kicker {
    font-size: 0.68rem;
    letter-spacing: 0.18em;
    font-weight: 700;
    color: #8AA4B7;
}
.n100-topbar h1 {
    font-size: 1.28rem;
    font-weight: 700;
    margin: 0.15rem 0 0.2rem 0;
    color: #FFFFFF;
}
.n100-topbar .sub {
    font-size: 0.82rem;
    color: #B7C6D3;
}

.n100-page-title {
    font-size: 1.45rem;
    font-weight: 700;
    color: #0B1F33;
    margin: 0 0 0.2rem 0;
}
.n100-page-sub {
    color: #5B6B7C;
    font-size: 0.95rem;
    margin: 0 0 1.1rem 0;
}

.n100-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(148px, 1fr));
    gap: 0.7rem;
    margin: 0.4rem 0 1.1rem 0;
}
.n100-kpi {
    background: #FFFFFF;
    border: 1px solid #D7DEE7;
    border-radius: 8px;
    padding: 0.75rem 0.85rem 0.7rem 0.85rem;
    box-shadow: 0 1px 2px rgba(11, 31, 51, 0.04);
}
.n100-kpi .lbl {
    font-size: 0.7rem;
    letter-spacing: 0.06em;
    text-transform: uppercase;
    color: #5B6B7C;
    font-weight: 600;
}
.n100-kpi .val {
    font-family: "IBM Plex Mono", ui-monospace, monospace;
    font-size: 1.28rem;
    font-weight: 500;
    color: #0B1F33;
    margin-top: 0.2rem;
}

.n100-section {
    font-size: 0.95rem;
    font-weight: 600;
    color: #0B1F33;
    margin: 0.4rem 0 0.55rem 0;
    letter-spacing: 0.01em;
}

.n100-card {
    background: #FFFFFF;
    border: 1px solid #D7DEE7;
    border-radius: 8px;
    padding: 0.9rem 1rem;
    box-shadow: 0 1px 2px rgba(11, 31, 51, 0.04);
}

.n100-badge {
    display: inline-block;
    font-size: 0.78rem;
    padding: 0.28rem 0.55rem;
    border-radius: 999px;
    margin: 0.18rem 0.18rem 0.18rem 0;
    border: 1px solid transparent;
}
.n100-badge.pos { background: #EAF6EF; color: #1F7A4D; border-color: #C8E6D3; }
.n100-badge.neg { background: #FDECEC; color: #B42318; border-color: #F5C2C0; }
.n100-badge.neu { background: #EEF2F6; color: #5B6B7C; border-color: #D7DEE7; }
.n100-badge.warn { background: #FEF3E6; color: #B45309; border-color: #F5D7B0; }

.n100-empty, .n100-warn, .n100-error {
    border-radius: 8px;
    padding: 0.85rem 1rem;
    font-size: 0.92rem;
}
.n100-empty { background: #EEF2F6; color: #5B6B7C; border: 1px solid #D7DEE7; }
.n100-warn { background: #FEF3E6; color: #7A3E08; border: 1px solid #F5D7B0; }
.n100-error { background: #FDECEC; color: #7A160F; border: 1px solid #F5C2C0; }

.n100-co-head h2 {
    margin: 0;
    font-size: 1.35rem;
    color: #0B1F33;
}
.n100-co-head .meta {
    color: #5B6B7C;
    font-size: 0.88rem;
    letter-spacing: 0.04em;
    margin-top: 0.2rem;
}

div[data-testid="stDataFrame"] {
    border: 1px solid #D7DEE7;
    border-radius: 8px;
    overflow: hidden;
}

.stDownloadButton button, .stButton button {
    border-radius: 6px;
    border: 1px solid #1B4F72;
    background: #1B4F72;
    color: #FFFFFF;
    font-weight: 600;
}
.stButton button[kind="secondary"] {
    background: #FFFFFF;
    color: #1B4F72;
}

.stAlert { border-radius: 8px; }

/* iQOO Neo 10 / tall 20:9 phones — CSS ~420×933 @3x (1260×2800) */
@media (max-width: 480px) {
    .block-container {
        padding-left: 0.7rem !important;
        padding-right: 0.7rem !important;
        padding-top: 0.65rem !important;
        padding-bottom: 1.4rem !important;
        max-width: 100% !important;
    }
    .n100-topbar {
        padding: 0.65rem 0.8rem;
        margin-bottom: 0.75rem;
        border-radius: 6px;
    }
    .n100-topbar h1 { font-size: 1.05rem; }
    .n100-topbar .sub { font-size: 0.72rem; }
    .n100-page-title { font-size: 1.15rem; }
    .n100-page-sub { font-size: 0.82rem; margin-bottom: 0.75rem; }
    .n100-kpi-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 0.45rem;
    }
    .n100-kpi { padding: 0.55rem 0.6rem; }
    .n100-kpi .lbl { font-size: 0.62rem; }
    .n100-kpi .val { font-size: 1.05rem; }
    .n100-co-head h2 { font-size: 1.1rem; }
    .n100-card { padding: 0.7rem 0.75rem; }
    [data-testid="stSidebar"] {
        min-width: 260px !important;
    }
    div[data-testid="stHorizontalBlock"] {
        flex-wrap: wrap !important;
        gap: 0.35rem !important;
    }
}
</style>
"""


def plotly_layout(fig, height: int = 420, title: str | None = None):
    fig.update_layout(
        title=dict(text=title or "", font=dict(size=14, color=NAVY, family="IBM Plex Sans")),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="#FFFFFF",
        font=dict(family="IBM Plex Sans", size=12, color=INK),
        height=height,
        margin=dict(l=48, r=24, t=48 if title else 24, b=48),
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="left", x=0, font=dict(size=11)),
        hoverlabel=dict(bgcolor=NAVY, font_size=12, font_family="IBM Plex Sans"),
    )
    fig.update_xaxes(showgrid=True, gridcolor="#EEF2F6", linecolor=LINE, zeroline=False, ticks="outside")
    fig.update_yaxes(showgrid=True, gridcolor="#EEF2F6", linecolor=LINE, zeroline=False, ticks="outside")
    return fig
