"""
FilterEngine — Core screener logic for the N100 Financial Intelligence Platform.

Day 15 Implementation:
- Load and apply 15 filterable metrics
- Handle D/E Financials sector exclusion
- Handle ICR Debt Free (infinity) logic
- Implement year-matching for market_cap and financial_ratios
- Return filtered, sorted DataFrame

Design Decisions (from Sprint 3 Discovery):
1. ROCE: Computed on-the-fly (not persisted in financial_ratios)
2. Year matching: For each company, find latest non-TTM fiscal year in financial_ratios,
   match to latest calendar year in market_cap
3. FCF CAGR: Computed on-the-fly using CAGREngine (Day 16+)
4. CFO/PAT ratio: Computed on-the-fly from cashflow/profitandloss (Day 16+)
"""

import sqlite3
from typing import Dict, Optional, List, Tuple
import pandas as pd
import numpy as np
import logging
import yaml
import os

from src.analytics.cagr import CAGREngine
from src.screener.composite import CompositeScorer

logger = logging.getLogger(__name__)


class FilterEngine:
    """
    Apply screener filters to financial data.
    
    Supports:
    - 15 filterable metrics
    - Custom thresholds via config dict
    - D/E Financials exclusion
    - ICR Debt Free handling
    - Year-matching logic
    """
    
    # 15 Filterable metrics (from Day 15 discovery)
    # Plus 3 special metrics for Turnaround Watch (Day 16)
    FILTERABLE_METRICS = [
        'roe_min',                  # return_on_equity_pct
        'de_max',                   # debt_to_equity
        'fcf_min',                  # free_cash_flow_cr
        'revenue_cagr_5yr_min',     # revenue_cagr_5yr
        'pat_cagr_5yr_min',         # pat_cagr_5yr
        'opm_min',                  # operating_profit_margin_pct
        'pe_max',                   # pe_ratio
        'pb_max',                   # pb_ratio
        'div_yield_min',            # dividend_yield_pct
        'icr_min',                  # interest_coverage
        'market_cap_min',           # market_cap_crore
        'net_profit_min',           # net_profit (profitandloss)
        'eps_cagr_min',             # eps_cagr_5yr
        'asset_turnover_min',       # asset_turnover
        'sales_min',                # sales (profitandloss)
        # Day 16 additions (Turnaround Watch special metrics)
        'revenue_cagr_3yr_min',     # revenue_cagr_3yr (computed on-the-fly)
        'fcf_positive_latest_year', # FCF > 0 in latest year (boolean)
        'de_yoy_declining',         # D/E declining year-over-year (boolean)
        'dividend_payout_ratio_pct_max',  # Dividend Payout < threshold (for Dividend Champion)
    ]
    
    def __init__(self, db_path: str = "nifty100.db"):
        """
        Initialize FilterEngine with database connection.
        
        Args:
            db_path: Path to SQLite database (default: nifty100.db in cwd)
        """
        self.db_path = db_path
        self.conn = None
        self._connect()
    
    def _connect(self):
        """Establish database connection."""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            logger.info(f"FilterEngine connected to {self.db_path}")
        except sqlite3.Error as e:
            logger.error(f"Database connection failed: {e}")
            raise
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            logger.info("FilterEngine connection closed")
    
    def _get_latest_year_match(self, company_id: str) -> Optional[Tuple[str, int]]:
        """
        Get the latest matching year pair for a company.
        
        Returns tuple (fiscal_year, calendar_year) where:
        - fiscal_year: Latest YYYY-MM from financial_ratios (non-TTM)
        - calendar_year: Latest YYYY from market_cap matching that company
        
        Returns None if no match found.
        
        Year matching logic (from Day 15 discovery):
        1. Find latest fiscal year in financial_ratios for this company
        2. Find latest calendar year in market_cap for this company
        3. If fiscal year is YYYY-MM (Mar-31 being Apr FY), extract YYYY
        4. Match to latest available calendar year
        """
        cursor = self.conn.cursor()
        
        # Get latest fiscal year from financial_ratios (exclude TTM marker if present)
        cursor.execute("""
            SELECT year FROM financial_ratios
            WHERE company_id = ?
            AND year GLOB '20*'
            ORDER BY year DESC
            LIMIT 1
        """, (company_id,))
        
        fiscal_row = cursor.fetchone()
        if not fiscal_row:
            return None
        
        fiscal_year = fiscal_row[0]  # Format: YYYY-MM
        
        # Extract calendar year from fiscal year
        # For Indian fiscal year (Apr-Mar): YYYY-04 to YYYY+1-03
        # Extract YYYY as the reference year
        try:
            cal_year_from_fiscal = int(fiscal_year.split('-')[0])
        except (ValueError, IndexError):
            logger.warning(f"Could not extract year from {fiscal_year}")
            return None
        
        # Get latest calendar year from market_cap for this company
        cursor.execute("""
            SELECT year FROM market_cap
            WHERE company_id = ?
            ORDER BY year DESC
            LIMIT 1
        """, (company_id,))
        
        market_row = cursor.fetchone()
        if not market_row:
            return None
        
        market_year = market_row[0]
        
        return (fiscal_year, market_year)
    
    def _exclude_financials_de_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Exclude Financial Services companies when D/E filter is applied.
        
        From Day 15 discovery: D/E filter must skip Financials because
        they have inherently different capital structures (leverage is normal).
        
        Args:
            df: DataFrame with company_id column
            
        Returns:
            Filtered DataFrame (removed Financials)
        """
        if df.empty:
            return df
        
        cursor = self.conn.cursor()
        cursor.execute("""
            SELECT company_id FROM sectors
            WHERE broad_sector = 'Financial Services'
        """)
        
        financials_ids = {row[0] for row in cursor.fetchall()}
        
        df_filtered = df[~df['company_id'].isin(financials_ids)].copy()
        
        if len(df_filtered) < len(df):
            logger.info(
                f"D/E filter: Excluded {len(df) - len(df_filtered)} "
                f"Financial Services companies"
            )
        
        return df_filtered
    
    def _apply_de_max(self, df: pd.DataFrame, de_max: float) -> pd.DataFrame:
        """Apply D/E max filter with Financials exclusion."""
        # First exclude Financials
        df = self._exclude_financials_de_filter(df)
        
        # Then apply D/E filter
        before = len(df)
        df = df[df['debt_to_equity'] <= de_max].copy()
        logger.info(f"D/E max {de_max}: {len(df)} companies (dropped {before - len(df)})")
        
        return df
    
    def _apply_icr_min(self, df: pd.DataFrame, icr_min: float) -> pd.DataFrame:
        """
        Apply Interest Coverage Ratio min filter with Debt Free handling.
        
        From Day 15 discovery: Debt-free companies (D/E = 0) have no interest
        expense, so ICR = infinity. These should always pass the ICR filter.
        
        Logic:
        1. If D/E = 0, treat as ICR = infinity (pass all thresholds)
        2. If D/E > 0 and ICR is null, skip (insufficient data)
        3. If D/E > 0 and ICR is not null, apply normal filter
        """
        cursor = self.conn.cursor()
        
        before = len(df)
        
        # Identify Debt Free companies (D/E = 0 or null borrowings)
        debt_free_mask = (df['debt_to_equity'] == 0) | (df['debt_to_equity'].isna())
        
        # For non-debt-free, apply filter
        non_debt_free_mask = ~debt_free_mask
        df_debt_free = df[debt_free_mask].copy()
        df_non_debt_free = df[non_debt_free_mask].copy()
        
        # Filter non-debt-free by ICR
        df_non_debt_free = df_non_debt_free[
            df_non_debt_free['interest_coverage'] >= icr_min
        ].copy()
        
        # Combine: debt-free always pass, others filtered
        df = pd.concat([df_debt_free, df_non_debt_free], ignore_index=False)
        
        logger.info(
            f"ICR min {icr_min}: {len(df)} companies "
            f"({len(df_debt_free)} debt-free, {len(df_non_debt_free)} filtered)"
        )
        
        return df
    
    def _compute_revenue_cagr_3yr(self, company_id: str) -> Optional[float]:
        """
        Compute 3-year Revenue CAGR for a company from profitandloss table.
        
        Returns the CAGR percentage, or None if insufficient data.
        """
        cursor = self.conn.cursor()
        
        # Get revenue history, excluding TTM (9999-12)
        cursor.execute("""
            SELECT year, sales FROM profitandloss
            WHERE company_id = ?
            AND year NOT LIKE '%-TTM'
            AND sales IS NOT NULL
            AND sales > 0
            ORDER BY year ASC
        """, (company_id,))
        
        history = cursor.fetchall()
        if len(history) < 4:  # Need 4+ data points for 3-year CAGR
            return None
        
        # Use last 4 data points for 3-year CAGR
        history_tuples = [(row[0], row[1]) for row in history[-4:]]
        
        cagr_pct, flag = CAGREngine.cagr(history_tuples, window_years=3, metric_name="Revenue")
        return cagr_pct
    
    def _check_de_yoy_declining(self, company_id: str) -> bool:
        """
        Check if D/E is declining year-over-year (current < previous).
        
        Returns True if current D/E < previous D/E, False otherwise or if
        insufficient historical data.
        """
        cursor = self.conn.cursor()
        
        # Get latest two fiscal years of D/E data
        cursor.execute("""
            SELECT year, debt_to_equity FROM financial_ratios
            WHERE company_id = ?
            AND year NOT LIKE '%-TTM'
            AND debt_to_equity IS NOT NULL
            ORDER BY year DESC
            LIMIT 2
        """, (company_id,))
        
        rows = cursor.fetchall()
        if len(rows) < 2:
            # Insufficient data; company doesn't qualify
            return False
        
        current_de = rows[0][1]  # Latest year
        previous_de = rows[1][1]  # Previous year
        
        # Return True if declining (current < previous)
        return current_de < previous_de
    
    def _apply_revenue_cagr_3yr_filter(self, df: pd.DataFrame, min_cagr: float) -> pd.DataFrame:
        """
        Apply Revenue CAGR 3yr min filter by computing on-the-fly for each company.
        """
        def compute_3yr_cagr(company_id):
            return self._compute_revenue_cagr_3yr(company_id)
        
        before = len(df)
        
        # Compute 3yr CAGR for each company
        df['revenue_cagr_3yr'] = df['company_id'].apply(compute_3yr_cagr)
        
        # Filter by threshold, treating None as failure to filter
        df = df[df['revenue_cagr_3yr'] >= min_cagr].copy()
        
        logger.info(f"Revenue CAGR 3yr min {min_cagr}: {len(df)} companies (dropped {before - len(df)})")
        
        return df
    
    def _apply_de_yoy_declining_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply D/E declining year-over-year filter.
        """
        def check_de_decline(company_id):
            return self._check_de_yoy_declining(company_id)
        
        before = len(df)
        
        # Check D/E decline for each company
        df['de_yoy_declining'] = df['company_id'].apply(check_de_decline)
        
        # Filter to only those with declining D/E
        df = df[df['de_yoy_declining'] == True].copy()
        
        logger.info(f"D/E YoY declining: {len(df)} companies (dropped {before - len(df)})")
        
        return df
    
    def _apply_fcf_positive_latest_year_filter(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Apply FCF positive in latest year filter.
        Already have FCF in base data, just check > 0.
        """
        before = len(df)
        
        df = df[df['free_cash_flow_cr'] > 0].copy()
        
        logger.info(f"FCF positive latest year: {len(df)} companies (dropped {before - len(df)})")
        
        return df
    
    def _apply_dividend_payout_max_filter(self, df: pd.DataFrame, max_payout: float) -> pd.DataFrame:
        """
        Apply Dividend Payout ratio max filter.
        """
        before = len(df)
        
        # Filter companies with payout <= max_payout
        df = df[df['dividend_payout_ratio_pct'] <= max_payout].copy()
        
        logger.info(f"Dividend Payout max {max_payout}%: {len(df)} companies (dropped {before - len(df)})")
        
        return df
    
    def load_preset(self, preset_name: str, config_path: str = "config/screener_config.yaml") -> Dict[str, Optional[float]]:
        """
        Load a preset screener definition from YAML config.
        
        Args:
            preset_name: Name of preset (e.g., 'quality_compounder')
            config_path: Path to screener_config.yaml
        
        Returns:
            Dict of filters ready for apply_filters()
        
        Raises:
            FileNotFoundError: If config file not found
            ValueError: If preset not found in config
        """
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Config file not found: {config_path}")
        
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        if preset_name not in config.get('presets', {}):
            raise ValueError(f"Preset '{preset_name}' not found in config")
        
        preset_config = config['presets'][preset_name]
        filters = preset_config.get('filters', {})
        
        logger.info(f"Loaded preset '{preset_name}': {len(filters)} filters")
        
        return filters
    
    def apply_filters(
        self,
        filters: Dict[str, Optional[float]]
    ) -> pd.DataFrame:
        """
        Apply screener filters to get matching companies.
        
        Args:
            filters: Dict with keys from FILTERABLE_METRICS
                    e.g., {'roe_min': 15.0, 'de_max': 1.0, 'fcf_min': 100.0}
                    Pass None or omit to skip filter
        
        Returns:
            DataFrame with matching companies, sorted by composite score (if available)
        
        Raises:
            ValueError: If invalid metric key provided
        """
        # Validate filter keys
        invalid_keys = set(filters.keys()) - set(self.FILTERABLE_METRICS)
        if invalid_keys:
            raise ValueError(f"Invalid metric keys: {invalid_keys}")
        
        # Load base data
        df = self._load_base_data()
        if df.empty:
            logger.warning("No companies found in database")
            return df
        
        logger.info(f"Starting with {len(df)} companies")
        
        # Apply each filter
        for metric, threshold in filters.items():
            if threshold is None:
                continue
            
            if metric == 'roe_min':
                df = df[df['return_on_equity_pct'] >= threshold].copy()
                logger.info(f"ROE min {threshold}: {len(df)} companies")
            
            elif metric == 'de_max':
                df = self._apply_de_max(df, threshold)
            
            elif metric == 'fcf_min':
                df = df[df['free_cash_flow_cr'] >= threshold].copy()
                logger.info(f"FCF min {threshold}: {len(df)} companies")
            
            elif metric == 'revenue_cagr_5yr_min':
                df = df[df['revenue_cagr_5yr'] >= threshold].copy()
                logger.info(f"Revenue CAGR 5yr min {threshold}: {len(df)} companies")
            
            elif metric == 'pat_cagr_5yr_min':
                df = df[df['pat_cagr_5yr'] >= threshold].copy()
                logger.info(f"PAT CAGR 5yr min {threshold}: {len(df)} companies")
            
            elif metric == 'opm_min':
                df = df[df['operating_profit_margin_pct'] >= threshold].copy()
                logger.info(f"OPM min {threshold}: {len(df)} companies")
            
            elif metric == 'pe_max':
                df = df[df['pe_ratio'] <= threshold].copy()
                logger.info(f"P/E max {threshold}: {len(df)} companies")
            
            elif metric == 'pb_max':
                df = df[df['pb_ratio'] <= threshold].copy()
                logger.info(f"P/B max {threshold}: {len(df)} companies")
            
            elif metric == 'div_yield_min':
                df = df[df['dividend_yield_pct'] >= threshold].copy()
                logger.info(f"Dividend Yield min {threshold}: {len(df)} companies")
            
            elif metric == 'icr_min':
                df = self._apply_icr_min(df, threshold)
            
            elif metric == 'market_cap_min':
                df = df[df['market_cap_crore'] >= threshold].copy()
                logger.info(f"Market Cap min {threshold}: {len(df)} companies")
            
            elif metric == 'net_profit_min':
                df = df[df['net_profit'] >= threshold].copy()
                logger.info(f"Net Profit min {threshold}: {len(df)} companies")
            
            elif metric == 'eps_cagr_min':
                df = df[df['eps_cagr_5yr'] >= threshold].copy()
                logger.info(f"EPS CAGR min {threshold}: {len(df)} companies")
            
            elif metric == 'asset_turnover_min':
                df = df[df['asset_turnover'] >= threshold].copy()
                logger.info(f"Asset Turnover min {threshold}: {len(df)} companies")
            
            elif metric == 'sales_min':
                df = df[df['sales'] >= threshold].copy()
                logger.info(f"Sales min {threshold}: {len(df)} companies")
            
            # Day 16 additions
            elif metric == 'revenue_cagr_3yr_min':
                df = self._apply_revenue_cagr_3yr_filter(df, threshold)
            
            elif metric == 'fcf_positive_latest_year':
                # threshold is a boolean
                if threshold:  # Only apply if True is set
                    df = self._apply_fcf_positive_latest_year_filter(df)
            
            elif metric == 'de_yoy_declining':
                # threshold is a boolean
                if threshold:  # Only apply if True is set
                    df = self._apply_de_yoy_declining_filter(df)
            
            elif metric == 'dividend_payout_ratio_pct_max':
                df = self._apply_dividend_payout_max_filter(df, threshold)
        
        # Compute composite quality score
        df = self.compute_composite_scores(df)
        
        # Sort by composite score (if available), then by company name
        if 'composite_quality_score' in df.columns:
            df = df.sort_values(
                by=['composite_quality_score', 'company_name'],
                ascending=[False, True]
            ).reset_index(drop=True)
        else:
            df = df.sort_values(by=['company_name']).reset_index(drop=True)
        
        logger.info(f"Filter complete: {len(df)} companies match criteria")
        return df
    
    def compute_composite_scores(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Compute composite quality scores using CompositeScorer.
        
        Args:
            df: DataFrame from apply_filters (after filter application)
        
        Returns:
            DataFrame with composite_quality_score column populated
        """
        if df.empty:
            return df
        
        try:
            with CompositeScorer(self.db_path) as scorer:
                df = scorer.compute_composite_score(df)
            return df
        except Exception as e:
            logger.warning(f"Failed to compute composite scores: {e}")
            # Return with NaN scores if computation fails
            df['composite_quality_score'] = np.nan
            return df
    
    def _load_base_data(self) -> pd.DataFrame:
        """
        Load base dataset with all 15 metrics and company info.
        
        Joins:
        - financial_ratios (12 metrics)
        - market_cap (4 metrics: P/E, P/B, Dividend Yield, Market Cap)
        - profitandloss (2 metrics: Net Profit, Sales) — requires year join
        - companies (name, sector for logging)
        - sectors (broad_sector for exclusions)
        
        Year-matching logic: For each company, find latest available year in
        financial_ratios and market_cap, then join profitandloss using that year.
        
        Returns:
            DataFrame with all 15 metrics + metadata
        """
        query = """
        SELECT
            fr.company_id,
            c.company_name,
            s.broad_sector,
            -- Financial Ratios (12 metrics)
            fr.return_on_equity_pct,
            fr.debt_to_equity,
            fr.free_cash_flow_cr,
            fr.revenue_cagr_5yr,
            fr.pat_cagr_5yr,
            fr.operating_profit_margin_pct,
            fr.interest_coverage,
            fr.eps_cagr_5yr,
            fr.asset_turnover,
            fr.net_profit_margin_pct,
            fr.dividend_payout_ratio_pct,
            -- Market Cap (4 metrics)
            mc.pe_ratio,
            mc.pb_ratio,
            mc.dividend_yield_pct,
            mc.market_cap_crore,
            -- P&L (2 metrics)
            pl.net_profit,
            pl.sales
        FROM financial_ratios fr
        LEFT JOIN market_cap mc
            ON fr.company_id = mc.company_id
            AND mc.year = (
                SELECT MAX(year) FROM market_cap
                WHERE company_id = fr.company_id
            )
        LEFT JOIN profitandloss pl
            ON fr.company_id = pl.company_id
            AND pl.year = fr.year
        LEFT JOIN companies c
            ON fr.company_id = c.id
        LEFT JOIN sectors s
            ON fr.company_id = s.company_id
        WHERE fr.year = (
            SELECT MAX(year) FROM financial_ratios
            WHERE company_id = fr.company_id
            AND year GLOB '20*'
        )
        ORDER BY c.company_name
        """
        
        try:
            df = pd.read_sql_query(query, self.conn)
            logger.info(f"Loaded {len(df)} companies with base data")
            return df
        except Exception as e:
            logger.error(f"Failed to load base data: {e}")
            raise
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()


# Example usage (for testing)
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    # Test FilterEngine
    with FilterEngine("nifty100.db") as engine:
        # Quality Compounder: ROE > 15%, D/E < 1.0, FCF > 0, Revenue CAGR 5yr > 10%
        filters = {
            'roe_min': 15.0,
            'de_max': 1.0,
            'fcf_min': 0,
            'revenue_cagr_5yr_min': 10.0
        }
        
        result = engine.apply_filters(filters)
        print(f"\nQuality Compounder Results ({len(result)} companies):")
        print(result[['company_name', 'return_on_equity_pct', 'debt_to_equity', 'free_cash_flow_cr']].head())
