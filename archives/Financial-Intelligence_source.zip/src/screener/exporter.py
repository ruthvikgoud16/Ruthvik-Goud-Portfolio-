"""
Excel Exporter for screener results.

Day 17 Implementation:
- Generate output/screener_output.xlsx with 6 preset sheets
- 20 KPI columns per sheet
- Composite score included
- Color-coded cells (green pass, red fail)
- Sorted by composite score descending
"""

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils.dataframe import dataframe_to_rows
import logging

logger = logging.getLogger(__name__)


class ScreenerExporter:
    """Export screener results to Excel."""
    
    # 20 KPI columns to include in export
    KPI_COLUMNS = [
        'company_id',
        'company_name',
        'broad_sector',
        'return_on_equity_pct',
        'net_profit_margin_pct',
        'debt_to_equity',
        'interest_coverage',
        'free_cash_flow_cr',
        'asset_turnover',
        'revenue_cagr_5yr',
        'pat_cagr_5yr',
        'eps_cagr_5yr',
        'pe_ratio',
        'pb_ratio',
        'dividend_yield_pct',
        'market_cap_crore',
        'dividend_payout_ratio_pct',
        'net_profit',
        'sales',
        'composite_quality_score',
    ]
    
    # Preset thresholds for color-coding
    PRESET_THRESHOLDS = {
        'quality_compounder': {
            'return_on_equity_pct': ('>=', 15.0),
            'debt_to_equity': ('<=', 1.0),
            'free_cash_flow_cr': ('>', 0),
            'revenue_cagr_5yr': ('>=', 10.0),
        },
        'value_pick': {
            'pe_ratio': ('<=', 20),
            'pb_ratio': ('<=', 3.0),
            'debt_to_equity': ('<=', 2.0),
            'dividend_yield_pct': ('>=', 1.0),
        },
        'growth_accelerator': {
            'pat_cagr_5yr': ('>=', 20.0),
            'revenue_cagr_5yr': ('>=', 15.0),
            'debt_to_equity': ('<=', 2.0),
        },
        'dividend_champion': {
            'dividend_yield_pct': ('>=', 2.0),
            'dividend_payout_ratio_pct': ('<=', 80.0),
            'free_cash_flow_cr': ('>', 0),
        },
        'debt_free_blue_chip': {
            'debt_to_equity': ('==', 0),
            'return_on_equity_pct': ('>=', 12.0),
            'sales': ('>=', 5000.0),
        },
        'turnaround_watch': {
            'free_cash_flow_cr': ('>', 0),
        },
    }
    
    def __init__(self, output_path: str = "output/screener_output.xlsx"):
        """Initialize exporter."""
        self.output_path = output_path
        self.green_fill = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
        self.red_fill = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
        self.white_font = Font(color="FFFFFF")
        self.black_font = Font(color="000000")
    
    def export_presets(self, preset_results: dict) -> None:
        """
        Export all preset results to Excel.
        
        Args:
            preset_results: Dict of {preset_name: filtered_dataframe}
        """
        wb = Workbook()
        wb.remove(wb.active)  # Remove default sheet
        
        for preset_name, df in preset_results.items():
            if df.empty:
                logger.warning(f"Preset {preset_name} returned no results")
                continue
            
            # Select and prepare columns
            df_export = self._prepare_export_data(df)
            
            # Create sheet
            sheet_name = self._format_sheet_name(preset_name)
            ws = wb.create_sheet(sheet_name)
            
            # Write data
            self._write_sheet(ws, df_export, preset_name)
            
            logger.info(f"Exported {preset_name}: {len(df_export)} companies")
        
        # Save workbook
        wb.save(self.output_path)
        logger.info(f"Screener output exported to {self.output_path}")
    
    def _prepare_export_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """Prepare dataframe with required columns."""
        df_export = df.copy()
        
        # Select available KPI columns
        available_cols = [col for col in self.KPI_COLUMNS if col in df_export.columns]
        df_export = df_export[available_cols]
        
        # Sort by composite score descending
        if 'composite_quality_score' in df_export.columns:
            df_export = df_export.sort_values('composite_quality_score', ascending=False)
        
        df_export = df_export.reset_index(drop=True)
        return df_export
    
    def _format_sheet_name(self, preset_name: str) -> str:
        """Convert preset name to sheet name."""
        # Excel sheet names max 31 chars
        name_map = {
            'quality_compounder': 'Quality Compounder',
            'value_pick': 'Value Pick',
            'growth_accelerator': 'Growth Accelerator',
            'dividend_champion': 'Dividend Champion',
            'debt_free_blue_chip': 'Debt-Free Blue Chip',
            'turnaround_watch': 'Turnaround Watch',
        }
        return name_map.get(preset_name, preset_name)[:31]
    
    def _write_sheet(self, ws, df: pd.DataFrame, preset_name: str) -> None:
        """Write dataframe to worksheet with formatting and color-coding."""
        # Write header
        for col_idx, col_name in enumerate(df.columns, 1):
            cell = ws.cell(row=1, column=col_idx)
            cell.value = col_name
            cell.font = Font(bold=True, color="FFFFFF")
            cell.fill = PatternFill(start_color="366092", end_color="366092", fill_type="solid")
            cell.alignment = Alignment(horizontal="center", vertical="center")
        
        # Write data
        for row_idx, row in enumerate(df.values, 2):
            for col_idx, value in enumerate(row, 1):
                cell = ws.cell(row=row_idx, column=col_idx)
                cell.value = value
                cell.alignment = Alignment(horizontal="right" if isinstance(value, (int, float)) else "left")
                
                # Color-code cells based on preset thresholds
                col_name = df.columns[col_idx - 1]
                if col_name in self.PRESET_THRESHOLDS.get(preset_name, {}):
                    threshold_op, threshold_val = self.PRESET_THRESHOLDS[preset_name][col_name]
                    if self._check_threshold(value, threshold_op, threshold_val):
                        cell.fill = self.green_fill
                    else:
                        cell.fill = self.red_fill
        
        # Adjust column widths
        for col_idx, col_name in enumerate(df.columns, 1):
            ws.column_dimensions[chr(64 + col_idx)].width = max(12, len(str(col_name)) + 2)
    
    def _check_threshold(self, value, op: str, threshold) -> bool:
        """Check if value meets threshold."""
        if value is None:
            return False
        
        try:
            if op == '>=':
                return value >= threshold
            elif op == '>':
                return value > threshold
            elif op == '<=':
                return value <= threshold
            elif op == '<':
                return value < threshold
            elif op == '==':
                return value == threshold
            else:
                return False
        except:
            return False
