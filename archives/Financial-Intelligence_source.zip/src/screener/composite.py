"""
CompositeScorer — Compute composite quality scores for the N100 screener.

Day 17 Implementation:
- 10 component metrics (ROE, ROCE, NPM, FCF CAGR, CFO/PAT, FCF flag, RevCAGR, PATCAGR, D/E, ICR)
- 4 components (Profitability 35%, Cash Quality 30%, Growth 20%, Leverage 15%)
- P10/P90 winsorisation per component
- Sector-relative normalization (within broad_sector)
- D/E inverse scoring (lower is better)
- Debt-free ICR handling (treat as favorable)
- Final score: 0–100
"""

import sqlite3
from typing import Dict, Optional, Tuple, List
import pandas as pd
import numpy as np
import logging

from src.analytics.ratios import ProfitabilityRatios
from src.analytics.cagr import CAGREngine
from src.analytics.cashflow_kpis import CashFlowKPIs

logger = logging.getLogger(__name__)


class CompositeScorer:
    """
    Compute composite quality score with sector-relative normalization.
    
    Score = 0–100 based on:
    - Profitability 35% (ROE 15% + ROCE 10% + NPM 10%)
    - Cash Quality 30% (FCF CAGR 15% + CFO/PAT 10% + FCF flag 5%)
    - Growth 20% (RevCAGR 10% + PATCAGR 10%)
    - Leverage 15% (D/E 10% + ICR 5%)
    """
    
    # Component weights (out of 100)
    COMPONENT_WEIGHTS = {
        'profitability': 35.0,      # ROE 15% + ROCE 10% + NPM 10%
        'cash_quality': 30.0,       # FCF CAGR 15% + CFO/PAT 10% + FCF flag 5%
        'growth': 20.0,             # RevCAGR 10% + PATCAGR 10%
        'leverage': 15.0,           # D/E 10% + ICR 5%
    }
    
    # Internal metric weights (normalized within component)
    PROFITABILITY_METRICS = {
        'roe': 15.0,
        'roce': 10.0,
        'npm': 10.0,
    }
    
    CASH_QUALITY_METRICS = {
        'fcf_cagr': 15.0,
        'cfo_pat_ratio': 10.0,
        'fcf_flag': 5.0,
    }
    
    GROWTH_METRICS = {
        'revenue_cagr_5yr': 10.0,
        'pat_cagr_5yr': 10.0,
    }
    
    LEVERAGE_METRICS = {
        'de_score': 10.0,
        'icr_score': 5.0,
    }
    
    def __init__(self, db_path: str = "nifty100.db"):
        """Initialize CompositeScorer with database connection."""
        self.db_path = db_path
        self.conn = None
        self._connect()
    
    def _connect(self):
        """Establish database connection."""
        try:
            self.conn = sqlite3.connect(self.db_path)
            self.conn.row_factory = sqlite3.Row
            logger.info(f"CompositeScorer connected to {self.db_path}")
        except sqlite3.Error as e:
            logger.error(f"Database connection failed: {e}")
            raise
    
    def close(self):
        """Close database connection."""
        if self.conn:
            self.conn.close()
            logger.info("CompositeScorer connection closed")
    
    def _compute_roce(self, company_id: str, year: str) -> Optional[float]:
        """Compute ROCE for a company-year."""
        cursor = self.conn.cursor()
        
        # Get required data from balancesheet and profitandloss
        cursor.execute("""
            SELECT fr.return_on_equity_pct, bs.equity_capital, bs.reserves, bs.total_assets,
                   pl.net_profit, pl.operating_profit, pl.interest, bs.borrowings
            FROM financial_ratios fr
            LEFT JOIN balancesheet bs ON fr.company_id = bs.company_id AND fr.year = bs.year
            LEFT JOIN profitandloss pl ON fr.company_id = pl.company_id AND fr.year = pl.year
            WHERE fr.company_id = ? AND fr.year = ?
        """, (company_id, year))
        
        row = cursor.fetchone()
        if not row:
            return None
        
        # ROCE = EBIT / (Equity + Debt - Cash)
        # Simplified: Use available data
        try:
            ebit = row[5]  # operating_profit
            equity = (row[1] or 0) + (row[2] or 0)  # equity_capital + reserves
            debt = row[7] or 0  # borrowings
            
            if not ebit or ebit == 0 or (equity + debt) <= 0:
                return None
            
            roce_pct = (ebit / (equity + debt)) * 100
            return roce_pct
        except:
            return None
    
    def _compute_fcf_cagr_5yr(self, company_id: str, year: str) -> Optional[float]:
        """Compute 5-year FCF CAGR from financial_ratios history."""
        cursor = self.conn.cursor()
        
        # Get FCF history, excluding TTM
        cursor.execute("""
            SELECT year, free_cash_flow_cr FROM financial_ratios
            WHERE company_id = ?
            AND year NOT LIKE '%-TTM'
            AND free_cash_flow_cr IS NOT NULL
            AND free_cash_flow_cr > 0
            ORDER BY year ASC
        """, (company_id,))
        
        history = cursor.fetchall()
        if len(history) < 6:  # Need 6+ points for 5-year CAGR
            return None
        
        history_tuples = [(row[0], row[1]) for row in history[-6:]]
        cagr_pct, flag = CAGREngine.cagr(history_tuples, window_years=5, metric_name="FCF")
        return cagr_pct
    
    def _compute_cfo_pat_ratio(self, company_id: str, year: str) -> Optional[float]:
        """Compute CFO/PAT ratio."""
        cursor = self.conn.cursor()
        
        cursor.execute("""
            SELECT cash_from_operations_cr FROM financial_ratios
            WHERE company_id = ? AND year = ?
        """, (company_id, year))
        
        row = cursor.fetchone()
        if not row or row[0] is None:
            return None
        
        cfo = row[0]
        
        # Get PAT from profitandloss
        cursor.execute("""
            SELECT net_profit FROM profitandloss
            WHERE company_id = ? AND year = ?
        """, (company_id, year))
        
        pl_row = cursor.fetchone()
        if not pl_row or pl_row[0] is None or pl_row[0] == 0:
            return None
        
        pat = pl_row[0]
        
        # CFO/PAT ratio (capped at 2.0 for extreme values)
        ratio = min(cfo / pat, 2.0) if pat != 0 else None
        return ratio
    
    def _get_fcf_flag(self, fcf_value: Optional[float]) -> float:
        """Return 1.0 if FCF > 0, else 0.0."""
        return 1.0 if fcf_value and fcf_value > 0 else 0.0
    
    def _normalize_winsorize(self, values: List[float], p_min: float = 10, p_max: float = 90) -> Tuple[List[float], float, float]:
        """
        Apply P10/P90 winsorisation and normalize to 0–100.
        
        Returns: (normalized_values, p10_value, p90_value)
        """
        arr = np.array([v for v in values if v is not None])
        
        if len(arr) == 0:
            return [0] * len(values), None, None
        
        p10 = np.percentile(arr, p_min)
        p90 = np.percentile(arr, p_max)
        
        # Winsorise: cap at P10/P90
        winsorised = np.clip(arr, p10, p90)
        
        # Normalize to 0–100
        if p90 == p10:
            # All values same, return 50 (middle of scale)
            normalized = np.array([50.0] * len(arr))
        else:
            normalized = ((winsorised - p10) / (p90 - p10)) * 100
        
        return normalized.tolist(), p10, p90
    
    def _inverse_normalize(self, normalized_scores: List[float]) -> List[float]:
        """Invert normalized scores (for metrics where lower is better, like D/E)."""
        return [100 - score for score in normalized_scores]
    
    def compute_composite_score(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Compute composite quality score for each company.
        
        Args:
            df: DataFrame with required columns (from FilterEngine.load_base_data)
        
        Returns:
            DataFrame with added 'composite_quality_score' column
        """
        df = df.copy()
        
        logger.info(f"Computing composite scores for {len(df)} companies")
        
        # Step 1: Compute missing metrics for each company
        df['roce'] = df.apply(lambda row: self._compute_roce(row['company_id'], row.get('year', '')), axis=1)
        df['fcf_cagr_5yr'] = df.apply(lambda row: self._compute_fcf_cagr_5yr(row['company_id'], row.get('year', '')), axis=1)
        df['cfo_pat_ratio'] = df.apply(lambda row: self._compute_cfo_pat_ratio(row['company_id'], row.get('year', '')), axis=1)
        df['fcf_flag'] = df['free_cash_flow_cr'].apply(self._get_fcf_flag)
        
        # Step 2: Normalize each metric within sector using P10/P90
        df = self._normalize_metrics_by_sector(df)
        
        # Step 3: Compute component scores (each 0–100)
        df['profitability_score'] = (
            df['roe_norm'] * (15/35) +
            df['roce_norm'] * (10/35) +
            df['npm_norm'] * (10/35)
        )
        df['profitability_score'].fillna(50, inplace=True)
        
        df['cash_quality_score'] = (
            df['fcf_cagr_norm'] * (15/30) +
            df['cfo_pat_norm'] * (10/30) +
            df['fcf_flag'] * 100 * (5/30)
        )
        df['cash_quality_score'].fillna(50, inplace=True)
        
        df['growth_score'] = (
            df['revenue_cagr_norm'] * (10/20) +
            df['pat_cagr_norm'] * (10/20)
        )
        df['growth_score'].fillna(50, inplace=True)
        
        df['leverage_score'] = (
            df['de_norm_inv'] * (10/15) +
            df['icr_norm'] * (5/15)
        )
        df['leverage_score'].fillna(50, inplace=True)
        
        # Step 4: Weighted composite score (0–100)
        df['composite_quality_score'] = (
            df['profitability_score'] * 0.35 +
            df['cash_quality_score'] * 0.30 +
            df['growth_score'] * 0.20 +
            df['leverage_score'] * 0.15
        )
        
        # Ensure score is within 0–100
        df['composite_quality_score'] = df['composite_quality_score'].clip(0, 100)
        
        logger.info(f"Composite score computed. Mean: {df['composite_quality_score'].mean():.2f}, Min: {df['composite_quality_score'].min():.2f}, Max: {df['composite_quality_score'].max():.2f}")
        
        return df
    
    def _normalize_metrics_by_sector(self, df: pd.DataFrame) -> pd.DataFrame:
        """Normalize all metrics within sector using P10/P90 winsorization."""
        df = df.copy()
        
        for broad_sector in df['broad_sector'].unique():
            sector_mask = df['broad_sector'] == broad_sector
            
            # Normalize each metric
            df.loc[sector_mask, 'roe_norm'] = self._normalize_values(
                df.loc[sector_mask, 'return_on_equity_pct']
            )
            df.loc[sector_mask, 'roce_norm'] = self._normalize_values(
                df.loc[sector_mask, 'roce']
            )
            df.loc[sector_mask, 'npm_norm'] = self._normalize_values(
                df.loc[sector_mask, 'net_profit_margin_pct']
            )
            df.loc[sector_mask, 'fcf_cagr_norm'] = self._normalize_values(
                df.loc[sector_mask, 'fcf_cagr_5yr']
            )
            df.loc[sector_mask, 'cfo_pat_norm'] = self._normalize_values(
                df.loc[sector_mask, 'cfo_pat_ratio']
            )
            df.loc[sector_mask, 'revenue_cagr_norm'] = self._normalize_values(
                df.loc[sector_mask, 'revenue_cagr_5yr']
            )
            df.loc[sector_mask, 'pat_cagr_norm'] = self._normalize_values(
                df.loc[sector_mask, 'pat_cagr_5yr']
            )
            
            # D/E: invert and normalize (lower D/E = higher score)
            de_inv = 1.0 / (1.0 + df.loc[sector_mask, 'debt_to_equity'])
            df.loc[sector_mask, 'de_norm_inv'] = self._normalize_values(de_inv)
            
            # ICR: debt-free = 100, otherwise normalize
            icr_adj = df.loc[sector_mask, 'interest_coverage'].copy()
            debt_free_mask = (df.loc[sector_mask, 'debt_to_equity'] == 0)
            icr_adj[debt_free_mask] = 100
            icr_adj[~debt_free_mask] = icr_adj[~debt_free_mask].clip(1, 20)  # Cap at 20
            df.loc[sector_mask, 'icr_norm'] = self._normalize_values(icr_adj)
        
        # Fill any remaining NaN with midpoint
        cols_to_fill = ['roe_norm', 'roce_norm', 'npm_norm', 'fcf_cagr_norm', 'cfo_pat_norm',
                       'revenue_cagr_norm', 'pat_cagr_norm', 'de_norm_inv', 'icr_norm']
        for col in cols_to_fill:
            df[col].fillna(50, inplace=True)
        
        return df
    
    def _normalize_values(self, values: pd.Series) -> pd.Series:
        """Normalize a series using P10/P90 winsorization."""
        valid_vals = values.dropna()
        if len(valid_vals) < 2:
            return pd.Series([50.0] * len(values), index=values.index)
        
        p10 = np.percentile(valid_vals, 10)
        p90 = np.percentile(valid_vals, 90)
        
        normalized = values.copy()
        normalized = normalized.clip(p10, p90)  # Winsorise
        
        if p90 > p10:
            normalized = ((normalized - p10) / (p90 - p10)) * 100
        else:
            normalized = pd.Series([50.0] * len(normalized), index=normalized.index)
        
        return normalized
    
    def __enter__(self):
        """Context manager entry."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
