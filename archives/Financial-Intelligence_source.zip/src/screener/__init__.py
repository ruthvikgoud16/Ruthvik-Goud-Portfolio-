"""
Screener module for N100 Financial Intelligence Platform.

Provides filtering, scoring, and peer comparison functionality.
"""

from .engine import FilterEngine

__all__ = ["FilterEngine"]
