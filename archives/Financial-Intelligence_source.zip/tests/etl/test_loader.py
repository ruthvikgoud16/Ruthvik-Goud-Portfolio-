"""Day 41 — loader source-file shape tests (read-only, no DB rewrite)."""

from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[2] / "project_reference" / "source_data" / "excel"


def _read(name, header):
    return pd.read_excel(ROOT / name, header=header)


def test_companies_rowcount_and_id():
    df = _read("companies.xlsx", 1)
    assert "id" in [c.lower() if isinstance(c, str) else c for c in df.columns] or df.shape[1] >= 5
    assert len(df) >= 90


def test_profitandloss_has_sales():
    df = _read("profitandloss.xlsx", 1)
    cols = [str(c).lower() for c in df.columns]
    assert any("sales" in c for c in cols)
    assert len(df) > 100


def test_balancesheet_has_assets():
    df = _read("balancesheet.xlsx", 1)
    cols = [str(c).lower() for c in df.columns]
    assert any("asset" in c for c in cols)


def test_cashflow_has_operating():
    df = _read("cashflow.xlsx", 1)
    cols = [str(c).lower() for c in df.columns]
    assert any("operat" in c for c in cols)


def test_sectors_covers_universe():
    df = _read("sectors.xlsx", 0)
    assert len(df) == 92


def test_market_cap_years():
    df = _read("market_cap.xlsx", 0)
    assert len(df) >= 500


def test_stock_prices_rows():
    df = _read("stock_prices.xlsx", 0)
    assert len(df) >= 5000


def test_documents_has_report_column():
    df = _read("documents.xlsx", 1)
    cols = [str(c).lower() for c in df.columns]
    assert any("report" in c or "annual" in c for c in cols)


def test_peer_groups_present():
    df = _read("peer_groups.xlsx", 0)
    assert len(df) >= 11


def test_financial_ratios_source_rows():
    df = _read("financial_ratios.xlsx", 0)
    assert len(df) >= 1000
