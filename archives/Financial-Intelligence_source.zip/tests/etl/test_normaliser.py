"""
Sprint 1 — Data Foundation
Unit Tests for Normalisation Module

35+ tests: 20 for normalize_year(), 15+ for normalize_ticker()
"""

import pytest
from src.etl.normaliser import (
    normalize_year,
    normalize_ticker,
    validate_normalized_year,
    extract_year_from_normalized,
    extract_month_from_normalized
)


# ==================== NORMALIZE_YEAR TESTS (20+) ====================

class TestNormalizeYear:
    """Test suite for normalize_year() function - 20+ tests"""
    
    def test_year_format_mar_2014(self):
        """Test: 'Mar 2014' → '2014-03'"""
        assert normalize_year("Mar 2014") == "2014-03"
    
    def test_year_format_dec_2012(self):
        """Test: 'Dec 2012' → '2012-12'"""
        assert normalize_year("Dec 2012") == "2012-12"
    
    def test_year_format_mar_dash_13(self):
        """Test: 'Mar-13' → '2013-03'"""
        assert normalize_year("Mar-13") == "2013-03"
    
    def test_year_format_mar_dash_14(self):
        """Test: 'Mar-14' → '2014-03'"""
        assert normalize_year("Mar-14") == "2014-03"
    
    def test_year_format_mar_dash_24(self):
        """Test: 'Mar-24' → '2024-03'"""
        assert normalize_year("Mar-24") == "2024-03"
    
    def test_year_format_integer_2019(self):
        """Test: 2019 (int) → '2019-03'"""
        assert normalize_year(2019) == "2019-03"
    
    def test_year_format_integer_2020(self):
        """Test: 2020 (int) → '2020-03'"""
        assert normalize_year(2020) == "2020-03"
    
    def test_year_format_string_integer(self):
        """Test: '2021' (str) → '2021-03'"""
        assert normalize_year("2021") == "2021-03"
    
    def test_year_format_iso_date(self):
        """Test: '2020-01-01' → '2020-01'"""
        assert normalize_year("2020-01-01") == "2020-01"
    
    def test_year_format_iso_date_december(self):
        """Test: '2023-12-31' → '2023-12'"""
        assert normalize_year("2023-12-31") == "2023-12"
    
    def test_year_format_already_normalized(self):
        """Test: '2014-03' → '2014-03' (already normalized)"""
        assert normalize_year("2014-03") == "2014-03"
    
    def test_year_format_all_months(self):
        """Test: All 12 months in 'MMM YYYY' format"""
        months = [
            ("Jan 2020", "2020-01"),
            ("Feb 2020", "2020-02"),
            ("Mar 2020", "2020-03"),
            ("Apr 2020", "2020-04"),
            ("May 2020", "2020-05"),
            ("Jun 2020", "2020-06"),
            ("Jul 2020", "2020-07"),
            ("Aug 2020", "2020-08"),
            ("Sep 2020", "2020-09"),
            ("Oct 2020", "2020-10"),
            ("Nov 2020", "2020-11"),
            ("Dec 2020", "2020-12"),
        ]
        for input_val, expected in months:
            assert normalize_year(input_val) == expected
    
    def test_year_format_case_insensitive(self):
        """Test: Case insensitivity"""
        assert normalize_year("MAR 2014") == "2014-03"
        assert normalize_year("mar 2014") == "2014-03"
        assert normalize_year("Mar 2014") == "2014-03"
    
    def test_year_format_with_whitespace(self):
        """Test: Extra whitespace handling"""
        assert normalize_year("  Mar 2014  ") == "2014-03"
        assert normalize_year("Mar  2014") == "2014-03"
    
    def test_year_format_float(self):
        """Test: Float year like 2013.0"""
        assert normalize_year(2013.0) == "2013-03"
        assert normalize_year("2013.0") == "2013-03"
    
    def test_year_format_none(self):
        """Test: None input → None"""
        assert normalize_year(None) is None
    
    def test_year_format_empty_string(self):
        """Test: Empty string → None"""
        assert normalize_year("") is None
        assert normalize_year("   ") is None
    
    def test_year_format_invalid_month(self):
        """Test: Invalid month name → None"""
        assert normalize_year("Xyz 2014") is None
        assert normalize_year("InvalidMonth 2020") is None
    
    def test_year_format_invalid_year_range(self):
        """Test: Year out of range → None"""
        assert normalize_year(1800) is None
        assert normalize_year(2200) is None
    
    def test_year_format_nan(self):
        """Test: NaN (float) → None"""
        import math
        assert normalize_year(float('nan')) is None


# ==================== NORMALIZE_TICKER TESTS (15+) ====================

class TestNormalizeTicker:
    """Test suite for normalize_ticker() function - 15+ tests"""
    
    def test_ticker_uppercase_conversion(self):
        """Test: Lowercase → Uppercase"""
        assert normalize_ticker("tcs") == "TCS"
        assert normalize_ticker("reliance") == "RELIANCE"
    
    def test_ticker_already_uppercase(self):
        """Test: Already uppercase"""
        assert normalize_ticker("TCS") == "TCS"
        assert normalize_ticker("INFY") == "INFY"
    
    def test_ticker_mixed_case(self):
        """Test: Mixed case → Uppercase"""
        assert normalize_ticker("TaTaMoToRs") == "TATAMOTORS"
        assert normalize_ticker("HdFcBaNk") == "HDFCBANK"
    
    def test_ticker_with_whitespace(self):
        """Test: Whitespace removal"""
        assert normalize_ticker("  TCS  ") == "TCS"
        assert normalize_ticker("\tRELIANCE\n") == "RELIANCE"
    
    def test_ticker_with_hyphen(self):
        """Test: Hyphen preservation"""
        assert normalize_ticker("ADANI-ENT") == "ADANI-ENT"
        assert normalize_ticker("adani-ent") == "ADANI-ENT"
    
    def test_ticker_with_underscore(self):
        """Test: Underscore preservation"""
        assert normalize_ticker("COMPANY_A") == "COMPANY_A"
    
    def test_ticker_with_numbers(self):
        """Test: Numbers preservation"""
        assert normalize_ticker("TCS123") == "TCS123"
        assert normalize_ticker("reliance2") == "RELIANCE2"
    
    def test_ticker_special_characters_removed(self):
        """Test: Special characters removal"""
        assert normalize_ticker("TCS@#$") == "TCS"
        assert normalize_ticker("RELI*ANCE") == "RELIANCE"
        assert normalize_ticker("IN&FY") == "INFY"
    
    def test_ticker_none(self):
        """Test: None input → None"""
        assert normalize_ticker(None) is None
    
    def test_ticker_empty_string(self):
        """Test: Empty string → None"""
        assert normalize_ticker("") is None
        assert normalize_ticker("   ") is None
    
    def test_ticker_all_special_chars(self):
        """Test: All special characters → None"""
        assert normalize_ticker("@#$%") is None
        assert normalize_ticker("   ***   ") is None
    
    def test_ticker_nan(self):
        """Test: NaN (float) → None"""
        import math
        assert normalize_ticker(float('nan')) is None
    
    def test_ticker_numeric_input(self):
        """Test: Numeric ticker (converted to string)"""
        assert normalize_ticker(12345) == "12345"
    
    def test_ticker_real_examples(self):
        """Test: Real Nifty 100 ticker examples"""
        tickers = ["ABB", "ADANIENSOL", "ADANIENT", "ADANIPORTS", "APOLLOHOSP",
                   "ASIANPAINT", "AXISBANK", "BAJAJ-AUTO", "BAJAJFINSV", "BAJFINANCE"]
        for ticker in tickers:
            assert normalize_ticker(ticker) == ticker
            assert normalize_ticker(ticker.lower()) == ticker
    
    def test_ticker_agtl_alias_maps_to_atgl(self):
        """cashflow.xlsx uses AGTL; companies.id is ATGL."""
        assert normalize_ticker("AGTL") == "ATGL"
        assert normalize_ticker("agtl") == "ATGL"


# ==================== HELPER FUNCTION TESTS ====================

class TestHelperFunctions:
    """Test suite for helper functions"""
    
    def test_validate_normalized_year_valid(self):
        """Test: Valid normalized year"""
        assert validate_normalized_year("2014-03") is True
        assert validate_normalized_year("2020-12") is True
        assert validate_normalized_year("9999-12") is True  # TTM marker
    
    def test_validate_normalized_year_invalid(self):
        """Test: Invalid normalized year"""
        assert validate_normalized_year("Mar 2014") is False
        assert validate_normalized_year("2014-13") is False  # Month > 12
        assert validate_normalized_year("1800-01") is False  # Year < 1900
        assert validate_normalized_year("9998-01") is True  # Year up to 9998 allowed
        assert validate_normalized_year("10000-01") is False  # Year > 9999 invalid
    
    def test_extract_year_from_normalized(self):
        """Test: Extract year component"""
        assert extract_year_from_normalized("2014-03") == 2014
        assert extract_year_from_normalized("2020-12") == 2020
    
    def test_extract_month_from_normalized(self):
        """Test: Extract month component"""
        assert extract_month_from_normalized("2014-03") == 3
        assert extract_month_from_normalized("2020-12") == 12
