"""Screener API tests."""

from fastapi.testclient import TestClient

from src.api.main import app
from src.analytics.company_panel import PROJECT_ROOT
from src.screener.engine import FilterEngine

client = TestClient(app)


def test_screener_min_roe():
    r = client.get("/api/v1/screener", params={"min_roe": 15})
    assert r.status_code == 200
    body = r.json()
    for row in body["results"]:
        roe = row.get("return_on_equity_pct")
        if roe is not None:
            assert roe >= 15


def test_screener_invalid_param():
    r = client.get("/api/v1/screener", params={"min_roe": "not-a-number"})
    assert r.status_code == 400


def test_screener_matches_filter_engine():
    r = client.get("/api/v1/screener", params={"min_roe": 15, "max_de": 1, "min_fcf": 0})
    engine = FilterEngine(str(PROJECT_ROOT / "nifty100.db"))
    df = engine.apply_filters({"roe_min": 15, "de_max": 1, "fcf_min": 0})
    engine.close()
    api_ids = {row["company_id"] if "company_id" in row else row.get("id") for row in r.json()["results"]}
    eng_ids = set(df["company_id"] if "company_id" in df.columns else df.iloc[:, 0])
    assert api_ids == set(eng_ids)
