"""Company endpoint extras."""

from fastapi.testclient import TestClient

from src.api.main import app

client = TestClient(app)


def test_search_filter():
    r = client.get("/api/v1/companies", params={"search": "TCS"})
    assert r.status_code == 200
    ids = [c["id"] for c in r.json()["companies"]]
    assert "TCS" in ids


def test_pl_year_window():
    r = client.get("/api/v1/companies/TCS/pl", params={"from_year": "2020-03", "to_year": "2024-03"})
    assert r.status_code == 200
    years = [row["year"] for row in r.json()["rows"]]
    assert years
    assert all("2020-03" <= y <= "2024-03" for y in years)
