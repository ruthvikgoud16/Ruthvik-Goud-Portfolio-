"""API tests (Days 42)."""

from fastapi.testclient import TestClient

from src.api.main import app

client = TestClient(app)


def test_health_ok():
    r = client.get("/api/v1/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "ok"
    for table in [
        "companies",
        "sectors",
        "profitandloss",
        "balancesheet",
        "cashflow",
        "financial_ratios",
        "analysis",
        "documents",
        "prosandcons",
        "stock_prices",
    ]:
        assert table in body["db_row_counts"]
        assert body["db_row_counts"][table] is not None


def test_companies_count():
    r = client.get("/api/v1/companies")
    assert r.status_code == 200
    assert r.json()["count"] == 92


def test_company_tcs():
    r = client.get("/api/v1/companies/TCS")
    assert r.status_code == 200
    assert r.json()["company"]["id"] == "TCS"


def test_company_invalid_404():
    r = client.get("/api/v1/companies/INVALID")
    assert r.status_code == 404


def test_tcs_ratios_history():
    r = client.get("/api/v1/companies/TCS/ratios")
    assert r.status_code == 200
    assert len(r.json()["rows"]) >= 10


def test_tearsheet_pdf():
    r = client.get("/api/v1/companies/TCS/tearsheet")
    assert r.status_code == 200
    assert r.headers["content-type"].startswith("application/pdf")
