"""Sector API tests — counts come from SQLite, not a fabricated 11."""

from fastapi.testclient import TestClient

from src.api.main import app
from src.api.db import get_connection

client = TestClient(app)


def test_sectors_match_database():
    r = client.get("/api/v1/sectors")
    assert r.status_code == 200
    conn = get_connection()
    n = conn.execute("SELECT COUNT(DISTINCT broad_sector) FROM sectors").fetchone()[0]
    conn.close()
    assert r.json()["count"] == n
    assert n == 10  # source caveat vs spec wording of 11


def test_sectors_it_alias():
    r = client.get("/api/v1/sectors/IT/companies")
    assert r.status_code == 200
    body = r.json()
    assert body["sector"] == "Information Technology"
    assert body["count"] >= 1
    assert all(c["broad_sector"] == "Information Technology" for c in body["companies"])


def test_unknown_sector_404():
    r = client.get("/api/v1/sectors/NotASector/companies")
    assert r.status_code == 404
