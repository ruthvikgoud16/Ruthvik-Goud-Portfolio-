"""Day 43 concurrency smoke test against TestClient."""

import time
from concurrent.futures import ThreadPoolExecutor

from fastapi.testclient import TestClient

from src.api.main import app

client = TestClient(app)


def test_ten_concurrent_screener_calls_under_10s():
    def one(_):
        return client.get("/api/v1/screener", params={"min_roe": 15}).status_code

    start = time.perf_counter()
    with ThreadPoolExecutor(max_workers=10) as pool:
        codes = list(pool.map(one, range(10)))
    elapsed = time.perf_counter() - start
    assert codes == [200] * 10
    assert elapsed < 10
