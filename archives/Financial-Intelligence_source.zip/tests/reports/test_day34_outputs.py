"""Day 34/35 report artifact tests — checks files that must already be generated."""

import re
from pathlib import Path

from src.analytics.company_panel import PROJECT_ROOT

TEARS = PROJECT_ROOT / "reports" / "tearsheets"
SECTOR = PROJECT_ROOT / "reports" / "sector"
PORT = PROJECT_ROOT / "reports" / "portfolio" / "portfolio_summary.pdf"


def _page_count(path: Path) -> int:
    data = path.read_bytes()
    counts = [int(n) for n in re.findall(rb"/Count\s+(\d+)", data)]
    return max(counts) if counts else 0


def test_ninety_two_tearsheets_two_pages_min_size():
    files = sorted(TEARS.glob("*_tearsheet.pdf"))
    assert len(files) == 92
    for path in files:
        assert path.stat().st_size >= 30 * 1024, path.name
        assert _page_count(path) == 2, path.name


def test_sample_tearsheets_exist():
    for ticker in ["TCS", "HDFCBANK", "RELIANCE", "SUNPHARMA", "TATASTEEL"]:
        assert (TEARS / f"{ticker}_tearsheet.pdf").exists()


def test_sector_reports_match_source_broad_sectors():
    files = list(SECTOR.glob("*_report.pdf"))
    assert len(files) == 10
    for path in files:
        assert path.stat().st_size > 1000
        assert _page_count(path) >= 1


def test_portfolio_one_page_per_company():
    assert PORT.exists()
    assert _page_count(PORT) == 92
