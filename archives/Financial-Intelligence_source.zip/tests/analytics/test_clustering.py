"""Day 36–37 clustering output tests."""

import pandas as pd

from src.analytics.clustering import FEATURE_COLS, N_CLUSTERS, write_cluster_outputs
from src.analytics.company_panel import PROJECT_ROOT, connect


def test_cluster_labels_cover_all_companies():
    write_cluster_outputs()
    df = pd.read_csv(PROJECT_ROOT / "output" / "cluster_labels.csv")
    conn = connect()
    ids = {r[0] for r in conn.execute("SELECT id FROM companies")}
    conn.close()
    assert set(df["company_id"]) == ids
    assert df["cluster_id"].between(0, 4).all()
    assert df["cluster_id"].nunique() == N_CLUSTERS
    assert df["cluster_name"].notna().all()
    assert (PROJECT_ROOT / "reports" / "elbow_plot.png").exists()
    assert (PROJECT_ROOT / "reports" / "correlation_heatmap.png").exists()
    stats = pd.read_csv(PROJECT_ROOT / "output" / "portfolio_stats.csv")
    assert set(["P10", "P25", "P50", "P75", "P90", "Mean", "Std"]).issubset(stats.columns)
    assert len(stats) == 10
