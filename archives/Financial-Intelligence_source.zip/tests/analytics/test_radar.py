"""
Day 19 — Unit Tests for Radar Chart Generation
Tests radar chart generation, normalization, peer averages, and file export
"""

import pytest
import sqlite3
from pathlib import Path
import numpy as np
from PIL import Image
from src.analytics.radar import RadarChartGenerator


@pytest.fixture
def rcg():
    """Create RadarChartGenerator instance for testing."""
    gen = RadarChartGenerator(db_path="nifty100.db", output_dir="tests/test_radar_output")
    yield gen
    gen.close()


@pytest.fixture
def conn():
    """Create database connection for verification queries."""
    conn = sqlite3.connect("nifty100.db")
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()


class TestRadarChartGeneratorInit:
    """Test RadarChartGenerator initialization."""
    
    def test_init_connects_to_database(self, rcg):
        """Test that __init__ successfully connects to database."""
        assert rcg.conn is not None
    
    def test_output_dir_created(self, rcg):
        """Test that output directory is created automatically."""
        assert rcg.output_dir.exists()
    
    def test_8_metrics_defined(self, rcg):
        """Test that exactly 8 metrics are defined."""
        assert len(rcg.metrics) == 8
    
    def test_8_metric_labels_defined(self, rcg):
        """Test that exactly 8 metric labels are defined."""
        assert len(rcg.metric_labels) == 8
    
    def test_11_peer_groups_defined(self, rcg):
        """Test that exactly 11 peer groups are defined."""
        assert len(rcg.peer_groups) == 11
    
    def test_metrics_list(self, rcg):
        """Test that correct metrics are in the list."""
        expected_metrics = [
            'return_on_equity_pct',
            'ROCE',
            'net_profit_margin_pct',
            'debt_to_equity',
            'free_cash_flow_cr',
            'pat_cagr_5yr',
            'revenue_cagr_5yr',
            'composite_quality_score',
        ]
        assert rcg.metrics == expected_metrics


class TestMetricValueRetrieval:
    """Test metric value retrieval."""
    
    def test_get_roe_value(self, rcg):
        """Test retrieving ROE value."""
        value = rcg._get_metric_value('TCS', '9999-12', 'return_on_equity_pct')
        if value is not None:
            assert isinstance(value, float)
    
    def test_get_composite_score(self, rcg):
        """Test retrieving composite quality score."""
        value = rcg._get_metric_value('TCS', '9999-12', 'composite_quality_score')
        if value is not None:
            assert isinstance(value, float)
            assert 0 <= value <= 100
    
    def test_get_roce_computed(self, rcg):
        """Test ROCE is computed on-the-fly."""
        value = rcg._get_metric_value('TCS', '2023-03', 'ROCE')
        # May be None if data insufficient, but should be callable
        if value is not None:
            assert isinstance(value, float)
    
    def test_missing_company_returns_none(self, rcg):
        """Test that non-existent company returns None."""
        value = rcg._get_metric_value('NONEXISTENT', '9999-12', 'return_on_equity_pct')
        assert value is None


class TestPeerGroupAssignment:
    """Test peer group identification."""
    
    def test_get_peer_group_tcs(self, rcg):
        """Test that TCS is in IT Services."""
        peer_group = rcg._get_peer_group('TCS')
        assert peer_group == 'IT Services'
    
    def test_get_peer_group_icicibank(self, rcg):
        """Test that ICICIBANK is in Private Banks."""
        peer_group = rcg._get_peer_group('ICICIBANK')
        assert peer_group == 'Private Banks'
    
    def test_get_peer_group_non_peer(self, rcg):
        """Test that non-peer company returns None."""
        peer_group = rcg._get_peer_group('ABB')
        assert peer_group is None
    
    def test_get_peer_group_nonexistent(self, rcg):
        """Test that non-existent company returns None."""
        peer_group = rcg._get_peer_group('NONEXISTENT')
        assert peer_group is None


class TestNormalization:
    """Test value normalization for radar display."""
    
    def test_normalize_all_values_in_range(self, rcg):
        """Test that normalized values are in [0, 100]."""
        values = {
            'return_on_equity_pct': 20.0,
            'ROCE': 15.0,
            'net_profit_margin_pct': 10.0,
            'debt_to_equity': 0.5,
            'free_cash_flow_cr': 100.0,
            'pat_cagr_5yr': 15.0,
            'revenue_cagr_5yr': 12.0,
            'composite_quality_score': 50.0,
        }
        
        all_values = {
            'return_on_equity_pct': [10.0, 15.0, 20.0, 25.0],
            'ROCE': [10.0, 15.0, 20.0],
            'net_profit_margin_pct': [5.0, 10.0, 15.0],
            'debt_to_equity': [0.3, 0.5, 0.7],
            'free_cash_flow_cr': [50.0, 100.0, 150.0],
            'pat_cagr_5yr': [10.0, 15.0, 20.0],
            'revenue_cagr_5yr': [8.0, 12.0, 16.0],
            'composite_quality_score': [30.0, 50.0, 70.0],
        }
        
        normalized = rcg._normalize_values(values, all_values)
        
        for metric, value in normalized.items():
            assert 0.0 <= value <= 100.0, f"{metric} value {value} out of range"
    
    def test_missing_values_default_to_50(self, rcg):
        """Test that missing values normalize to 50 (midpoint)."""
        values = {
            'return_on_equity_pct': None,
            'ROCE': None,
            'net_profit_margin_pct': None,
            'debt_to_equity': None,
            'free_cash_flow_cr': None,
            'pat_cagr_5yr': None,
            'revenue_cagr_5yr': None,
            'composite_quality_score': None,
        }
        
        all_values = {m: [100.0] for m in rcg.metrics}
        normalized = rcg._normalize_values(values, all_values)
        
        for metric, value in normalized.items():
            assert value == 50.0, f"{metric} should normalize to 50.0, got {value}"
    
    def test_de_inversion_logic(self, rcg):
        """Test that D/E is inverted (lower D/E gets higher score)."""
        # D/E = 0 (debt-free) should map to high value
        # D/E = 2 (leveraged) should map to low value
        values_low_de = {'debt_to_equity': 0.1}
        values_high_de = {'debt_to_equity': 2.0}
        all_values = {'debt_to_equity': [0.1, 0.5, 1.0, 2.0, 3.0]}
        
        norm_low = rcg._normalize_values(values_low_de, all_values)['debt_to_equity']
        norm_high = rcg._normalize_values(values_high_de, all_values)['debt_to_equity']
        
        assert norm_low > norm_high, "Lower D/E should have higher normalized score"


class TestPeerAverageComputation:
    """Test peer average calculations."""
    
    def test_compute_peer_averages_returns_dict(self, rcg):
        """Test that peer averages computation returns valid dict."""
        all_values = {
            'return_on_equity_pct': [10.0, 15.0, 20.0],
            'ROCE': [12.0, 16.0, 20.0],
            'net_profit_margin_pct': [5.0, 10.0],
            'debt_to_equity': [0.5, 1.0],
            'free_cash_flow_cr': [100.0, 150.0, 200.0],
            'pat_cagr_5yr': [10.0, 15.0],
            'revenue_cagr_5yr': [8.0, 12.0, 16.0],
            'composite_quality_score': [30.0, 50.0, 70.0],
        }
        
        averages = rcg._compute_peer_averages(all_values)
        
        assert len(averages) == 8
        assert averages['return_on_equity_pct'] == 15.0  # (10+15+20)/3
        assert averages['ROCE'] == 16.0  # (12+16+20)/3
    
    def test_peer_averages_handles_empty_values(self, rcg):
        """Test that empty metric values are handled."""
        all_values = {m: [] for m in rcg.metrics}
        averages = rcg._compute_peer_averages(all_values)
        
        # All averages should be None or NaN
        for metric, value in averages.items():
            assert value is None or (isinstance(value, float) and np.isnan(value))


class TestChartGeneration:
    """Test chart file generation."""
    
    def test_generate_peer_group_charts(self, rcg):
        """Test generating charts for IT Services peer group."""
        count = rcg.generate_peer_group_charts('IT Services')
        
        # IT Services has 5 companies: TCS, INFY, WIPRO, HCL, TECHM
        assert count >= 1, "Should generate at least 1 chart for IT Services"
    
    def test_generate_non_peer_charts(self, rcg):
        """Test generating charts for non-peer companies."""
        count = rcg.generate_non_peer_charts()
        
        # Should generate charts for companies without peer group (36 total, some might skip)
        assert count > 0, "Should generate charts for non-peer companies"
    
    def test_generated_files_are_png(self, rcg):
        """Test that generated files are valid PNG."""
        rcg.generate_peer_group_charts('IT Services')
        
        png_files = list(rcg.output_dir.glob('*.png'))
        assert len(png_files) > 0, "Should have generated at least one PNG file"
        
        # Verify file is valid PNG
        for png_file in png_files[:3]:  # Check first 3
            img = Image.open(png_file)
            assert img.format == 'PNG'
    
    def test_generated_files_not_empty(self, rcg):
        """Test that PNG files are not empty."""
        rcg.generate_peer_group_charts('Pharmaceuticals')
        
        png_files = list(rcg.output_dir.glob('*.png'))
        for png_file in png_files:
            assert png_file.stat().st_size > 1000, f"{png_file.name} is too small"
    
    def test_generate_all_charts_returns_stats(self, rcg):
        """Test that generate_all_charts returns proper statistics."""
        stats = rcg.generate_all_charts()
        
        assert 'peer_group_charts' in stats
        assert 'non_peer_charts' in stats
        assert 'total_charts' in stats
        assert stats['peer_group_charts'] > 0
        assert stats['total_charts'] > 0


class TestPeerPercentileIntegration:
    """Test integration with peer_percentiles table."""
    
    def test_all_peer_values_retrieval(self, rcg):
        """Test retrieving all metric values for peer group."""
        all_values = rcg._get_all_peer_values('IT Services', '9999-12')
        
        assert len(all_values) == 8
        assert all(isinstance(all_values[m], list) for m in rcg.metrics)
    
    def test_all_nifty100_values_retrieval(self, rcg):
        """Test retrieving all metric values across Nifty 100."""
        all_values = rcg._get_all_nifty100_values('9999-12')
        
        assert len(all_values) == 8
        assert all(isinstance(all_values[m], list) for m in rcg.metrics)
    
    def test_peer_averages_with_real_data(self, rcg):
        """Test peer averages with real database data."""
        all_values = rcg._get_all_peer_values('IT Services', '9999-12')
        averages = rcg._compute_peer_averages(all_values)
        
        # Averages should be reasonable values or None
        for metric, avg in averages.items():
            if avg is not None:
                assert isinstance(avg, float)


class TestLatestYearDetection:
    """Test latest year detection for companies."""
    
    def test_get_latest_year_for_company(self, rcg):
        """Test getting latest year for a company."""
        year = rcg._get_latest_year('TCS')
        
        # Should be non-TTM year
        assert year is not None
        assert year != '9999-12'
    
    def test_get_latest_year_nonexistent_company(self, rcg):
        """Test getting latest year for non-existent company."""
        year = rcg._get_latest_year('NONEXISTENT')
        
        assert year is None


class TestFileExport:
    """Test PNG file export."""
    
    def test_output_directory_exists(self, rcg):
        """Test that output directory is created."""
        assert rcg.output_dir.exists()
        assert rcg.output_dir.is_dir()
    
    def test_filename_format(self, rcg):
        """Test that PNG filenames follow format {company_id}_radar.png."""
        rcg.generate_peer_group_charts('FMCG')
        
        png_files = list(rcg.output_dir.glob('*.png'))
        for png_file in png_files:
            name = png_file.name
            assert name.endswith('_radar.png')
            # Extract company_id
            company_id = name.replace('_radar.png', '')
            assert len(company_id) > 0
    
    def test_png_file_size_reasonable(self, rcg):
        """Test that PNG files have reasonable file size."""
        rcg.generate_peer_group_charts('Oil & Gas')
        
        png_files = list(rcg.output_dir.glob('*.png'))
        for png_file in png_files:
            size = png_file.stat().st_size
            # Expect 50KB to 500KB per file
            assert 50000 < size < 500000, f"{png_file.name} size {size} out of expected range"


class TestEdgeCases:
    """Test edge cases and error handling."""
    
    def test_missing_metric_values_handled(self, rcg):
        """Test that missing metric values don't crash chart generation."""
        # Generate charts should handle NULL values gracefully
        count = rcg.generate_peer_group_charts('Automobiles')
        assert count > 0
    
    def test_single_company_group(self, rcg):
        """Test handling of peer group with single company."""
        # Some groups might have only 1 company
        all_values = rcg._get_all_peer_values('Steel', '9999-12')
        # Should still work with 1 company
        assert len(all_values) == 8
    
    def test_extreme_values_normalization(self, rcg):
        """Test normalization of extreme values."""
        values = {
            'return_on_equity_pct': 100.0,  # Very high
            'ROCE': 0.0,  # Zero
            'net_profit_margin_pct': -50.0,  # Negative
            'debt_to_equity': 0.001,  # Very low
            'free_cash_flow_cr': 10000.0,  # Very high
            'pat_cagr_5yr': -100.0,  # Very negative
            'revenue_cagr_5yr': 500.0,  # Extreme positive
            'composite_quality_score': 0.0,  # Minimum
        }
        
        all_values = {
            'return_on_equity_pct': [0.0, 50.0, 100.0, 150.0],
            'ROCE': [-50.0, 0.0, 50.0],
            'net_profit_margin_pct': [-100.0, -50.0, 0.0, 50.0],
            'debt_to_equity': [0.001, 0.5, 1.0, 2.0],
            'free_cash_flow_cr': [100.0, 1000.0, 10000.0],
            'pat_cagr_5yr': [-100.0, 0.0, 50.0],
            'revenue_cagr_5yr': [0.0, 100.0, 500.0],
            'composite_quality_score': [0.0, 50.0, 100.0],
        }
        
        normalized = rcg._normalize_values(values, all_values)
        
        # All should be in [0, 100]
        for metric, value in normalized.items():
            assert 0.0 <= value <= 100.0


class TestIntegration:
    """Integration tests combining multiple components."""
    
    def test_full_workflow_peer_group(self, rcg):
        """Test full workflow for peer group chart generation."""
        # Should complete without errors
        count = rcg.generate_peer_group_charts('Private Banks')
        
        assert count > 0
        png_files = list(rcg.output_dir.glob('*BANK*_radar.png'))
        assert len(png_files) > 0
    
    def test_full_workflow_non_peer(self, rcg):
        """Test full workflow for non-peer chart generation."""
        count = rcg.generate_non_peer_charts()
        
        assert count > 0
        png_files = list(rcg.output_dir.glob('*.png'))
        assert len(png_files) > 0
    
    def test_generate_all_charts_workflow(self, rcg):
        """Test complete workflow generating all charts."""
        stats = rcg.generate_all_charts()
        
        assert stats['total_charts'] > 50
        assert stats['peer_group_charts'] == 56  # All 11 groups × avg 5 companies
        
        # Verify files actually exist
        png_files = list(rcg.output_dir.glob('*.png'))
        assert len(png_files) > 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
