import pandas as pd

from src.analytics.company_panel import keep_primary_fiscal_rows


def test_keep_primary_fiscal_drops_intra_year_snapshot():
    df = pd.DataFrame(
        {
            "company_id": ["BHEL", "BHEL", "BHEL"],
            "year": ["2023-03", "2024-03", "2024-09"],
            "free_cash_flow_cr": [1.0, 2.0, 99.0],
        }
    )
    out = keep_primary_fiscal_rows(df)
    assert list(out["year"]) == ["2023-03", "2024-03"]
    assert 99.0 not in set(out["free_cash_flow_cr"])
