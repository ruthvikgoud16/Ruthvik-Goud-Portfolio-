"""Day 31–32 cash-flow intelligence output tests."""

from pathlib import Path

import pandas as pd

from src.analytics.cashflow_intelligence import COLUMNS, build_intelligence
from src.analytics.company_panel import PROJECT_ROOT, connect

XLSX = PROJECT_ROOT / "output" / "cashflow_intelligence.xlsx"


def test_intelligence_has_92_companies_and_required_columns():
    intel, alerts = build_intelligence()
    conn = connect()
    ids = [r[0] for r in conn.execute("SELECT id FROM companies")]
    conn.close()
    assert len(intel) == 92
    assert list(intel.columns) == COLUMNS
    assert set(intel["company_id"]) == set(ids)
    assert set(alerts["company_id"]).issubset(set(ids))
    assert intel["distress_flag"].isin([True, False]).all()


def test_xlsx_written_matches_builder_when_present():
    if not XLSX.exists():
        return
    written = pd.read_excel(XLSX)
    assert len(written) == 92
    assert list(written.columns) == COLUMNS
