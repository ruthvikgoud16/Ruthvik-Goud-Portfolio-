"""
Day 26 Tests: Valuation Module
Tests for FCF Yield, sector median P/E, P/E comparison, and flag classification.
"""

import pytest
import pandas as pd
import numpy as np
import sqlite3
import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.analytics.valuation import ValuationEngine


class TestFCFYieldFormula:
    """Tests for FCF Yield calculation formula."""
    
    def test_standard_fcf_yield(self):
        """Test standard FCF yield calculation."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'fcf_cr': [1000.0],
            'market_cap_crore': [10000.0]
        })
        result = engine.calculate_fcf_yield(df)
        expected_yield = (1000.0 / 10000.0) * 100
        assert result['FCF_yield_pct'].iloc[0] == expected_yield
        assert result['FCF_yield_pct'].iloc[0] == 10.0
    
    def test_negative_fcf(self):
        """Test FCF yield with negative FCF (cash-burning)."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'fcf_cr': [-500.0],
            'market_cap_crore': [10000.0]
        })
        result = engine.calculate_fcf_yield(df)
        assert result['FCF_yield_pct'].iloc[0] == -5.0
    
    def test_zero_market_cap(self):
        """Test FCF yield with zero market cap returns NULL."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'fcf_cr': [1000.0],
            'market_cap_crore': [0.0]
        })
        result = engine.calculate_fcf_yield(df)
        assert pd.isna(result['FCF_yield_pct'].iloc[0])
    
    def test_missing_market_cap(self):
        """Test FCF yield with NULL market cap returns NULL."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'fcf_cr': [1000.0],
            'market_cap_crore': [np.nan]
        })
        result = engine.calculate_fcf_yield(df)
        assert pd.isna(result['FCF_yield_pct'].iloc[0])
    
    def test_missing_fcf(self):
        """Test FCF yield with NULL FCF returns NULL."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'fcf_cr': [np.nan],
            'market_cap_crore': [10000.0]
        })
        result = engine.calculate_fcf_yield(df)
        assert pd.isna(result['FCF_yield_pct'].iloc[0])


class TestSectorMedianPE:
    """Tests for sector median P/E calculation."""
    
    def test_sector_median_calculation(self):
        """Test sector median P/E is calculated correctly."""
        engine = ValuationEngine()
        historical_df = pd.DataFrame({
            'sector': ['IT', 'IT', 'IT', 'IT', 'IT'],
            'pe_ratio': [40, 50, 60, 70, 80]
        })
        medians = engine.calculate_sector_median_pe(historical_df)
        assert medians['IT'] == 60.0  # Median of 40, 50, 60, 70, 80
    
    def test_multiple_sectors(self):
        """Test median calculation for multiple sectors."""
        engine = ValuationEngine()
        historical_df = pd.DataFrame({
            'sector': ['IT', 'IT', 'Financials', 'Financials'],
            'pe_ratio': [50, 60, 30, 40]
        })
        medians = engine.calculate_sector_median_pe(historical_df)
        assert medians['IT'] == 55.0
        assert medians['Financials'] == 35.0


class TestPEComparison:
    """Tests for P/E comparison calculation."""
    
    def test_pe_comparison_above_median(self):
        """Test P/E comparison when above median."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [60.0],
            'sector': ['IT']
        })
        sector_medians = {'IT': 40.0}
        result = engine.calculate_pe_comparison(df, sector_medians)
        # (60/40 - 1) * 100 = 50%
        assert result['PE_vs_sector_median_pct'].iloc[0] == 50.0
    
    def test_pe_comparison_below_median(self):
        """Test P/E comparison when below median."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [30.0],
            'sector': ['IT']
        })
        sector_medians = {'IT': 50.0}
        result = engine.calculate_pe_comparison(df, sector_medians)
        # (30/50 - 1) * 100 = -40%
        assert result['PE_vs_sector_median_pct'].iloc[0] == -40.0
    
    def test_null_pe(self):
        """Test P/E comparison with NULL P/E returns NULL."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [np.nan],
            'sector': ['IT']
        })
        sector_medians = {'IT': 40.0}
        result = engine.calculate_pe_comparison(df, sector_medians)
        assert pd.isna(result['PE_vs_sector_median_pct'].iloc[0])
    
    def test_null_sector_median(self):
        """Test P/E comparison with NULL sector median returns NULL."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [50.0],
            'sector': ['Unknown']
        })
        sector_medians = {}  # No median for Unknown sector
        result = engine.calculate_pe_comparison(df, sector_medians)
        assert pd.isna(result['PE_vs_sector_median_pct'].iloc[0])


class TestFlagClassification:
    """Tests for valuation flag classification."""
    
    def test_caution_flag(self):
        """Test Caution flag when P/E > 1.5x sector median."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [70.0],
            '5yr_median_PE': [40.0]
        })
        result = engine.classify_valuation_flag(df)
        # 70 > 40 * 1.5 (60) → Caution
        assert result['flag'].iloc[0] == 'Caution'
    
    def test_discount_flag(self):
        """Test Discount flag when P/E < 0.7x sector median."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [25.0],
            '5yr_median_PE': [40.0]
        })
        result = engine.classify_valuation_flag(df)
        # 25 < 40 * 0.7 (28) → Discount
        assert result['flag'].iloc[0] == 'Discount'
    
    def test_fair_flag(self):
        """Test Fair flag when between thresholds."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [40.0],
            '5yr_median_PE': [40.0]
        })
        result = engine.classify_valuation_flag(df)
        # 40 is between 28 and 60 → Fair
        assert result['flag'].iloc[0] == 'Fair'
    
    def test_exact_1_5x_boundary(self):
        """Test exact 1.5x boundary is Fair (not Caution)."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [60.0],
            '5yr_median_PE': [40.0]
        })
        result = engine.classify_valuation_flag(df)
        # 60 = 40 * 1.5 (not >) → Fair
        assert result['flag'].iloc[0] == 'Fair'
    
    def test_exact_0_7x_boundary(self):
        """Test exact 0.7x boundary is Fair (not Discount)."""
        engine = ValuationEngine()
        df = pd.DataFrame({
            'pe_ratio': [28.0],
            '5yr_median_PE': [40.0]
        })
        result = engine.classify_valuation_flag(df)
        # 28 = 40 * 0.7 (not <) → Fair
        assert result['flag'].iloc[0] == 'Fair'


class TestDataIntegrity:
    """Tests for data integrity and quality."""
    
    def test_no_duplicate_companies(self):
        """Test that valuation has no duplicate company IDs."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        duplicates = df[df.duplicated('company_id', keep=False)]
        assert len(duplicates) == 0
    
    def test_valid_company_ids(self):
        """Test that all company IDs exist in companies table."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        conn = sqlite3.connect('nifty100.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM companies")
        valid_ids = {row[0] for row in cursor.fetchall()}
        conn.close()
        
        for company_id in df['company_id']:
            assert company_id in valid_ids
    
    def test_period_selection(self):
        """Test that latest period is correctly selected."""
        engine = ValuationEngine()
        df = engine.load_latest_valuation_data()
        
        # Check no sentinel year
        assert '9999-12' not in df['financial_year'].values
        
        # Check mostly 2024-03 (91 companies) with SIEMENS at 2024-09
        year_counts = df['financial_year'].value_counts()
        assert year_counts.get('2024-03', 0) == 91
        assert year_counts.get('2024-09', 0) == 1
    
    def test_92_company_structure(self):
        """Test that result has 92 companies."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        assert len(df) == 92
    
    def test_required_output_columns(self):
        """Test that output has exact required columns."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        required = [
            'company_id', 'company_name', 'sector', 'P/E', 'P/B',
            'EV/EBITDA', 'FCF_yield_pct', '5yr_median_PE',
            'PE_vs_sector_median_pct', 'flag'
        ]
        assert list(df.columns) == required
    
    def test_flag_csv_excludes_fair(self):
        """Test that flags CSV only has Caution and Discount."""
        df = pd.read_csv('output/valuation_flags.csv')
        assert 'Fair' not in df['flag'].values
        assert set(df['flag'].unique()).issubset({'Caution', 'Discount'})


class TestOutputFiles:
    """Tests for output file validity."""
    
    def test_excel_file_readable(self):
        """Test that Excel file can be reopened."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 0
    
    def test_csv_file_readable(self):
        """Test that CSV file can be reopened."""
        df = pd.read_csv('output/valuation_flags.csv')
        assert isinstance(df, pd.DataFrame)
        assert len(df) > 0
    
    def test_csv_headers_correct(self):
        """Test that CSV has correct headers."""
        df = pd.read_csv('output/valuation_flags.csv')
        expected = [
            'company_id', 'company_name', 'sector', 'P/E', 'P/B',
            'EV/EBITDA', 'FCF_yield_pct', '5yr_median_PE',
            'PE_vs_sector_median_pct', 'flag'
        ]
        assert list(df.columns) == expected
    
    def test_csv_round_trip(self):
        """Test that CSV can be written and read back."""
        df1 = pd.read_csv('output/valuation_flags.csv')
        temp_path = 'output/test_temp.csv'
        df1.to_csv(temp_path, index=False)
        df2 = pd.read_csv(temp_path)
        os.remove(temp_path)
        # Compare structure and key values (floating point may differ slightly)
        assert list(df1.columns) == list(df2.columns)
        assert len(df1) == len(df2)
        assert df1['company_id'].equals(df2['company_id'])


class TestDashboardIntegration:
    """Tests for dashboard integration."""
    
    def test_get_valuation_returns_data(self):
        """Test that get_valuation returns actual Day 26 values."""
        from src.dashboard.utils import db
        
        result = db.get_valuation('TCS')
        assert isinstance(result, pd.DataFrame)
        assert not result.empty
    
    def test_get_valuation_has_required_fields(self):
        """Test that get_valuation returns all required fields."""
        from src.dashboard.utils import db
        
        result = db.get_valuation('TCS')
        if not result.empty:
            assert 'P/E' in result.columns
            assert 'FCF_yield_pct' in result.columns
            assert 'flag' in result.columns
    
    def test_invalid_ticker_safe(self):
        """Test that invalid ticker doesn't crash."""
        from src.dashboard.utils import db
        
        result = db.get_valuation('INVALIDXYZ')
        assert isinstance(result, pd.DataFrame)
        # Should be empty but not error
    
    def test_no_source_db_mutation(self):
        """Test that valuation doesn't modify source database."""
        # Count records before
        conn = sqlite3.connect('nifty100.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM financial_ratios")
        count_before = cursor.fetchone()[0]
        conn.close()
        
        # Run valuation
        engine = ValuationEngine()
        engine.run_full_valuation()
        
        # Count records after
        conn = sqlite3.connect('nifty100.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM financial_ratios")
        count_after = cursor.fetchone()[0]
        conn.close()
        
        assert count_before == count_after


class TestEdgeCases:
    """Tests for edge case handling."""
    
    def test_company_with_null_fcf(self):
        """ATGL FCF yield is numeric after AGTL→ATGL cashflow repair."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        atgl = df[df['company_id'] == 'ATGL']
        assert not atgl.empty
        assert pd.notna(atgl['FCF_yield_pct'].iloc[0])
    
    def test_negative_fcf_preserved(self):
        """Test that negative FCF is preserved (not converted to zero)."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        # Find a company with negative FCF
        negative_fcf = df[df['FCF_yield_pct'] < 0]
        # There should be some companies with negative FCF
        assert len(negative_fcf) > 0


class TestRealDataValidation:
    """Tests validating against real source data."""
    
    def test_tcs_valuation_accuracy(self):
        """Test TCS valuation matches source data."""
        df = pd.read_excel('output/valuation_summary.xlsx')
        tcs = df[df['company_id'] == 'TCS'].iloc[0]
        
        # Get source data
        conn = sqlite3.connect('nifty100.db')
        cursor = conn.cursor()
        
        # FCF
        cursor.execute("""
            SELECT free_cash_flow_cr 
            FROM financial_ratios 
            WHERE company_id = 'TCS' AND year = '2024-03'
        """)
        fcf = cursor.fetchone()[0]
        
        # Market cap
        cursor.execute("""
            SELECT market_cap_crore, pe_ratio 
            FROM market_cap 
            WHERE company_id = 'TCS' AND year = 2024
        """)
        mcap, pe = cursor.fetchone()
        
        conn.close()
        
        # Verify FCF Yield
        expected_yield = (fcf / mcap) * 100
        assert abs(tcs['FCF_yield_pct'] - expected_yield) < 0.01
        
        # Verify P/E
        assert tcs['P/E'] == pe


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
