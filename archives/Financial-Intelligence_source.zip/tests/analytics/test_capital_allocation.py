from pathlib import Path

import pandas as pd

from src.analytics.capital_allocation import build_capital_allocation, write_capital_allocation
from src.analytics.company_panel import PROJECT_ROOT, connect
from src.etl.normaliser import normalize_ticker
from src.etl.repair_cashflow_aliases import repair_aliased_cashflow_rows


def test_agtl_normalizes_to_atgl():
    assert normalize_ticker("AGTL") == "ATGL"


def test_atgl_cashflow_present_after_repair():
    repair_aliased_cashflow_rows()
    conn = connect()
    n = conn.execute(
        "SELECT COUNT(*) FROM cashflow WHERE company_id='ATGL' AND year GLOB '20*'"
    ).fetchone()[0]
    conn.close()
    assert n >= 7


def test_capital_allocation_includes_atgl_and_all_source_years():
    repair_aliased_cashflow_rows()
    df = build_capital_allocation()
    conn = connect()
    companies = {r[0] for r in conn.execute("SELECT id FROM companies")}
    src = pd.read_sql_query(
        "SELECT company_id, COUNT(*) n FROM cashflow WHERE year GLOB '20*' GROUP BY 1",
        conn,
    )
    conn.close()
    assert "ATGL" in set(df["company_id"])
    assert set(df["company_id"]) <= companies
    out_n = df.groupby("company_id").size()
    for _, row in src.iterrows():
        assert int(out_n.get(row["company_id"], 0)) == int(row["n"])


def test_write_capital_allocation_schema(tmp_path):
    repair_aliased_cashflow_rows()
    path = write_capital_allocation(tmp_path / "capital_allocation.csv")
    df = pd.read_csv(path)
    assert list(df.columns) == [
        "company_id",
        "year",
        "cfo_sign",
        "cfi_sign",
        "cff_sign",
        "pattern_label",
    ]
    assert len(df) >= 1056
