"""
Day 20: Peer Comparison Reporting Pipeline Tests

Comprehensive tests for peer comparison merge logic, validation, and output integrity.

Tests cover:
- Data loading
- Merge cardinality validation
- Duplicate key detection
- Orphaned record handling
- Output schema correctness
- No fabricated data
- Real data integration
"""

import pytest
import pandas as pd
import sqlite3
from pathlib import Path
from src.analytics.peer_comparison import PeerComparisonReporter


@pytest.fixture
def reporter():
    """Create reporter instance pointing to test database."""
    return PeerComparisonReporter(db_path='nifty100.db')


@pytest.fixture
def reporter_with_data(reporter):
    """Create reporter with loaded data."""
    reporter.connect()
    reporter.load_data()
    return reporter


class TestDataLoading:
    """Test data loading from database."""
    
    def test_connect_to_database(self, reporter):
        """Test database connection."""
        reporter.connect()
        assert reporter.conn is not None
        reporter.disconnect()
    
    def test_load_peer_percentiles(self, reporter_with_data):
        """Test peer_percentiles table loads."""
        assert reporter_with_data.peer_percentiles_df is not None
        assert len(reporter_with_data.peer_percentiles_df) > 0
        assert 'company_id' in reporter_with_data.peer_percentiles_df.columns
        assert 'peer_group_name' in reporter_with_data.peer_percentiles_df.columns
        assert 'metric_name' in reporter_with_data.peer_percentiles_df.columns
        assert 'percentile_rank' in reporter_with_data.peer_percentiles_df.columns
    
    def test_load_financial_ratios(self, reporter_with_data):
        """Test financial_ratios table loads."""
        assert reporter_with_data.financial_ratios_df is not None
        assert len(reporter_with_data.financial_ratios_df) > 0
        assert 'company_id' in reporter_with_data.financial_ratios_df.columns
        assert 'year' in reporter_with_data.financial_ratios_df.columns
    
    def test_load_companies(self, reporter_with_data):
        """Test companies reference data loads."""
        assert reporter_with_data.companies_df is not None
        assert len(reporter_with_data.companies_df) == 92  # Known from project
        assert 'company_id' in reporter_with_data.companies_df.columns
        assert 'company_name' in reporter_with_data.companies_df.columns
    
    def test_load_peer_groups(self, reporter_with_data):
        """Test peer_groups assignment data loads."""
        assert reporter_with_data.peer_groups_df is not None
        assert len(reporter_with_data.peer_groups_df) == 56  # Known from Day 18
        assert 'company_id' in reporter_with_data.peer_groups_df.columns
        assert 'peer_group_name' in reporter_with_data.peer_groups_df.columns


class TestMergeValidation:
    """Test merge cardinality and duplicate detection."""
    
    def test_peer_percentiles_grain_is_unique(self, reporter_with_data):
        """Test peer_percentiles has unique (company, peer_group, metric, year) keys."""
        df = reporter_with_data.peer_percentiles_df
        key_cols = ['company_id', 'peer_group_name', 'metric_name', 'year']
        is_unique, dups = reporter_with_data._check_duplicates(df, key_cols)
        assert is_unique, f"Found duplicates: {dups}"
    
    def test_merge_cardinality_validation(self, reporter_with_data):
        """Test merge cardinality checker."""
        left = pd.DataFrame({'a': [1, 2, 3], 'b': ['x', 'y', 'z']})
        right = pd.DataFrame({'a': [1, 2, 3], 'c': [10, 20, 30]})
        merged = left.merge(right, on='a', how='left')
        
        is_valid, msg = reporter_with_data._validate_merge_cardinality(
            left, right, merged, on=['a'], merge_type='left'
        )
        assert is_valid, f"Merge failed cardinality check: {msg}"
    
    def test_no_many_to_many_join(self, reporter_with_data):
        """Test that peer-to-financial merge doesn't cause explosion."""
        # Simulate the merge
        peer_sample = reporter_with_data.peer_percentiles_df.head(100).copy()
        fin_sample = reporter_with_data.financial_ratios_df.copy()
        
        before = len(peer_sample)
        merged = peer_sample.merge(fin_sample, on=['company_id', 'year'], how='left')
        after = len(merged)
        
        # For left merge, after should <= before * max_matches_per_key
        # Expected: 1 financial_ratios row per (company, year)
        assert after <= before * 2, f"Join explosion: {before} → {after}"


class TestPeerComparisonBuild:
    """Test peer comparison building."""
    
    def test_build_peer_comparison_returns_dataframe(self, reporter_with_data):
        """Test build_peer_comparison returns a DataFrame."""
        result = reporter_with_data.build_peer_comparison()
        assert isinstance(result, pd.DataFrame)
        assert len(result) > 0
    
    def test_output_schema_correct(self, reporter_with_data):
        """Test output has expected columns."""
        result = reporter_with_data.build_peer_comparison()
        
        expected_cols = [
            'company_id', 'company_name', 'peer_group_name', 'metric_name',
            'metric_value', 'percentile_rank', 'kpi_value', 'year'
        ]
        
        for col in expected_cols:
            assert col in result.columns, f"Missing column: {col}"
    
    def test_output_row_count_reasonable(self, reporter_with_data):
        """Test output row count is within expected range."""
        result = reporter_with_data.build_peer_comparison()
        
        # Expected: peer_percentiles rows (6,658)
        # Some may have NULL KPI values (orphaned)
        assert len(result) >= 6000, f"Too few rows: {len(result)}"
        assert len(result) <= 7000, f"Too many rows: {len(result)}"
    
    def test_no_duplicate_keys_in_output(self, reporter_with_data):
        """Test output has no duplicate comparison keys."""
        result = reporter_with_data.build_peer_comparison()
        
        key_cols = ['company_id', 'peer_group_name', 'metric_name', 'year']
        is_unique, dups = reporter_with_data._check_duplicates(result, key_cols)
        
        assert is_unique, f"Found {len(dups)} duplicate keys"
    
    def test_no_nulls_in_critical_columns(self, reporter_with_data):
        """Test critical columns have no NULLs."""
        result = reporter_with_data.build_peer_comparison()
        
        critical_cols = ['company_id', 'peer_group_name', 'metric_name', 'year']
        
        for col in critical_cols:
            null_count = result[col].isna().sum()
            assert null_count == 0, f"{col} has {null_count} nulls"
    
    def test_percentile_rank_in_valid_range(self, reporter_with_data):
        """Test percentile_rank values are in [0, 1] or NULL."""
        result = reporter_with_data.build_peer_comparison()
        
        valid_mask = (
            result['percentile_rank'].isna() |
            ((result['percentile_rank'] >= 0.0) & (result['percentile_rank'] <= 1.0))
        )
        
        assert valid_mask.all(), "Some percentile_rank values outside [0, 1]"
    
    def test_all_metrics_mapped(self, reporter_with_data):
        """Test all peer_percentiles metrics are present in output."""
        result = reporter_with_data.build_peer_comparison()
        
        input_metrics = set(reporter_with_data.peer_percentiles_df['metric_name'].unique())
        output_metrics = set(result['metric_name'].unique())
        
        assert input_metrics == output_metrics, f"Metrics mismatch: {input_metrics - output_metrics}"


class TestOrphanedRecords:
    """Test handling of orphaned/unmatched records."""
    
    def test_orphaned_metrics_identified(self, reporter_with_data):
        """Test orphaned metrics (no KPI value) are identified."""
        result = reporter_with_data.build_peer_comparison()
        
        orphaned = result[result['kpi_value'].isna()]
        validation = reporter_with_data.get_validation_report()
        
        assert validation['orphaned_records'] == len(orphaned)
    
    def test_mostly_matched_records(self, reporter_with_data):
        """Test majority of peer metrics have matching KPI values."""
        result = reporter_with_data.build_peer_comparison()

        cagr_metrics = {"PAT_CAGR_5yr", "Revenue_CAGR_5yr", "EPS_CAGR_5yr"}
        non_cagr = result[~result["metric_name"].isin(cagr_metrics)]
        non_cagr_rate = non_cagr["kpi_value"].notna().mean() if len(non_cagr) else 0
        assert non_cagr_rate > 0.9, f"Non-CAGR match rate {non_cagr_rate*100:.1f}%"

        # 5-year CAGRs are null when the exact start fiscal year is missing or
        # the window is a sign-change edge case (not a join failure).
        matched = result[result["kpi_value"].notna()]
        match_rate = len(matched) / len(result) if len(result) > 0 else 0
        assert match_rate > 0.8, f"Only {match_rate*100:.1f}% records matched to KPI"


class TestCompanyPeerSummary:
    """Test company-level peer comparison queries."""
    
    def test_get_company_peer_summary(self, reporter_with_data):
        """Test get_company_peer_summary returns data for specific company."""
        reporter_with_data.build_peer_comparison()
        
        # Pick a known company from peer_groups
        summary = reporter_with_data.get_company_peer_summary('TCS')
        
        assert len(summary) > 0, "No data for TCS"
        assert all(summary['company_id'] == 'TCS')
    
    def test_company_summary_sorted_by_year(self, reporter_with_data):
        """Test company summary is sorted by year."""
        reporter_with_data.build_peer_comparison()
        
        summary = reporter_with_data.get_company_peer_summary('HDFCBANK')
        years = summary['year'].tolist()
        
        # Check years are in ascending order
        assert years == sorted(years), "Years not in sorted order"


class TestValidationReport:
    """Test validation report generation."""
    
    def test_validation_report_exists(self, reporter_with_data):
        """Test validation report is generated."""
        reporter_with_data.build_peer_comparison()
        report = reporter_with_data.get_validation_report()
        
        assert isinstance(report, dict)
        assert len(report) > 0
    
    def test_validation_report_has_key_metrics(self, reporter_with_data):
        """Test validation report contains key metrics."""
        reporter_with_data.build_peer_comparison()
        report = reporter_with_data.get_validation_report()
        
        expected_keys = [
            'peer_percentiles_unique',
            'merge_cardinality_valid',
            'output_unique',
            'output_rows',
            'orphaned_records',
        ]
        
        for key in expected_keys:
            assert key in report, f"Missing validation key: {key}"


class TestNoFabrication:
    """Test that no fabricated data is introduced."""
    
    def test_kpi_values_come_from_database(self, reporter_with_data):
        """Test all KPI values come from financial_ratios, not fabricated."""
        result = reporter_with_data.build_peer_comparison()
        
        # Sample a row with KPI value
        sample = result[result['kpi_value'].notna()].iloc[0]
        
        # Verify it exists in financial_ratios
        fin_match = reporter_with_data.financial_ratios_df[
            (reporter_with_data.financial_ratios_df['company_id'] == sample['company_id']) &
            (reporter_with_data.financial_ratios_df['year'] == sample['year'])
        ]
        
        assert len(fin_match) > 0, "KPI value not found in source data"
    
    def test_peer_group_from_peer_groups_table(self, reporter_with_data):
        """Test peer_group assignments come from peer_groups table."""
        result = reporter_with_data.build_peer_comparison()
        
        # Verify all peer_group_name values exist in peer_groups table
        peer_names_in_result = set(result['peer_group_name'].unique())
        peer_names_in_table = set(reporter_with_data.peer_groups_df['peer_group_name'].unique())
        
        assert peer_names_in_result.issubset(peer_names_in_table), \
            f"Unknown peer groups: {peer_names_in_result - peer_names_in_table}"
    
    def test_company_ids_match_companies_table(self, reporter_with_data):
        """Test company IDs are valid (from companies table)."""
        result = reporter_with_data.build_peer_comparison()
        
        result_companies = set(result['company_id'].unique())
        valid_companies = set(reporter_with_data.companies_df['company_id'].unique())
        
        # All companies in result should be valid
        invalid = result_companies - valid_companies
        assert len(invalid) == 0, f"Invalid company IDs: {invalid}"


class TestEdgeCases:
    """Test edge cases and boundary conditions."""
    
    def test_handle_null_kpi_values_gracefully(self, reporter_with_data):
        """Test NULL KPI values are preserved (not fabricated)."""
        result = reporter_with_data.build_peer_comparison()
        
        # Some rows may have NULL kpi_value (orphaned metrics)
        orphaned = result[result['kpi_value'].isna()]
        
        # These should NOT be replaced with defaults
        for _, row in orphaned.iterrows():
            assert pd.isna(row['kpi_value']), "Null values were replaced"
    
    def test_handle_companies_without_peer_assignment(self, reporter_with_data):
        """Test companies without peer assignment are not in output."""
        result = reporter_with_data.build_peer_comparison()
        
        # peer_percentiles only includes companies IN peer_groups (56 companies)
        result_companies = set(result['company_id'].unique())
        peer_companies = set(reporter_with_data.peer_groups_df['company_id'].unique())
        
        # All result companies should be in peer_groups
        assert result_companies.issubset(peer_companies), \
            "Result contains companies without peer assignment"
    
    def test_handle_historical_vs_ttm_years(self, reporter_with_data):
        """Test both historical years and TTM (9999-12) are present."""
        result = reporter_with_data.build_peer_comparison()
        
        years = set(result['year'].unique())
        
        # Should have both historical and TTM
        assert '9999-12' in years, "Missing TTM year"
        assert any(year != '9999-12' for year in years), "Missing historical years"
    
    def test_consistent_metric_values_across_years(self, reporter_with_data):
        """Test metric values match percentile_rank interpretation."""
        result = reporter_with_data.build_peer_comparison()
        
        # For a company-metric-peer group, verify metric_value is consistent
        sample = result[result['metric_name'] == 'ROE'].iloc[0]
        
        # metric_value should be non-null or match metric from peer_percentiles
        assert sample['metric_value'] is not None or sample['kpi_value'] is not None


class TestRealDataIntegration:
    """Test end-to-end integration with real project data."""
    
    def test_end_to_end_pipeline(self, reporter):
        """Test complete pipeline from database to output."""
        reporter.connect()
        reporter.load_data()
        result = reporter.build_peer_comparison()
        
        assert result is not None
        assert len(result) > 0
        assert result['company_id'].nunique() > 0
        
        reporter.disconnect()
    
    def test_save_to_csv(self, reporter_with_data, tmp_path):
        """Test saving output to CSV."""
        reporter_with_data.build_peer_comparison()
        
        output_path = str(tmp_path / 'peer_comparison.csv')
        saved_path = reporter_with_data.save_to_csv(output_path)
        
        assert Path(saved_path).exists()
        
        # Verify CSV is readable
        df = pd.read_csv(saved_path)
        assert len(df) > 0
