"""
Day 29 NLP Parser Tests
=======================

Comprehensive tests for analysis text parsing covering:
- Multiple period formats
- Spacing variations
- Negative values
- Decimal percentages
- TTM/Last Year formats
- Error handling
- Cross-validation
"""

import pytest
import sys
import os
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent.parent.parent / 'src'))

from nlp.parser import AnalysisParser, ParseResult, parse_analysis_dataframe


class TestParseBasicFormats:
    """Test parsing of basic standard formats"""
    
    def test_numeric_years_format(self):
        """Parse '10 Years: 21%' format"""
        result = AnalysisParser.parse_period_value("10 Years: 21%")
        assert result.is_valid
        assert result.period_years == 10
        assert result.value_pct == 21.0
        assert result.period == "10 Years"
    
    def test_numeric_years_no_colon(self):
        """Parse '10 Years 21%' format (no colon)"""
        result = AnalysisParser.parse_period_value("10 Years 21%")
        assert result.is_valid
        assert result.period_years == 10
        assert result.value_pct == 21.0
    
    def test_five_year_format(self):
        """Parse '5 Years: 24%' format"""
        result = AnalysisParser.parse_period_value("5 Years: 24%")
        assert result.is_valid
        assert result.period_years == 5
        assert result.value_pct == 24.0
    
    def test_three_year_format(self):
        """Parse '3 Years: 17%' format"""
        result = AnalysisParser.parse_period_value("3 Years: 17%")
        assert result.is_valid
        assert result.period_years == 3
        assert result.value_pct == 17.0


class TestParseSpecialFormats:
    """Test parsing of special period formats"""
    
    def test_ttm_format(self):
        """Parse 'TTM: 43%' format"""
        result = AnalysisParser.parse_period_value("TTM: 43%")
        assert result.is_valid
        assert result.period == "TTM"
        assert result.value_pct == 43.0
        assert result.period_years is None
    
    def test_ttm_no_colon(self):
        """Parse 'TTM 43%' format (no colon)"""
        result = AnalysisParser.parse_period_value("TTM 43%")
        assert result.is_valid
        assert result.period == "TTM"
        assert result.value_pct == 43.0
    
    def test_last_year_format(self):
        """Parse 'Last Year: 12%' format"""
        result = AnalysisParser.parse_period_value("Last Year: 12%")
        assert result.is_valid
        assert result.period == "Last Year"
        assert result.value_pct == 12.0
    
    def test_singular_year_format(self):
        """Parse '1 Year: -2%' format"""
        result = AnalysisParser.parse_period_value("1 Year: -2%")
        assert result.is_valid
        assert result.period_years == 1
        assert result.value_pct == -2.0


class TestParseSpacing:
    """Test handling of whitespace variations"""
    
    def test_extra_spaces_before_period(self):
        """Parse '     10 Years: 21%' format"""
        result = AnalysisParser.parse_period_value("     10 Years: 21%")
        assert result.is_valid
        assert result.value_pct == 21.0
    
    def test_extra_spaces_after_colon(self):
        """Parse '10 Years:       21%' format"""
        result = AnalysisParser.parse_period_value("10 Years:       21%")
        assert result.is_valid
        assert result.value_pct == 21.0
    
    def test_multiple_spaces_between_year_and_number(self):
        """Parse '10  Years: 21%' format"""
        result = AnalysisParser.parse_period_value("10  Years: 21%")
        assert result.is_valid
        assert result.period_years == 10


class TestParseNumericVariations:
    """Test parsing of numeric value variations"""
    
    def test_negative_percentage(self):
        """Parse '-2%' format"""
        result = AnalysisParser.parse_period_value("1 Year: -2%")
        assert result.is_valid
        assert result.value_pct == -2.0
    
    def test_positive_signed_percentage(self):
        """Parse '+21%' format"""
        result = AnalysisParser.parse_period_value("10 Years: +21%")
        assert result.is_valid
        assert result.value_pct == 21.0
    
    def test_decimal_percentage(self):
        """Parse decimal percentage like '12.5%'"""
        result = AnalysisParser.parse_period_value("5 Years: 12.5%")
        assert result.is_valid
        assert result.value_pct == 12.5
    
    def test_very_negative_percentage(self):
        """Parse '-47%' format"""
        result = AnalysisParser.parse_period_value("TTM: -47%")
        assert result.is_valid
        assert result.value_pct == -47.0


class TestParseErrors:
    """Test error handling for invalid inputs"""
    
    def test_null_input(self):
        """Handle None input"""
        result = AnalysisParser.parse_period_value(None)
        assert not result.is_valid
        assert result.failure_reason == 'Null or empty input'
    
    def test_empty_string(self):
        """Handle empty string"""
        result = AnalysisParser.parse_period_value("")
        assert not result.is_valid
    
    def test_whitespace_only(self):
        """Handle whitespace-only input"""
        result = AnalysisParser.parse_period_value("   ")
        assert not result.is_valid
    
    def test_invalid_format(self):
        """Handle completely invalid format"""
        result = AnalysisParser.parse_period_value("foobar xyz 123")
        assert not result.is_valid
        assert result.failure_reason is not None
    
    def test_no_percentage_sign(self):
        """Handle missing % sign"""
        result = AnalysisParser.parse_period_value("10 Years: 21")
        assert result.is_valid  # Should still parse
        assert result.value_pct == 21.0


class TestOutputSchema:
    """Test parse result schema"""
    
    def test_parse_result_to_dict(self):
        """Verify ParseResult converts to dict correctly"""
        result = AnalysisParser.parse_period_value("10 Years: 21%")
        result_dict = result.to_dict()
        
        assert 'period' in result_dict
        assert 'period_years' in result_dict
        assert 'value_pct' in result_dict
        assert 'is_valid' in result_dict
        assert 'failure_reason' in result_dict
    
    def test_successful_parse_schema(self):
        """Verify successful parse has correct schema"""
        result = AnalysisParser.parse_period_value("5 Years: 12%")
        assert result.is_valid is True
        assert result.failure_reason is None
        assert result.value_pct == 12.0
        assert result.period == "5 Years"


class TestDataFrameParsing:
    """Test parsing full DataFrame"""
    
    def test_parse_analysis_row(self):
        """Parse a complete row with all 4 fields"""
        row_dict = {
            'id': 1,
            'company_id': 'TCS',
            'compounded_sales_growth': '10 Years: 11%',
            'compounded_profit_growth': '10 Years: 9%',
            'stock_price_cagr': '10 Years: 14%',
            'roe': '10 Years: 40%',
        }
        
        parsed = AnalysisParser.parse_analysis_row(row_dict)
        
        assert parsed['id'] == 1
        assert parsed['company_id'] == 'TCS'
        assert len(parsed['fields']) == 4
        assert len(parsed['failures']) == 0
        
        # Check each field
        for field_name, field_result in parsed['fields'].items():
            assert field_result['is_valid'] is True
            assert field_result['value_pct'] is not None
    
    def test_parse_row_with_failures(self):
        """Parse row with invalid field"""
        row_dict = {
            'id': 1,
            'company_id': 'TCS',
            'compounded_sales_growth': '10 Years: 11%',
            'compounded_profit_growth': 'invalid text here',
            'stock_price_cagr': '10 Years: 14%',
            'roe': '10 Years: 40%',
        }
        
        parsed = AnalysisParser.parse_analysis_row(row_dict)
        
        assert len(parsed['failures']) == 1
        assert parsed['failures'][0]['field'] == 'compounded_profit_growth'


class TestRealData:
    """Test against real analysis.xlsx data"""
    
    def test_parse_hdfcbank_row(self):
        """Parse real HDFCBANK row"""
        result = AnalysisParser.parse_period_value("10 Years: 21%")
        assert result.is_valid
        assert result.value_pct == 21.0
    
    def test_parse_ttm_with_spaces(self):
        """Parse real TTM row with extra spaces"""
        result = AnalysisParser.parse_period_value("TTM:            43%")
        assert result.is_valid
        assert result.value_pct == 43.0
    
    def test_parse_last_year_format(self):
        """Parse real Last Year format"""
        result = AnalysisParser.parse_period_value("Last Year:      12%")
        assert result.is_valid
        assert result.value_pct == 12.0


class TestDuplicatePrevention:
    """Test prevention of duplicate logical records"""
    
    def test_same_value_twice(self):
        """Verify two parses of same value don't create duplicates"""
        result1 = AnalysisParser.parse_period_value("10 Years: 21%")
        result2 = AnalysisParser.parse_period_value("10 Years: 21%")
        
        assert result1.to_dict() == result2.to_dict()


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
