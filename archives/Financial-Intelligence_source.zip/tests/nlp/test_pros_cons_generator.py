"""Day 30 auto pros/cons generator tests."""

from pathlib import Path

import pandas as pd
import pytest

from src.nlp.pros_cons_generator import (
    CON_TEXT,
    PRO_TEXT,
    coverage_report,
    evaluate_cons,
    evaluate_pros,
    generate_pros_cons,
)
from src.analytics.company_panel import connect

PROJECT_ROOT = Path(__file__).resolve().parents[2]


def test_twelve_pro_and_con_rules_defined():
    assert list(PRO_TEXT.keys()) == list(range(1, 13))
    assert list(CON_TEXT.keys()) == list(range(1, 13))


def test_generate_uses_real_company_ids_only():
    df = generate_pros_cons()
    conn = connect()
    valid = {row[0] for row in conn.execute("SELECT id FROM companies")}
    conn.close()
    assert not df.empty
    extra = set(df["company_id"]) - valid
    assert extra == set()


def test_output_schema_and_confidence_floor():
    df = generate_pros_cons()
    assert list(df.columns) == ["company_id", "type", "rule_id", "text", "confidence_pct"]
    assert set(df["type"].unique()) <= {"pro", "con"}
    assert (df["confidence_pct"] > 60).all()
    assert df["rule_id"].str.match(r"^(pro|con)_\d{2}$").all()


def test_non_financial_high_de_rule_exists_in_logic():
    """Con 1 must not apply to Financials; text includes actual D/E."""
    from src.nlp.pros_cons_generator import CompanyContext

    ratios = pd.DataFrame(
        {
            "company_id": ["X"],
            "year": ["2024-03"],
            "debt_to_equity": [3.5],
            "return_on_equity_pct": [12.0],
            "free_cash_flow_cr": [100.0],
            "operating_profit_margin_pct": [10.0],
            "interest_coverage": [4.0],
            "dividend_payout_ratio_pct": [20.0],
            "revenue_cagr_5yr": [8.0],
            "pat_cagr_5yr": [6.0],
            "eps_cagr_5yr": [5.0],
        }
    )
    empty = pd.DataFrame()
    ctx_fin = CompanyContext("X", "Financials", ratios, empty, empty, empty, None, 15.0)
    ctx_ind = CompanyContext("X", "Industrials", ratios, empty, empty, empty, None, 15.0)
    fin_cons = [r["rule_id"] for r in evaluate_cons(ctx_fin)]
    ind_cons = [r["rule_id"] for r in evaluate_cons(ctx_ind)]
    assert "con_01" not in fin_cons
    assert "con_01" in ind_cons
    text = next(r["text"] for r in evaluate_cons(ctx_ind) if r["rule_id"] == "con_01")
    assert "3.50" in text


def test_debt_free_pro_rule():
    ratios = pd.DataFrame(
        {
            "company_id": ["Y"],
            "year": ["2024-03"],
            "debt_to_equity": [0.0],
            "return_on_equity_pct": [10.0],
            "free_cash_flow_cr": [1.0],
            "operating_profit_margin_pct": [10.0],
            "interest_coverage": [None],
            "dividend_payout_ratio_pct": [10.0],
            "revenue_cagr_5yr": [8.0],
            "pat_cagr_5yr": [6.0],
            "eps_cagr_5yr": [5.0],
        }
    )
    from src.nlp.pros_cons_generator import CompanyContext

    ctx = CompanyContext("Y", "IT", ratios, pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), None, 12.0)
    ids = [r["rule_id"] for r in evaluate_pros(ctx)]
    assert "pro_03" in ids
    assert "pro_07" in ids


def test_interest_zero_is_debt_free_for_pro_07_not_pro_03():
    from src.nlp.pros_cons_generator import CompanyContext

    ratios = pd.DataFrame(
        {
            "company_id": ["Z"],
            "year": ["2024-03"],
            "debt_to_equity": [0.4],
            "return_on_equity_pct": [10.0],
            "free_cash_flow_cr": [1.0],
            "operating_profit_margin_pct": [10.0],
            "interest_coverage": [None],
            "dividend_payout_ratio_pct": [10.0],
            "revenue_cagr_5yr": [8.0],
            "pat_cagr_5yr": [6.0],
            "eps_cagr_5yr": [5.0],
        }
    )
    pl = pd.DataFrame({"company_id": ["Z"], "year": ["2024-03"], "interest": [0.0], "sales": [100.0], "net_profit": [10.0]})
    ctx = CompanyContext("Z", "IT", ratios, pl, pd.DataFrame(), pd.DataFrame(), None, 12.0)
    ids = [r["rule_id"] for r in evaluate_pros(ctx)]
    assert "pro_07" in ids
    assert "pro_03" not in ids


def test_written_csv_matches_generator():
    df = generate_pros_cons()
    out = PROJECT_ROOT / "output" / "pros_cons_generated.csv"
    if out.exists():
        written = pd.read_csv(out)
        assert list(written.columns) == list(df.columns)
