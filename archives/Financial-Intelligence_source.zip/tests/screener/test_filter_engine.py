"""
Unit tests for FilterEngine (Day 15).

Tests:
1. Load base data correctly
2. Apply ROE min filter
3. Apply D/E max filter with Financials exclusion
4. Apply ICR min with Debt Free handling
5. Apply combination of filters
6. Verify year-matching logic
"""

import pytest
import pandas as pd
from src.screener.engine import FilterEngine


class TestFilterEngine:
    """FilterEngine tests."""
    
    @pytest.fixture
    def engine(self):
        """Create FilterEngine instance."""
        eng = FilterEngine("nifty100.db")
        yield eng
        eng.close()
    
    def test_load_base_data(self, engine):
        """Test base data loading."""
        df = engine._load_base_data()
        
        assert not df.empty, "Base data should not be empty"
        assert len(df) == 92, f"Expected 92 companies, got {len(df)}"
        
        # Check required columns exist
        required_cols = [
            'company_id', 'company_name',
            'return_on_equity_pct', 'debt_to_equity', 'free_cash_flow_cr',
            'revenue_cagr_5yr', 'pat_cagr_5yr', 'operating_profit_margin_pct',
            'pe_ratio', 'pb_ratio', 'dividend_yield_pct', 'market_cap_crore',
            'interest_coverage', 'eps_cagr_5yr', 'asset_turnover',
            'net_profit', 'sales'
        ]
        for col in required_cols:
            assert col in df.columns, f"Missing column: {col}"
    
    def test_roe_min_filter(self, engine):
        """Test ROE min filter."""
        result = engine.apply_filters({'roe_min': 15.0})
        
        assert not result.empty, "ROE > 15% should match at least 1 company"
        
        # Verify all returned companies have ROE >= 15%
        valid_roe = result['return_on_equity_pct'].dropna()
        assert all(valid_roe >= 15.0), "Some companies have ROE < 15%"
    
    def test_de_max_filter_excludes_financials(self, engine):
        """Test D/E max filter excludes Financial Services companies."""
        # Get all companies to establish baseline
        all_df = engine._load_base_data()
        
        # Get Financial Services companies
        import sqlite3
        cursor = engine.conn.cursor()
        cursor.execute("""
            SELECT company_id FROM sectors
            WHERE broad_sector = 'Financial Services'
        """)
        financials = {row[0] for row in cursor.fetchall()}
        
        # Apply D/E filter
        result = engine.apply_filters({'de_max': 1.0})
        
        # Verify no Financial Services companies in result
        financials_in_result = result[result['company_id'].isin(financials)]
        assert financials_in_result.empty, \
            f"D/E filter should exclude Financial Services, but found: {financials_in_result['company_name'].tolist()}"
    
    def test_icr_min_debt_free_handling(self, engine):
        """Test ICR min filter passes debt-free companies."""
        result = engine.apply_filters({'icr_min': 5.0})
        
        # Some companies should have passed despite potentially low ICR
        # because they are debt-free
        debt_free_mask = result['debt_to_equity'] == 0
        debt_free_in_result = result[debt_free_mask]
        
        # At least check that filtering doesn't error out
        assert isinstance(result, pd.DataFrame), "Result should be DataFrame"
    
    def test_fcf_min_filter(self, engine):
        """Test FCF min filter."""
        result = engine.apply_filters({'fcf_min': 100.0})
        
        assert not result.empty, "FCF > 100 Cr should match at least 1 company"
        
        # Verify all returned companies have FCF >= 100
        valid_fcf = result['free_cash_flow_cr'].dropna()
        assert all(valid_fcf >= 100.0), "Some companies have FCF < 100"
    
    def test_combined_filters_quality_compounder(self, engine):
        """Test combined filters (Quality Compounder preset)."""
        filters = {
            'roe_min': 15.0,
            'de_max': 1.0,
            'fcf_min': 0,
            'revenue_cagr_5yr_min': 10.0
        }
        
        result = engine.apply_filters(filters)
        
        # Should return 1-50 companies for reasonable preset
        assert 0 < len(result) <= 50, \
            f"Quality Compounder should return 1-50 companies, got {len(result)}"
        
        # Verify all filters applied
        assert all(result['return_on_equity_pct'] >= 15.0), "ROE filter failed"
        assert all(result['free_cash_flow_cr'] >= 0), "FCF filter failed"
        assert all(result['revenue_cagr_5yr'] >= 10.0), "Revenue CAGR filter failed"
    
    def test_invalid_filter_raises_error(self, engine):
        """Test invalid filter key raises ValueError."""
        with pytest.raises(ValueError):
            engine.apply_filters({'invalid_metric': 10.0})
    
    def test_filter_with_none_values(self, engine):
        """Test filters handle None (skip) correctly."""
        filters = {
            'roe_min': 15.0,
            'de_max': None,  # Skip this filter
            'fcf_min': 0
        }
        
        result = engine.apply_filters(filters)
        
        # Should complete without error
        assert isinstance(result, pd.DataFrame)
    
    def test_result_sorting(self, engine):
        """Test result is sorted by composite score if available."""
        result = engine.apply_filters({})
        
        # Should be sorted (by name if no composite score)
        assert not result.empty, "Result should not be empty"
        # Just verify sorting doesn't error


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
