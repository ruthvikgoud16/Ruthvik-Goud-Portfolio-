"""Day 41 — DQ rule unit tests (crafted violations)."""

from unittest.mock import patch

import pandas as pd

from src.etl.validator import (
    DQ01_NonNullSalesPositive,
    DQ02_BSBalance,
    DQ03_FKIntegrity,
    DQ04_OperatingCFPositive,
    DQ05_EBITCalculation,
    DQ06_SalesNonZero,
    DQ07_EquityPositive,
    DQ08_BorrowingsNonNegative,
    DQ09_YearFormatValid,
    DQ10_FixedAssetsNonNegative,
    DQ11_TaxRateValid,
    DQ12_DividendPayoutValid,
    DQ13_URLValidation,
    DQ14_EPSSignMatch,
    DQ15_BSBalanceCounter,
    DQ16_CoverageCheck,
)


def _ids(df):
    return set(df["rule_id"].unique()) if not df.empty else set()


def test_dq01_null_sales():
    df = pd.DataFrame({"id": [1], "sales": [None]})
    out = DQ01_NonNullSalesPositive().validate(df, table_name="profitandloss")
    assert _ids(out) == {"DQ-01"}
    assert out.iloc[0]["severity"] == "CRITICAL"


def test_dq02_imbalance():
    df = pd.DataFrame({"id": [1], "total_assets": [100.0], "total_liabilities": [10.0], "equity": [10.0]})
    out = DQ02_BSBalance().validate(df)
    assert _ids(out) == {"DQ-02"}
    assert out.iloc[0]["severity"] == "WARNING"


def test_dq03_fk():
    df = pd.DataFrame({"id": [1], "company_id": ["NOTAREAL"]})
    out = DQ03_FKIntegrity().validate(df, valid_company_ids={"TCS"}, table_name="pl")
    assert _ids(out) == {"DQ-03"}
    assert out.iloc[0]["severity"] == "CRITICAL"


def test_dq04_negative_cfo():
    df = pd.DataFrame({"id": [1], "cash_from_operations": [-5.0]})
    out = DQ04_OperatingCFPositive().validate(df)
    assert _ids(out) == {"DQ-04"}


def test_dq05_placeholder_schema():
    df = pd.DataFrame({"id": [1], "operating_profit": [10.0]})
    rule = DQ05_EBITCalculation()
    out = rule.validate(df)
    assert rule.rule_id == "DQ-05"
    assert out.empty  # dataset has no separate EBIT column


def test_dq06_zero_sales():
    df = pd.DataFrame({"id": [1], "sales": [0.0]})
    out = DQ06_SalesNonZero().validate(df, table_name="profitandloss")
    assert _ids(out) == {"DQ-06"}
    assert out.iloc[0]["severity"] == "CRITICAL"


def test_dq07_negative_equity():
    df = pd.DataFrame({"id": [1], "equity": [-1.0]})
    out = DQ07_EquityPositive().validate(df)
    assert _ids(out) == {"DQ-07"}


def test_dq08_negative_borrowings():
    df = pd.DataFrame({"id": [1], "borrowings": [-2.0]})
    out = DQ08_BorrowingsNonNegative().validate(df)
    assert _ids(out) == {"DQ-08"}


def test_dq09_bad_year():
    df = pd.DataFrame({"id": [1], "year": ["not-a-year"]})
    out = DQ09_YearFormatValid().validate(df, table_name="profitandloss")
    assert "DQ-09" in _ids(out)


def test_dq10_negative_fixed_assets():
    df = pd.DataFrame({"id": [1], "fixed_assets": [-3.0]})
    out = DQ10_FixedAssetsNonNegative().validate(df)
    assert _ids(out) == {"DQ-10"}


def test_dq11_tax_out_of_range():
    df = pd.DataFrame({"id": [1], "tax_percentage": [90.0]})
    out = DQ11_TaxRateValid().validate(df)
    assert _ids(out) == {"DQ-11"}


def test_dq12_payout():
    df = pd.DataFrame({"id": [1], "dividend_payout": [250.0]})
    out = DQ12_DividendPayoutValid().validate(df)
    assert _ids(out) == {"DQ-12"}


def test_dq13_url(monkeypatch):
    df = pd.DataFrame({"id": [1], "url": ["http://example.invalid/x"]})

    class Fake:
        status_code = 404

    with patch("src.etl.validator.requests.head", return_value=Fake()):
        out = DQ13_URLValidation().validate(df, url_validation_enabled=True)
    assert _ids(out) == {"DQ-13"}


def test_dq14_eps_sign():
    df = pd.DataFrame({"id": [1], "eps": [1.0], "net_profit": [-10.0]})
    out = DQ14_EPSSignMatch().validate(df)
    assert _ids(out) == {"DQ-14"}


def test_dq15_counter_does_not_crash():
    rule = DQ15_BSBalanceCounter()
    out = rule.validate(pd.DataFrame({"total_assets": [1]}))
    assert rule.rule_id == "DQ-15"
    assert out.empty


def test_dq16_short_history():
    df = pd.DataFrame({"company_id": ["X", "X"], "year": ["2023-03", "2024-03"]})
    out = DQ16_CoverageCheck().validate(df)
    assert _ids(out) == {"DQ-16"}
