"""
Day 25 Tests: Trends, Sectors, Capital Allocation, Annual Reports Screens
Tests for trend analysis, sector bubble charts, capital allocation treemap,
and annual report access functionality.
"""

import pytest
import pandas as pd
from unittest.mock import Mock, patch
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.dashboard.utils import db


class TestTrendAnalysis:
    """Tests for Trend Analysis screen functionality."""
    
    def test_get_trend_data_returns_dataframe(self):
        """Test that get_trend_data returns a DataFrame."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            metrics = ['Revenue', 'ROE %']
            result = db.get_trend_data(ticker, metrics)
            assert isinstance(result, pd.DataFrame)
    
    def test_get_available_trend_metrics_returns_list(self):
        """Test that available metrics returns a list."""
        metrics = db.get_available_trend_metrics()
        assert isinstance(metrics, list)
        assert len(metrics) > 0
    
    def test_trend_metrics_include_revenue_and_roe(self):
        """Test that key metrics are available."""
        metrics = db.get_available_trend_metrics()
        assert 'Revenue' in metrics
        assert 'ROE %' in metrics
    
    def test_trend_data_max_10_years(self):
        """Test that trend data respects 10-year limit."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_trend_data(ticker, ['Revenue'])
            # Should return at most 10 years (query already limits in page logic)
            assert len(result) <= 13  # db function returns all, page limits to 10
    
    def test_trend_data_year_column_present(self):
        """Test that trend data includes year column."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_trend_data(ticker, ['Revenue'])
            if not result.empty:
                assert 'year' in result.columns
    
    def test_trend_data_sorted_descending(self):
        """Test that trend data is sorted by year descending."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_trend_data(ticker, ['Revenue'])
            if len(result) > 1:
                years = result['year'].tolist()
                assert years == sorted(years, reverse=True)
    
    def test_trend_data_invalid_ticker(self):
        """Test trend data with invalid ticker returns empty."""
        result = db.get_trend_data('INVALIDXYZ', ['Revenue'])
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    def test_multiple_metrics_selection(self):
        """Test that multiple metrics can be requested."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            metrics = ['Revenue', 'Net Profit', 'ROE %']
            result = db.get_trend_data(ticker, metrics)
            if not result.empty:
                for metric in metrics:
                    if metric in result.columns:
                        assert result[metric].dtype in [float, int, object]


class TestSectorAnalysis:
    """Tests for Sector Analysis screen functionality."""
    
    def test_get_all_sectors_returns_list(self):
        """Test that get_all_sectors returns a list."""
        sectors = db.get_all_sectors()
        assert isinstance(sectors, list)
    
    def test_sectors_count(self):
        """Test that we have expected number of sectors."""
        sectors = db.get_all_sectors()
        assert len(sectors) >= 5  # At least 5 broad sectors
    
    def test_get_sector_companies_returns_dataframe(self):
        """Test that get_sector_companies returns DataFrame."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_companies(sectors[0])
            assert isinstance(result, pd.DataFrame)
    
    def test_sector_companies_have_required_columns(self):
        """Test that sector data has required columns."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_companies(sectors[0])
            if not result.empty:
                required = ['company_id', 'company_name', 'revenue', 'roe']
                for col in required:
                    assert col in result.columns
    
    def test_sector_companies_include_market_cap(self):
        """Test that sector data includes market cap."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_companies(sectors[0])
            if not result.empty:
                assert 'market_cap_crore' in result.columns
    
    def test_sector_companies_include_subsector(self):
        """Test that sector data includes sub-sector."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_companies(sectors[0])
            if not result.empty:
                assert 'sub_sector' in result.columns
    
    def test_get_sector_medians_returns_dict(self):
        """Test that get_sector_medians returns dict."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_medians(sectors[0])
            assert isinstance(result, dict)
    
    def test_sector_medians_include_roe(self):
        """Test that sector medians include ROE."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_medians(sectors[0])
            if result:
                assert 'ROE %' in result
    
    def test_sector_medians_numeric_values(self):
        """Test that sector medians are numeric."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_medians(sectors[0])
            for key, value in result.items():
                if value is not None:
                    assert isinstance(value, (int, float))
    
    def test_invalid_sector_returns_empty(self):
        """Test that invalid sector returns empty results."""
        result = db.get_sector_companies('INVALID_SECTOR_XYZ')
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0


class TestCapitalAllocation:
    """Tests for Capital Allocation screen functionality."""
    
    def test_get_capital_allocation_data_returns_dataframe(self):
        """Test that capital allocation data returns DataFrame."""
        result = db.get_capital_allocation_data()
        assert isinstance(result, pd.DataFrame)
    
    def test_capital_allocation_has_required_columns(self):
        """Test that capital data has required columns."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            required = ['company_id', 'company_name', 'pattern_label', 'size_metric']
            for col in required:
                assert col in result.columns
    
    def test_capital_allocation_patterns_exist(self):
        """Test that capital allocation patterns are identified."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            patterns = result['pattern_label'].unique()
            assert len(patterns) > 0
    
    def test_capital_allocation_pattern_counts(self):
        """Test that pattern counts are reasonable."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            pattern_counts = result['pattern_label'].value_counts()
            # Each pattern should have at least 1 company
            assert all(count >= 1 for count in pattern_counts.values)
    
    def test_capital_allocation_no_duplicates(self):
        """Test that each company appears once."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            duplicates = result[result.duplicated('company_id', keep=False)]
            assert len(duplicates) == 0
    
    def test_capital_allocation_size_metric_numeric(self):
        """Test that size metric is numeric."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            assert result['size_metric'].dtype in [float, int]
    
    def test_capital_allocation_known_patterns(self):
        """Test that known patterns are present."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            patterns = result['pattern_label'].unique()
            expected = ['Shareholder Returns', 'Reinvestor', 'Growth Funded by Debt']
            found = [p for p in expected if p in patterns]
            assert len(found) >= 2  # At least 2 of the expected patterns


class TestAnnualReports:
    """Tests for Annual Reports screen functionality."""
    
    def test_get_annual_reports_returns_dataframe(self):
        """Test that get_annual_reports returns DataFrame."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_annual_reports(ticker)
            assert isinstance(result, pd.DataFrame)
    
    def test_annual_reports_have_year_column(self):
        """Test that annual reports have year column."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_annual_reports(ticker)
            if not result.empty:
                assert 'year' in result.columns
    
    def test_annual_reports_have_url_column(self):
        """Test that annual reports have URL column."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_annual_reports(ticker)
            if not result.empty:
                assert 'annual_report' in result.columns
    
    def test_annual_reports_sorted_descending(self):
        """Test that reports are sorted by year descending."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_annual_reports(ticker)
            if len(result) > 1:
                years = result['year'].tolist()
                # Should be sorted descending
                for i in range(len(years) - 1):
                    assert years[i] >= years[i+1]
    
    def test_annual_reports_urls_not_null(self):
        """Test that report URLs are not null when present."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_annual_reports(ticker)
            if not result.empty:
                # Function filters for NOT NULL, so all should be non-null
                assert result['annual_report'].notna().all()
    
    def test_annual_reports_urls_are_strings(self):
        """Test that report URLs are strings."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_annual_reports(ticker)
            if not result.empty:
                assert result['annual_report'].dtype == object
    
    def test_annual_reports_invalid_ticker(self):
        """Test that invalid ticker returns empty DataFrame."""
        result = db.get_annual_reports('INVALIDXYZ')
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0


class TestEdgeCases:
    """Tests for edge case handling."""
    
    def test_trend_empty_metrics_list(self):
        """Test trend data with empty metrics list."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_trend_data(ticker, [])
            assert isinstance(result, pd.DataFrame)
    
    def test_sector_with_missing_market_cap(self):
        """Test sector analysis handles missing market cap."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_companies(sectors[0])
            if not result.empty:
                # Should have market cap column even if some values are NaN
                assert 'market_cap_crore' in result.columns
    
    def test_company_with_no_reports(self):
        """Test that companies without reports return empty."""
        # Try a company that might not have reports
        result = db.get_annual_reports('TESTXYZ')
        assert len(result) == 0
    
    def test_capital_allocation_missing_market_cap(self):
        """Test capital allocation handles missing market cap."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            # size_metric should have fallback value
            assert result['size_metric'].notna().all()
    
    def test_sector_medians_with_nulls(self):
        """Test sector medians handle NULL values correctly."""
        sectors = db.get_all_sectors()
        if sectors:
            result = db.get_sector_medians(sectors[0])
            # Should return dict, values can be None for missing data
            assert isinstance(result, dict)


class TestDataIntegrity:
    """Tests for data integrity and consistency."""
    
    def test_trend_data_no_sentinel_years(self):
        """Test that trend data excludes sentinel year 9999-12."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_trend_data(ticker, ['Revenue'])
            if not result.empty:
                assert '9999-12' not in result['year'].values
    
    def test_sector_companies_match_sector_assignment(self):
        """Test that sector companies actually belong to that sector."""
        sectors = db.get_all_sectors()
        if sectors and len(sectors) > 0:
            sector = sectors[0]
            companies = db.get_sector_companies(sector)
            if not companies.empty:
                # All companies should have at least company_id
                assert companies['company_id'].notna().all()
    
    def test_capital_allocation_company_count(self):
        """Test capital allocation covers expected number of companies."""
        result = db.get_capital_allocation_data()
        if not result.empty:
            # Should cover most of Nifty 100
            assert len(result) >= 80
            assert len(result) <= 92
    
    def test_annual_reports_url_format(self):
        """Test that annual report URLs have expected format."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_annual_reports(ticker)
            if not result.empty:
                url = result.iloc[0]['annual_report']
                # Should be BSE URL
                assert isinstance(url, str)
                assert 'bseindia.com' in url.lower() or 'http' in url.lower()


class TestPerformance:
    """Tests for performance and caching."""
    
    def test_trend_data_cached(self):
        """Test that get_trend_data uses caching."""
        import inspect
        source = inspect.getsource(db.get_trend_data)
        assert '@st.cache_data' in source
    
    def test_sector_companies_cached(self):
        """Test that get_sector_companies uses caching."""
        import inspect
        source = inspect.getsource(db.get_sector_companies)
        assert '@st.cache_data' in source
    
    def test_capital_allocation_cached(self):
        """Test that get_capital_allocation_data uses caching."""
        import inspect
        source = inspect.getsource(db.get_capital_allocation_data)
        assert '@st.cache_data' in source
    
    def test_annual_reports_cached(self):
        """Test that get_annual_reports uses caching."""
        import inspect
        source = inspect.getsource(db.get_annual_reports)
        assert '@st.cache_data' in source


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
