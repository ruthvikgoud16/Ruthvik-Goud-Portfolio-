"""
Day 22 Dashboard Foundation Tests

Test suite verifying:
- Database connection and path resolution
- All 8 cached database functions
- Page imports and renderability
- Cache decorator presence
- Ticker validation
- Error handling
- Integration checks
"""

import pytest
import sys
import os
from pathlib import Path
import pandas as pd
import sqlite3
import inspect

# Add project root to path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from src.dashboard.utils import db
from src.dashboard import app


class TestDatabasePathResolution:
    """Test database path resolution logic."""
    
    def test_db_path_exists(self):
        """Database file must exist at the resolved path."""
        db_path = db._get_db_path()
        assert os.path.exists(db_path), f"Database not found at {db_path}"
    
    def test_db_path_is_absolute(self):
        """Resolved path must be absolute."""
        db_path = db._get_db_path()
        assert os.path.isabs(db_path), f"Database path is not absolute: {db_path}"
    
    def test_db_path_ends_with_nifty100_db(self):
        """Database path must end with nifty100.db."""
        db_path = db._get_db_path()
        assert db_path.endswith("nifty100.db"), f"Unexpected database path: {db_path}"
    
    def test_db_connection_opens(self):
        """Database connection must open without error."""
        conn = db._get_connection()
        assert conn is not None
        conn.close()


class TestDatabaseFunctions:
    """Test all 8 main database functions."""
    
    def test_get_companies_returns_dataframe(self):
        """get_companies must return DataFrame."""
        result = db.get_companies()
        assert isinstance(result, pd.DataFrame)
    
    def test_get_companies_has_data(self):
        """get_companies must return 92 companies."""
        result = db.get_companies()
        assert len(result) == 92, f"Expected 92 companies, got {len(result)}"
    
    def test_get_companies_has_required_columns(self):
        """get_companies must have id and company_name columns."""
        result = db.get_companies()
        assert "id" in result.columns
        assert "company_name" in result.columns
    
    def test_get_ratios_returns_dataframe(self):
        """get_ratios must return DataFrame."""
        result = db.get_ratios("TCS")
        assert isinstance(result, pd.DataFrame)
    
    def test_get_ratios_with_ticker(self):
        """get_ratios with valid ticker must return data."""
        result = db.get_ratios("TCS")
        assert len(result) > 0, "No ratios found for TCS"
    
    def test_get_ratios_with_invalid_ticker(self):
        """get_ratios with invalid ticker must return empty DataFrame."""
        result = db.get_ratios("INVALIDTICKER")
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    def test_get_pl_returns_dataframe(self):
        """get_pl must return DataFrame."""
        result = db.get_pl("TCS")
        assert isinstance(result, pd.DataFrame)
    
    def test_get_bs_returns_dataframe(self):
        """get_bs must return DataFrame."""
        result = db.get_bs("TCS")
        assert isinstance(result, pd.DataFrame)
    
    def test_get_cf_returns_dataframe(self):
        """get_cf must return DataFrame."""
        result = db.get_cf("TCS")
        assert isinstance(result, pd.DataFrame)
    
    def test_get_sectors_returns_dataframe(self):
        """get_sectors must return DataFrame."""
        result = db.get_sectors()
        assert isinstance(result, pd.DataFrame)
    
    def test_get_peers_returns_dataframe(self):
        """get_peers must return DataFrame."""
        result = db.get_peers("IT Services")
        assert isinstance(result, pd.DataFrame)
    
    def test_get_valuation_returns_empty_dataframe(self):
        """get_valuation must return DataFrame (Day 26 implemented)."""
        result = db.get_valuation("TCS")
        assert isinstance(result, pd.DataFrame)
        # After Day 26, should have actual valuation data


class TestHelperFunctions:
    """Test helper functions."""
    
    def test_validate_ticker_with_valid_ticker(self):
        """validate_ticker must return True for valid ticker."""
        result = db.validate_ticker("TCS")
        assert result is True
    
    def test_validate_ticker_with_invalid_ticker(self):
        """validate_ticker must return False for invalid ticker."""
        result = db.validate_ticker("INVALIDXYZ")
        assert result is False
    
    def test_get_company_name_with_valid_ticker(self):
        """get_company_name must return company name for valid ticker."""
        result = db.get_company_name("TCS")
        assert result is not None
        assert isinstance(result, str)
        assert len(result) > 0
    
    def test_get_company_name_with_invalid_ticker(self):
        """get_company_name must return the ticker itself for invalid ticker."""
        result = db.get_company_name("INVALIDXYZ")
        assert result == "INVALIDXYZ"
    
    def test_get_latest_year_returns_string(self):
        """get_latest_year must return a year string."""
        result = db.get_latest_year()
        assert result is None or isinstance(result, str)
    
    def test_get_available_years_with_valid_ticker(self):
        """get_available_years must return list of years."""
        result = db.get_available_years("TCS")
        assert isinstance(result, list)
        assert len(result) > 0
    
    def test_get_available_years_with_invalid_ticker(self):
        """get_available_years must return empty list for invalid ticker."""
        result = db.get_available_years("INVALIDXYZ")
        assert isinstance(result, list)
        assert len(result) == 0
    
    def test_get_all_peer_groups_returns_list(self):
        """get_all_peer_groups must return list of peer group names."""
        result = db.get_all_peer_groups()
        assert isinstance(result, list)
        assert len(result) > 0


class TestCacheDecorators:
    """Test that cache decorators are properly applied."""
    
    def test_get_companies_has_cache_decorator(self):
        """get_companies must have @st.cache_data decorator."""
        func = db.get_companies
        # Streamlit's cache_data wraps the function
        assert hasattr(func, "__wrapped__") or "cached" in str(func)
    
    def test_get_ratios_has_cache_decorator(self):
        """get_ratios must have @st.cache_data decorator."""
        func = db.get_ratios
        assert hasattr(func, "__wrapped__") or "cached" in str(func)
    
    def test_get_pl_has_cache_decorator(self):
        """get_pl must have @st.cache_data decorator."""
        func = db.get_pl
        assert hasattr(func, "__wrapped__") or "cached" in str(func)
    
    def test_get_bs_has_cache_decorator(self):
        """get_bs must have @st.cache_data decorator."""
        func = db.get_bs
        assert hasattr(func, "__wrapped__") or "cached" in str(func)
    
    def test_get_cf_has_cache_decorator(self):
        """get_cf must have @st.cache_data decorator."""
        func = db.get_cf
        assert hasattr(func, "__wrapped__") or "cached" in str(func)
    
    def test_get_sectors_has_cache_decorator(self):
        """get_sectors must have @st.cache_data decorator."""
        func = db.get_sectors
        assert hasattr(func, "__wrapped__") or "cached" in str(func)
    
    def test_get_peers_has_cache_decorator(self):
        """get_peers must have @st.cache_data decorator."""
        func = db.get_peers
        assert hasattr(func, "__wrapped__") or "cached" in str(func)
    
    def test_get_valuation_has_cache_decorator(self):
        """get_valuation must have @st.cache_data decorator."""
        func = db.get_valuation
        assert hasattr(func, "__wrapped__") or "cached" in str(func)


class TestPageImports:
    """Test that all page files can be imported without errors."""
    
    def test_import_page_01_home(self):
        """Page 1 (Home) must import without errors."""
        from src.dashboard.screens import page_01_home
        assert hasattr(page_01_home, "render")
    
    def test_import_page_02_profile(self):
        """Page 2 (Profile) must import without errors."""
        from src.dashboard.screens import page_02_profile
        assert hasattr(page_02_profile, "render")
    
    def test_import_page_03_screener(self):
        """Page 3 (Screener) must import without errors."""
        from src.dashboard.screens import page_03_screener
        assert hasattr(page_03_screener, "render")
    
    def test_import_page_04_peers(self):
        """Page 4 (Peers) must import without errors."""
        from src.dashboard.screens import page_04_peers
        assert hasattr(page_04_peers, "render")
    
    def test_import_page_05_trends(self):
        """Page 5 (Trends) must import without errors."""
        from src.dashboard.screens import page_05_trends
        assert hasattr(page_05_trends, "render")
    
    def test_import_page_06_sectors(self):
        """Page 6 (Sectors) must import without errors."""
        from src.dashboard.screens import page_06_sectors
        assert hasattr(page_06_sectors, "render")
    
    def test_import_page_07_capital(self):
        """Page 7 (Capital) must import without errors."""
        from src.dashboard.screens import page_07_capital
        assert hasattr(page_07_capital, "render")
    
    def test_import_page_08_reports(self):
        """Page 8 (Reports) must import without errors."""
        from src.dashboard.screens import page_08_reports
        assert hasattr(page_08_reports, "render")


class TestErrorHandling:
    """Test error handling in database functions."""
    
    def test_get_companies_handles_connection_error(self):
        """get_companies must gracefully handle errors."""
        result = db.get_companies()
        # Should return DataFrame, not raise exception
        assert isinstance(result, pd.DataFrame)
    
    def test_get_ratios_handles_invalid_input(self):
        """get_ratios must handle invalid ticker gracefully."""
        result = db.get_ratios("NOTREAL")
        assert isinstance(result, pd.DataFrame)
    
    def test_validate_ticker_handles_error(self):
        """validate_ticker must return False on error, not crash."""
        result = db.validate_ticker("TEST")
        assert isinstance(result, bool)


class TestDataIntegrity:
    """Test data integrity and consistency."""
    
    def test_companies_ticker_unique(self):
        """Company tickers must be unique."""
        companies = db.get_companies()
        assert len(companies["id"].unique()) == len(companies)
    
    def test_ratios_have_quality_score(self):
        """Financial ratios must include composite_quality_score."""
        ratios = db.get_ratios("TCS")
        if len(ratios) > 0:
            assert "composite_quality_score" in ratios.columns
    
    def test_pl_has_required_columns(self):
        """P&L data must have required columns."""
        pl = db.get_pl("TCS")
        if len(pl) > 0:
            assert "sales" in pl.columns or len(pl.columns) > 0


class TestIntegration:
    """Integration tests across multiple functions."""
    
    def test_get_company_then_ratios(self):
        """Can retrieve a company then get its ratios."""
        companies = db.get_companies()
        first_ticker = companies.iloc[0]["id"]
        ratios = db.get_ratios(first_ticker)
        assert isinstance(ratios, pd.DataFrame)
    
    def test_get_company_then_peers(self):
        """Can retrieve peer group for a company."""
        peer_groups = db.get_all_peer_groups()
        if len(peer_groups) > 0:
            peers = db.get_peers(peer_groups[0])
            assert isinstance(peers, pd.DataFrame)
    
    def test_validate_then_get_name(self):
        """Validate ticker then get company name."""
        valid = db.validate_ticker("TCS")
        assert valid
        name = db.get_company_name("TCS")
        assert name is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
