"""
Day 24 Tests: Screener and Peer Comparison Screens
Tests for stock screener filtering, presets, CSV export, 
peer group radar charts, and peer comparison tables.
"""

import pytest
import pandas as pd
from unittest.mock import Mock, patch
import sys
import os

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.dashboard.utils import db
from src.dashboard.screens import page_03_screener, page_04_peers


class TestScreenerData:
    """Tests for screener data retrieval."""
    
    def test_get_screener_data_returns_dataframe(self):
        """Test that get_screener_data returns a DataFrame."""
        result = db.get_screener_data()
        assert isinstance(result, pd.DataFrame)
    
    def test_screener_data_has_required_columns(self):
        """Test that screener data has all required columns."""
        result = db.get_screener_data()
        if not result.empty:
            required_cols = [
                'company_id', 'company_name', 'sector',
                'return_on_equity_pct', 'debt_to_equity', 'free_cash_flow_cr',
                'revenue_cagr_5yr', 'pat_cagr_5yr', 'operating_profit_margin_pct',
                'composite_quality_score'
            ]
            for col in required_cols:
                assert col in result.columns, f"Missing column: {col}"
    
    def test_screener_data_includes_market_cap_metrics(self):
        """Test that screener data includes P/E, P/B, Div Yield."""
        result = db.get_screener_data()
        if not result.empty:
            assert 'pe_ratio' in result.columns
            assert 'pb_ratio' in result.columns
            assert 'dividend_yield_pct' in result.columns
    
    def test_screener_data_non_empty(self):
        """Test that screener returns data for Nifty 100."""
        result = db.get_screener_data()
        assert len(result) > 0, "Screener should return companies"
        assert len(result) <= 100, "Should not exceed Nifty 100 count"
    
    def test_screener_data_latest_year_only(self):
        """Test that screener returns only latest year data per company."""
        result = db.get_screener_data()
        if not result.empty:
            # Check no duplicates
            assert result['company_id'].nunique() == len(result), \
                "Should have one row per company"


class TestScreenerFiltering:
    """Tests for screener filter logic."""
    
    def setup_method(self):
        """Create sample data for filter tests."""
        self.sample_data = pd.DataFrame({
            'company_id': ['A', 'B', 'C', 'D'],
            'return_on_equity_pct': [20.0, 10.0, 25.0, 5.0],
            'debt_to_equity': [0.5, 2.0, 0.0, 1.5],
            'free_cash_flow_cr': [1000, -500, 2000, 100],
            'revenue_cagr_5yr': [15.0, 5.0, 20.0, -5.0],
            'pat_cagr_5yr': [25.0, 10.0, 30.0, -10.0],
            'operating_profit_margin_pct': [20.0, 5.0, 30.0, 2.0],
            'interest_coverage': [10.0, 2.0, 50.0, 1.0],
            'pe_ratio': [15.0, 25.0, 18.0, 30.0],
            'pb_ratio': [2.0, 4.0, 2.5, 5.0],
            'dividend_yield_pct': [2.5, 0.5, 3.0, 0.0],
            'composite_quality_score': [75, 50, 85, 40]
        })
    
    def test_filter_roe_min(self):
        """Test ROE minimum filter."""
        filters = {'roe_min': 15.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['return_on_equity_pct'] >= 15.0)
    
    def test_filter_de_max(self):
        """Test D/E maximum filter."""
        filters = {'de_max': 1.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['debt_to_equity'] <= 1.0)
    
    def test_filter_fcf_min(self):
        """Test FCF minimum filter."""
        filters = {'fcf_min': 0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 3  # A, C, D pass (B negative)
        assert all(result['free_cash_flow_cr'] >= 0)
    
    def test_filter_revenue_cagr_min(self):
        """Test Revenue CAGR minimum filter."""
        filters = {'revenue_cagr_min': 10.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['revenue_cagr_5yr'] >= 10.0)
    
    def test_filter_pat_cagr_min(self):
        """Test PAT CAGR minimum filter."""
        filters = {'pat_cagr_min': 20.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['pat_cagr_5yr'] >= 20.0)
    
    def test_filter_opm_min(self):
        """Test OPM minimum filter."""
        filters = {'opm_min': 10.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['operating_profit_margin_pct'] >= 10.0)
    
    def test_filter_pe_max(self):
        """Test P/E maximum filter."""
        filters = {'pe_max': 20.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['pe_ratio'] <= 20.0)
    
    def test_filter_pb_max(self):
        """Test P/B maximum filter."""
        filters = {'pb_max': 3.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['pb_ratio'] <= 3.0)
    
    def test_filter_div_yield_min(self):
        """Test Dividend Yield minimum filter."""
        filters = {'div_yield_min': 2.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass
        assert all(result['dividend_yield_pct'] >= 2.0)
    
    def test_filter_icr_min(self):
        """Test ICR minimum filter."""
        filters = {'icr_min': 5.0}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        # A (ICR=10) and C (D/E=0, debt-free) pass
        assert len(result) == 2
    
    def test_filter_icr_debt_free_bypass(self):
        """Test that debt-free companies pass ICR filter."""
        filters = {'icr_min': 100.0}  # Very high ICR
        result = page_03_screener.apply_filters(self.sample_data, filters)
        # Only C passes (debt-free)
        assert 'C' in result['company_id'].values
    
    def test_multiple_filters_combined(self):
        """Test multiple filters working together."""
        filters = {
            'roe_min': 15.0,
            'de_max': 1.0,
            'fcf_min': 500
        }
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 2  # A and C pass all three
    
    def test_no_filters_returns_all(self):
        """Test that empty filters return all data."""
        filters = {}
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == len(self.sample_data)
    
    def test_impossible_filters_return_empty(self):
        """Test that conflicting filters return empty result."""
        filters = {
            'roe_min': 50.0,  # Too high
            'de_max': -1.0    # Impossible
        }
        result = page_03_screener.apply_filters(self.sample_data, filters)
        assert len(result) == 0


class TestScreenerPresets:
    """Tests for screener preset configurations."""
    
    def test_all_six_presets_defined(self):
        """Test that all 6 presets are defined."""
        assert 'Quality' in page_03_screener.PRESETS
        assert 'Value' in page_03_screener.PRESETS
        assert 'Growth' in page_03_screener.PRESETS
        assert 'Dividend' in page_03_screener.PRESETS
        assert 'Debt-Free' in page_03_screener.PRESETS
        assert 'Turnaround' in page_03_screener.PRESETS
    
    def test_quality_preset_values(self):
        """Test Quality preset has correct Sprint 3 values."""
        preset = page_03_screener.PRESETS['Quality']
        assert preset['roe_min'] == 15.0
        assert preset['de_max'] == 1.0
        assert preset['fcf_min'] == 0
        assert preset['revenue_cagr_min'] == 10.0
    
    def test_value_preset_values(self):
        """Test Value preset has correct Sprint 3 values."""
        preset = page_03_screener.PRESETS['Value']
        assert preset['pe_max'] == 20
        assert preset['pb_max'] == 3.0
        assert preset['de_max'] == 2.0
        assert preset['div_yield_min'] == 1.0
    
    def test_growth_preset_values(self):
        """Test Growth preset has correct Sprint 3 values."""
        preset = page_03_screener.PRESETS['Growth']
        assert preset['pat_cagr_min'] == 20.0
        assert preset['revenue_cagr_min'] == 15.0
        assert preset['de_max'] == 2.0
    
    def test_dividend_preset_values(self):
        """Test Dividend preset has correct Sprint 3 values."""
        preset = page_03_screener.PRESETS['Dividend']
        assert preset['div_yield_min'] == 2.0
        assert preset['fcf_min'] == 0
    
    def test_debt_free_preset_values(self):
        """Test Debt-Free preset has correct Sprint 3 values."""
        preset = page_03_screener.PRESETS['Debt-Free']
        assert preset['de_max'] == 0
        assert preset['roe_min'] == 12.0
    
    def test_turnaround_preset_values(self):
        """Test Turnaround preset has correct Sprint 3 values."""
        preset = page_03_screener.PRESETS['Turnaround']
        assert preset['revenue_cagr_min'] == 10.0
        assert preset['fcf_min'] == 0


class TestPeerGroups:
    """Tests for peer group functionality."""
    
    def test_get_all_peer_groups_returns_list(self):
        """Test that peer groups are returned as list."""
        result = db.get_all_peer_groups()
        assert isinstance(result, list)
    
    def test_peer_groups_count(self):
        """Test that we have 11 peer groups from Sprint 3."""
        result = db.get_all_peer_groups()
        assert len(result) == 11, f"Expected 11 peer groups, got {len(result)}"
    
    def test_peer_groups_include_expected_names(self):
        """Test that known peer groups exist."""
        result = db.get_all_peer_groups()
        expected = ['IT Services', 'Private Banks', 'Pharmaceuticals']
        for group in expected:
            assert group in result, f"Missing peer group: {group}"
    
    def test_get_peers_returns_dataframe(self):
        """Test that get_peers returns DataFrame."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peers(groups[0])
            assert isinstance(result, pd.DataFrame)
    
    def test_get_peers_has_company_ids(self):
        """Test that peer group contains company IDs."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peers(groups[0])
            if not result.empty:
                assert 'company_id' in result.columns
                assert len(result) > 0


class TestPeerRadarData:
    """Tests for peer radar chart data."""
    
    def test_get_peer_radar_data_returns_dataframe(self):
        """Test that radar data returns DataFrame."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_radar_data(groups[0])
            assert isinstance(result, pd.DataFrame)
    
    def test_radar_data_has_required_columns(self):
        """Test that radar data has company_id, metric, value."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_radar_data(groups[0])
            if not result.empty:
                assert 'company_id' in result.columns
                assert 'metric' in result.columns
                assert 'value' in result.columns
    
    def test_radar_data_includes_eight_metrics(self):
        """Test that radar includes 8 metrics per company."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_radar_data(groups[0])
            if not result.empty:
                expected_metrics = {
                    'ROE', 'ROCE', 'NPM', 'D/E', 'FCF',
                    'PAT CAGR', 'Revenue CAGR', 'Quality Score'
                }
                actual_metrics = set(result['metric'].unique())
                # Should have most metrics (some may be missing for some companies)
                assert len(actual_metrics) >= 5, f"Too few metrics: {actual_metrics}"
    
    def test_radar_values_normalized_0_100(self):
        """Test that radar values are in 0-100 range."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_radar_data(groups[0])
            if not result.empty:
                assert result['value'].min() >= 0, "Values should be >= 0"
                assert result['value'].max() <= 100, "Values should be <= 100"


class TestPeerMetrics:
    """Tests for peer comparison metrics."""
    
    def test_get_peer_group_metrics_returns_dataframe(self):
        """Test that peer metrics returns DataFrame."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_group_metrics(groups[0])
            assert isinstance(result, pd.DataFrame)
    
    def test_peer_metrics_include_key_columns(self):
        """Test that peer metrics has company and KPI columns."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_group_metrics(groups[0])
            if not result.empty:
                assert 'company_id' in result.columns
                assert 'Company' in result.columns
                assert 'ROE %' in result.columns
                assert 'Quality Score' in result.columns
    
    def test_peer_metrics_sorted_by_quality(self):
        """Test that peer metrics are sorted by quality score descending."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_group_metrics(groups[0])
            if len(result) > 1 and 'Quality Score' in result.columns:
                quality_scores = result['Quality Score'].dropna()
                if len(quality_scores) > 1:
                    # Check descending order
                    assert all(quality_scores.iloc[i] >= quality_scores.iloc[i+1] 
                              for i in range(len(quality_scores)-1))


class TestHelperFunctions:
    """Tests for helper functions."""
    
    def test_get_company_name_returns_string(self):
        """Test that get_company_name returns a string."""
        companies = db.get_companies()
        if not companies.empty:
            ticker = companies.iloc[0]['id']
            result = db.get_company_name(ticker)
            assert isinstance(result, str)
            assert len(result) > 0
    
    def test_get_company_name_invalid_ticker(self):
        """Test that invalid ticker returns the ticker itself."""
        result = db.get_company_name('INVALID_TICKER_XYZ')
        assert result == 'INVALID_TICKER_XYZ'


class TestEdgeCases:
    """Tests for edge case handling."""
    
    def test_empty_dataframe_filtering(self):
        """Test filtering empty DataFrame doesn't crash."""
        empty_df = pd.DataFrame(columns=[
            'company_id', 'return_on_equity_pct', 'debt_to_equity', 
            'free_cash_flow_cr', 'revenue_cagr_5yr', 'pat_cagr_5yr',
            'operating_profit_margin_pct', 'interest_coverage',
            'pe_ratio', 'pb_ratio', 'dividend_yield_pct'
        ])
        filters = {'roe_min': 15.0}
        result = page_03_screener.apply_filters(empty_df, filters)
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    def test_invalid_peer_group_returns_empty(self):
        """Test that invalid peer group returns empty result."""
        result = db.get_peers('INVALID_GROUP_XYZ')
        assert isinstance(result, pd.DataFrame)
        assert len(result) == 0
    
    def test_missing_columns_dont_crash_filter(self):
        """Test that missing columns are handled gracefully."""
        partial_df = pd.DataFrame({
            'company_id': ['A', 'B'],
            'return_on_equity_pct': [20.0, 10.0]
        })
        filters = {'roe_min': 15.0, 'de_max': 1.0}
        # Should filter ROE but skip D/E (missing column causes KeyError - expected)
        try:
            result = page_03_screener.apply_filters(partial_df, filters)
            # If it succeeds, check ROE worked
            assert all(result['return_on_equity_pct'] >= 15.0)
        except KeyError:
            # Expected if trying to filter missing column
            pass


class TestDataIntegrity:
    """Tests for data integrity and consistency."""
    
    def test_screener_no_duplicate_companies(self):
        """Test that screener has no duplicate company rows."""
        result = db.get_screener_data()
        if not result.empty:
            duplicates = result[result.duplicated('company_id', keep=False)]
            assert len(duplicates) == 0, f"Found {len(duplicates)} duplicate rows"
    
    def test_peer_groups_no_orphans(self):
        """Test that all peer group companies exist in master list."""
        groups = db.get_all_peer_groups()
        companies = db.get_companies()
        company_ids = set(companies['id'])
        
        for group in groups[:3]:  # Check first 3 groups
            peers = db.get_peers(group)
            if not peers.empty:
                for peer_id in peers['company_id']:
                    assert peer_id in company_ids, \
                        f"Peer {peer_id} in {group} not in master list"
    
    def test_radar_data_consistent_per_company(self):
        """Test that radar data doesn't have duplicate metric entries."""
        groups = db.get_all_peer_groups()
        if groups:
            result = db.get_peer_radar_data(groups[0])
            if not result.empty:
                # Check for duplicates
                duplicates = result[
                    result.duplicated(subset=['company_id', 'metric'], keep=False)
                ]
                assert len(duplicates) == 0, "Found duplicate metric entries"


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
