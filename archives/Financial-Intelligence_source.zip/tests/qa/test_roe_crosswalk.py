from src.qa.roe_crosswalk import classify_roe


def test_tcs_style_decimal_is_source_anomaly_not_pass():
    status, reason = classify_roe(0.52, 50.94)
    assert status == "SOURCE_ANOMALY"
    assert "unit" in reason.lower() or "decimal" in reason.lower()


def test_close_values_pass():
    status, _reason = classify_roe(31.80, 29.79)
    assert status == "PASS"


def test_missing_source_is_anomaly():
    status, _reason = classify_roe(None, 10.0)
    assert status == "SOURCE_ANOMALY"


def test_missing_engine_is_anomaly():
    status, _reason = classify_roe(17.3, None)
    assert status == "SOURCE_ANOMALY"


def test_both_missing_is_fail():
    status, _reason = classify_roe(None, None)
    assert status == "FAIL"
