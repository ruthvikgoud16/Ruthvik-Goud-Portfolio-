"""
Day 18 — Unit Tests for Peer Percentile Rankings
Tests PERCENT_RANK computation, D/E inversion, missing values, peer group handling
"""

import pytest
import sqlite3
from src.analytics.peer import PeerPercentile


@pytest.fixture
def pp():
    """Create PeerPercentile instance for testing."""
    pp_instance = PeerPercentile(db_path="nifty100.db")
    yield pp_instance
    pp_instance.close()


@pytest.fixture
def conn():
    """Create database connection for verification queries."""
    conn = sqlite3.connect("nifty100.db")
    conn.row_factory = sqlite3.Row
    yield conn
    conn.close()


class TestPeerPercentileInit:
    """Test PeerPercentile initialization."""
    
    def test_init_connects_to_database(self, pp):
        """Test that __init__ successfully connects to database."""
        assert pp.conn is not None
    
    def test_metrics_dict_has_10_entries(self, pp):
        """Test that metrics dict contains exactly 10 metrics."""
        assert len(pp.metrics) == 10
    
    def test_metrics_names(self, pp):
        """Test that all required metrics are present."""
        required_metrics = {
            'ROE', 'ROCE', 'NPM', 'D/E_inv', 'FCF',
            'PAT_CAGR_5yr', 'Revenue_CAGR_5yr', 'EPS_CAGR_5yr', 'ICR', 'Asset_Turnover'
        }
        assert set(pp.metrics.keys()) == required_metrics
    
    def test_peer_groups_has_11_entries(self, pp):
        """Test that peer_groups list contains exactly 11 groups."""
        assert len(pp.peer_groups) == 11
    
    def test_peer_groups_names(self, pp):
        """Test that all required peer groups are present."""
        required_groups = {
            'Automobiles', 'Consumer Finance', 'FMCG', 'IT Services', 'Life Insurance',
            'Oil & Gas', 'Pharmaceuticals', 'Power & Utilities', 'Private Banks',
            'Public Sector Banks', 'Steel'
        }
        assert set(pp.peer_groups) == required_groups
    
    def test_de_metric_is_inverse(self, pp):
        """Test that D/E metric is marked as inverse."""
        _, is_inverse = pp.metrics['D/E_inv']
        assert is_inverse is True
    
    def test_roe_metric_not_inverse(self, pp):
        """Test that ROE metric is not marked as inverse."""
        _, is_inverse = pp.metrics['ROE']
        assert is_inverse is False


class TestMetricValueRetrieval:
    """Test metric value retrieval from database."""
    
    def test_get_roe_value(self, pp):
        """Test retrieving ROE value for a company-year."""
        # ABB 2012-12 should have ROE
        value = pp._get_metric_value('ABB', '2012-12', 'ROE')
        assert value is not None
        assert isinstance(value, float)
        assert value > 0
    
    def test_get_npm_value(self, pp):
        """Test retrieving NPM value for a company-year."""
        value = pp._get_metric_value('ABB', '2012-12', 'NPM')
        assert value is not None
        assert isinstance(value, float)
    
    def test_get_de_value(self, pp):
        """Test retrieving D/E value for a company-year."""
        value = pp._get_metric_value('ABB', '2012-12', 'D/E_inv')
        assert value is not None
        assert isinstance(value, float)
        assert value >= 0
    
    def test_get_roce_value(self, pp):
        """Test computing ROCE value for a company-year."""
        value = pp._get_metric_value('ABB', '2012-12', 'ROCE')
        # ROCE might be None if data insufficient, but should be computable for major companies
        if value is not None:
            assert isinstance(value, float)
            assert value > 0 or value == 0
    
    def test_missing_value_returns_none(self, pp):
        """Test that non-existent company-year returns None."""
        value = pp._get_metric_value('NONEXISTENT', '9999-12', 'ROE')
        assert value is None
    
    def test_fcf_value(self, pp):
        """Test retrieving FCF value."""
        value = pp._get_metric_value('ABB', '2012-12', 'FCF')
        if value is not None:
            assert isinstance(value, float)


class TestPeerGroupAssignment:
    """Test peer group assignment logic."""
    
    def test_get_peer_group_for_tcs(self, pp):
        """Test that TCS is assigned to IT Services peer group."""
        peer_group = pp._get_peer_group_for_company('TCS')
        assert peer_group == 'IT Services'
    
    def test_get_peer_group_for_icicibank(self, pp):
        """Test that ICICIBANK is assigned to Private Banks peer group."""
        peer_group = pp._get_peer_group_for_company('ICICIBANK')
        assert peer_group == 'Private Banks'
    
    def test_get_peer_group_for_unassigned_company(self, pp):
        """Test that unassigned company returns None."""
        # ABB is not in any peer group
        peer_group = pp._get_peer_group_for_company('ABB')
        assert peer_group is None
    
    def test_get_peer_group_nonexistent_company(self, pp):
        """Test that non-existent company returns None."""
        peer_group = pp._get_peer_group_for_company('NONEXISTENT')
        assert peer_group is None


class TestPercentileRankComputation:
    """Test PERCENT_RANK computation logic."""
    
    def test_single_value_percentile(self, pp):
        """Test percentile rank for single value (should be 1.0)."""
        all_values = [('ABC', 100.0)]
        rank = pp._compute_percentile_rank(100.0, all_values, is_inverse=False)
        assert rank == 1.0
    
    def test_lowest_value_percentile(self, pp):
        """Test percentile rank for lowest value (should be 0.0)."""
        all_values = [('A', 10.0), ('B', 20.0), ('C', 30.0)]
        rank = pp._compute_percentile_rank(10.0, all_values, is_inverse=False)
        assert rank == 0.0
    
    def test_highest_value_percentile(self, pp):
        """Test percentile rank for highest value (should be 1.0)."""
        all_values = [('A', 10.0), ('B', 20.0), ('C', 30.0)]
        rank = pp._compute_percentile_rank(30.0, all_values, is_inverse=False)
        assert rank == 1.0
    
    def test_middle_value_percentile(self, pp):
        """Test percentile rank for middle value (should be 0.5)."""
        all_values = [('A', 10.0), ('B', 20.0), ('C', 30.0)]
        rank = pp._compute_percentile_rank(20.0, all_values, is_inverse=False)
        assert rank == 0.5
    
    def test_de_inverse_lowest_value(self, pp):
        """Test that D/E inversion makes lowest value get highest rank."""
        # For D/E, lower is better, so lowest D/E should get 1.0 after inversion
        all_values = [('A', 0.5), ('B', 1.0), ('C', 1.5)]
        rank = pp._compute_percentile_rank(0.5, all_values, is_inverse=True)
        assert rank == 1.0
    
    def test_de_inverse_highest_value(self, pp):
        """Test that D/E inversion makes highest value get lowest rank."""
        # For D/E, higher value should get 0.0 after inversion
        all_values = [('A', 0.5), ('B', 1.0), ('C', 1.5)]
        rank = pp._compute_percentile_rank(1.5, all_values, is_inverse=True)
        assert rank == 0.0
    
    def test_empty_values_list(self, pp):
        """Test that empty values list returns 0.5 (neutral)."""
        rank = pp._compute_percentile_rank(100.0, [], is_inverse=False)
        assert rank == 0.5
    
    def test_percentile_rank_clamped_to_01(self, pp):
        """Test that percentile rank is clamped to [0, 1]."""
        all_values = [('A', 10.0), ('B', 20.0)]
        rank = pp._compute_percentile_rank(25.0, all_values, is_inverse=False)
        assert 0.0 <= rank <= 1.0


class TestPeerPercentilesTable:
    """Test peer_percentiles table population and querying."""
    
    def test_table_exists(self, conn):
        """Test that peer_percentiles table exists."""
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='peer_percentiles'")
        assert cursor.fetchone() is not None
    
    def test_table_has_data(self, conn):
        """Test that peer_percentiles table has been populated."""
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM peer_percentiles")
        count = cursor.fetchone()[0]
        assert count > 0
    
    def test_percentile_rank_in_valid_range(self, conn):
        """Test that all percentile ranks are in [0, 1]."""
        cursor = conn.cursor()
        cursor.execute("SELECT MIN(percentile_rank), MAX(percentile_rank) FROM peer_percentiles")
        min_rank, max_rank = cursor.fetchone()
        assert min_rank >= 0.0
        assert max_rank <= 1.0
    
    def test_all_10_metrics_present(self, conn):
        """Test that all 10 metrics are in the table."""
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT metric_name FROM peer_percentiles ORDER BY metric_name")
        metrics = [row[0] for row in cursor.fetchall()]
        required_metrics = [
            'Asset_Turnover', 'D/E_inv', 'EPS_CAGR_5yr', 'FCF', 'ICR',
            'NPM', 'PAT_CAGR_5yr', 'Revenue_CAGR_5yr', 'ROE', 'ROCE'
        ]
        assert sorted(metrics) == sorted(required_metrics)
    
    def test_all_11_peer_groups_present(self, conn):
        """Test that all 11 peer groups are in the table."""
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT peer_group_name FROM peer_percentiles ORDER BY peer_group_name")
        groups = [row[0] for row in cursor.fetchall()]
        required_groups = [
            'Automobiles', 'Consumer Finance', 'FMCG', 'IT Services', 'Life Insurance',
            'Oil & Gas', 'Pharmaceuticals', 'Power & Utilities', 'Private Banks',
            'Public Sector Banks', 'Steel'
        ]
        assert sorted(groups) == sorted(required_groups)
    
    def test_unique_constraint_enforced(self, conn):
        """Test that UNIQUE constraint is on (company_id, peer_group_name, metric_name, year)."""
        cursor = conn.cursor()
        cursor.execute("""
            SELECT COUNT(*) FROM (
                SELECT company_id, peer_group_name, metric_name, year
                FROM peer_percentiles
                GROUP BY company_id, peer_group_name, metric_name, year
                HAVING COUNT(*) > 1
            )
        """)
        duplicates = cursor.fetchone()[0]
        assert duplicates == 0
    
    def test_metric_values_non_null(self, conn):
        """Test that metric_value is not NULL for populated rows."""
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM peer_percentiles WHERE metric_value IS NULL")
        null_count = cursor.fetchone()[0]
        assert null_count == 0


class TestGetCompanyPeerPercentiles:
    """Test retrieval of company peer percentiles."""
    
    def test_get_tcs_percentiles(self, pp):
        """Test retrieving TCS percentiles for IT Services peer group."""
        # Get latest year
        cursor = pp.conn.cursor()
        cursor.execute("SELECT DISTINCT year FROM peer_percentiles ORDER BY year DESC LIMIT 1")
        latest_year = cursor.fetchone()[0]
        
        percentiles = pp.get_company_peer_percentiles('TCS', 'IT Services', latest_year)
        assert len(percentiles) > 0
        assert all('metric_name' in p for p in percentiles)
        assert all('metric_value' in p for p in percentiles)
        assert all('percentile_rank' in p for p in percentiles)
    
    def test_percentiles_have_valid_ranks(self, pp):
        """Test that percentile ranks are in valid range."""
        cursor = pp.conn.cursor()
        cursor.execute("SELECT DISTINCT year FROM peer_percentiles ORDER BY year DESC LIMIT 1")
        latest_year = cursor.fetchone()[0]
        
        percentiles = pp.get_company_peer_percentiles('TCS', 'IT Services', latest_year)
        for p in percentiles:
            assert 0.0 <= p['percentile_rank'] <= 1.0
    
    def test_get_percentiles_nonexistent_company(self, pp):
        """Test that retrieving percentiles for non-existent company returns empty list."""
        percentiles = pp.get_company_peer_percentiles('NONEXISTENT', 'IT Services', '9999-12')
        assert len(percentiles) == 0


class TestGetPeerGroupSummary:
    """Test retrieval of peer group summary statistics."""
    
    def test_get_it_services_summary(self, pp):
        """Test retrieving IT Services peer group summary."""
        cursor = pp.conn.cursor()
        cursor.execute("SELECT DISTINCT year FROM peer_percentiles ORDER BY year DESC LIMIT 1")
        latest_year = cursor.fetchone()[0]
        
        # Use NPM which is available for IT Services
        summary = pp.get_peer_group_summary('IT Services', latest_year, 'NPM')
        assert len(summary) > 0
        assert all('company_id' in s for s in summary)
        assert all('company_name' in s for s in summary)
        assert all('metric_value' in s for s in summary)
        assert all('percentile_rank' in s for s in summary)
    
    def test_summary_sorted_by_percentile_desc(self, pp):
        """Test that peer group summary is sorted by percentile_rank descending."""
        cursor = pp.conn.cursor()
        cursor.execute("SELECT DISTINCT year FROM peer_percentiles ORDER BY year DESC LIMIT 1")
        latest_year = cursor.fetchone()[0]
        
        # Use a metric that should have data for IT Services
        summary = pp.get_peer_group_summary('IT Services', latest_year, 'NPM')
        ranks = [s['percentile_rank'] for s in summary]
        assert ranks == sorted(ranks, reverse=True)
    
    def test_summary_highest_rank_first(self, pp):
        """Test that highest percentile rank company is first in summary."""
        cursor = pp.conn.cursor()
        cursor.execute("SELECT DISTINCT year FROM peer_percentiles ORDER BY year DESC LIMIT 1")
        latest_year = cursor.fetchone()[0]
        
        summary = pp.get_peer_group_summary('IT Services', latest_year, 'NPM')
        if len(summary) > 1:
            assert summary[0]['percentile_rank'] >= summary[-1]['percentile_rank']


class TestVerifyPercentileDistribution:
    """Test percentile distribution verification."""
    
    def test_verify_returns_dict(self, pp):
        """Test that verify_percentile_distribution returns a dict."""
        result = pp.verify_percentile_distribution()
        assert isinstance(result, dict)
        assert 'metrics_checked' in result
        assert 'metrics_ok' in result
    
    def test_all_10_metrics_checked(self, pp):
        """Test that all 10 metrics are checked."""
        result = pp.verify_percentile_distribution()
        assert result['metrics_checked'] == 10
    
    def test_all_metrics_ok(self, pp):
        """Test that all metrics pass verification."""
        result = pp.verify_percentile_distribution()
        assert result['metrics_ok'] > 0
        assert len(result['metrics_issues']) == 0


class TestDEInversionLogic:
    """Test D/E inversion logic specifically."""
    
    def test_lower_de_gets_higher_rank(self, pp):
        """Test that companies with lower D/E get higher percentile ranks."""
        cursor = pp.conn.cursor()
        cursor.execute("SELECT DISTINCT year FROM peer_percentiles ORDER BY year DESC LIMIT 1")
        latest_year = cursor.fetchone()[0]
        
        # Get D/E rankings for a peer group
        cursor.execute("""
            SELECT company_id, metric_value, percentile_rank
            FROM peer_percentiles
            WHERE peer_group_name = 'Private Banks' AND metric_name = 'D/E_inv' AND year = ?
            ORDER BY metric_value ASC
        """, (latest_year,))
        
        rows = cursor.fetchall()
        if len(rows) > 1:
            # Company with lowest D/E should have highest or near-highest percentile rank
            lowest_de_company = rows[0]
            # The relationship isn't strictly monotonic due to ties, but trend should hold
            assert lowest_de_company is not None


class TestMissingPeerGroupHandling:
    """Test handling of companies with missing peer group assignments."""
    
    def test_companies_without_peer_group(self, conn):
        """Test that companies without peer group are not in peer_percentiles."""
        cursor = conn.cursor()
        
        # Get companies without peer group
        cursor.execute("""
            SELECT DISTINCT c.id
            FROM companies c
            LEFT JOIN peer_groups pg ON c.id = pg.company_id
            WHERE pg.company_id IS NULL
        """)
        
        no_peer_companies = [row[0] for row in cursor.fetchall()]
        
        if no_peer_companies:
            # Verify these companies are not in peer_percentiles
            for company_id in no_peer_companies[:5]:
                cursor.execute(
                    "SELECT COUNT(*) FROM peer_percentiles WHERE company_id = ?",
                    (company_id,)
                )
                count = cursor.fetchone()[0]
                assert count == 0, f"Company {company_id} should not have peer percentiles"
    
    def test_no_peer_group_companies_reported(self):
        """Test that companies without peer group are properly reported."""
        pp = PeerPercentile(db_path="nifty100.db")
        
        # Get all companies without peer group
        cursor = pp.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT c.id
            FROM companies c
            LEFT JOIN peer_groups pg ON c.id = pg.company_id
            WHERE pg.company_id IS NULL
        """)
        
        expected_no_peer = set(row[0] for row in cursor.fetchall())
        
        # The populate script should handle these gracefully
        assert len(expected_no_peer) > 0, "Should have some companies without peer group"
        
        pp.close()


class TestROCEComputation:
    """Test ROCE computation logic."""
    
    def test_compute_roce_for_valid_company(self, pp):
        """Test computing ROCE for a company with sufficient data."""
        roce = pp._compute_roce('TCS', '2023-03')
        if roce is not None:
            assert isinstance(roce, float)
            assert roce >= 0
    
    def test_compute_roce_nonexistent_company(self, pp):
        """Test that computing ROCE for non-existent company returns None."""
        roce = pp._compute_roce('NONEXISTENT', '9999-12')
        assert roce is None
    
    def test_roce_missing_data_returns_none(self, pp):
        """Test that ROCE returns None when required data is missing."""
        # Try early year when data might be sparse
        roce = pp._compute_roce('TCS', '2010-03')
        # Could be None or a value; just check it's valid if not None
        if roce is not None:
            assert isinstance(roce, float)


class TestEdgeCases:
    """Test edge cases and error handling."""
    
    def test_negative_metric_values(self, pp):
        """Test that negative metric values (like negative FCF) are handled."""
        # Get a sample FCF value that might be negative
        cursor = pp.conn.cursor()
        cursor.execute("""
            SELECT company_id, year, metric_value
            FROM peer_percentiles
            WHERE metric_name = 'FCF' AND metric_value < 0
            LIMIT 1
        """)
        row = cursor.fetchone()
        # If such a value exists, verify it's in the percentiles table
        if row:
            assert row[2] is not None
    
    def test_zero_metric_values(self, pp):
        """Test that zero metric values are handled correctly."""
        cursor = pp.conn.cursor()
        cursor.execute("""
            SELECT COUNT(*)
            FROM peer_percentiles
            WHERE metric_value = 0
        """)
        count = cursor.fetchone()[0]
        # Should have some zero values
        assert count >= 0
    
    def test_identical_metric_values_in_peer_group(self, pp):
        """Test handling of identical metric values (all companies have same value)."""
        # This should still produce valid percentile ranks (all 0.5 or vary slightly)
        cursor = pp.conn.cursor()
        cursor.execute("""
            SELECT DISTINCT percentile_rank
            FROM peer_percentiles
            WHERE metric_name = 'D/E_inv' AND peer_group_name = 'Pharmaceuticals'
            LIMIT 10
        """)
        ranks = [row[0] for row in cursor.fetchall()]
        # All should be valid
        assert all(0.0 <= r <= 1.0 for r in ranks)


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
