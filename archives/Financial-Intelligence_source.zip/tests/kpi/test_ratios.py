"""
Sprint 2 — Day 08: Unit Tests for Profitability Ratios

Tests cover (original 19 + new Financials benchmark tests):

Original Tests:
 1. Normal NPM (positive case)
 2. NPM zero sales → None
 3. NPM negative sales → None
 4. NPM None sales → None
 5. OPM normal
 6. OPM zero sales → None
 7. OPM negative sales → None
 8. ROE normal (positive equity)
 9. ROE negative equity → None
10. ROE zero equity → None
11. ROE negative net profit
12. ROA zero assets → None
13. ROA negative assets → None
14. ROCE normal
15. ROCE zero capital → None
16. ROCE negative capital → None
17. OPM cross-check match within tolerance
18. OPM cross-check mismatch >1%
19. Integration: all ratios consistent

Day 08 Financials Benchmark Tests (new):
20. is_financials_company — Financials sector detected
21. is_financials_company — non-Financials not detected
22. is_financials_company — None input returns False
23. Benchmark ignores None ROCE observations
24. Benchmark computes correct per-year median
25. is_above_benchmark — ROCE above median returns True
26. is_above_benchmark — ROCE below median returns False
27. is_above_benchmark — None ROCE returns None
28. is_above_benchmark — no benchmark for year returns None
29. ROCE formula unchanged for Financials companies
30. all_benchmarks returns all computed years
"""

import pytest
import sys
import os

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.analytics.ratios import ProfitabilityRatios, FinancialsSectorBenchmark


# =========================================================================
# ORIGINAL TESTS (19) — preserved unmodified
# =========================================================================

class TestNetProfitMargin:
    """Test NPM calculations."""

    def test_npm_normal(self):
        """Test 1: Normal NPM calculation."""
        # net_profit=100, sales=500 → NPM = 20%
        result = ProfitabilityRatios.net_profit_margin(net_profit=100, sales=500)
        assert result == pytest.approx(20.0, abs=0.01)

    def test_npm_zero_sales(self):
        """Test 2: NPM with zero sales → None."""
        result = ProfitabilityRatios.net_profit_margin(net_profit=100, sales=0)
        assert result is None

    def test_npm_negative_sales(self):
        """Test 3: NPM with negative sales → None."""
        result = ProfitabilityRatios.net_profit_margin(net_profit=100, sales=-500)
        assert result is None

    def test_npm_none_sales(self):
        """Test 4: NPM with None sales → None."""
        result = ProfitabilityRatios.net_profit_margin(net_profit=100, sales=None)
        assert result is None


class TestOperatingProfitMargin:
    """Test OPM calculations."""

    def test_opm_normal(self):
        """Test 5: Normal OPM calculation."""
        # operating_profit=150, sales=500 → OPM = 30%
        result = ProfitabilityRatios.operating_profit_margin(
            operating_profit=150, sales=500
        )
        assert result == pytest.approx(30.0, abs=0.01)

    def test_opm_zero_sales(self):
        """Test 6: OPM with zero sales → None."""
        result = ProfitabilityRatios.operating_profit_margin(
            operating_profit=150, sales=0
        )
        assert result is None

    def test_opm_negative_sales(self):
        """Test 7: OPM with negative sales → None."""
        result = ProfitabilityRatios.operating_profit_margin(
            operating_profit=150, sales=-500
        )
        assert result is None


class TestReturnOnEquity:
    """Test ROE calculations with negative equity handling."""

    def test_roe_normal(self):
        """Test 8: Normal ROE with positive equity."""
        # net_profit=100, equity=500, reserves=100 → ROE = 100/600 = 16.67%
        result = ProfitabilityRatios.return_on_equity(
            net_profit=100,
            equity_capital=500,
            reserves=100
        )
        assert result == pytest.approx(16.67, abs=0.01)

    def test_roe_negative_equity(self):
        """Test 9: ROE with negative equity → None (MANDATORY edge case)."""
        # net_profit=100, equity=-500, reserves=100 → total=-400 → None
        result = ProfitabilityRatios.return_on_equity(
            net_profit=100,
            equity_capital=-500,
            reserves=100
        )
        assert result is None

    def test_roe_zero_equity(self):
        """Test 10: ROE with zero total equity → None."""
        result = ProfitabilityRatios.return_on_equity(
            net_profit=100,
            equity_capital=0,
            reserves=0
        )
        assert result is None

    def test_roe_negative_net_profit(self):
        """Test 11: ROE with negative net profit (loss)."""
        # net_profit=-50, equity=500, reserves=100 → ROE = -50/600 = -8.33%
        result = ProfitabilityRatios.return_on_equity(
            net_profit=-50,
            equity_capital=500,
            reserves=100
        )
        assert result == pytest.approx(-8.33, abs=0.01)


class TestReturnOnAssets:
    """Test ROA calculations."""

    def test_roa_zero_assets(self):
        """Test 12: ROA with zero assets → None."""
        result = ProfitabilityRatios.return_on_assets(
            net_profit=100, total_assets=0
        )
        assert result is None

    def test_roa_negative_assets(self):
        """Test 13: ROA with negative assets → None."""
        result = ProfitabilityRatios.return_on_assets(
            net_profit=100, total_assets=-500
        )
        assert result is None


class TestROCE:
    """Test ROCE calculations."""

    def test_roce_normal(self):
        """Test 14: ROCE with normal inputs."""
        # EBIT=200, equity=500, reserves=100, borrowings=400 → ROCE = 200/1000 = 20%
        result = ProfitabilityRatios.roce(
            ebit=200,
            equity_capital=500,
            reserves=100,
            borrowings=400
        )
        assert result == pytest.approx(20.0, abs=0.01)

    def test_roce_zero_capital(self):
        """Test 15: ROCE with zero capital employed → None."""
        result = ProfitabilityRatios.roce(
            ebit=200,
            equity_capital=0,
            reserves=0,
            borrowings=0
        )
        assert result is None

    def test_roce_negative_capital(self):
        """Test 16: ROCE with negative capital employed → None."""
        result = ProfitabilityRatios.roce(
            ebit=200,
            equity_capital=500,
            reserves=100,
            borrowings=-800  # Total = -200
        )
        assert result is None


class TestOPMCrossCheck:
    """Test OPM cross-check functionality."""

    def test_opm_match_within_tolerance(self):
        """Test 17: OPM computed vs source match within 1%."""
        computed_opm = 30.0   # (150/500)*100
        source_opm = 30.05    # Within 0.05% → Match
        diff = abs(computed_opm - source_opm)
        assert diff < 1.0, (
            f"OPM mismatch: computed={computed_opm}, source={source_opm}, diff={diff}%"
        )

    def test_opm_mismatch_exceeds_tolerance(self):
        """Test 18: OPM mismatch exceeds 1% → Should be logged."""
        computed_opm = 30.0
        source_opm = 31.5     # Difference = 1.5% > threshold
        diff = abs(computed_opm - source_opm)
        assert diff > 1.0, f"Expected mismatch >1%, got {diff}%"


class TestIntegration:
    """Integration tests with multiple ratios."""

    def test_all_ratios_consistent(self):
        """Test 19: All ratio functions work together without error."""
        npm = ProfitabilityRatios.net_profit_margin(net_profit=100, sales=500)
        opm = ProfitabilityRatios.operating_profit_margin(
            operating_profit=150, sales=500
        )
        roe = ProfitabilityRatios.return_on_equity(
            net_profit=100, equity_capital=500, reserves=100
        )
        roa = ProfitabilityRatios.return_on_assets(net_profit=100, total_assets=1000)
        roce = ProfitabilityRatios.roce(
            ebit=200, equity_capital=500, reserves=100, borrowings=400
        )
        assert npm is not None
        assert opm is not None
        assert roe is not None
        assert roa is not None
        assert roce is not None


# =========================================================================
# DAY 08 NEW TESTS — Financials Sector Benchmark
# =========================================================================

class TestFinancialsSectorDetection:
    """Test is_financials_company() classification."""

    def test_is_financials_company_positive(self):
        """Test 20: broad_sector='Financials' is detected correctly."""
        assert FinancialsSectorBenchmark.is_financials_company("Financials") is True

    def test_is_financials_company_non_financials(self):
        """Test 21: Non-Financials sectors are not classified as Financials."""
        for sector in [
            "Industrials",
            "Information Technology",
            "Consumer Discretionary",
            "Energy",
            "Healthcare",
            "Materials",
            "Consumer Staples",
            "Communication Services",
            "Real Estate",
        ]:
            assert FinancialsSectorBenchmark.is_financials_company(sector) is False, (
                f"Expected False for sector='{sector}'"
            )

    def test_is_financials_company_none_input(self):
        """Test 22: None broad_sector returns False (not Financials)."""
        assert FinancialsSectorBenchmark.is_financials_company(None) is False

    def test_is_financials_company_case_sensitive(self):
        """is_financials_company is case-sensitive (matches DB value exactly)."""
        # DB stores 'Financials' (capital F); 'financials' is not a match
        assert FinancialsSectorBenchmark.is_financials_company("financials") is False
        assert FinancialsSectorBenchmark.is_financials_company("FINANCIALS") is False


class TestFinancialsBenchmarkCalculation:
    """Test FinancialsSectorBenchmark median calculation and edge cases."""

    def _make_benchmark_with_observations(self) -> FinancialsSectorBenchmark:
        """Helper: build a benchmark with known observations for testing."""
        bm = FinancialsSectorBenchmark()
        # Year 2023-03: 5 companies with ROCE values [4, 5, 6, 7, 8]
        # → median = 6.0
        for company, roce in [
            ("BANK_A", 4.0),
            ("BANK_B", 5.0),
            ("BANK_C", 6.0),
            ("BANK_D", 7.0),
            ("BANK_E", 8.0),
        ]:
            bm.add_observation(company, "2023-03", roce)
        # Year 2022-03: 3 companies with ROCE [3, 9, 12]
        # → median = 9.0
        for company, roce in [
            ("BANK_A", 3.0),
            ("BANK_B", 9.0),
            ("BANK_C", 12.0),
        ]:
            bm.add_observation(company, "2022-03", roce)
        return bm

    def test_benchmark_ignores_none_observations(self):
        """Test 23: None ROCE values do not contribute to benchmark."""
        bm = FinancialsSectorBenchmark()
        bm.add_observation("BANK_A", "2023-03", None)   # should be ignored
        bm.add_observation("BANK_B", "2023-03", None)   # should be ignored
        bm.add_observation("BANK_C", "2023-03", 10.0)   # only valid obs

        result = bm.get_benchmark("2023-03")
        assert result == pytest.approx(10.0, abs=0.001)
        assert bm.observation_count("2023-03") == 1

    def test_benchmark_correct_per_year_median_odd(self):
        """Test 24a: Correct median with odd number of observations."""
        bm = self._make_benchmark_with_observations()
        # 2023-03: [4, 5, 6, 7, 8] → median = 6.0
        result = bm.get_benchmark("2023-03")
        assert result == pytest.approx(6.0, abs=0.001)

    def test_benchmark_correct_per_year_median_even(self):
        """Test 24b: Correct median with even number of observations."""
        bm = FinancialsSectorBenchmark()
        # 4 values: [4, 6, 8, 10] → median = (6+8)/2 = 7.0
        for company, roce in [
            ("BANK_A", 4.0),
            ("BANK_B", 6.0),
            ("BANK_C", 8.0),
            ("BANK_D", 10.0),
        ]:
            bm.add_observation(company, "2023-03", roce)
        result = bm.get_benchmark("2023-03")
        assert result == pytest.approx(7.0, abs=0.001)

    def test_benchmark_per_year_isolation(self):
        """Benchmark years are isolated — 2022 median does not affect 2023."""
        bm = self._make_benchmark_with_observations()
        result_2022 = bm.get_benchmark("2022-03")
        result_2023 = bm.get_benchmark("2023-03")
        assert result_2022 == pytest.approx(9.0, abs=0.001)
        assert result_2023 == pytest.approx(6.0, abs=0.001)

    def test_is_above_benchmark_above(self):
        """Test 25: ROCE above median returns True."""
        bm = self._make_benchmark_with_observations()
        # 2023-03 median = 6.0; a value of 7.5 is above
        result = bm.is_above_benchmark(7.5, "2023-03")
        assert result is True

    def test_is_above_benchmark_below(self):
        """Test 26: ROCE below median returns False."""
        bm = self._make_benchmark_with_observations()
        # 2023-03 median = 6.0; a value of 4.0 is below
        result = bm.is_above_benchmark(4.0, "2023-03")
        assert result is False

    def test_is_above_benchmark_none_roce(self):
        """Test 27: None ROCE returns None (cannot assess)."""
        bm = self._make_benchmark_with_observations()
        result = bm.is_above_benchmark(None, "2023-03")
        assert result is None

    def test_is_above_benchmark_no_benchmark_for_year(self):
        """Test 28: No benchmark available for a year returns None."""
        bm = FinancialsSectorBenchmark()
        # No observations added for any year
        result = bm.is_above_benchmark(5.0, "2023-03")
        assert result is None

    def test_roce_formula_unchanged_for_financials(self):
        """
        Test 29: ROCE formula is IDENTICAL for Financials and non-Financials.

        Verifies that the benchmark carve-out does NOT alter the ROCE
        calculation itself. Same inputs must yield same ROCE regardless of
        whether a company is Financials or not.
        """
        # Typical bank-like inputs (high borrowings relative to equity)
        ebit = 50_000.0         # ₹50,000 Cr
        equity_capital = 500.0
        reserves = 80_000.0
        borrowings = 600_000.0

        roce_value = ProfitabilityRatios.roce(
            ebit=ebit,
            equity_capital=equity_capital,
            reserves=reserves,
            borrowings=borrowings,
        )
        expected = (ebit / (equity_capital + reserves + borrowings)) * 100
        assert roce_value == pytest.approx(expected, rel=1e-9)

        # The same value is what a FinancialsSectorBenchmark would compare against.
        # Building a benchmark with the same value → it equals the median exactly.
        bm = FinancialsSectorBenchmark()
        bm.add_observation("BANK_A", "2023-03", roce_value)
        bm.add_observation("BANK_B", "2023-03", roce_value - 1.0)
        bm.add_observation("BANK_C", "2023-03", roce_value + 1.0)

        # Median of [x-1, x, x+1] = x
        assert bm.get_benchmark("2023-03") == pytest.approx(roce_value, rel=1e-9)

    def test_all_benchmarks_returns_all_years(self):
        """Test 30: all_benchmarks() returns entries for every observed year."""
        bm = self._make_benchmark_with_observations()
        result = bm.all_benchmarks()
        assert "2022-03" in result
        assert "2023-03" in result
        assert len(result) == 2


class TestOPMCrossCheckMethod:
    """Test the opm_crosscheck() method directly."""

    def test_crosscheck_within_tolerance_returns_true(self):
        """opm_crosscheck returns True when values are within tolerance."""
        result = ProfitabilityRatios.opm_crosscheck(
            computed_opm=30.0,
            source_opm=30.3,
            company_id="TCS",
            year="2023-03",
        )
        assert result is True

    def test_crosscheck_exceeds_tolerance_returns_false(self):
        """opm_crosscheck returns False when values differ by more than 1%."""
        result = ProfitabilityRatios.opm_crosscheck(
            computed_opm=30.0,
            source_opm=31.5,
            company_id="TCS",
            year="2023-03",
        )
        assert result is False

    def test_crosscheck_none_computed_returns_true(self):
        """opm_crosscheck returns True if computed is None (cannot compare)."""
        result = ProfitabilityRatios.opm_crosscheck(
            computed_opm=None,
            source_opm=30.0,
        )
        assert result is True

    def test_crosscheck_none_source_returns_true(self):
        """opm_crosscheck returns True if source is None (cannot compare)."""
        result = ProfitabilityRatios.opm_crosscheck(
            computed_opm=30.0,
            source_opm=None,
        )
        assert result is True

    def test_crosscheck_exact_tolerance_boundary(self):
        """opm_crosscheck: diff exactly at 1.0 is within tolerance (not >1)."""
        result = ProfitabilityRatios.opm_crosscheck(
            computed_opm=30.0,
            source_opm=31.0,  # diff = 1.0, not > 1.0
        )
        assert result is True


if __name__ == '__main__':
    import pytest as _pytest
    _pytest.main([__file__, '-v'])
