"""
Sprint 2 — Day 09: Unit Tests for Leverage & Efficiency Ratios

Tests cover all 8 required tests plus additional edge-case coverage:

Required (8):
 1. Normal D/E
 2. Debt-free D/E (borrowings=0) returns 0.0
 3. Financials high-D/E warning suppressed
 4. Non-Financials high-D/E flag raised
 5. Normal ICR
 6. Interest = 0 returns None
 7. ICR None + interest=0 produces "Debt Free" label
 8. ICR < 1.5 produces at-risk warning

Additional edge cases:
 9.  D/E with invalid denominator (equity+reserves ≤ 0) → None
10.  D/E with None borrowings → None
11.  D/E exactly at threshold (5.0) does NOT trigger flag (rule is > 5, not ≥ 5)
12.  Non-Financials D/E exactly at threshold is not flagged
13.  Non-Financials D/E above threshold is flagged
14.  Financials D/E above threshold is suppressed (not flagged)
15.  ICR with None operating_profit → None
16.  ICR with None interest → None
17.  ICR ≥ 1.5 does NOT produce warning
18.  ICR None (debt-free) does NOT produce warning (no debt = no risk)
19.  icr_label returns None when ICR is computed (not debt-free)
20.  icr_label returns None when interest > 0 even if ICR is None (data gap, not debt-free)
21.  Net Debt normal (borrowings > investments)
22.  Net Debt negative (net cash position)
23.  Net Debt with None investments treated as 0
24.  Net Debt None borrowings → None
25.  Asset Turnover normal
26.  Asset Turnover with total_assets = 0 → None
27.  Asset Turnover with total_assets < 0 → None
28.  Asset Turnover with None sales → None
29.  compute_all integration — debt-free non-Financials
30.  compute_all integration — high-leverage non-Financials
31.  compute_all integration — high-leverage Financials (suppressed)
32.  compute_all integration — at-risk ICR
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.analytics.leverage import (
    LeverageRatios,
    HIGH_LEVERAGE_DE_THRESHOLD,
    ICR_AT_RISK_THRESHOLD,
    ICR_DEBT_FREE_LABEL,
)


# =========================================================================
# DEBT-TO-EQUITY
# =========================================================================

class TestDebtToEquity:

    def test_de_normal(self):
        """Test 1: Normal D/E calculation."""
        # borrowings=600, equity=500, reserves=100 → D/E = 600/600 = 1.0
        result = LeverageRatios.debt_to_equity(
            borrowings=600, equity_capital=500, reserves=100
        )
        assert result == pytest.approx(1.0, abs=1e-6)

    def test_de_debt_free_returns_zero(self):
        """Test 2: borrowings=0 returns 0.0 (NOT None)."""
        result = LeverageRatios.debt_to_equity(
            borrowings=0, equity_capital=500, reserves=100
        )
        assert result == 0.0
        assert result is not None

    def test_de_invalid_denominator_returns_none(self):
        """Test 9: equity + reserves ≤ 0 → None."""
        result = LeverageRatios.debt_to_equity(
            borrowings=500, equity_capital=-600, reserves=100
        )
        assert result is None  # total_equity = -500 ≤ 0

    def test_de_zero_equity_returns_none(self):
        """equity + reserves = 0 → None."""
        result = LeverageRatios.debt_to_equity(
            borrowings=500, equity_capital=0, reserves=0
        )
        assert result is None

    def test_de_none_borrowings_returns_none(self):
        """Test 10: None borrowings → None."""
        result = LeverageRatios.debt_to_equity(
            borrowings=None, equity_capital=500, reserves=100
        )
        assert result is None

    def test_de_high_value(self):
        """D/E above threshold computes correctly."""
        # borrowings=3000, equity=500, reserves=100 → D/E = 3000/600 = 5.0
        result = LeverageRatios.debt_to_equity(
            borrowings=3000, equity_capital=500, reserves=100
        )
        assert result == pytest.approx(5.0, abs=1e-6)

    def test_de_fractional(self):
        """D/E fractional result (healthy company)."""
        # borrowings=300, equity=500, reserves=700 → D/E = 300/1200 = 0.25
        result = LeverageRatios.debt_to_equity(
            borrowings=300, equity_capital=500, reserves=700
        )
        assert result == pytest.approx(0.25, abs=1e-6)


# =========================================================================
# HIGH LEVERAGE FLAG
# =========================================================================

class TestHighLeverageFlag:

    def test_flag_suppressed_for_financials(self):
        """Test 3: Financials company with D/E >> 5 — flag suppressed."""
        # LICI has D/E > 300 in the database; flag must be False
        result = LeverageRatios.high_leverage_flag(
            de_ratio=332.59, broad_sector="Financials"
        )
        assert result is False

    def test_flag_raised_for_non_financials_above_threshold(self):
        """Test 4: Non-Financials D/E > 5 raises flag."""
        result = LeverageRatios.high_leverage_flag(
            de_ratio=20.0, broad_sector="Energy"
        )
        assert result is True

    def test_flag_not_raised_at_exact_threshold(self):
        """Test 11/12: D/E exactly 5.0 does NOT trigger flag (rule is strictly > 5)."""
        result = LeverageRatios.high_leverage_flag(
            de_ratio=5.0, broad_sector="Energy"
        )
        assert result is False

    def test_flag_raised_just_above_threshold(self):
        """Test 13: D/E = 5.001 for non-Financials → True."""
        result = LeverageRatios.high_leverage_flag(
            de_ratio=5.001, broad_sector="Industrials"
        )
        assert result is True

    def test_flag_not_raised_below_threshold(self):
        """Non-Financials D/E < 5 → no flag."""
        result = LeverageRatios.high_leverage_flag(
            de_ratio=2.5, broad_sector="Healthcare"
        )
        assert result is False

    def test_flag_none_de_returns_false(self):
        """None D/E → False (cannot assess)."""
        result = LeverageRatios.high_leverage_flag(
            de_ratio=None, broad_sector="Energy"
        )
        assert result is False

    def test_flag_suppressed_for_all_financials_subsectors(self):
        """Test 14: All Financials sub-sector companies suppress the flag."""
        for de in [6.0, 10.0, 50.0, 333.0]:
            result = LeverageRatios.high_leverage_flag(
                de_ratio=de, broad_sector="Financials"
            )
            assert result is False, f"Expected False for Financials D/E={de}"

    def test_flag_for_non_financials_various_sectors(self):
        """High D/E (> 5) raises flag for all non-Financials sectors."""
        for sector in ["Energy", "Industrials", "Materials", "Consumer Discretionary",
                       "Healthcare", "Information Technology"]:
            result = LeverageRatios.high_leverage_flag(
                de_ratio=10.0, broad_sector=sector
            )
            assert result is True, f"Expected True for sector='{sector}'"


# =========================================================================
# INTEREST COVERAGE RATIO (ICR)
# =========================================================================

class TestInterestCoverageRatio:

    def test_icr_normal(self):
        """Test 5: Normal ICR calculation."""
        # operating_profit=200, other_income=50, interest=100 → ICR = 250/100 = 2.5
        result = LeverageRatios.interest_coverage_ratio(
            operating_profit=200, other_income=50, interest=100
        )
        assert result == pytest.approx(2.5, abs=1e-6)

    def test_icr_interest_zero_returns_none(self):
        """Test 6: interest = 0 → returns None (per specification)."""
        result = LeverageRatios.interest_coverage_ratio(
            operating_profit=200, other_income=50, interest=0
        )
        assert result is None

    def test_icr_interest_none_returns_none(self):
        """Test 16: interest = None → returns None."""
        result = LeverageRatios.interest_coverage_ratio(
            operating_profit=200, other_income=50, interest=None
        )
        assert result is None

    def test_icr_none_operating_profit_returns_none(self):
        """Test 15: operating_profit = None → returns None."""
        result = LeverageRatios.interest_coverage_ratio(
            operating_profit=None, other_income=50, interest=100
        )
        assert result is None

    def test_icr_none_other_income_treated_as_zero(self):
        """other_income = None is treated as 0 (COALESCE convention)."""
        result = LeverageRatios.interest_coverage_ratio(
            operating_profit=200, other_income=None, interest=100
        )
        assert result == pytest.approx(2.0, abs=1e-6)

    def test_icr_negative_numerator(self):
        """ICR with negative EBIT (loss-making company)."""
        # operating_profit=-300, other_income=50, interest=100 → ICR = -250/100 = -2.5
        result = LeverageRatios.interest_coverage_ratio(
            operating_profit=-300, other_income=50, interest=100
        )
        assert result == pytest.approx(-2.5, abs=1e-6)

    def test_icr_below_threshold(self):
        """ICR = 1.2 (below 1.5 threshold) — confirms numeric result."""
        result = LeverageRatios.interest_coverage_ratio(
            operating_profit=120, other_income=0, interest=100
        )
        assert result == pytest.approx(1.2, abs=1e-6)
        assert result < ICR_AT_RISK_THRESHOLD


# =========================================================================
# ICR LABEL
# =========================================================================

class TestICRLabel:

    def test_label_debt_free(self):
        """Test 7: ICR=None + interest=0 → 'Debt Free' label."""
        result = LeverageRatios.icr_label(icr_value=None, interest=0)
        assert result == ICR_DEBT_FREE_LABEL
        assert result == "Debt Free"

    def test_label_none_when_icr_computed(self):
        """Test 19: When ICR is a valid number, no label is needed."""
        result = LeverageRatios.icr_label(icr_value=3.5, interest=100)
        assert result is None

    def test_label_none_when_interest_nonzero_icr_none(self):
        """Test 20: interest > 0 but ICR = None (data gap) → not 'Debt Free'."""
        # This case can occur if operating_profit is None
        result = LeverageRatios.icr_label(icr_value=None, interest=50)
        assert result is None

    def test_label_none_interest_treated_same_as_zero(self):
        """ICR=None + interest=None → 'Debt Free' (no interest expense)."""
        result = LeverageRatios.icr_label(icr_value=None, interest=None)
        assert result == ICR_DEBT_FREE_LABEL


# =========================================================================
# ICR WARNING FLAG
# =========================================================================

class TestICRWarning:

    def test_warning_icr_below_threshold(self):
        """Test 8: ICR < 1.5 produces at-risk warning."""
        result = LeverageRatios.icr_warning(icr_value=1.2)
        assert result is True

    def test_warning_icr_above_threshold(self):
        """Test 17: ICR ≥ 1.5 does NOT produce warning."""
        result = LeverageRatios.icr_warning(icr_value=2.0)
        assert result is False

    def test_warning_icr_exactly_at_threshold(self):
        """ICR exactly = 1.5 is NOT at-risk (rule is strictly < 1.5)."""
        result = LeverageRatios.icr_warning(icr_value=1.5)
        assert result is False

    def test_warning_icr_none_debt_free(self):
        """Test 18: ICR = None (debt-free) → no warning (no debt = no risk)."""
        result = LeverageRatios.icr_warning(icr_value=None)
        assert result is False

    def test_warning_icr_negative(self):
        """Negative ICR (EBIT < 0) is < 1.5 and triggers warning."""
        result = LeverageRatios.icr_warning(icr_value=-2.5)
        assert result is True

    def test_warning_just_below_threshold(self):
        """ICR = 1.499 is strictly < 1.5 → at-risk."""
        result = LeverageRatios.icr_warning(icr_value=1.499)
        assert result is True


# =========================================================================
# NET DEBT
# =========================================================================

class TestNetDebt:

    def test_net_debt_normal(self):
        """Test 21: Normal net debt (borrowings > investments)."""
        # borrowings=1000, investments=200 → net_debt = 800
        result = LeverageRatios.net_debt(borrowings=1000, investments=200)
        assert result == pytest.approx(800.0, abs=1e-6)

    def test_net_debt_negative_net_cash(self):
        """Test 22: Net cash position (investments > borrowings) → negative."""
        result = LeverageRatios.net_debt(borrowings=200, investments=500)
        assert result == pytest.approx(-300.0, abs=1e-6)

    def test_net_debt_none_investments_treated_as_zero(self):
        """Test 23: investments = None → treated as 0."""
        result = LeverageRatios.net_debt(borrowings=1000, investments=None)
        assert result == pytest.approx(1000.0, abs=1e-6)

    def test_net_debt_none_borrowings_returns_none(self):
        """Test 24: borrowings = None → None."""
        result = LeverageRatios.net_debt(borrowings=None, investments=200)
        assert result is None

    def test_net_debt_zero_borrowings(self):
        """Zero borrowings with investments → negative net debt (net cash)."""
        result = LeverageRatios.net_debt(borrowings=0, investments=300)
        assert result == pytest.approx(-300.0, abs=1e-6)

    def test_net_debt_both_zero(self):
        """Both borrowings and investments = 0 → net debt = 0."""
        result = LeverageRatios.net_debt(borrowings=0, investments=0)
        assert result == pytest.approx(0.0, abs=1e-6)


# =========================================================================
# ASSET TURNOVER
# =========================================================================

class TestAssetTurnover:

    def test_asset_turnover_normal(self):
        """Test 25: Normal asset turnover."""
        # sales=1000, total_assets=500 → AT = 2.0
        result = LeverageRatios.asset_turnover(sales=1000, total_assets=500)
        assert result == pytest.approx(2.0, abs=1e-6)

    def test_asset_turnover_zero_assets_returns_none(self):
        """Test 26: total_assets = 0 → None (per specification)."""
        result = LeverageRatios.asset_turnover(sales=1000, total_assets=0)
        assert result is None

    def test_asset_turnover_negative_assets_returns_none(self):
        """Test 27: total_assets < 0 → None."""
        result = LeverageRatios.asset_turnover(sales=1000, total_assets=-500)
        assert result is None

    def test_asset_turnover_none_sales_returns_none(self):
        """Test 28: sales = None → None."""
        result = LeverageRatios.asset_turnover(sales=None, total_assets=500)
        assert result is None

    def test_asset_turnover_fractional(self):
        """Asset-light company (AT < 1)."""
        # sales=300, total_assets=1000 → AT = 0.3
        result = LeverageRatios.asset_turnover(sales=300, total_assets=1000)
        assert result == pytest.approx(0.3, abs=1e-6)


# =========================================================================
# COMPUTE_ALL INTEGRATION
# =========================================================================

class TestComputeAll:

    def test_compute_all_debt_free_non_financials(self):
        """Test 29: Debt-free non-Financials company — all leverage metrics."""
        result = LeverageRatios.compute_all(
            borrowings=0,
            equity_capital=500,
            reserves=200,
            operating_profit=150,
            other_income=10,
            interest=0,
            investments=50,
            sales=1000,
            total_assets=700,
            broad_sector="Information Technology",
        )
        assert result["debt_to_equity"] == 0.0
        assert result["high_leverage_flag"] is False        # D/E = 0.0, below threshold
        assert result["interest_coverage"] is None          # interest = 0
        assert result["icr_label"] == "Debt Free"
        assert result["icr_warning"] is False               # debt-free = no risk
        assert result["net_debt"] == pytest.approx(-50.0)   # 0 - 50 = -50 (net cash)
        assert result["asset_turnover"] == pytest.approx(1000/700, abs=1e-6)

    def test_compute_all_high_leverage_non_financials(self):
        """Test 30: High-leverage non-Financials — flag raised."""
        result = LeverageRatios.compute_all(
            borrowings=6000,
            equity_capital=500,
            reserves=100,
            operating_profit=200,
            other_income=50,
            interest=300,
            investments=100,
            sales=2000,
            total_assets=8000,
            broad_sector="Energy",
        )
        # D/E = 6000/600 = 10.0 > 5 → flag raised
        assert result["debt_to_equity"] == pytest.approx(10.0, abs=1e-6)
        assert result["high_leverage_flag"] is True
        # ICR = (200+50)/300 = 0.833 < 1.5 → warning
        assert result["interest_coverage"] == pytest.approx(250/300, abs=1e-6)
        assert result["icr_label"] is None
        assert result["icr_warning"] is True
        assert result["net_debt"] == pytest.approx(5900.0)
        assert result["asset_turnover"] == pytest.approx(2000/8000, abs=1e-6)

    def test_compute_all_high_leverage_financials_suppressed(self):
        """Test 31: High-leverage Financials — D/E computed, flag suppressed."""
        result = LeverageRatios.compute_all(
            borrowings=300_000,
            equity_capital=500,
            reserves=80_000,
            operating_profit=50_000,
            other_income=1_000,
            interest=20_000,
            investments=10_000,
            sales=100_000,
            total_assets=400_000,
            broad_sector="Financials",
        )
        de = result["debt_to_equity"]
        # D/E = 300000/80500 ≈ 3.73 — well above 5 for a bank would be:
        # Use unreserved borrowings to force high D/E
        assert de is not None
        # Flag must be suppressed regardless of D/E
        assert result["high_leverage_flag"] is False

    def test_compute_all_at_risk_icr(self):
        """Test 32: Company with ICR < 1.5 — at-risk warning fires."""
        result = LeverageRatios.compute_all(
            borrowings=1000,
            equity_capital=500,
            reserves=200,
            operating_profit=100,
            other_income=0,
            interest=200,           # ICR = 100/200 = 0.5 < 1.5
            investments=50,
            sales=800,
            total_assets=1700,
            broad_sector="Industrials",
        )
        assert result["interest_coverage"] == pytest.approx(0.5, abs=1e-6)
        assert result["icr_warning"] is True
        assert result["icr_label"] is None                  # has interest, not debt-free


if __name__ == '__main__':
    import pytest as _pytest
    _pytest.main([__file__, '-v'])
