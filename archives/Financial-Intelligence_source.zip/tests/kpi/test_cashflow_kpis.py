"""
Sprint 2 — Day 11: Unit Tests for Cash Flow KPIs & Capital Allocation

Tests cover:
  1. FCF normal calculation
  2. Negative FCF allowed
  3. CFO Quality Score calculation
  4. CFO Quality Score classifications (High, Moderate, Accrual Risk)
  5. PAT = 0 handling
  6. CapEx Intensity calculation
  7. CapEx Intensity classifications
  8. FCF Conversion Rate
  9. Operating profit = 0 handling
  10. Capital allocation pattern classification
  11. High CFO/PAT → Shareholder Returns
  12. All 8 capital allocation patterns
  Plus additional edge cases and integrations
"""

import pytest
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from src.analytics.cashflow_kpis import (
    CashFlowKPIs,
    CFO_QUALITY_HIGH,
    CFO_QUALITY_MODERATE,
    CFO_QUALITY_ACCRUAL_RISK,
    CAPEX_ASSET_LIGHT,
    CAPEX_MODERATE,
    CAPEX_CAPITAL_INTENSIVE,
    PATTERN_REINVESTOR,
    PATTERN_SHAREHOLDER_RETURNS,
    PATTERN_LIQUIDATING_ASSETS,
    PATTERN_DISTRESS_SIGNAL,
    PATTERN_GROWTH_FUNDED_BY_DEBT,
    PATTERN_CASH_ACCUMULATOR,
    PATTERN_PRE_REVENUE,
    PATTERN_MIXED,
)


# =========================================================================
# FREE CASH FLOW
# =========================================================================

class TestFreeCashFlow:

    def test_fcf_normal_positive(self):
        """Test 1: Normal FCF calculation (positive CFO, negative CFI)."""
        fcf = CashFlowKPIs.free_cash_flow(
            operating_activity=10000.0,
            investing_activity=-3000.0
        )
        assert fcf == pytest.approx(7000.0, abs=1.0)

    def test_fcf_negative_allowed(self):
        """Test 2: Negative FCF is valid and must NOT be rejected."""
        fcf = CashFlowKPIs.free_cash_flow(
            operating_activity=5000.0,
            investing_activity=-8000.0
        )
        assert fcf == pytest.approx(-3000.0, abs=1.0)
        assert fcf is not None  # Must not convert to None

    def test_fcf_none_operating(self):
        """FCF with None operating activity returns None."""
        fcf = CashFlowKPIs.free_cash_flow(
            operating_activity=None,
            investing_activity=-3000.0
        )
        assert fcf is None

    def test_fcf_none_investing(self):
        """FCF with None investing activity returns None."""
        fcf = CashFlowKPIs.free_cash_flow(
            operating_activity=10000.0,
            investing_activity=None
        )
        assert fcf is None

    def test_fcf_zero_both(self):
        """FCF with both zero cash flows."""
        fcf = CashFlowKPIs.free_cash_flow(
            operating_activity=0.0,
            investing_activity=0.0
        )
        assert fcf == pytest.approx(0.0, abs=0.01)


# =========================================================================
# CFO QUALITY RATIO & SCORE
# =========================================================================

class TestCFOQuality:

    def test_cfo_quality_ratio_normal(self):
        """Test 3: CFO/PAT ratio calculation."""
        ratio = CashFlowKPIs.cfo_quality_ratio(
            operating_activity=12000.0,
            net_profit=10000.0
        )
        assert ratio == pytest.approx(1.2, abs=0.01)

    def test_cfo_quality_ratio_pat_zero(self):
        """Test 5a: PAT = 0 returns None."""
        ratio = CashFlowKPIs.cfo_quality_ratio(
            operating_activity=12000.0,
            net_profit=0.0
        )
        assert ratio is None

    def test_cfo_quality_ratio_pat_none(self):
        """Test 5b: PAT = None returns None."""
        ratio = CashFlowKPIs.cfo_quality_ratio(
            operating_activity=12000.0,
            net_profit=None
        )
        assert ratio is None

    def test_cfo_quality_score_5yr_high(self):
        """Test 4a: CFO Quality 5-year average > 1.0 → High Quality."""
        ratios = [1.1, 1.2, 1.3, 1.05, 1.15]
        avg, label = CashFlowKPIs.cfo_quality_score_5yr(ratios)
        assert avg == pytest.approx(1.16, abs=0.01)
        assert label == CFO_QUALITY_HIGH

    def test_cfo_quality_score_5yr_moderate(self):
        """Test 4b: CFO Quality 5-year average 0.5-1.0 → Moderate."""
        ratios = [0.6, 0.7, 0.8, 0.9, 0.75]
        avg, label = CashFlowKPIs.cfo_quality_score_5yr(ratios)
        assert avg == pytest.approx(0.75, abs=0.01)
        assert label == CFO_QUALITY_MODERATE

    def test_cfo_quality_score_5yr_accrual_risk(self):
        """Test 4c: CFO Quality 5-year average < 0.5 → Accrual Risk."""
        ratios = [0.3, 0.25, 0.4, 0.35, 0.2]
        avg, label = CashFlowKPIs.cfo_quality_score_5yr(ratios)
        assert avg == pytest.approx(0.3, abs=0.01)
        assert label == CFO_QUALITY_ACCRUAL_RISK

    def test_cfo_quality_score_5yr_with_none_values(self):
        """CFO Quality ignores None values; averages valid ratios."""
        ratios = [1.0, None, 1.2, None, 0.8]
        avg, label = CashFlowKPIs.cfo_quality_score_5yr(ratios)
        assert avg == pytest.approx(1.0, abs=0.01)
        assert label == CFO_QUALITY_MODERATE  # avg=1.0 is exactly at boundary

    def test_cfo_quality_score_5yr_all_none(self):
        """CFO Quality with all None values returns (None, None)."""
        ratios = [None, None, None]
        avg, label = CashFlowKPIs.cfo_quality_score_5yr(ratios)
        assert avg is None
        assert label is None

    def test_cfo_quality_score_5yr_boundary_1_0(self):
        """CFO Quality exactly 1.0 → Moderate (not >= comparison)."""
        ratios = [1.0, 1.0, 1.0, 1.0, 1.0]
        avg, label = CashFlowKPIs.cfo_quality_score_5yr(ratios)
        assert avg == pytest.approx(1.0, abs=0.01)
        assert label == CFO_QUALITY_MODERATE

    def test_cfo_quality_score_5yr_boundary_0_5(self):
        """CFO Quality exactly 0.5 → Moderate."""
        ratios = [0.5, 0.5, 0.5]
        avg, label = CashFlowKPIs.cfo_quality_score_5yr(ratios)
        assert avg == pytest.approx(0.5, abs=0.01)
        assert label == CFO_QUALITY_MODERATE


# =========================================================================
# CAPEX INTENSITY
# =========================================================================

class TestCapExIntensity:

    def test_capex_intensity_normal(self):
        """Test 6: CapEx Intensity calculation."""
        capex = CashFlowKPIs.capex_intensity(
            investing_activity=-5000.0,
            sales=100000.0
        )
        assert capex == pytest.approx(5.0, abs=0.01)

    def test_capex_intensity_zero_sales(self):
        """Test 6 edge: CapEx with zero sales returns None."""
        capex = CashFlowKPIs.capex_intensity(
            investing_activity=-5000.0,
            sales=0.0
        )
        assert capex is None

    def test_capex_intensity_none_sales(self):
        """CapEx with None sales returns None."""
        capex = CashFlowKPIs.capex_intensity(
            investing_activity=-5000.0,
            sales=None
        )
        assert capex is None

    def test_capex_intensity_uses_abs(self):
        """CapEx uses absolute value of investing activity."""
        capex1 = CashFlowKPIs.capex_intensity(-5000.0, 100000.0)
        capex2 = CashFlowKPIs.capex_intensity(5000.0, 100000.0)
        assert capex1 == pytest.approx(capex2, abs=0.01)

    def test_capex_intensity_classification_asset_light(self):
        """Test 7a: CapEx < 3% → Asset Light."""
        label = CashFlowKPIs.capex_intensity_classification(2.5)
        assert label == CAPEX_ASSET_LIGHT

    def test_capex_intensity_classification_moderate(self):
        """Test 7b: CapEx 3-8% → Moderate."""
        label = CashFlowKPIs.capex_intensity_classification(5.0)
        assert label == CAPEX_MODERATE

    def test_capex_intensity_classification_capital_intensive(self):
        """Test 7c: CapEx > 8% → Capital Intensive."""
        label = CashFlowKPIs.capex_intensity_classification(10.0)
        assert label == CAPEX_CAPITAL_INTENSIVE

    def test_capex_intensity_classification_boundary_3(self):
        """CapEx exactly 3.0% → Moderate."""
        label = CashFlowKPIs.capex_intensity_classification(3.0)
        assert label == CAPEX_MODERATE

    def test_capex_intensity_classification_boundary_8(self):
        """CapEx exactly 8.0% → Moderate."""
        label = CashFlowKPIs.capex_intensity_classification(8.0)
        assert label == CAPEX_MODERATE

    def test_capex_intensity_classification_none(self):
        """CapEx classification with None input."""
        label = CashFlowKPIs.capex_intensity_classification(None)
        assert label is None


# =========================================================================
# FCF CONVERSION RATE
# =========================================================================

class TestFCFConversionRate:

    def test_fcf_conversion_rate_normal(self):
        """Test 8: FCF Conversion Rate calculation."""
        fcf_conv = CashFlowKPIs.fcf_conversion_rate(
            free_cash_flow=7000.0,
            operating_profit=8000.0
        )
        assert fcf_conv == pytest.approx(87.5, abs=0.1)

    def test_fcf_conversion_rate_operating_profit_zero(self):
        """Test 9a: operating_profit = 0 returns None."""
        fcf_conv = CashFlowKPIs.fcf_conversion_rate(
            free_cash_flow=7000.0,
            operating_profit=0.0
        )
        assert fcf_conv is None

    def test_fcf_conversion_rate_operating_profit_none(self):
        """Test 9b: operating_profit = None returns None."""
        fcf_conv = CashFlowKPIs.fcf_conversion_rate(
            free_cash_flow=7000.0,
            operating_profit=None
        )
        assert fcf_conv is None

    def test_fcf_conversion_rate_negative_fcf(self):
        """FCF Conversion with negative FCF."""
        fcf_conv = CashFlowKPIs.fcf_conversion_rate(
            free_cash_flow=-2000.0,
            operating_profit=8000.0
        )
        assert fcf_conv == pytest.approx(-25.0, abs=0.1)

    def test_fcf_conversion_rate_none_fcf(self):
        """FCF Conversion with None FCF."""
        fcf_conv = CashFlowKPIs.fcf_conversion_rate(
            free_cash_flow=None,
            operating_profit=8000.0
        )
        assert fcf_conv is None


# =========================================================================
# CAPITAL ALLOCATION PATTERNS
# =========================================================================

class TestCapitalAllocationPattern:

    def test_pattern_reinvestor(self):
        """Test 10a: (+, -, -) with normal CFO/PAT → Reinvestor."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=10000.0,
            cfi=-3000.0,
            cff=-2000.0,
            cfo_to_pat_ratio=0.8  # Not high
        )
        assert cfo_sign == "+"
        assert cfi_sign == "-"
        assert cff_sign == "-"
        assert pattern == PATTERN_REINVESTOR

    def test_pattern_shareholder_returns(self):
        """Test 11: (+, -, -) with high CFO/PAT (>1.0) → Shareholder Returns."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=10000.0,
            cfi=-3000.0,
            cff=-2000.0,
            cfo_to_pat_ratio=1.2  # High quality
        )
        assert cfo_sign == "+"
        assert cfi_sign == "-"
        assert cff_sign == "-"
        assert pattern == PATTERN_SHAREHOLDER_RETURNS

    def test_pattern_liquidating_assets(self):
        """Test 12a: (+, +, -) → Liquidating Assets."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=10000.0,
            cfi=2000.0,
            cff=-5000.0,
            cfo_to_pat_ratio=None
        )
        assert pattern == PATTERN_LIQUIDATING_ASSETS

    def test_pattern_distress_signal(self):
        """Test 12b: (-, +, +) → Distress Signal."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=-8000.0,
            cfi=3000.0,
            cff=4000.0,
            cfo_to_pat_ratio=None
        )
        assert pattern == PATTERN_DISTRESS_SIGNAL

    def test_pattern_growth_funded_by_debt(self):
        """Test 12c: (-, -, +) → Growth Funded by Debt."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=-2000.0,
            cfi=-5000.0,
            cff=8000.0,
            cfo_to_pat_ratio=None
        )
        assert pattern == PATTERN_GROWTH_FUNDED_BY_DEBT

    def test_pattern_cash_accumulator(self):
        """Test 12d: (+, +, +) → Cash Accumulator."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=15000.0,
            cfi=3000.0,
            cff=2000.0,
            cfo_to_pat_ratio=None
        )
        assert pattern == PATTERN_CASH_ACCUMULATOR

    def test_pattern_pre_revenue(self):
        """Test 12e: (-, -, -) → Pre-Revenue."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=-1000.0,
            cfi=-5000.0,
            cff=-500.0,
            cfo_to_pat_ratio=None
        )
        assert pattern == PATTERN_PRE_REVENUE

    def test_pattern_mixed(self):
        """Test 12f: (+, -, +) → Mixed."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=10000.0,
            cfi=-3000.0,
            cff=2000.0,
            cfo_to_pat_ratio=None
        )
        assert pattern == PATTERN_MIXED

    def test_pattern_with_zero_values(self):
        """Pattern classification with zero cash flows (treated as sign "0")."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=0.0,
            cfi=1000.0,
            cff=-500.0,
            cfo_to_pat_ratio=None
        )
        assert cfo_sign == "0"
        assert cfi_sign == "+"
        assert cff_sign == "-"

    def test_pattern_with_none_values(self):
        """Pattern classification with None cash flows."""
        cfo_sign, cfi_sign, cff_sign, pattern = CashFlowKPIs.capital_allocation_pattern(
            cfo=None,
            cfi=-3000.0,
            cff=-2000.0,
            cfo_to_pat_ratio=None
        )
        assert cfo_sign is None


# =========================================================================
# INTEGRATION TESTS
# =========================================================================

class TestComputeAllCashFlowKPIs:

    def test_compute_all_normal(self):
        """Compute all cash-flow KPIs in one call."""
        result = CashFlowKPIs.compute_all_cashflow_kpis(
            operating_activity=10000.0,
            investing_activity=-3000.0,
            financing_activity=-2000.0,
            sales=100000.0,
            operating_profit=8000.0,
            net_profit=6000.0,
            cfo_to_pat_historical=[0.9, 1.1, 1.0, 1.05, 0.95]
        )
        assert result["free_cash_flow"] == pytest.approx(7000.0, abs=1.0)
        assert result["cfo_quality_5yr"][0] == pytest.approx(1.0, abs=0.01)
        assert result["cfo_quality_5yr"][1] == CFO_QUALITY_MODERATE
        assert result["capex_intensity_pct"] == pytest.approx(3.0, abs=0.01)
        assert result["capex_intensity_label"] == CAPEX_MODERATE
        assert result["fcf_conversion_rate"] == pytest.approx(87.5, abs=0.1)
        # Current CFO/PAT = 10000/6000 = 1.667 > 1.0 → Shareholder Returns
        assert result["capital_allocation_pattern"][3] == PATTERN_SHAREHOLDER_RETURNS

    def test_compute_all_with_negative_fcf(self):
        """Compute with negative FCF (growth investment phase)."""
        result = CashFlowKPIs.compute_all_cashflow_kpis(
            operating_activity=5000.0,
            investing_activity=-12000.0,
            financing_activity=8000.0,
            sales=100000.0,
            operating_profit=7000.0,
            net_profit=5000.0
        )
        assert result["free_cash_flow"] == pytest.approx(-7000.0, abs=1.0)
        assert result["fcf_conversion_rate"] == pytest.approx(-100.0, abs=0.1)


class TestDay31DistressAndDeleveraging:

    def test_distress_when_cfo_negative_and_cff_positive(self):
        assert CashFlowKPIs.distress_signal(-100.0, 50.0) is True

    def test_no_distress_when_cfo_positive(self):
        assert CashFlowKPIs.distress_signal(100.0, 50.0) is False

    def test_deleveraging_requires_cff_outflow_and_falling_debt(self):
        assert CashFlowKPIs.deleveraging_flag(-20.0, 80.0, 100.0) is True
        assert CashFlowKPIs.deleveraging_flag(-20.0, 120.0, 100.0) is False
        assert CashFlowKPIs.deleveraging_flag(20.0, 80.0, 100.0) is False


if __name__ == '__main__':
    import pytest as _pytest
    _pytest.main([__file__, '-v'])
