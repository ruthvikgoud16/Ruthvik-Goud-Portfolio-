"""AC-05: stored 5-year revenue CAGR must match CAGREngine on annual P&L."""

from pathlib import Path

import pytest

from src.analytics.cagr import CAGREngine, FLAG_NORMAL, extract_metric_history
from src.analytics.company_panel import connect

DB = Path(__file__).resolve().parents[2] / "nifty100.db"


@pytest.mark.skipif(not DB.exists(), reason="nifty100.db not present")
def test_stored_revenue_cagr_matches_canonical_5yr_window():
    conn = connect(DB)
    companies = [r[0] for r in conn.execute("SELECT id FROM companies ORDER BY id")]
    mismatches = []
    checked = 0
    for cid in companies:
        rows = conn.execute(
            "SELECT year, sales FROM profitandloss WHERE company_id=? ORDER BY year",
            (cid,),
        ).fetchall()
        history = extract_metric_history(rows, "sales")
        latest = conn.execute(
            """
            SELECT year, revenue_cagr_5yr
            FROM financial_ratios
            WHERE company_id=? AND year GLOB '20*'
            ORDER BY year DESC
            LIMIT 1
            """,
            (cid,),
        ).fetchone()
        if latest is None:
            continue
        year, stored = latest
        hist_through = [(y, v) for y, v in history if str(y) <= str(year)]
        calc, flag = CAGREngine.cagr(hist_through, 5, "Revenue")
        if flag != FLAG_NORMAL or stored is None or calc is None:
            continue
        checked += 1
        if abs(calc - stored) > 0.1:
            mismatches.append((cid, year, stored, calc, abs(calc - stored)))
    conn.close()
    assert checked >= 80, f"too few NORMAL 5yr CAGRs to validate: {checked}"
    assert mismatches == [], mismatches[:10]
