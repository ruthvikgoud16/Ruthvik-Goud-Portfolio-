"""Streamlit Cloud / local entrypoint at the repository root."""

from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "src" / "dashboard"))

from src.dashboard.app import main

main()
