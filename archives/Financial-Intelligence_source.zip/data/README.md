# Runtime data

The production SQLite database **D-01 `nifty100.db` stays at the repository root**. Dozens of tests and scripts open `nifty100.db` or `./nifty100.db`. Moving it under `data/` would break those paths.

- Raw workbooks: `project_reference/source_data/excel/`
- Database: `./nifty100.db` (gitignored; create with `make load`)
- Derived tables: inside the same SQLite file (`financial_ratios`, `peer_percentiles`, …)

Do not duplicate the database. Do not commit `.db` files.
