# Final analytical outputs

Generated files remain in `output/` (and `reports/`) at the paths tests and exporters already use. This folder is an **index**, not a second copy.

## Deliverable files in `output/`

| File | Notes |
|---|---|
| `capital_allocation.csv` | D-06 |
| `screener_output.xlsx` | D-07 |
| `peer_comparison_report.csv` | D-09 (CSV from PeerComparisonReporter) |
| `valuation_summary.xlsx` | D-12 |
| `cashflow_intelligence.xlsx` | D-13 |
| `pros_cons_generated.csv` | D-14 |
| `analysis_parsed.csv` | D-15 |
| `cluster_labels.csv` | D-19 |
| `ROE_CROSS_VALIDATION_FINAL.csv` | AC-06 evidence |
| `D06_CAPITAL_ALLOCATION_FINAL_AUDIT.csv` | D-06 coverage |
| `D14_PROS_CONS_FINAL_AUDIT.csv` / `D14_RULE_AUDIT.csv` | D-14 coverage |
| `D17_SECTOR_FINAL_AUDIT.csv` | D-17 coverage |
| `SECTOR_SOURCE_RECONCILIATION.md` | 10-sector source note |
| `DAY45_ACCEPTANCE_GATES.md` | Final gate matrix |
| `SPRINT6_FINAL_GATE_REPORT.md` | Sprint 6 close |
| `FINAL_PROJECT_DELIVERY_REPORT.md` | Delivery narrative |
| `FINAL_D06_D14_D17_CLEANUP_REPORT.md` | ATGL / pros-cons / sector cleanup |

Load audits (`load_audit.csv`, `validation_failures.csv`) are produced by `make load` / `make report` and are gitignored as generic `output/*.csv` unless listed in `.gitignore` exceptions.

## Audits

Longer-form discovery notes that are still useful: `output/audits/`.
