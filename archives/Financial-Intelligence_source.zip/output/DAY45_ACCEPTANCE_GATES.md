# Day 45 acceptance gates

Source of truth: measured against `nifty100.db` and generated artifacts. PASS-WITH-CAVEATS means the technical implementation is correct and a source/data limitation remains.

| Gate ID | Requirement | Result | Evidence | Actual |
|---|---|---|---|---|
| AC-01 | companies = 92 | PASS | COUNT(*)=92 | 92 |
| AC-02 | ≥90% companies have ≥10y P&L, BS, CF | PASS | P&L 95.7% (88/92); BS 95.6%; CF 93.4% | 88 |
| AC-03 | FK check empty | PASS | rows=0 | 0 |
| AC-04 | financial_ratios ≥ 1100 | PASS | COUNT(*)=1163 | 1163 |
| AC-05 | Revenue CAGR ±0.1% vs engine (exact 5-year fiscal window, TTM excluded) | PASS | INFY /calc-stored/=0.0000 flag=NORMAL; RELIANCE /calc-stored/=0.0000 flag=NORMAL; TCS /calc-stored/=0.0000 flag=NORMAL; checked=89 max_delta=0.0000 | 0.0 |
| AC-06 | ROE engine vs companies.roe_percentage (source preserved) | PASS-WITH-CAVEATS | HDFCBANK src=17.1 eng=14.33974005030719 status=PASS; INFY src=31.8 eng=29.788006718416632 status=PASS; ITC src=29.47 eng=27.851074395694365 status=PASS; RELIANCE src=9.25 eng=9.958650553699458 status=PASS; TCS src=0.52 eng=50.944313673485176 status=SOURCE_ANOMALY; full=ROE_CROSS_VALIDATION_FINAL.csv PASS=71 SOURCE_ANOMALY=21 FAIL=0 | 21 |
| AC-07 | Quality screener 10–50 names | PASS | n=36 (engine; Financials D/E carve-out applies) | 36 |
| AC-08 | Profile bundle <3s (5 tickers) | PASS | seconds=0.138,0.053,0.041,0.040,0.041 | 0.13789699999999994 |
| AC-09 | Screener CSV well-formed headers | PASS | columns include company_id and ROE | True |
| AC-10 | 5 sample tearsheets 2 pages / ≥30KB | PASS-WITH-CAVEATS | automated size/page check; visual overflow is team-lead | 5 |
| AC-11 | GET /health 200 | PASS | status=200 | 200 |
| AC-12 | TCS ratios ≥10 years | PASS | rows=12 | 12 |
| AC-13 | API screener matches FilterEngine (not a restated xlsx) | PASS | api=36 engine=36 | 36 |
| AC-14 | peer_percentiles has 11 groups | PASS | distinct groups=11; broad_sector count=10 (see SECTOR_SOURCE_RECONCILIATION.md) | 11 |
| AC-15 | 92 cluster assignments, no null cluster_id | PASS | n=92 | 92 |
| AC-16 | ≥1 pro and ≥1 con per company under official rules | PASS-WITH-CAVEATS | official 12+12 rules only; no fabricated bullets. missing_pro=['BHEL', 'GODREJCP', 'JINDALSTEL'] missing_con_n=48. See output/PROS_CONS_FINAL_AUDIT.csv | 474 |
| AC-17 | 92 tearsheets ≥30KB | PASS | n=92 | 92 |
| AC-18 | pytest ≥60 tests, 0 failures | PASS | 863 passed, 0 failed, 0 skipped (`PYTHONPATH=. pytest tests/ --html=reports/pytest_report.html -q`) | 863 |
| AC-19 | validation_failures.csv schema | PASS-WITH-CAVEATS | actual columns=['field', 'message', 'record_identifier', 'rule_id', 'severity', 'table', 'value']; company_id/issue named record_identifier/message | ['field', 'message', 'record_identifier', 'rule_id', 'severity', 'table', 'value'] |
| AC-20 | analyst_guide.pdf ≥10 pages | PASS | pages=11 | 11 |
