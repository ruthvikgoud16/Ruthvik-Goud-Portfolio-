# Repository organization inventory (post-pass)

Legend: **KEEP-PROJECT** production code · **KEEP-FINAL** user-facing evidence · **KEEP-REFERENCE** Bluestock/organizer materials · **KEEP-SCREENSHOT** visual demo · **KEEP-DATA** runtime/source data · **KEEP-TEST** tests · **MOVE** already relocated · **REMOVE** deleted this pass · **SECURITY-REVIEW** inspected

This file was written after the full tree inspection (`git ls-files`, root listing, docs/output/reports). Classifications below are the **final** state.

## Root

| Item | Class | Reason |
|---|---|---|
| `src/` | KEEP-PROJECT | Application code |
| `tests/` | KEEP-TEST | pytest suite |
| `config/screener_config.yaml` | KEEP-PROJECT | D-08 |
| `notebooks/exploratory_queries.sql` | KEEP-FINAL | D-04 |
| `docs/` | KEEP-FINAL | Guides, OpenAPI, sign-off |
| `reports/` | KEEP-FINAL | PDFs, radar, pytest HTML |
| `output/` | KEEP-FINAL | Deliverable CSVs/XLSX and gates |
| `scripts/` | KEEP-PROJECT | Moved from repo root |
| `project_reference/` | KEEP-REFERENCE | Organizer materials |
| `screenshots/` | KEEP-SCREENSHOT | Dashboard/API captures |
| `data/README.md` | KEEP-DATA | Explains root `nifty100.db` |
| `README.md`, `Makefile`, `requirements.txt`, `.gitignore`, `.env.example` | KEEP-PROJECT | Entry points |
| `.env` | SECURITY-REVIEW | Local paths only; gitignored; not committed |
| `nifty100.db` | KEEP-DATA | D-01; gitignored; **not moved** (path compatibility) |
| `venv/` | REMOVE from git | Local environment |
| Root Excel workbooks | MOVE | Now `project_reference/source_data/excel/` |
| Assignment PDF, sprint MD, Day 19 checklist, Week2 pack, `api_response.json` | MOVE | Under `project_reference/` |
| `run_*.py` at root | MOVE | `scripts/` |
| `SPRINT1_DISCOVERY_REPORT.md` | MOVE | `output/audits/` |
| Day-by-day `output/DAY*_VERIFICATION*` (except DAY45) | REMOVE | Development process notes |
| Sprint retrospectives / git-push notes / `output/final_deliverables/` duplicates | REMOVE | Duplicates or process clutter |
| `Week2_Prerequisites/` leftover after move | REMOVE | Duplicate of `project_reference/week2_prerequisites/` |

## `src/` (no package reshuffle)

Existing packages already match etl / analytics / nlp / reports / dashboard / api plus `screener` and `qa`. Forcing extra moves would break imports. **KEEP-PROJECT**.

Path-only updates (not formulas): `SOURCE_DATA_DIR` default; cash-flow repair workbook path; NLP `analysis.xlsx` path.

## `tests/`

**KEEP-TEST.** `tests/etl/test_loader.py` now reads Excel from `project_reference/source_data/excel`. `tests/test_radar_output/` PNGs remain as test artifacts.

## Bluestock reference (preserved, not duplicated)

- `project_reference/requirements/assignment/Nifty100_Project_Document_FINAL (1).pdf`
- `project_reference/requirements/sprint_requirements/PROJECT_SPRINTS_AND_WEEK2_REQUIREMENTS.md`
- `project_reference/requirements/acceptance/DAY19_REQUIREMENTS_CHECKLIST.md`
- `project_reference/requirements/acceptance/REQUIREMENTS_TRACEABILITY.md`
- Twelve `.xlsx` workbooks under `source_data/excel/`
- `source_data/other_data/api_response.json` (Alpha Vantage demo-key **message**, not a live secret)
- `week2_prerequisites/` entire pack

## Intentionally not moved

- `nifty100.db` remains at repo root.
- Deliverable CSVs/XLSX remain in `output/` so exporters and tests keep working. `output/final/README.md` is an index only.
- D-21 HTML moved to `reports/testing/pytest_report.html` (single git mv).

## Security-review notes

- No `sk_live`, GitHub PATs, AWS access keys, or PEM private keys in tracked text files.
- Finnhub usage in Week-2 script is environment-variable based (`your_api_key_here` placeholders).
- `.env` contains `DB_PATH` / `SOURCE_DATA_DIR` / DQ flags only.
- Historical exposure: if a real Finnhub key was ever used on a developer machine, it would not be removed from Git history by this commit; none found in current tracked content.
