# SPRINT 5 GATE REPORT
**Intelligence, NLP & PDF Reports — Days 29–35**

**Date:** 2026-09-12  
**Verdict:** PASS-WITH-CAVEATS  
**Sprint 6:** NOT STARTED

---

## Day 29 (pre-existing, not redone)

`src/nlp/parser.py`, `output/analysis_parsed.csv` (80 parsed fields), cross-validation CSV. Parse failures logged to `output/nlp_parse_failures.csv` (empty body) rather than overwriting Sprint 1 `parse_failures.csv`.

## Deliverable checklist

| Deliverable | Status |
|---|---|
| output/pros_cons_generated.csv | Present — 574 rows, 92 companies. **Not** ≥1 pro and ≥1 con for every company |
| output/analysis_parsed.csv | Present (Day 29) |
| output/cashflow_intelligence.xlsx | Present — 92 rows, required columns |
| output/distress_alerts.csv | Present — 13 companies |
| reports/tearsheets/ | 92 PDFs, 2 pages, ≥30 KB |
| reports/sector/ | 10 PDFs (source has 10 broad sectors, not 11) |
| reports/portfolio/portfolio_summary.pdf | 92 pages |
| src/nlp/parser.py + pros_cons_generator.py | Present |
| src/reports/tearsheet.py + sector_report.py | Present |

## Exit criteria

| Criterion | Result |
|---|---|
| ≥1 pro and ≥1 con for every company | **FAIL vs literal gate** — 91/92 have a pro (BHEL none); 42/92 have a con. Rules were not loosened; rows were not invented |
| 92 tearsheets ≥30 KB | **PASS** |
| Visual review of 5 tearsheets | Sample files exist at 2 pages / ~100 KB; team-lead visual sign-off pending |
| cashflow_intelligence.xlsx 92 rows + columns | **PASS** |
| Sprint 5 review meeting signed off | **NOT DONE** (human) |

## Tests actually run

```
PYTHONPATH=. venv/bin/pytest -q --tb=line
```

**808 passed, 0 failed, 0 skipped, 14 warnings** (matplotlib pyparsing deprecation + urllib3 LibreSSL). Runtime ~41s.

Warnings are environmental, not assertion failures.

## Documented caveats carried forward

1. Pros/cons coverage cannot be forced from the 12+12 thresholds on this universe without fabricating signals.
2. 10 broad sectors in source vs “11 sector PDFs” wording.
3. Capital-allocation CSV missing ATGL; extra `Other (...)` labels from Sprint 2.
4. Abnormal ROE/ROCE from source denominators still appear in tiles/tables.
5. FCF CAGR often null under Sprint 2 CAGR edge-case rules.
6. Distress rule fires on several Financials (CFO/CFF sign pattern).
7. Team-lead meeting / signature is outside this repo.

## Next

Sprint 6 (clustering, FastAPI, full QA pack, analyst guide, acceptance checklist) has **not** been started.
