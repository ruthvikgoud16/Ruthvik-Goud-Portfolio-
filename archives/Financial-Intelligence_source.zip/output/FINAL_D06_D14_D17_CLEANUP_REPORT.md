# Final D-06 / D-14 / D-17 cleanup report

Date: 2026-09-13. No fabricated financials, companies, sectors, or generic pros/cons. **Not committed** (awaiting review).

## D-06 — `output/capital_allocation.csv`

**Previous issue:** ATGL missing (91 companies, 1,056 rows). Sprint 5 `cashflow_intelligence.xlsx` listed ATGL with null cash-flow fields.

**Root cause:** `cashflow.xlsx` stores Adani Total Gas as ticker **`AGTL`** (transposition of **`ATGL`**). Years Mar 2018–Mar 2024 match ATGL P&L. `normalize_ticker` only trimmed/uppercased, so `AGTL` failed the companies-table FK filter and seven real cash-flow rows were dropped. `M&M` already mapped to `MM` because `&` is stripped. This was a company-ID alias bug, not missing source cashflow.

**Fix:**
- `SOURCE_COMPANY_ID_ALIASES = {"AGTL": "ATGL"}` in `normalize_ticker`
- Idempotent repair `src/etl/repair_cashflow_aliases.py` inserts the seven annual rows into SQLite without a full Sprint 1 reload
- Exporter `src/analytics/capital_allocation.py` rebuilds the CSV from annual `cashflow` (LEFT JOIN P&L for CFO/PAT)

**Final coverage:** 92 companies, **1,063** company-years (1,056 + 7 ATGL). Audit: every company `COMPLETE`. ATGL 2018-03–2024-03. Intelligence now labels ATGL **Shareholder Returns** with a computed FCF CAGR.

**Remaining limitation:** None for capital allocation. JIOFIN still has only two source years (complete relative to source).

## D-14 — `output/pros_cons_generated.csv`

**Previous issue:** File existed; some companies had no official pro and/or no official con.

**Rules audited:** All 12 pro + 12 con rules. Independent matrix: `output/D14_RULE_AUDIT.csv` (92 × 24).

**Defects found/fixed:**
- Latest-year / TTM / fiscal collapse already in place from the prior pass
- Pro 7 now treats **interest expense = 0** as Debt Free (Sprint ICR rule), not only D/E = 0. No extra universe rows fired from that (no latest-year interest = 0)
- ATGL FCF now exists; still no extra official con (latest FCF positive; 5-year FCF not all negative)

**Final coverage:** 474 rows, 92 companies in file, confidence_pct > 60.

**Missing pro (SOURCE/RULE LIMITATION):**

| company_id | Why no official pro |
|---|---|
| BHEL | Latest ROE 1.15%, D/E 0.36, FCF −2,382 Cr, Rev CAGR −4.73%, OPM 3.0%, ICR 1.59 (not >10), PAT/EPS CAGR negative |
| GODREJCP | Latest ROE −4.5%, FCF negative, Rev CAGR 6.4% (not >15), OPM 21% (not >25), PAT/EPS CAGR unavailable (sign-change), ICR 2.41 |
| JINDALSTEL | Latest ROE 13.4% (not >20 for 3 years), FCF negative, Rev CAGR 1.40% (not >15), OPM 20.3%, ICR 8.0 (not >10), PAT/EPS CAGR unavailable |

**Missing con:** 48 companies. None of the 12 con thresholds fire on the latest annual series (high-quality names such as TCS/RELIANCE included). Per-company reason column is in `output/D14_PROS_CONS_FINAL_AUDIT.csv`; per-rule evidence is `output/D14_RULE_AUDIT.csv`. Not filled with generic risk language.

## D-17 — `reports/sector/`

**Previous issue:** Tracker asks for 11 sector PDFs; source has 10 `broad_sector` values.

**Reconciliation:** `sectors.xlsx` / `sectors.broad_sector` = 10. `companies.xlsx` has no sector column. 11 **peer groups** are not GICS sectors. Energy includes sub-sector Power & Utilities (6 names). No loader collapse of two broad sectors.

**Authoritative count:** **10**

**Generated PDFs:** **10**, deterministic `reports/sector/<Sector>_report.pdf`, no extras/empties/duplicates. All 92 companies assigned once. Programmatic check: 1+ page, non-empty decompressed text, every sector ticker present.

**Remaining gap:** An 11th PDF would be fabricated. Sponsor mapping required if GICS Utilities must be split from Energy.

## Cross-deliverable IDs

`capital_allocation.csv`, `cashflow_intelligence.xlsx`, `pros_cons_generated.csv`, `companies.id`, and sector PDFs all use canonical IDs (`ATGL`, not `AGTL`).

Downstream regenerated: financial_ratios (ATGL FCF), capital allocation, cashflow intelligence, distress/pattern CSVs, ATGL tearsheet, 10 sector PDFs, valuation_summary.xlsx (FCF yield now 92/92).

## Tests

`PYTHONPATH=. pytest tests/ --html=reports/pytest_report.html -q`

**868 passed, 0 failed, 0 skipped.**
