# Sector source reconciliation

**Question:** Does this project have 11 broad sectors?
**Answer:** No. Every authoritative classification source in the repository has **10** `broad_sector` values. An 11th GICS-style sector was **not** invented.

## Authoritative sources inspected

| Source | Location | Sector-like field | Distinct values | Notes |
|---|---|---|---|---|
| `sectors.xlsx` | project root (Sprint 1 loader input) | `broad_sector` | **10** | 92 rows, one per company |
| `sectors` table | `nifty100.db` | `broad_sector` | **10** | Loaded from `sectors.xlsx` without collapsing names |
| `companies.xlsx` / `companies` table | project root / SQLite | *(none)* | — | No sector column |
| `peer_groups.xlsx` / `peer_percentiles` | project root / SQLite | `peer_group_name` | **11** | Industry peer buckets (Private Banks, IT Services, …), **not** GICS broad sectors |
| Dashboard FilterEngine / API `/api/v1/sectors` | `src/screener/engine.py`, `src/api/routers/sectors.py` | `sectors.broad_sector` | **10** | Read-only from SQLite |
| Clustering | `src/analytics/clustering.py` | joins `sectors.broad_sector` | **10** | Used only for median imputation |

No mapping file, README, or loader step merges two distinct `broad_sector` strings into one. Unique values in Excel and SQLite are identical.

## The 10 broad sectors (company counts)

| broad_sector | companies |
|---|---|
| Communication Services | 2 |
| Consumer Discretionary | 14 |
| Consumer Staples | 7 |
| Energy | 14 |
| Financials | 23 |
| Healthcare | 6 |
| Industrials | 10 |
| Information Technology | 5 |
| Materials | 9 |
| Real Estate | 2 |
| **Total** | **92** |

## Why this is 10, not 11

GICS lists 11 sectors, including **Utilities** as separate from **Energy**. In this Bluestock extract, power and utility names are stored as sub-sector `Power & Utilities` **under** `broad_sector = Energy` (6 companies), not as their own broad sector.

`sub_sector` has **46** values. Those are industry labels, not a hidden 11th broad sector.

The **11 peer groups** (AC-14) are a different taxonomy used for peer percentiles. They must not be copied into `broad_sector`.

## Evidence that no legitimate 11th broad sector exists

1. `SELECT DISTINCT broad_sector FROM sectors` returns 10 rows.
2. `sectors.xlsx` `broad_sector.nunique() == 10`.
3. `companies.xlsx` has no alternate sector column to recover a missing label.
4. Loader `src/etl/loader.py` loads `sectors.xlsx` as-is (`header_row=0`).
5. Sector PDFs are named from actual `broad_sector` strings (`reports/sector/<slug>_report.pdf`) — 10 files, no duplicates, no empty sector.

## Impact on sector PDF generation

`src/reports/run_batch.py` writes one PDF per distinct non-null `broad_sector`. Current files:

- `Communication_Services_report.pdf`
- `Consumer_Discretionary_report.pdf`
- `Consumer_Staples_report.pdf`
- `Energy_report.pdf`
- `Financials_report.pdf`
- `Healthcare_report.pdf`
- `Industrials_report.pdf`
- `Information_Technology_report.pdf`
- `Materials_report.pdf`
- `Real_Estate_report.pdf`

There is no 11th PDF because there is no 11th source sector. Forcing an 11th file would be an empty or fabricated report.

## HUMAN / PROJECT-DATA DECISION REQUIRED

If the sponsor **requires** 11 GICS sectors, they must supply an official mapping (for example, splitting `Energy` / `Power & Utilities` into Utilities). That mapping is **not** in this repository and will not be guessed.

Until then, the platform correctly reports **10** broad sectors.
