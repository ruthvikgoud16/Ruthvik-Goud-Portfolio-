# D-17 sector reconciliation

Authoritative field: `sectors.broad_sector` loaded from `sectors.xlsx`.
Companies in universe: 92. Assigned in sectors table: 92.
Distinct broad_sector values: 10 (not 11).

An 11th GICS sector was not invented. Peer groups (11) are a different taxonomy.
Power & Utilities names sit under Energy as a sub_sector.

| sector | companies | PDF |
|---|---|---|
| Communication Services | 2 | Communication_Services_report.pdf |
| Consumer Discretionary | 14 | Consumer_Discretionary_report.pdf |
| Consumer Staples | 7 | Consumer_Staples_report.pdf |
| Energy | 14 | Energy_report.pdf |
| Financials | 23 | Financials_report.pdf |
| Healthcare | 6 | Healthcare_report.pdf |
| Industrials | 10 | Industrials_report.pdf |
| Information Technology | 5 | Information_Technology_report.pdf |
| Materials | 9 | Materials_report.pdf |
| Real Estate | 2 | Real_Estate_report.pdf |

PDF files on disk: 10. Expected: 10.
Extra PDFs: none. Missing PDFs: none.
Duplicate company assignments: 0.

11-sector requirement: **cannot be satisfied from source data** without a sponsor mapping.
