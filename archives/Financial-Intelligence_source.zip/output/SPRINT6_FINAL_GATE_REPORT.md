# SPRINT 6 GATE REPORT
**API, clustering, QA — Days 36–45 (final acceptance pass)**

**Date:** 2026-09-12
**Verdict:** PASS-WITH-CAVEATS
**Team-lead signature:** Ruthvik Goud — `docs/TEAM_LEAD_SIGNOFF.md`

---

## Tests actually run

```
PYTHONPATH=. pytest tests/ --html=reports/pytest_report.html -q
```

**863 passed, 0 failed, 0 skipped**, ~49s. HTML: `reports/pytest_report.html`.

New coverage in this pass includes canonical 5-year CAGR window tests, DB alignment of stored revenue CAGR, ROE crosswalk statuses, and primary fiscal-year collapse.

## Day-by-day

| Days | Delivered |
|---|---|
| 36–37 | `src/analytics/clustering.py`, `output/cluster_labels.csv` (92), elbow + heatmap, outliers, portfolio_stats |
| 38–40 | FastAPI `src/api/` under `/api/v1`, `docs/openapi.json`, Postman JSON |
| 41 | `tests/etl/test_loader.py`, `tests/dq/test_rules.py` |
| 42 | `tests/api/*` + HTML report |
| 43 | Screener timing notes; SQLite indexes |
| 44 | `docs/analyst_guide.pdf` (11 pages), README run instructions |
| 45 | Acceptance matrix, team-lead sign-off, final delivery report |

## Acceptance gates (measured)

See `output/DAY45_ACCEPTANCE_GATES.md` for the full matrix.

| Gate | Result | Explanation |
|---|---|---|
| AC-01–04 | PASS | 92 companies, coverage, FKs, 1163 ratio rows |
| AC-05 | PASS | Exact 5-year fiscal window; TTM excluded; max \|stored−engine\| = 0.0000 on 89 NORMAL names |
| AC-06 | PASS-WITH-CAVEATS | Engine vs `companies.roe_percentage`; TCS 0.52 is SOURCE_ANOMALY; 21 anomalies, 0 FAIL. CSV: `output/ROE_CROSS_VALIDATION_FINAL.csv` |
| AC-07–09, 11–15, 17, 18, 20 | PASS | Quality screener 36 names; API health; 11 peer groups; 92 clusters; 863 tests; 11-page guide |
| AC-10 | PASS-WITH-CAVEATS | 2 pages and ≥30KB automated; visual overflow remains a human eyeball |
| AC-16 | PASS-WITH-CAVEATS | Official 12+12 only. Missing pro: BHEL, GODREJCP, JINDALSTEL. Missing con: 48 names. Audit: `output/PROS_CONS_FINAL_AUDIT.csv` |
| AC-19 | PASS-WITH-CAVEATS | File exists; columns use `record_identifier`/`message` |
| Broad sectors | 10 (not 11) | `output/SECTOR_SOURCE_RECONCILIATION.md` |

## Final-pass technical fixes (no fabricated data)

1. **CAGREngine** uses latest annual fiscal period minus exactly N years (same month). TTM `9999-12` is never an endpoint. Ratio populator slices history through the row year. Stored 5-year revenue CAGR now matches the engine within 0.1% (exact 0 on checked NORMAL rows).
2. **ROE:** workbook field preserved. Crosswalk statuses PASS / SOURCE_ANOMALY / FAIL — no silent overwrite, no inflated tolerance.
3. **Pros/cons:** primary fiscal month per company (drops intra-year 2024-09 snapshots); debt-free uses floating-point zero. No generic bullets.
4. **Sectors:** confirmed 10 `broad_sector` values in `sectors.xlsx` and SQLite. 11 peer groups are a different taxonomy.

## Other truths

- Dashboard still reads SQLite (`src/dashboard/utils/db.py`), not HTTP. API screener matches `FilterEngine`.
- FilterEngine latest-year query uses `year GLOB '20*'` so TTM is not chosen as latest.
- Cluster with extreme ROE still reflects the Sprint 2 denominator caveat (BEL/HAL).
- 92 tearsheets regenerated after the CAGR fix; all 2 pages and ≥30KB. 10 sector PDFs, no empty duplicates. Portfolio 92 pages.

## How to run

```
streamlit run src/dashboard/app.py
uvicorn src.api.main:app --port 8000
PYTHONPATH=. pytest tests/ --html=reports/pytest_report.html -q
```
