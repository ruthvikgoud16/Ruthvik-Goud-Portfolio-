# DAY 19 REQUIREMENTS CHECKLIST
## Radar Charts Generation

**Date:** 2026-09-05  
**Status:** Discovery Phase Complete  

---

## REQUIREMENT TRACEABILITY MATRIX

### Requirement 1: Radar Chart Generation
**Spec:** "Generate polar/radar chart for each peer group company — 8 axes: ROE, ROCE, NPM, D/E, FCF score, PAT CAGR 5yr, Revenue CAGR 5yr, Composite Score"

| Requirement | Implementation | Test | Verification |
|-------------|-----------------|------|--------------|
| Radar chart for each peer group company | src/analytics/radar.py → RadarChartGenerator.generate_peer_group_chart() | test_generate_peer_group_chart() | PNG file exists with correct axes |
| 8 axes exactly | metrics = [ROE, ROCE, NPM, D/E_inv, FCF, PAT_CAGR_5yr, Revenue_CAGR_5yr, composite_quality_score] | test_8_axes_present() | 8 lines on radar plot |
| Axes correctly labeled | axis_labels = ['ROE (%)', 'ROCE (%)', 'NPM (%)', 'D/E', 'FCF (₹Cr)', 'PAT CAGR (%)', 'Rev CAGR (%)', 'Quality Score'] | test_axis_labels_correct() | PNG displays correct labels |
| Values normalized to [0,100] for display | Normalize each metric independently (min=0, max=100) | test_normalization_range() | All values in [0, 100] |
| Filled polygon for company | plt.fill() for company values | test_filled_polygon_present() | Polygon visible on chart |

**Status:** ✅ Implementation planned

---

### Requirement 2: Peer Group Average Overlay
**Spec:** "Show company values as filled polygon + peer group average as dashed overlay"

| Requirement | Implementation | Test | Verification |
|-------------|-----------------|------|--------------|
| Peer group average computed | Calculate mean of each metric across peer group | test_peer_avg_computed() | Average matches manual SQL calculation |
| Dashed line overlay | plt.plot(linestyle='--') for peer average | test_dashed_line_overlay() | Dashed line visible on chart |
| Both overlays visible | Company = solid fill, Peer avg = dashed | test_both_overlays_visible() | Visual inspection of PNG |
| Legend distinguishing both | legend(['Company', 'Peer Avg']) | test_legend_present() | Legend visible on chart |

**Status:** ✅ Implementation planned

---

### Requirement 3: File Export
**Spec:** "Export as PNG to `reports/radar_charts/` — format: `{company_id}_radar.png`"

| Requirement | Implementation | Test | Verification |
|-------------|-----------------|------|--------------|
| Directory structure | create_if_missing(reports/radar_charts/) | test_directory_exists() | Directory created automatically |
| PNG format | plt.savefig(..., format='png') | test_png_format() | File has .png extension |
| Filename format | f"{company_id}_radar.png" | test_filename_format() | Filename matches spec (e.g., TCS_radar.png) |
| All peer group companies | Generate for each company in peer_groups table | test_all_companies_exported() | 56 PNG files in directory |
| File readable | Image dimensions > 0, can be opened with PIL | test_file_readable() | File size > 0, valid PNG header |

**Status:** ✅ Implementation planned

---

### Requirement 4: Non-Peer Companies Handling
**Spec:** "For non-peer companies: standalone chart with Nifty 100 average"

| Requirement | Implementation | Test | Verification |
|-------------|-----------------|------|--------------|
| Identify non-peer companies | Companies not in peer_groups table (36 companies) | test_identify_non_peer() | Correct count (36) |
| Generate standalone chart | Create radar without peer group overlay | test_non_peer_chart_generated() | PNG exists for non-peer company |
| Nifty 100 average computed | Calculate mean across all 92 companies | test_nifty100_avg_computed() | Average matches manual calculation |
| Dashed overlay for Nifty 100 avg | plt.plot(linestyle='--') for Nifty 100 avg | test_nifty100_overlay() | Dashed line visible on chart |
| Filename still {company_id}_radar.png | Same naming convention | test_non_peer_filename() | File named correctly (e.g., ABB_radar.png) |

**Status:** ✅ Implementation planned

---

### Requirement 5: Library Choice
**Spec:** "Use matplotlib or plotly"

| Requirement | Implementation | Test | Verification |
|-------------|-----------------|------|--------------|
| Use matplotlib | import matplotlib.pyplot as plt | test_matplotlib_import() | No import errors |
| Polar plot | ax = fig.add_subplot(111, projection='polar') | test_polar_projection() | Chart is polar, not Cartesian |
| PNG output capability | savefig supports PNG | test_savefig_png() | PNG files generated successfully |

**Status:** ✅ matplotlib chosen (lighter weight, standard for analytics)

---

## DATA SOURCE REQUIREMENTS

### Data Sources

| Metric | Source Table | Column | Coverage | Status |
|--------|-------------|--------|----------|--------|
| ROE | financial_ratios | return_on_equity_pct | 90.89% | ✅ |
| ROCE | financial_ratios | (computed on-the-fly per Day 18) | ~85% | ✅ |
| NPM | financial_ratios | net_profit_margin_pct | 100.0% | ✅ |
| D/E | financial_ratios | debt_to_equity | 90.89% | ✅ |
| FCF | financial_ratios | free_cash_flow_cr | 90.54% | ✅ |
| PAT CAGR 5yr | financial_ratios | pat_cagr_5yr | 93.55% | ✅ |
| Revenue CAGR 5yr | financial_ratios | revenue_cagr_5yr | 99.74% | ✅ |
| Composite Score | financial_ratios | composite_quality_score | 100.0% | ✅ |
| Peer Average | peer_percentiles | percentile_rank (for context) | Per metric | ✅ |
| Nifty 100 Average | financial_ratios | (compute across all companies) | 100.0% | ✅ |

**Status:** ✅ All data available

---

## NORMALIZATION STRATEGY

**Challenge:** 8 metrics have different scales/units:
- ROE, ROCE, NPM, PAT CAGR, Revenue CAGR: percentages (0-50% typical)
- D/E: ratios (0-3 typical)
- FCF: ₹ Crores (varies by company size)
- Composite Score: 0-100 (already normalized)

**Solution:** Min-Max normalization per metric per peer group
```
normalized_value = ((value - min) / (max - min)) * 100
```
Where min/max are computed from peer group (or Nifty 100 for non-peer).

**Test:** test_normalization_strategy()

---

## EDGE CASES & SPECIAL HANDLING

### Edge Case 1: Missing Metric Values
**Scenario:** Company has NULL FCF in latest year
**Handling:** Skip chart generation for that company-year pair or use 0
**Test:** test_missing_value_handling()

### Edge Case 2: All Companies in Peer Group Have Same Metric
**Scenario:** All 5 IT Services companies have identical ROE (0.0 from NULL)
**Handling:** Set min=max, normalized_value=50 (midpoint)
**Test:** test_identical_values_handling()

### Edge Case 3: Single Company in Peer Group
**Scenario:** Some peer groups might have only 1 company
**Handling:** Generate chart anyway; peer average = company value
**Test:** test_single_company_group()

### Edge Case 4: Non-Peer Company with All Missing Values
**Scenario:** ABB has no compositeScore in latest year
**Handling:** Skip chart generation for that company-year
**Test:** test_non_peer_all_missing()

### Edge Case 5: Very Large or Negative Values
**Scenario:** FCF = -500 Cr (cash burn), D/E = 100 (highly leveraged)
**Handling:** Include in min-max normalization naturally; normalized to [0, 100]
**Test:** test_extreme_values_handling()

---

## OUTPUT STRUCTURE

```
reports/
└── radar_charts/
    ├── TCS_radar.png
    ├── INFY_radar.png
    ├── WIPRO_radar.png
    ├── ABB_radar.png
    ├── ADANIENSOL_radar.png
    └── ... (92 total PNG files, one per company)
```

**Total Files Expected:** 92 (56 peer group + 36 non-peer)

**Directory Creation:** Automatic in code

---

## CHART SPECIFICATIONS

### Visual Properties
- **Chart Type:** Polar (radar)
- **Background:** White or light gray
- **Company Polygon:** Solid fill with semi-transparency (alpha=0.3), dark color
- **Peer Average Line:** Dashed red line (linestyle='--'), linewidth=2
- **Nifty 100 Line (non-peer):** Dashed blue line
- **Grid:** Polar grid visible (theta and radius)
- **Legend:** Top right, with company name and comparison baseline

### Size & DPI
- **Figure Size:** 10 x 10 inches (square for radar)
- **DPI:** 100 (balance quality vs file size)
- **File Size Estimate:** ~50-100 KB per PNG

---

## TEST REQUIREMENTS

**Unit Tests:** tests/analytics/test_radar.py
- 15-20 tests covering all requirements and edge cases
- TestRadarChartGeneration (main functionality)
- TestPeerAverageOverlay (dashed overlay)
- TestNonPeerHandling (Nifty 100 average)
- TestFileExport (PNG generation)
- TestNormalization (value scaling)
- TestEdgeCases (missing values, extremes)

**Integration Tests:**
- Generate all 92 charts in sequence
- Verify all files exist and are readable
- Check for any silent failures

---

## VERIFICATION GATES

**Pre-Implementation:**
- ✅ peer_percentiles table has data (6,658 rows)
- ✅ financial_ratios has composite_quality_score
- ✅ All 92 companies exist in database
- ✅ All 11 peer groups defined

**Post-Implementation:**
- [ ] All 92 PNG files generated successfully
- [ ] Each PNG >= 10 KB and < 500 KB
- [ ] Each PNG has valid matplotlib header
- [ ] Random sample PNG files display correctly in image viewer
- [ ] 92 + 36 = 128 total expected files (future Day 20)
- [ ] No missing chart for any company in peer_groups table

---

## KNOWN CONSTRAINTS & NOTES

1. **ROCE Computation:** Uses Day 18 PeerPercentile class method
2. **Non-Peer Identification:** Companies without peer_groups entry
3. **Latest Year Only:** Charts use TTM (9999-12) or latest available year
4. **No Interactive Charts:** PNG export only (Day 20 will add Excel, which may have interactive elements)
5. **Matplotlib Limitation:** No built-in polar bar charts; using line + fill approach

---

## COMPLETION CRITERIA

| Item | Criteria | Status |
|------|----------|--------|
| Code written | src/analytics/radar.py complete | Pending |
| Tests written | tests/analytics/test_radar.py (15+ tests) | Pending |
| Tests passing | 15+ new tests + 285 regression = 300+ | Pending |
| Charts generated | 92 PNG files in reports/radar_charts/ | Pending |
| Files valid | All PNG readable, > 0 bytes | Pending |
| DB integrity | 0 FK violations after any reads | Pending |
| Documentation | DAY19_VERIFICATION.md complete | Pending |
| Regression | 0 failures in existing test suites | Pending |

---

**Checklist Status:** ✅ COMPLETE — Ready for Phase 2 Implementation

