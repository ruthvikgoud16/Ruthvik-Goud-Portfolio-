# BLUESTOCK FINANCIAL INTELLIGENCE — PROJECT DOCUMENTATION
## Sprint 1 | Sprint 2 | Week 2 Requirements

**Project:** Bluestock Financial Intelligence — Nifty 100 Analytics Platform  
**Duration:** August 18 — September 15, 2026  
**Document Generated:** August 18, 2026  

---

# SPRINT 1 — DATA FOUNDATION & ETL PIPELINE
**Due:** 22 Aug 2026 | **Days:** 01–07 | **Status:** ✅ COMPLETE

## Sprint Goal
Build nifty100.db with 11 tables, load 12 source files with zero CRITICAL failures in final database, implement 16 DQ rules, and pass all ETL tests.

## Days & Deliverables

### Day 01 — Environment Setup
**Tasks:**
- Create venv, requirements.txt, .env, Makefile
- Create directory structure: src/, db/, tests/, output/, notebooks/
- Set up logging and configuration

**Deliverables:**
- Project structure complete
- Dependencies installed
- Build automation ready

### Day 02 — Normalization & Loader
**Tasks:**
- Write src/etl/normaliser.py with normalize_year() and normalize_ticker()
- Handle year format variations: "Mar 2023", "Mar-13", "2019", "2024-09"
- Write loader.py with FK filtering
- Implement 35+ unit tests (20 year + 15 ticker tests)

**Deliverables:**
- normaliser.py with all format handlers
- loader.py with FK validation
- 35+ tests passing

### Day 03 — Validation & DQ Rules
**Tasks:**
- Implement validator.py with 16 DQ rules (DQ-01 to DQ-16)
  - **CRITICAL (4):** DQ-01 (Non-null sales ≥0), DQ-03 (FK integrity), DQ-06 (Sales ≠0), DQ-09 (Year format)
  - **WARNING (12):** DQ-02, DQ-04, DQ-05, DQ-07, DQ-08, DQ-10, DQ-11, DQ-12, DQ-13, DQ-14, DQ-15, DQ-16
- Generate validation_failures.csv with failure details

**Deliverables:**
- validator.py with all 16 rules
- validation_failures.csv schema

### Day 04 — SQLite Schema
**Tasks:**
- Create db/schema.sql with 11 tables:
  - companies, sectors, profitandloss, balancesheet, cashflow, financial_ratios, analysis, documents, prosandcons, stock_prices, peer_groups, market_cap
- Define PKs, FKs, constraints
- Initialize database

**Deliverables:**
- db/schema.sql (11 tables)
- Database file created

### Day 05 — Full Data Load
**Tasks:**
- Load all 12 source files from workspace root
- Execute normalization and FK filtering
- Reject CRITICAL DQ failures before insert
- Generate load_audit.csv
- Verify 0 CRITICAL failures in final DB (1 ADANIENSOL DQ-06 rejected & documented)

**Deliverables:**
- nifty100.db with 12,176 rows
- load_audit.csv (truthful audit trail)
- validation_failures.csv (1 CRITICAL documented)

### Day 06 — Manual Data Quality Review
**Tasks:**
- Select 5 random companies (ADANIGREEN, BAJFINANCE, EICHERMOT, HAL, SUNPHARMA)
- Verify ≥5 years financial data for each
- Cross-table alignment check (P&L ↔ BS ↔ CF)
- Database-wide <5-year check (1 company: JIOFIN, legitimate IPO)
- Investigate anomalies (0 bugs found)

**Deliverables:**
- Day 06 Manual Review Report
- Database integrity verified

### Day 07 — Exploratory Queries & Sprint Wrap-Up
**Tasks:**
- Create 11 exploratory SQL queries (10+ required)
- Final ETL test run (39/39 passing)
- Run all 16 DQ rules (all executed)
- Verify FK check = 0
- Generate Sprint 1 final reports

**Deliverables:**
- notebooks/exploratory_queries.sql (11 queries)
- SPRINT1_FINAL_VERIFICATION_REPORT.txt
- REQUIREMENTS_TRACEABILITY.md
- SPRINT1_RETROSPECTIVE.md

## Final Verification Checklist (Sprint 1)
- ✅ 12 source files processed
- ✅ 11 required tables built (13 total with system)
- ✅ 12,176 total rows loaded
- ✅ companies = 92
- ✅ FK check = 0 violations
- ✅ All 16 DQ rules executed
- ✅ CRITICAL failures in DB = 0 (1 rejected & documented)
- ✅ 39 ETL tests passing (100%)
- ✅ 5 companies manually reviewed
- ✅ Database-wide <5-year analysis complete
- ✅ 11 exploratory SQL queries executed
- ✅ load_audit.csv & validation_failures.csv truthful
- ✅ schema.sql matches database
- ✅ All 7 Makefile targets defined

## Sprint 1 Status
**✅ COMPLETE — PASSED FINAL SANITY AUDIT**
- All 12 technical requirements satisfied
- 0 defects found
- Documentation complete & truthful
- Ready for human sign-off

---

# SPRINT 2 — FINANCIAL RATIO ENGINE
**Due:** 30 Aug 2026 | **Days:** 08–14 | **Story Points:** 42 SP | **Status:** NOT STARTED

## Sprint Goal
Compute 50+ KPIs for all 92 companies across all available years. Populate financial_ratios table with 1,100+ rows. Handle all formula edge cases correctly.

## Days & Deliverables

### Day 08 — Profitability Ratios
**Tasks:**
- Write src/analytics/ratios.py
- Implement Net Profit Margin: net_profit / sales × 100 (return None if sales = 0)
- Implement Operating Profit Margin (cross-check vs opm_percentage, log if difference > 1%)
- Implement ROE: net_profit / (equity_capital + reserves) × 100 (return None if equity+reserves ≤ 0)
- Implement ROCE: EBIT / (equity + reserves + borrowings) × 100
- For Financials sector: use sector-relative ROCE benchmark
- Implement ROA: net_profit / total_assets × 100 (return None if total_assets = 0)
- Write 8 unit tests

**Deliverables:**
- src/analytics/ratios.py (profitability functions)
- 8 passing unit tests

### Day 09 — Leverage & Efficiency Ratios
**Tasks:**
- Implement Debt-to-Equity: borrowings / (equity_capital + reserves) (return 0 if borrowings = 0)
- Add D/E flag: if D/E > 5 AND NOT Financials sector → high_leverage_flag = True
- Implement Interest Coverage: (operating_profit + other_income) / interest (return None if interest = 0)
- For ICR = None (debt-free) → store icr_label = "Debt Free"
- Add ICR warning: if ICR < 1.5 → at-risk flag
- Implement Net Debt: borrowings - investments
- Implement Asset Turnover: sales / total_assets (return None if total_assets = 0)
- Write 8 unit tests

**Deliverables:**
- Leverage & efficiency ratio functions
- 8 passing unit tests

### Day 10 — CAGR Engine (All Growth Metrics)
**Tasks:**
- Write src/analytics/cagr.py
- Implement CAGR formula: ((end/start)^(1/n) - 1) × 100
- Compute Revenue CAGR: 3-year, 5-year, 10-year windows
- Compute PAT (net profit) CAGR: 3-year, 5-year, 10-year windows
- Compute EPS CAGR: 3-year, 5-year, 10-year windows
- Handle 6 edge cases with flags:
  - Positive→Positive: compute normally
  - Positive→Negative: DECLINE_TO_LOSS
  - Negative→Positive: TURNAROUND
  - Negative→Negative: BOTH_NEGATIVE
  - Zero base: ZERO_BASE
  - Insufficient data: INSUFFICIENT
- Store CAGR flag in separate column
- Write 10 unit tests

**Deliverables:**
- src/analytics/cagr.py
- 10 passing unit tests

### Day 11 — Cash Flow KPIs & Capital Allocation
**Tasks:**
- Implement Free Cash Flow: operating_activity + investing_activity (negative allowed)
- Implement CFO Quality Score: CFO/PAT ratio avg over 5 years (>1.0=High, 0.5-1.0=Moderate, <0.5=Accrual Risk)
- Implement CapEx Intensity: abs(investing_activity) / sales × 100 (<3%=Asset Light, 3-8%=Moderate, >8%=Capital Intensive)
- Implement FCF Conversion Rate: FCF / operating_profit × 100 (return None if operating_profit = 0)
- Implement 8-pattern capital allocation classifier based on (CFO sign, CFI sign, CFF sign):
  - (+,-,-) = Reinvestor
  - (+,-,-) with high CFO/PAT = Shareholder Returns
  - (+,+,-) = Liquidating Assets
  - (-,+,+) = Distress Signal
  - (-,-,+) = Growth Funded by Debt
  - (+,+,+) = Cash Accumulator
  - (-,-,-) = Pre-Revenue
  - (+,-,+) = Mixed
- Generate output/capital_allocation.csv

**Deliverables:**
- src/analytics/cashflow_kpis.py
- output/capital_allocation.csv

### Day 12 — Populate financial_ratios Table
**Tasks:**
- Run full ratio engine for all 92 companies across all years
- Populate 14+ KPI columns:
  - net_profit_margin_pct, operating_profit_margin_pct
  - return_on_equity_pct, debt_to_equity, interest_coverage
  - asset_turnover, free_cash_flow_cr, capex_cr
  - earnings_per_share, book_value_per_share, dividend_payout_ratio_pct
  - total_debt_cr, cash_from_operations_cr
  - revenue_cagr_5yr, pat_cagr_5yr, eps_cagr_5yr
  - composite_quality_score
- Verify: SELECT COUNT(*) FROM financial_ratios ≥ 1,100 rows
- Manual spot-check: 3 companies, recompute ROE & 5-year Revenue CAGR, difference < 0.1%

**Deliverables:**
- financial_ratios table populated (≥1,100 rows)
- Manual spot-check completed

### Day 13 — Bank ROCE Carve-Out & Edge Case Log
**Tasks:**
- For 19 Financials sector companies: suppress standard D/E warning (high leverage is structurally normal)
- Cross-check computed ROCE vs roce_percentage column (log anomalies where difference > 5%)
- Cross-check computed ROE vs roe_percentage column (use ratio engine for analytics, source for display)
- Generate output/ratio_edge_cases.log
- Categorize each anomaly: data source issue | version difference | formula discrepancy

**Deliverables:**
- output/ratio_edge_cases.log (all anomalies documented)
- Financials sector carve-out implemented

### Day 14 — Tests & Sprint Review
**Tasks:**
- Run all 20 KPI formula unit tests (0 failures)
- Review ratio_edge_cases.log (all anomalies understood)
- Screener preview: filter ROE > 15% AND D/E < 1 (result count 15-50, makes business sense)
- Sprint 2 retrospective (formula decisions, edge case resolutions)
- Demo financial_ratios table to team lead (5 companies with all KPIs)

**Deliverables:**
- 20 unit tests passing
- Sprint 2 retrospective
- Screener demo results

## Exit Criteria (Definition of Done)
- ✅ SELECT COUNT(*) FROM financial_ratios returns ≥ 1,100 rows
- ✅ All 14 KPI columns populated (zero null-only columns)
- ✅ All 20 KPI formula unit tests pass (0 failures)
- ✅ Manual spot-check: ROE & Revenue CAGR for 3 companies match manual calculation within 0.1%
- ✅ ratio_edge_cases.log exists with documented explanation for every entry
- ✅ Sprint 2 review meeting completed and signed off

## Sprint 2 Deliverables
- financial_ratios table in SQLite (≥1,100 rows, 14+ KPI columns)
- output/capital_allocation.csv (8-pattern label per company-year)
- output/ratio_edge_cases.log (all anomalies documented)
- src/analytics/ratios.py (profitability, leverage, efficiency)
- src/analytics/cagr.py (CAGR engine with edge cases)
- src/analytics/cashflow_kpis.py (CFO quality, CapEx, FCF)
- tests/kpi/ (20 formula unit tests)

---

# WEEK 2 — FINANCIAL STATEMENT ANALYSIS & INSIGHTS
**Due:** Before Day 08 of Sprint 2 (before Financial Ratio Engine implementation)  
**Status:** NOT STARTED  
**Focus:** Analysis layer built on top of Sprint 1 database

## Prerequisites
- Sprint 1 data foundation complete (nifty100.db)
- All 12 source files loaded
- Basic SQL queries working

## Week 2 Learning Objectives
1. Understand financial statement analysis techniques
2. Learn how to extract insights from P&L, BS, CF data
3. Build analytical queries for business decision-making
4. Prepare knowledge base for Sprint 2 KPI definitions

## Week 2 Deliverables

### 1. Stock Market Fundamentals
- Market structure and participant roles
- Nifty 100 index composition and selection criteria
- Stock pricing and valuation basics
- Risk-return trade-offs

### 2. Financial Statement Analysis (TCS Case Study)
- P&L statement deep-dive: revenue recognition, expense categorization, profit margins
- Balance sheet analysis: asset composition, liability structure, equity quality
- Cash flow statement: operating, investing, financing activities
- Financial ratio interpretation: profitability, liquidity, solvency, efficiency
- TCS financial trajectory 2010–2024

### 3. API Data Extraction
- REST API design for financial data
- Authentication and rate limiting
- Data pipeline from external sources to SQLite
- Real-time vs. batch data considerations

### 4. Software Architecture Diagram
- ETL pipeline architecture (Sprint 1)
- Ratio engine architecture (Sprint 2)
- Dashboard & API architecture (Sprint 3+)
- Database schema relationships
- Data flow and dependencies

### 5. FinTech Research Report
- Industry trends in financial analytics
- Competitive landscape analysis
- Technology trends (cloud, ML, APIs)
- Regulatory environment
- Opportunities for Bluestock platform

## Week 2 Key Concepts for Sprint 2 Ratio Engine

### Profitability Analysis
- Gross Profit Margin: (Sales - COGS) / Sales
- Operating Profit Margin: EBIT / Sales
- Net Profit Margin: PAT / Sales
- Return on Equity: PAT / Equity
- Return on Assets: PAT / Total Assets
- Return on Capital Employed: EBIT / (Equity + Debt)

### Leverage & Solvency
- Debt-to-Equity Ratio: Debt / Equity
- Interest Coverage Ratio: EBIT / Interest Expense
- Debt Service Coverage: Operating Cash Flow / Debt Repayment
- Current Ratio: Current Assets / Current Liabilities
- Quick Ratio: (Current Assets - Inventory) / Current Liabilities

### Efficiency Metrics
- Asset Turnover: Sales / Total Assets
- Inventory Turnover: COGS / Inventory
- Receivable Turnover: Sales / Accounts Receivable
- Payable Turnover: COGS / Accounts Payable

### Growth Metrics (CAGR)
- Revenue CAGR: Compound Annual Growth Rate over n years
- Earnings CAGR: PAT growth rate
- EPS CAGR: Earnings per share growth
- Asset CAGR: Growth in total assets

### Cash Flow Analysis
- Operating Cash Flow Quality: CFO / PAT (>1 = high quality)
- Free Cash Flow: Operating CF - Capital Expenditure
- Cash Conversion Cycle: DIO + DSO - DPO
- Capital Allocation Patterns: CFO/CFI/CFF signs → business strategy

### Sector-Specific Considerations
- Banking/Financials: Alternative metrics (Cost-to-Income, Capital Adequacy Ratio)
- Manufacturing: Capital intensity, asset turnover critical
- IT Services: Asset-light model, high margins
- Pharma: R&D intensity, regulatory risks

## Week 2 Resource References
- TCS Financial Analysis (2010–2024 historical data)
- Nifty 100 industry composition
- Financial ratio benchmarks by sector
- Growth rate distributions by industry

---

# PROJECT TIMELINE
```
Week of Aug 18:
  - Sprint 1 Days 01–07 (Data Foundation) — ✅ COMPLETE

Week of Aug 25:
  - Sprint 2 Days 08–14 (Ratio Engine) — PENDING

Week of Sep 1:
  - Sprint 3+ (Dashboard, API, Advanced Analytics) — NOT STARTED

Week 2 Deliverables:
  - Integrated with Sprint 1 database
  - Knowledge base for Sprint 2 implementation
  - Financial analysis case studies
```

---

# TECHNOLOGY STACK

**Sprint 1 (Complete):**
- Python 3.9
- SQLite (nifty100.db)
- pandas (data manipulation)
- pytest (testing)
- openpyxl (Excel reading)

**Sprint 2 (Planned):**
- Python 3.9 (analytics layer)
- NumPy (numerical computations)
- pandas (groupby, rolling calculations)
- pytest (20+ unit tests)

**Week 2 (Learning):**
- Documentation & case studies
- SQL queries for analysis
- Python notebooks (exploratory)

---

# PROJECT GOVERNANCE

**Stakeholders:**
- NK (Nanda Kumar) — Lead
- SI (singhnijjar2022) — Developer
- VA (Varshitha Vadlamuru) — QA
- RU (Ruthvik Goud) — Developer
- AN (Ankitha B67) — Analyst

**Definition of Done:**
- All acceptance criteria met
- Code reviewed and approved
- Unit tests passing (100%)
- Documentation updated
- No fabrication or suppression
- Audit trail complete (if applicable)

---

**Document Version:** 1.0  
**Last Updated:** August 18, 2026  
**Status:** Sprint 1 Complete, Sprint 2 & Week 2 Pending
