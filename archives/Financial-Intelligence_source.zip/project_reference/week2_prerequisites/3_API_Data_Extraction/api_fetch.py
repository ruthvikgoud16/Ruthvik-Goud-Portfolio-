#!/usr/bin/env python3
"""
API Data Extraction Script
===========================

Reproduces the Week 2 API requirement:
- Calls Finnhub real-time stock quote API
- Authenticates using environment variable
- Saves authentic JSON response
- Converts to CSV
- Validates data integrity
- Scans for credential exposure

Usage:
    Set environment variable: export FINNHUB_API_KEY="your_key_here"
    Run: python3 api_fetch.py
"""

import os
import sys
import json
import csv
import urllib.request
import urllib.error
from datetime import datetime

def get_api_key():
    """Read API key from environment variable."""
    key = os.getenv('FINNHUB_API_KEY')
    if not key:
        print("❌ ERROR: FINNHUB_API_KEY environment variable not set")
        print("Set it with: export FINNHUB_API_KEY='your_api_key'")
        sys.exit(1)
    return key

def fetch_stock_quotes(symbols, api_key):
    """Fetch real stock quotes from Finnhub API."""
    quotes = []
    base_url = "https://finnhub.io/api/v1/quote"
    
    print(f"\nFetching {len(symbols)} stock quotes from Finnhub API...")
    
    for symbol in symbols:
        endpoint = f"{base_url}?symbol={symbol}&token={api_key}"
        
        try:
            print(f"  {symbol}...", end=" ", flush=True)
            response = urllib.request.urlopen(endpoint, timeout=10)
            data = json.loads(response.read().decode())
            
            if data.get('c') and data.get('c') > 0:
                quotes.append({
                    "symbol": symbol,
                    "current_price": data.get('c'),
                    "change": data.get('d'),
                    "change_percent": data.get('dp'),
                    "high": data.get('h'),
                    "low": data.get('l'),
                    "open": data.get('o'),
                    "previous_close": data.get('pc'),
                    "timestamp": data.get('t')
                })
                print("✅")
            else:
                print("⚠️  (no data)")
                
        except urllib.error.HTTPError as e:
            print(f"❌ HTTP {e.code}")
        except Exception as e:
            print(f"❌ {e}")
    
    return quotes

def save_json(quotes, filepath):
    """Save quotes as JSON."""
    response = {
        "meta_data": {
            "api_provider": "Finnhub",
            "endpoint": "https://finnhub.io/api/v1/quote",
            "function": "Real-time stock quotes",
            "timestamp": datetime.now().isoformat(),
            "records": len(quotes)
        },
        "quotes": quotes
    }
    
    os.makedirs(os.path.dirname(filepath), exist_ok=True)
    with open(filepath, 'w') as f:
        json.dump(response, f, indent=2)
    
    print(f"✅ Saved JSON: {filepath} ({os.path.getsize(filepath)} bytes)")
    return response

def save_csv(quotes, filepath):
    """Convert JSON to CSV."""
    with open(filepath, 'w', newline='') as f:
        fieldnames = ["symbol", "current_price", "change", "change_percent", 
                      "high", "low", "open", "previous_close", "timestamp"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        
        writer.writeheader()
        for quote in quotes:
            writer.writerow(quote)
    
    print(f"✅ Saved CSV: {filepath} ({os.path.getsize(filepath)} bytes)")

def validate_csv_json_correspondence(quotes, csv_filepath):
    """Verify CSV matches JSON."""
    with open(csv_filepath, 'r') as f:
        reader = csv.DictReader(f)
        csv_rows = list(reader)
    
    if len(quotes) != len(csv_rows):
        print(f"❌ Record count mismatch: JSON={len(quotes)}, CSV={len(csv_rows)}")
        return False
    
    # Spot check first record
    if len(quotes) > 0:
        json_first = quotes[0]
        csv_first = csv_rows[0]
        
        if json_first['symbol'] != csv_first['symbol']:
            print(f"❌ Symbol mismatch: JSON={json_first['symbol']}, CSV={csv_first['symbol']}")
            return False
        
        if str(json_first['current_price']) != csv_first['current_price']:
            print(f"❌ Price mismatch: JSON={json_first['current_price']}, CSV={csv_first['current_price']}")
            return False
    
    print(f"✅ JSON↔CSV validation passed ({len(quotes)} records verified)")
    return True

def scan_for_credentials(filepaths, api_key_redacted_prefix):
    """Security: Check files don't contain API key."""
    print("\n🔒 Security Scan...")
    
    found_exposure = False
    
    for filepath in filepaths:
        if not os.path.exists(filepath):
            continue
        
        with open(filepath, 'r', errors='ignore') as f:
            content = f.read()
        
        # Check for actual API key (first 10 chars should be sufficient)
        if api_key_redacted_prefix in content:
            print(f"❌ SECURITY RISK: API key found in {filepath}")
            found_exposure = True
    
    if not found_exposure:
        print("✅ No API keys exposed in generated files")
    
    return not found_exposure

def main():
    """Main workflow."""
    print("\n" + "=" * 70)
    print("WEEK 2 API REQUIREMENT: REAL PUBLIC API CALL & DATA EXTRACTION")
    print("=" * 70)
    
    # Step 1: Get API key
    api_key = get_api_key()
    api_key_prefix = api_key[:10]  # For security checking
    print(f"✅ API key loaded (length: {len(api_key)})")
    
    # Step 2: Fetch data
    symbols = ["AAPL", "MSFT", "GOOGL", "TSLA", "AMZN"]
    quotes = fetch_stock_quotes(symbols, api_key)
    
    if not quotes:
        print("❌ No quotes retrieved")
        sys.exit(1)
    
    print(f"✅ Retrieved {len(quotes)} quotes")
    
    # Step 3: Save JSON
    base_dir = "/Users/ruthvikgoud/Financial-Intelligence/Week2_Prerequisites/3_API_Data_Extraction"
    json_file = os.path.join(base_dir, "Week2_API_Response_Real.json")
    csv_file = os.path.join(base_dir, "Week2_API_Response_Real.csv")
    
    print("\n" + "=" * 70)
    print("SAVING DATA")
    print("=" * 70)
    
    response = save_json(quotes, json_file)
    save_csv(quotes, csv_file)
    
    # Step 4: Validate
    print("\n" + "=" * 70)
    print("VALIDATION")
    print("=" * 70)
    
    validate_csv_json_correspondence(quotes, csv_file)
    
    # Step 5: Security scan
    security_ok = scan_for_credentials([json_file, csv_file], api_key_prefix)
    
    # Final status
    print("\n" + "=" * 70)
    if security_ok and len(quotes) > 0:
        print("✅ WORKFLOW COMPLETE - API REQUIREMENT SATISFIED")
        print("=" * 70)
        print(f"\nSummary:")
        print(f"  API Provider: Finnhub")
        print(f"  Endpoint: https://finnhub.io/api/v1/quote")
        print(f"  Records Retrieved: {len(quotes)}")
        print(f"  JSON: {json_file}")
        print(f"  CSV: {csv_file}")
        print(f"  Security: ✅ Passed")
        return 0
    else:
        print("❌ WORKFLOW FAILED")
        print("=" * 70)
        return 1

if __name__ == "__main__":
    sys.exit(main())
