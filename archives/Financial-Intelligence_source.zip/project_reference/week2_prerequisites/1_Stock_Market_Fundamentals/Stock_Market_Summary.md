# STOCK MARKET FUNDAMENTALS — ONE-PAGE SUMMARY

**The Stock Market** is a platform where investors buy/sell company shares. India's primary exchanges are **NSE** (National Stock Exchange, 1992) and **BSE** (Bombay Stock Exchange, 1875) [Source: NSE, BSE Official]. Our Nifty 100 dataset covers 92 of the largest 100 NSE-listed companies spanning 12+ years (FY2013–FY2024).

## 20 Core Concepts at a Glance

| **Concept** | **Definition** | **Example** |
|---|---|---|
| **Stock Market** | Trading platform for equity shares [SEBI] | NSE, BSE |
| **NIFTY 100** | Index of 100 largest NSE companies by market cap | 92 in our dataset |
| **SENSEX** | Index of 30 largest BSE companies | BSE benchmark |
| **IPO** | Private company goes public [Zerodha Varsity] | ADANIPORTS, TATAMOTORS |
| **SME IPO** | IPO for smaller companies | Mid-cap growth businesses |
| **Market Cap** | Stock Price × Shares Outstanding | TCS: ₹40L Cr |
| **P/E Ratio** | Stock Price / Earnings Per Share | TCS: 78.69x |
| **P/B Ratio** | Market Cap / Book Value of Equity | NESTLEIND: 14.34x |
| **EPS** | Net Profit / Shares Outstanding | TCS: ₹127–₹135 (12 years) |
| **Dividend** | Cash returned to shareholders | TCS: 50%+ payout ratio |
| **Bonus Shares** | Free shares to existing holders (e.g., 1:5) | No value change |
| **Stock Split** | Shares divided into smaller units (e.g., 1→2) | Improves retail access |
| **Trading Volume** | Shares traded in a period (liquidity) | RELIANCE: 42M+ monthly |
| **Balance Sheet** | Assets = Liabilities + Equity (point-in-time snapshot) | TCS: ₹1.61L Cr assets |
| **P&L Statement** | Revenue − Expenses = Profit (annual) | TCS: ₹2.52L Cr revenue → ₹49K Cr profit |
| **Cash Flow Statement** | Operating + Investing + Financing cash flows | TCS: ₹50K+ Cr operating CF |
| **ROE** | Net Profit / Equity (profitability) | TCS: ~48% (excellent) |
| **D/E Ratio** | Debt / Equity (leverage & risk) | TCS: ~0.1 (very safe) |
| **Current Ratio** | Current Assets / Current Liabilities (liquidity) | Healthy if >1.0 |
| **Operating Margin** | Operating Profit / Revenue (core profitability) | TCS: 26.8% (excellent) |

## Five Analysis Frameworks

1. **Valuation:** Market Cap, P/E, P/B → Fair value?  
2. **Profitability:** EPS, P&L, ROE → Making money?  
3. **Financial Health:** Balance Sheet, D/E, Current Ratio → Stable?  
4. **Cash Generation:** Cash Flow → Growth & dividends sustainable?  
5. **Growth:** Revenue/Profit CAGR → Sustainable growth?

## Real Data Foundation

Our Nifty 100 dataset provides 12+ years of verified P&L, Balance Sheet, and Cash Flow data for 92 companies. This enables rigorous financial analysis and trend identification—exactly what Bluestock's analytics platform does.

---

**Data Sources:** Bluestock Financial Intelligence Platform (companies.xlsx, profitandloss.xlsx, balancesheet.xlsx, cashflow.xlsx, market_cap.xlsx)  
**Coverage:** 92 Nifty 100 companies, FY2013–FY2024 (12+ years) | **Created:** Week 2 Prerequisite

