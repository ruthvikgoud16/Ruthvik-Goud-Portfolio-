# Project reference materials

This directory holds **original project-provided** assignment documents, sprint requirements, and source datasets.

They are retained for reproducibility and context. **Do not edit these files** to “fix” financials. Application code should read Excel sources from `source_data/excel/` without duplicating the workbooks elsewhere.

## Layout

```
project_reference/
├── README.md                          This file
├── requirements/
│   ├── assignment/                    Official assignment PDF
│   ├── sprint_requirements/           Sprint / week structure
│   └── acceptance/                    Requirement checklists and traceability
├── source_data/
│   ├── excel/                         12 Bluestock workbooks used by ETL
│   ├── csv/                           (reserved)
│   └── other_data/                    Sample API demo JSON (not a live secret)
├── reference_pdfs/                    (reserved for extra PDFs)
├── reference_docs/                    (reserved)
└── week2_prerequisites/               Week-2 organizer pack (markets, statements, API demo)
```

## Excel sources (ETL)

`companies`, `profitandloss`, `balancesheet`, `cashflow`, `analysis`, `documents`, `prosandcons`, `sectors`, `stock_prices`, `market_cap`, `financial_ratios`, `peer_groups`.

Set `SOURCE_DATA_DIR=project_reference/source_data/excel` in `.env` (see `.env.example`).

## Not in this folder

Generated outputs (`output/`, `reports/`), application code (`src/`), and tests (`tests/`) are separate. Do not mix scratch notes or agent prompts here.
