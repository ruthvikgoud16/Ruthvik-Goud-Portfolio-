# Repository structure

User-facing map of the N100 Financial Intelligence Platform after the final organization pass. Paths are repository-relative.

## `src/`

Production Python packages:

| Package | Role |
|---|---|
| `src/etl/` | Excel → SQLite load, normalize, validate, cash-flow alias repair |
| `src/analytics/` | Ratios, CAGR, peers, radar, valuation, capital allocation, clustering, cash-flow intelligence |
| `src/nlp/` | Analysis-text parser and official 12+12 pros/cons |
| `src/reports/` | Tearsheets, sector PDFs, portfolio, analyst guide |
| `src/dashboard/` | Streamlit app and eight page modules |
| `src/api/` | FastAPI application and routers |
| `src/screener/` | Filter engine and Excel export |
| `src/qa/` | Acceptance gates and ROE crosswalk |

Do not treat these packages as a dump of notebooks or sprint notes.

## `tests/`

pytest modules grouped by area (`tests/etl`, `tests/analytics`, `tests/nlp`, `tests/reports`, `tests/dashboard`, `tests/api`, plus `tests/kpi` and `tests/screener`). Run from the repo root with `PYTHONPATH=.`.

## `data/`

Documents how runtime data is stored. The live SQLite file remains **`nifty100.db` at the repository root** because many tests and scripts open that path. The file is gitignored; rebuild with `make load`.

## `config/`

`screener_config.yaml` (deliverable D-08).

## `notebooks/`

`exploratory_queries.sql` (deliverable D-04).

## `output/`

Final analytical CSVs/XLSX and acceptance evidence. Writers still target this directory so tests keep working. See `output/final/README.md` for the deliverable index and `output/audits/` for retained audit notes.

## `reports/`

| Subfolder | Contents |
|---|---|
| `reports/tearsheets/` | 92 company PDFs |
| `reports/sector/` | 10 sector PDFs |
| `reports/portfolio/` | Portfolio summary PDF |
| `reports/radar_charts/` | D-10 radar PNGs |
| `reports/testing/` | pytest HTML (D-21) |

Elbow and correlation plots for clustering live at `reports/elbow_plot.png` and `reports/correlation_heatmap.png`.

## `screenshots/`

Portfolio captures of the finished dashboard and API docs. See `screenshots/README.md`.

## `docs/`

Analyst guide PDF, acceptance checklist PDF, OpenAPI JSON, team-lead sign-off, and this structure guide.

## `project_reference/`

**Unmodified** Bluestock / organizer assignment PDFs, sprint text, Excel workbooks, and Week-2 prerequisite pack. Application code reads the Excel files from `project_reference/source_data/excel`.

## `scripts/`

Optional helpers (`run_screener_export.py`, `run_radar_generation.py`, `run_peer_percentiles.py`). Prefer `PYTHONPATH=. python scripts/<name>.py`.
