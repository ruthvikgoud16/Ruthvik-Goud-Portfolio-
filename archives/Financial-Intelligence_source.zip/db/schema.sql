-- Sprint 1 — Data Foundation
-- SQLite Database Schema: nifty100.db
-- 11 Tables with Primary Keys and Foreign Keys
--
-- Load Order (respecting FK dependencies):
-- 1. companies (master table)
-- 2. sectors (independent)
-- 3. profitandloss, balancesheet, cashflow, financial_ratios (FK: company_id)
-- 4. analysis, documents, prosandcons (FK: company_id)
-- 5. stock_prices, market_cap (FK: company_id)
-- 6. peer_groups (FK: company_id, peer_company_id)

-- Enable foreign key enforcement
PRAGMA foreign_keys = ON;

-- =============================================================================
-- TABLE 1: companies (Master Reference Table)
-- =============================================================================
-- Source: companies.xlsx (92 rows, 12 columns)
-- PK: id (company ticker)
-- No FK dependencies

CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY,                    -- Company ticker (ABB, TCS, RELIANCE, etc.)
    company_logo TEXT,                      -- URL to company logo
    company_name TEXT NOT NULL,             -- Full company name
    chart_link TEXT,                        -- URL to price chart
    about_company TEXT,                     -- Company description
    website TEXT,                           -- Corporate website URL
    nse_profile TEXT,                       -- NSE profile URL
    bse_profile TEXT,                       -- BSE profile URL
    face_value REAL,                        -- Face value per share (₹)
    book_value REAL,                        -- Book value per share (₹)
    roce_percentage REAL,                   -- Return on Capital Employed (%)
    roe_percentage REAL                     -- Return on Equity (%)
);

-- =============================================================================
-- TABLE 2: sectors (Sector Classification)
-- =============================================================================
-- Source: sectors.xlsx (92 rows, 6 columns)
-- PK: id
-- FK: company_id → companies(id)

CREATE TABLE IF NOT EXISTS sectors (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    broad_sector TEXT,                      -- Industrials, IT, Financial Services, etc.
    sub_sector TEXT,                        -- Capital Goods, Software, Banks, etc.
    index_weight_pct REAL,                  -- Weight in Nifty 100 index (%)
    market_cap_category TEXT,               -- Large Cap, Mid Cap, Small Cap
    FOREIGN KEY (company_id) REFERENCES companies(id)
);

-- =============================================================================
-- TABLE 3: profitandloss (Annual P&L Statements FY2010-2024)
-- =============================================================================
-- Source: profitandloss.xlsx (1,276 rows, 15 columns)
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, year)

CREATE TABLE IF NOT EXISTS profitandloss (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    year TEXT NOT NULL,                     -- Normalized format: YYYY-MM (e.g., 2014-03)
    sales REAL NOT NULL,                    -- Revenue (₹ Crores)
    expenses REAL,                          -- Operating expenses (₹ Crores)
    operating_profit REAL,                  -- EBIT (₹ Crores)
    opm_percentage REAL,                    -- Operating Profit Margin (%)
    other_income REAL,                      -- Non-operating income (₹ Crores)
    interest REAL,                          -- Interest expense (₹ Crores)
    depreciation REAL,                      -- Depreciation (₹ Crores)
    profit_before_tax REAL,                 -- PBT (₹ Crores)
    tax_percentage REAL,                    -- Tax rate (%)
    net_profit REAL,                        -- PAT (₹ Crores)
    eps REAL,                               -- Earnings Per Share (₹)
    dividend_payout REAL,                   -- Dividend payout ratio (%)
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, year)
);

-- =============================================================================
-- TABLE 4: balancesheet (Annual Balance Sheets FY2010-2024)
-- =============================================================================
-- Source: balancesheet.xlsx (1,312 rows, 13 columns)
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, year)

CREATE TABLE IF NOT EXISTS balancesheet (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    year TEXT NOT NULL,                     -- Normalized format: YYYY-MM
    equity_capital REAL,                    -- Equity share capital (₹ Crores)
    reserves REAL,                          -- Reserves & surplus (₹ Crores)
    borrowings REAL,                        -- Total borrowings (₹ Crores)
    other_liabilities REAL,                 -- Other liabilities (₹ Crores)
    total_liabilities REAL,                 -- Total liabilities (₹ Crores)
    fixed_assets REAL,                      -- Fixed assets (₹ Crores)
    cwip REAL,                              -- Capital Work-In-Progress (₹ Crores)
    investments REAL,                       -- Investments (₹ Crores)
    other_asset REAL,                       -- Other assets (₹ Crores)
    total_assets REAL,                      -- Total assets (₹ Crores)
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, year)
);

-- Add computed column for equity (reserves + equity_capital)
-- Note: SQLite doesn't support ALTER TABLE ADD COMPUTED COLUMN directly
-- This will be computed in application layer for DQ validation

-- =============================================================================
-- TABLE 5: cashflow (Annual Cash Flow Statements FY2010-2024)
-- =============================================================================
-- Source: cashflow.xlsx (1,187 rows, 7 columns)
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, year)

CREATE TABLE IF NOT EXISTS cashflow (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    year TEXT NOT NULL,                     -- Normalized format: YYYY-MM
    operating_activity REAL,                -- Cash from operations (₹ Crores)
    investing_activity REAL,                -- Cash from investing (₹ Crores)
    financing_activity REAL,                -- Cash from financing (₹ Crores)
    net_cash_flow REAL,                     -- Net change in cash (₹ Crores)
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, year)
);

-- Alias for DQ validation
-- operating_activity = cash_from_operations

-- =============================================================================
-- TABLE 6: financial_ratios (Pre-computed Financial Ratios)
-- =============================================================================
-- Source: financial_ratios.xlsx (1,184 rows, 16 columns)
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, year)

CREATE TABLE IF NOT EXISTS financial_ratios (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    year TEXT NOT NULL,                     -- Normalized format: YYYY-MM
    net_profit_margin_pct REAL,             -- Net profit margin (%)
    operating_profit_margin_pct REAL,       -- Operating profit margin (%)
    return_on_equity_pct REAL,              -- ROE (%)
    debt_to_equity REAL,                    -- Debt-to-equity ratio
    interest_coverage REAL,                 -- Interest coverage ratio
    asset_turnover REAL,                    -- Asset turnover ratio
    free_cash_flow_cr REAL,                 -- Free cash flow (₹ Crores)
    capex_cr REAL,                          -- Capital expenditure (₹ Crores)
    earnings_per_share REAL,                -- EPS (₹)
    book_value_per_share REAL,              -- BVPS (₹)
    dividend_payout_ratio_pct REAL,         -- Dividend payout ratio (%)
    total_debt_cr REAL,                     -- Total debt (₹ Crores)
    cash_from_operations_cr REAL,           -- Operating cash flow (₹ Crores)
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, year)
);

-- =============================================================================
-- TABLE 7: analysis (Pre-computed Growth Metrics - PARTIAL DATA)
-- =============================================================================
-- Source: analysis.xlsx (20 rows, 6 columns)
-- Note: Contains data for only 8 companies
-- PK: id
-- FK: company_id → companies(id)

CREATE TABLE IF NOT EXISTS analysis (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL UNIQUE,
    compounded_sales_growth REAL,           -- Sales CAGR (%)
    compounded_profit_growth REAL,          -- Profit CAGR (%)
    stock_price_cagr REAL,                  -- Stock price CAGR (%)
    roe REAL,                               -- Average ROE (%)
    FOREIGN KEY (company_id) REFERENCES companies(id)
);

-- =============================================================================
-- TABLE 8: documents (Annual Report URLs)
-- =============================================================================
-- Source: documents.xlsx (1,585 rows, 4 columns)
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, Year)
-- Note: Year column capitalized in source file

CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    year TEXT NOT NULL,                     -- Source uses "Year" (not normalized)
    annual_report TEXT,                     -- URL to annual report PDF
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, year)
);

-- =============================================================================
-- TABLE 9: prosandcons (Qualitative Insights - PARTIAL DATA)
-- =============================================================================
-- Source: prosandcons.xlsx (16 rows, 4 columns)
-- Note: Contains data for only 8 companies
-- PK: id
-- FK: company_id → companies(id)

CREATE TABLE IF NOT EXISTS prosandcons (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL UNIQUE,
    pros TEXT,                              -- Positive aspects
    cons TEXT,                              -- Risk factors / concerns
    FOREIGN KEY (company_id) REFERENCES companies(id)
);

-- =============================================================================
-- TABLE 10: stock_prices (Monthly OHLCV Data 2020-2024 - SIMULATED)
-- =============================================================================
-- Source: stock_prices.xlsx (5,520 rows, 9 columns)
-- Note: Data labeled as SIMULATED
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, date)

CREATE TABLE IF NOT EXISTS stock_prices (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    date TEXT NOT NULL,                     -- Format: YYYY-MM-DD (monthly data)
    open_price REAL,                        -- Opening price (₹)
    high_price REAL,                        -- High price (₹)
    low_price REAL,                         -- Low price (₹)
    close_price REAL,                       -- Closing price (₹)
    volume INTEGER,                         -- Trading volume
    adjusted_close REAL,                    -- Adjusted closing price (₹)
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, date)
);

-- =============================================================================
-- TABLE 11: market_cap (Valuation Multiples 2019-2024 - SIMULATED)
-- =============================================================================
-- Source: market_cap.xlsx (552 rows, 9 columns)
-- Note: Data labeled as SIMULATED
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, year)

CREATE TABLE IF NOT EXISTS market_cap (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    year INTEGER NOT NULL,                  -- Calendar year (2019, 2020, ...)
    market_cap_crore REAL,                  -- Market capitalization (₹ Crores)
    enterprise_value_crore REAL,            -- Enterprise value (₹ Crores)
    pe_ratio REAL,                          -- Price-to-Earnings ratio
    pb_ratio REAL,                          -- Price-to-Book ratio
    ev_ebitda REAL,                         -- EV/EBITDA multiple
    dividend_yield_pct REAL,                -- Dividend yield (%)
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, year)
);

-- =============================================================================
-- TABLE 12: peer_groups (Peer Group Memberships)
-- =============================================================================
-- Source: peer_groups.xlsx (56 rows, 4 columns)
-- PK: id
-- FK: company_id → companies(id)
-- Note: is_benchmark indicates if company is the benchmark for the peer group

CREATE TABLE IF NOT EXISTS peer_groups (
    id INTEGER PRIMARY KEY,
    peer_group_name TEXT NOT NULL,          -- E.g., "Private Banks", "IT Services"
    company_id TEXT NOT NULL,
    is_benchmark TEXT,                      -- "True" or "False" (stored as TEXT)
    FOREIGN KEY (company_id) REFERENCES companies(id)
);

-- =============================================================================
-- INDEXES FOR QUERY PERFORMANCE
-- =============================================================================

-- Company lookups
CREATE INDEX IF NOT EXISTS idx_companies_name ON companies(company_name);

-- Year-based queries
CREATE INDEX IF NOT EXISTS idx_pl_company_year ON profitandloss(company_id, year);
CREATE INDEX IF NOT EXISTS idx_bs_company_year ON balancesheet(company_id, year);
CREATE INDEX IF NOT EXISTS idx_cf_company_year ON cashflow(company_id, year);
CREATE INDEX IF NOT EXISTS idx_ratios_company_year ON financial_ratios(company_id, year);
CREATE INDEX IF NOT EXISTS idx_docs_company_year ON documents(company_id, year);

-- Stock price lookups
CREATE INDEX IF NOT EXISTS idx_prices_company_date ON stock_prices(company_id, date);
CREATE INDEX IF NOT EXISTS idx_prices_date ON stock_prices(date);

-- Market cap lookups
CREATE INDEX IF NOT EXISTS idx_mcap_company_year ON market_cap(company_id, year);
CREATE INDEX IF NOT EXISTS idx_mcap_year ON market_cap(year);

-- Sector analysis
CREATE INDEX IF NOT EXISTS idx_sectors_company ON sectors(company_id);
CREATE INDEX IF NOT EXISTS idx_sectors_broad ON sectors(broad_sector);
CREATE INDEX IF NOT EXISTS idx_sectors_sub ON sectors(sub_sector);

-- Peer group analysis
CREATE INDEX IF NOT EXISTS idx_peers_group ON peer_groups(peer_group_name);
CREATE INDEX IF NOT EXISTS idx_peers_company ON peer_groups(company_id);

-- =============================================================================
-- SCHEMA VERSION & METADATA
-- =============================================================================

CREATE TABLE IF NOT EXISTS schema_metadata (
    key TEXT PRIMARY KEY,
    value TEXT
);

INSERT OR REPLACE INTO schema_metadata (key, value) VALUES ('version', '1.0');
INSERT OR REPLACE INTO schema_metadata (key, value) VALUES ('created_date', datetime('now'));
INSERT OR REPLACE INTO schema_metadata (key, value) VALUES ('sprint', 'Sprint 1 - Data Foundation');
INSERT OR REPLACE INTO schema_metadata (key, value) VALUES ('table_count', '11');
INSERT OR REPLACE INTO schema_metadata (key, value) VALUES ('source_files', '12');

-- =============================================================================
-- END OF SCHEMA
-- =============================================================================

-- =============================================================================
-- TABLE 13: peer_percentiles (Peer Group Percentile Rankings - Day 18)
-- =============================================================================
-- Computed metrics: PERCENT_RANK for 10 KPIs within each peer group by year
-- PK: id
-- FK: company_id → companies(id)
-- Composite Unique: (company_id, peer_group_name, metric_name, year)

CREATE TABLE IF NOT EXISTS peer_percentiles (
    id INTEGER PRIMARY KEY,
    company_id TEXT NOT NULL,
    peer_group_name TEXT NOT NULL,          -- E.g., "IT Services", "Private Banks"
    metric_name TEXT NOT NULL,              -- ROE, ROCE, NPM, D/E_inv, FCF, etc.
    metric_value REAL,                      -- Original metric value (before percentile)
    percentile_rank REAL,                   -- PERCENT_RANK within peer group (0.0-1.0)
    year TEXT NOT NULL,                     -- Fiscal year (YYYY-MM format)
    FOREIGN KEY (company_id) REFERENCES companies(id),
    UNIQUE(company_id, peer_group_name, metric_name, year)
);

-- Index for efficient peer_percentile queries
CREATE INDEX IF NOT EXISTS idx_peer_percentiles_group_year ON peer_percentiles(peer_group_name, year);
CREATE INDEX IF NOT EXISTS idx_peer_percentiles_company ON peer_percentiles(company_id);
CREATE INDEX IF NOT EXISTS idx_peer_percentiles_metric ON peer_percentiles(metric_name);

