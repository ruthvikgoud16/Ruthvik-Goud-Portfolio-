# Screenshots

Captures of the finished Streamlit dashboard (port 8501) and FastAPI docs (port 8000). These are for GitHub visitors; they are not a substitute for running the app.

## Dashboard

| File | Screen | What it shows |
|---|---|---|
| [dashboard/01_home.png](dashboard/01_home.png) | Home | Market overview KPIs and year controls |
| [dashboard/02_profile.png](dashboard/02_profile.png) | Company Profile | Single-company statements and KPIs |
| [dashboard/03_screener.png](dashboard/03_screener.png) | Screener | Filters and result table |
| [dashboard/04_peers.png](dashboard/04_peers.png) | Peer Comparison | Peer metrics / radar |
| [dashboard/05_trends.png](dashboard/05_trends.png) | Trend Analysis | Historical metric chart |
| [dashboard/06_sector.png](dashboard/06_sector.png) | Sector Analysis | Sector comparison view |
| [dashboard/07_capital_allocation.png](dashboard/07_capital_allocation.png) | Capital Allocation | Allocation visualization |
| [dashboard/08_reports.png](dashboard/08_reports.png) | Annual Reports | Report links for a company |

## API

| File | What it shows |
|---|---|
| [api/01_openapi_docs.png](api/01_openapi_docs.png) | FastAPI Swagger UI at `/docs` |

`website/` is reserved for additional public-site captures if added later.

## iQOO Neo 10 submission pack

Phone-oriented demo materials (device profile, checklist, demo script, portrait captures):

→ [submission/iqoo_neo10/](../submission/iqoo_neo10/)
