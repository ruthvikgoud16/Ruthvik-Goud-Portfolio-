# Documentation

| Path | Contents |
|---|---|
| `guides/` | README, repository structure, team-lead sign-off, analyst guide PDF, acceptance checklist PDF, OpenAPI |
| `acceptance/` | Day-45 gates, final delivery report, ROE cross-check, sector reconciliation |
| `screenshots/` | Desktop dashboard + API captures |
| `reports_sample/` | Sample TCS tearsheet, IT sector PDF, portfolio summary |
| `architecture/` | Week-2 architecture notes |
| Assignment PDF | Bluestock project document (if present at Documentation root) |

Status: **PASS-WITH-CAVEATS** — see acceptance folder.
