# Demo Video — what to put here

Upload **one** video file (MP4 preferred), 3–6 minutes.

Suggested filename:
`Ruthvik_N100_Financial_Intelligence_Demo.mp4`

## How to record (fast)

### Option A — Laptop (easiest)

1. Start the app:
   ```bash
   cd Financial-Intelligence
   source venv/bin/activate
   export PYTHONPATH=.
   streamlit run streamlit_app.py
   ```
2. Open http://localhost:8501
3. macOS: **Cmd+Shift+5** → Record Selected Portion (browser window)
4. Follow `RECORDING_SCRIPT.md` (same folder)

### Option B — iQOO Neo 10

1. Open your Streamlit Cloud URL in Chrome
2. Screen record (notification shade → Screen record)
3. Portrait mode; walk the 8 screens

### Option C — Loom / OBS

Record browser tab; export MP4 into this folder.

## Must show in the video

1. Home KPIs (92 companies)
2. Company Profile (search TCS or INFY)
3. Screener + Quality preset
4. At least one of: Peers / Trends / Sector
5. Capital Allocation treemap
6. Reports screen
7. (Optional) API `/docs` on laptop

## Do not

- Do not invent numbers while speaking
- Say **N/A** when the UI shows N/A
- Mention PASS-WITH-CAVEATS briefly at the end
