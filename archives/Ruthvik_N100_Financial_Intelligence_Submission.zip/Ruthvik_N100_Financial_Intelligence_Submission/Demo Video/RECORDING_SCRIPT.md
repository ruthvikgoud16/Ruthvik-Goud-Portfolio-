# Recording script (≈4 min)

0:00 Intro — “N100 Financial Intelligence for 92 Nifty 100 companies.”
0:20 Home — KPIs, sector donut, quality table
0:50 Profile — pick TCS; ROE, charts, pros/cons
1:30 Screener — Quality preset; show match count + table
2:10 Peers or Trends — short
2:40 Sector — Financials or IT; 10 sectors only
3:00 Capital Allocation — treemap
3:20 Reports — tearsheet / annual report cards
3:40 Close — GitHub + Streamlit Cloud; PASS-WITH-CAVEATS

Keep voice clear. Pause 1 second between screens.
