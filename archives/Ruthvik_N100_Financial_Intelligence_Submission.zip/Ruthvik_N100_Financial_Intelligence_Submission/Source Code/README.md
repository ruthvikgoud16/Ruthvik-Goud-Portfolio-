# Source Code

## Contents

| File | Description |
|---|---|
| `Financial-Intelligence_source.zip` | Full project source (no `venv/`, no `.git/`) |
| `GITHUB_LINK.txt` | Public/private GitHub URL |

## How to run (after unzip)

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
# optional full stack: pip install -r requirements-dev.txt
cp .env.example .env
export PYTHONPATH=.
# DB: copy nifty100.db from Datasets/sqlite/ into project root
streamlit run streamlit_app.py
```

Main dashboard file: `streamlit_app.py`  
Cloud entrypoint: same file on branch `main`
