# PPT / Slides

| File | Description |
|---|---|
| `N100_Financial_Intelligence_Presentation.pptx` | 9-slide pitch deck (widescreen 16:9) |

## Rename on Google Drive (important)

This local folder is named **`PPT - Slides`** because macOS cannot use `/` in folder names.

When you create the folder in Google Drive, name it exactly:

**`PPT / Slides`**

Then upload the `.pptx` into that Drive folder.
