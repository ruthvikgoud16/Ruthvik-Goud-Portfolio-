# Datasets

| Path | Contents |
|---|---|
| `excel/` | 12 Bluestock source workbooks (companies, P&L, BS, CF, …) |
| `sqlite/nifty100.db` | Loaded SQLite database (D-01) used by dashboard/API |
| `generated_outputs/` | Sample analytical CSVs/XLSX (capital allocation, screener, valuation, …) |
| `api_response.json` | Week-2 demo API sample (not a live secret) |

Do not edit Excel files to “fix” financials — they are source of truth.
